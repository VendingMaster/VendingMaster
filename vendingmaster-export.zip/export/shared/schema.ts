import { pgTable, text, serial, integer, boolean, real, jsonb, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Kategorie produktów
export const PRODUCT_CATEGORIES = [
  "Obiady",
  "Śniadania", 
  "Zupy", 
  "Sałatki", 
  "Napoje", 
  "Przekąski"
];

export const productCategorySchema = z.string()
  .min(2, { message: "Nazwa kategorii musi zawierać minimum 2 znaki" })
  .max(30, { message: "Nazwa kategorii nie może przekraczać 30 znaków" });

// Preferencje dietetyczne
export const DIETARY_PREFERENCES = [
  "Klasyk",
  "Wege",
  "Wege z rybką",
  "Zero rybki",
  "Balans",
  "Bez glutenu i nabiału",
  "Niskie IG",
  "Keto",
  "Hashimoto",
  "Dolce Vita",
  "Low Carb",
  "Low Carb wege",
  "Twój mikrobiom"
] as const;

export const dietaryPreferenceSchema = z.enum(DIETARY_PREFERENCES);

// Format karty RFID
export const RFID_CARD_FORMATS = ["decimal", "hex"] as const;
export const rfidCardFormatSchema = z.enum(RFID_CARD_FORMATS);

// Walidacja numeru karty RFID
export const rfidCardNumberSchema = z.string()
  .min(4, { message: "Numer karty RFID musi zawierać minimum 4 znaki" })
  .refine(
    (val) => {
      // Sprawdzenie dla formatu HEX
      const isValidHex = /^[0-9A-Fa-f]+$/.test(val);
      // Sprawdzenie dla formatu DECIMAL
      const isValidDecimal = /^\d+$/.test(val);
      return isValidHex || isValidDecimal;
    },
    { message: "Numer karty RFID musi być w formacie HEX (np. 1A2B3C) lub Decimal (np. 123456)" }
  );

// Schemat do odbioru danych z czujnika temperatury
export const temperatureReadingSchema = z.object({
  temperature: z.number().min(-50).max(100), // Temperatura w °C
  humidity: z.number().min(0).max(100).optional(), // Wilgotność w % (opcjonalna)
  sensorId: z.string().optional(), // Identyfikator czujnika (opcjonalny)
  timestamp: z.string().optional() // Timestamp jako string ISO format (opcjonalny)
});

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

// Stawki VAT
export const VAT_RATES = [
  "23%",
  "8%", 
  "5%", 
  "0%"
] as const;

export const vatRateSchema = z.enum(VAT_RATES);

// Product schema
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  shortDescription: text("shortDescription").notNull(),
  longDescription: text("longDescription").notNull(),
  price: real("price").notNull(),
  purchasePrice: real("purchasePrice"),  // Cena zakupu do obliczania zysków
  category: text("category").notNull().default("Obiady"),
  vatRate: text("vatRate").notNull().default("8%"),  // Domyślna stawka VAT 8% (żywność)
  imageUrl: text("imageUrl").notNull(),
  weight: real("weight"),  // Waga produktu w gramach
  totalCalories: integer("totalCalories"),  // Kaloryczność całej porcji
  ingredients: text("ingredients"),  // Pełny skład produktu
  allergens: text("allergens"),  // Lista alergenów
  nutritionFacts: jsonb("nutritionFacts").notNull(),
  sku: text("sku"),  // SKU (Stock Keeping Unit) - wewnętrzny kod produktu (obowiązkowy)
  ean: text("ean"),   // Kod EAN (opcjonalny)
  dietaryPreferences: jsonb("dietaryPreferences").default([]).notNull(),  // Preferencje dietetyczne (tablica)
  visibleInEmployeePortal: boolean("visible_in_employee_portal").notNull().default(true),  // Widoczność w portalu pracownika
});

// Employee schema
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  firstName: text("firstName").notNull(),
  lastName: text("lastName").notNull(),
  rfidCardNumber: text("rfidCardNumber").unique(),
  rfidCardFormat: text("rfidCardFormat").notNull().default("decimal"), // "decimal" lub "hex"
  email: text("email"),
  passwordHash: text("passwordHash"), // Zahaszowane hasło pracownika
  passwordSalt: text("passwordSalt"), // Sól do hasła
  passwordResetRequired: boolean("passwordResetRequired").default(false), // Czy wymagana jest zmiana hasła
  lastPasswordChange: timestamp("lastPasswordChange"), // Data ostatniej zmiany hasła
  dietaryPreference: text("dietaryPreference"), // Preferencja dietetyczna pracownika
});

// Chamber schema
export const chambers = pgTable("chambers", {
  id: serial("id").primaryKey(),
  productId: integer("productId"),
  employeeId: integer("employeeId"),
  isAvailable: boolean("isAvailable").notNull().default(false)
});

// Typ dla dodatkowych ustawień
export const otherSettingsSchema = z.object({
  inventoryBasedAssignment: z.boolean().optional(),
  // Ustawienia wygaszacza ekranu dla trybu kiosk
  screensaverEnabled: z.boolean().optional(),
  screensaverTimeout: z.number().min(5).max(3600).optional(), // czas w sekundach
  screensaverImageUrl: z.string().optional(),
}).partial();

// Settings schema
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  adminPin: text("adminPin").notNull().default("1308"),
  machineName: text("machineName").notNull().default("Inteligentny Automat"),
  adminLogo: text("adminLogo"), // URL do logotypu panelu administratora
  minTemperature: real("minTemperature").notNull().default(10), // Minimalna bezpieczna temperatura
  maxTemperature: real("maxTemperature").notNull().default(24), // Maksymalna bezpieczna temperatura
  expiringDaysThreshold: integer("expiring_days_threshold").notNull().default(0), // Liczba dni do wygaśnięcia dla produktów "Kończących się termin"
  expiredDaysThreshold: integer("expired_days_threshold").notNull().default(-1), // Liczba dni do wygaśnięcia dla produktów "Przeterminowane" 
  inventoryBasedAssignment: boolean("inventory_based_assignment").notNull().default(false), // Tryb przypisywania produktów do szuflad bazujący na magazynie
  loadingModeRfidCardNumber: text("loading_mode_rfid_card_number"), // Numer karty RFID dla trybu załadunkowego
  maxReservationDays: integer("max_reservation_days").notNull().default(7), // Maksymalna liczba dni do przodu, na które pracownik może zarezerwować posiłek
  firstReservationDays: integer("first_reservation_days").notNull().default(2), // Liczba dni do przodu, po których pracownik może dokonać pierwszej rezerwacji
  autoGenerateMealReservations: boolean("auto_generate_meal_reservations").notNull().default(false), // Automatyczne generowanie rezerwacji posiłków dla pracowników
  employeePortalBackgroundColor: text("employee_portal_background_color").notNull().default("#F7EEE2"), // Kolor tła dla portalu pracownika
  employeePortalButtonColor: text("employee_portal_button_color").notNull().default("#91AD41"), // Kolor przycisków dla portalu pracownika
  screensaverEnabled: boolean("screensaver_enabled").notNull().default(false), // Włączenie/wyłączenie wygaszacza ekranu
  screensaverTimeoutSeconds: integer("screensaver_timeout_seconds").notNull().default(60), // Czas nieaktywności przed uruchomieniem wygaszacza (w sekundach)
  screensaverImageUrl: text("screensaver_image_url"), // URL do obrazu wygaszacza ekranu
  otherSettings: jsonb("otherSettings").notNull().default({})
});

// Kategorie produktów w bazie danych
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  icon: text("icon"), // Ikona kategorii (emoji)
  displayOrder: integer("display_order").default(0), // Kolejność wyświetlania
});

// Odczyty temperatury
export const temperatureReadings = pgTable("temperatureReadings", {
  id: serial("id").primaryKey(),
  temperature: real("temperature").notNull(),
  humidity: real("humidity"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Dostawy
export const deliveries = pgTable("deliveries", {
  id: serial("id").primaryKey(),
  deliveryNumber: text("delivery_number").notNull(), // Numer dostawy (np. D-20250325-001)
  deliveryDate: date("delivery_date").notNull(), // Data dostawy
  notes: text("notes"), // Dodatkowe uwagi do całej dostawy
  createdAt: timestamp("created_at").notNull().defaultNow(), // Data utworzenia wpisu
});

// Elementy dostawy (produkty w dostawie)
export const deliveryItems = pgTable("delivery_items", {
  id: serial("id").primaryKey(),
  deliveryId: integer("delivery_id").notNull().references(() => deliveries.id), // Powiązanie z dostawą
  productId: integer("product_id").notNull().references(() => products.id), // Powiązanie z produktem
  quantity: integer("quantity").notNull(), // Ilość dostarczona
  expiryDate: date("expiry_date").notNull(), // Data ważności
  batchNumber: text("batch_number"), // Numer partii (opcjonalny)
  createdAt: timestamp("created_at").notNull().defaultNow(), // Data utworzenia wpisu
});

// Stan magazynowy produktów
export const inventory = pgTable("inventory", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(), // ID produktu
  quantity: integer("quantity").notNull().default(1), // Ilość sztuk
  expiryDate: date("expiry_date").notNull(), // Data przydatności do spożycia
  batchNumber: text("batch_number"), // Numer partii (opcjonalny)
  addedAt: timestamp("added_at").notNull().defaultNow(), // Data dodania do magazynu
  notes: text("notes"), // Dodatkowe uwagi (opcjonalne)
  deliveryId: integer("delivery_id"), // Referencja do dostawy (opcjonalna)
  disposed: boolean("disposed").notNull().default(false), // Czy produkt został zutylizowany
  disposedAt: timestamp("disposed_at"), // Data utylizacji
  disposedQuantity: integer("disposed_quantity"), // Ilość zutylizowana
  isUsed: boolean("is_used").notNull().default(false), // Czy produkt został rozchodowany
  usedAt: timestamp("used_at"), // Data rozchodu
  usedQuantity: integer("used_quantity"), // Ilość rozchodowana
  usageReason: text("usage_reason"), // Powód rozchodu
});

// Rozchody produktów
export const usages = pgTable("usages", {
  id: serial("id").primaryKey(),
  inventoryId: integer("inventory_id").notNull(), // ID pozycji magazynowej
  productId: integer("product_id").notNull(), // ID produktu
  quantity: integer("quantity").notNull(), // Ilość rozchodowana
  reason: text("reason"), // Powód rozchodu
  usedAt: timestamp("used_at").notNull().defaultNow(), // Data rozchodu
  notes: text("notes"), // Dodatkowe uwagi
  timestamp: timestamp("timestamp").notNull().defaultNow(), // Dokładna data i czas rozchodu
});

// Rezerwacje posiłków przez pracowników
export const mealReservations = pgTable("meal_reservations", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(), // ID pracownika
  productId: integer("product_id").notNull(), // ID produktu
  reservedForDate: date("reserved_for_date").notNull(), // Data na którą zarezerwowano posiłek
  reservedAt: timestamp("reserved_at").notNull().defaultNow(), // Data i czas dokonania rezerwacji
  status: text("status").notNull().default("active"), // Status rezerwacji: active, fulfilled, cancelled
  fulfillmentDate: timestamp("fulfillment_date"), // Data i czas realizacji rezerwacji 
  chamberId: integer("chamber_id"), // ID szuflady użytej do realizacji
  assignmentType: text("assignment_type", { enum: ["manual", "preference", "random"] }), // Sposób przydzielenia produktu
});

// Oceny posiłków przez pracowników
export const mealRatings = pgTable("meal_ratings", {
  id: serial("id").primaryKey(),
  reservationId: integer("reservation_id").notNull(), // ID rezerwacji posiłku
  employeeId: integer("employee_id").notNull(), // ID pracownika
  productId: integer("product_id").notNull(), // ID produktu
  rating: integer("rating").notNull(), // Ocena od 1 do 5
  comment: text("comment"), // Komentarz do oceny (opcjonalny)
  createdAt: timestamp("created_at").notNull().defaultNow(), // Data i czas wystawienia oceny
});

// Harmonogram pracy pracowników - dni, w których pracownik jest w pracy
export const employeeWorkDays = pgTable("employee_work_days", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(), // ID pracownika
  workDate: date("work_date").notNull(), // Data pracy
  createdAt: timestamp("created_at").notNull().defaultNow(), // Data i czas dodania dnia pracy
});

// Usunięte dni pracy pracowników - dni, w których pracownik nie pracuje (szczególnie przyszłe daty)
export const employeeNonWorkDays = pgTable("employee_non_work_days", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(), // ID pracownika
  workDate: date("work_date").notNull(), // Data wolna od pracy
  createdAt: timestamp("created_at").notNull().defaultNow(), // Data i czas usunięcia dnia pracy
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const nutritionFactsSchema = z.object({
  energyValue: z.number(),
  fat: z.number(),
  saturatedFat: z.number(),
  carbs: z.number(),
  sugars: z.number(),
  protein: z.number(),
  salt: z.number()
});

export const insertProductSchema = createInsertSchema(products).extend({
  nutritionFacts: nutritionFactsSchema,
  category: productCategorySchema,
  vatRate: vatRateSchema,
  sku: z.string().min(1, { message: "SKU jest wymagane" }),
  ean: z.string().optional().or(z.literal('')),
  dietaryPreferences: z.array(dietaryPreferenceSchema).default([])
});

// Typy statusów produktów w magazynie
export const INVENTORY_STATUS = ["active", "expiring", "expired"] as const;
export const inventoryStatusSchema = z.enum(INVENTORY_STATUS);
export type InventoryStatus = z.infer<typeof inventoryStatusSchema>;

// Typy powodów użycia/rozchodu produktów
export const USAGE_REASONS = [
  "drawer_assignment", // Przypisanie do szuflady
  "manual_usage",      // Ręczny rozchód (np. wydanie pracownikowi)
  "disposal",          // Utylizacja (np. przeterminowanie)
  "other"              // Inne powody
] as const;
export const usageReasonSchema = z.enum(USAGE_REASONS);
export type UsageReason = z.infer<typeof usageReasonSchema>;

// Schemat dla operacji na hasłach
export const passwordSchema = z.object({
  password: z.string().min(6, { message: "Hasło musi mieć co najmniej 6 znaków" }),
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Hasła nie są zgodne",
  path: ["confirmPassword"]
});

// Schemat dla zmiany hasła 
export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, { message: "Aktualne hasło jest wymagane" }),
  password: z.string().min(6, { message: "Hasło musi mieć co najmniej 6 znaków" }),
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Hasła nie są zgodne",
  path: ["confirmPassword"]
});

// Schemat dla dodawania/edycji pracownika
export const insertEmployeeSchema = createInsertSchema(employees).omit({
  passwordHash: true,
  passwordSalt: true,
  passwordResetRequired: true,
  lastPasswordChange: true
}).extend({
  rfidCardNumber: rfidCardNumberSchema.optional().nullable(),
  rfidCardFormat: rfidCardFormatSchema,
  email: z.string().email({ message: "Niepoprawny format adresu email" }).optional().or(z.literal('')),
  dietaryPreference: dietaryPreferenceSchema.optional().nullable(),
  password: z.string().min(6, { message: "Hasło musi mieć co najmniej 6 znaków" }).optional(),
  confirmPassword: z.string().optional(),
}).refine(data => {
  // Jeśli password jest ustawione, to confirmPassword też musi być ustawione i zgodne
  if (data.password) {
    return data.confirmPassword === data.password;
  }
  return true;
}, {
  message: "Hasła nie są zgodne",
  path: ["confirmPassword"]
});

export const insertChamberSchema = createInsertSchema(chambers);

export const insertSettingsSchema = createInsertSchema(settings).extend({
  loadingModeRfidCardNumber: z.string().optional().nullable(),
  employeePortalBackgroundColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, { 
    message: "Kolor tła musi być w formacie HEX (np. #F7EEE2)" 
  }),
  employeePortalButtonColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, { 
    message: "Kolor przycisków musi być w formacie HEX (np. #91AD41)" 
  }),
  screensaverEnabled: z.boolean().optional().default(false),
  screensaverTimeoutSeconds: z.number().min(10).max(300).optional().default(60),
  screensaverImageUrl: z.string().optional().nullable(),
});

export const insertCategorySchema = createInsertSchema(categories).extend({
  displayOrder: z.number().min(0).default(0),
});

export const insertTemperatureReadingSchema = createInsertSchema(temperatureReadings).omit({
  id: true,
  timestamp: true
});

// Schemat dla elementów dostawy
export const insertDeliveryItemSchema = createInsertSchema(deliveryItems).omit({
  id: true,
  createdAt: true
}).extend({
  expiryDate: z.coerce.date().transform(date => date.toISOString().split('T')[0])
});

export const insertDeliverySchema = createInsertSchema(deliveries).omit({
  id: true,
  createdAt: true
}).extend({
  deliveryDate: z.coerce.date().transform(date => date.toISOString().split('T')[0]),
  items: z.array(insertDeliveryItemSchema.omit({ deliveryId: true }))
});

export const insertInventorySchema = createInsertSchema(inventory, {
  expiryDate: z.string().min(1)
}).omit({
  id: true,
  addedAt: true
}).extend({
  expiryDate: z.coerce.date().refine(
    (date) => {
      // Zezwalamy na daty wstecz o jeden dzień
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      yesterday.setHours(0, 0, 0, 0);
      return date >= yesterday;
    }, 
    { message: "Data przydatności może być tylko wczorajsza lub późniejsza (dla celów testowych)" }
  ).transform(date => date.toISOString().split('T')[0]),
  deliveryId: z.number().optional().nullable()
});

export const insertUsageSchema = createInsertSchema(usages).omit({
  id: true,
  usedAt: true,
  timestamp: true
}).extend({
  reason: usageReasonSchema.default("manual_usage"),
  notes: z.string().optional()
});

export const insertMealReservationSchema = createInsertSchema(mealReservations).omit({
  id: true,
  reservedAt: true,
  status: true,
  fulfillmentDate: true
}).extend({
  reservedForDate: z.coerce.date().transform(date => date.toISOString().split('T')[0]),
  assignmentType: z.enum(['manual', 'preference', 'random']).optional()
});

export const insertMealRatingSchema = createInsertSchema(mealRatings).omit({
  id: true,
  createdAt: true
}).extend({
  rating: z.number().min(1).max(5)
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;

export type InsertChamber = z.infer<typeof insertChamberSchema>;
export type Chamber = typeof chambers.$inferSelect;

export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settings.$inferSelect;
export type OtherSettings = z.infer<typeof otherSettingsSchema>;

export type NutritionFacts = z.infer<typeof nutritionFactsSchema>;
export type ProductCategory = z.infer<typeof productCategorySchema>;
export type TemperatureReading = z.infer<typeof temperatureReadingSchema>;
export type InsertTemperatureReading = z.infer<typeof insertTemperatureReadingSchema>;
export type TemperatureReadingDB = typeof temperatureReadings.$inferSelect;
export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;
export type DietaryPreference = z.infer<typeof dietaryPreferenceSchema>;
export type InsertDeliveryItem = z.infer<typeof insertDeliveryItemSchema>;
export type DeliveryItem = typeof deliveryItems.$inferSelect;
export type InsertDelivery = z.infer<typeof insertDeliverySchema>;

// Rozszerzony typ DeliveryItem z dodatkowymi polami
export type ExtendedDeliveryItem = Omit<InsertDeliveryItem, 'deliveryId'> & {
  productName?: string;
  status?: string; // Dostępny, Zutylizowany, Użyty, Częściowo użyty, Częściowo zutylizowany
};

export type Delivery = typeof deliveries.$inferSelect & { 
  items?: ExtendedDeliveryItem[]
};
export type InsertInventory = z.infer<typeof insertInventorySchema>;
export type Inventory = typeof inventory.$inferSelect;
export type InsertUsage = z.infer<typeof insertUsageSchema>;
export type Usage = typeof usages.$inferSelect;
export type InsertMealReservation = z.infer<typeof insertMealReservationSchema>;
export type MealReservation = typeof mealReservations.$inferSelect & {
  productName?: string;
  productImage?: string;
  shortDescription?: string;
  weight?: number;
  calories?: number;
  hasRating?: boolean; // Czy posiłek został już oceniony
};

export type InsertMealRating = z.infer<typeof insertMealRatingSchema>;
export type MealRating = typeof mealRatings.$inferSelect;

// Schemat dla dni pracy pracownika
export const insertEmployeeWorkDaySchema = createInsertSchema(employeeWorkDays).omit({
  id: true,
  createdAt: true
}).extend({
  workDate: z.coerce.date().transform(date => date.toISOString().split('T')[0])
});

export type InsertEmployeeWorkDay = z.infer<typeof insertEmployeeWorkDaySchema>;
export type EmployeeWorkDay = typeof employeeWorkDays.$inferSelect;

// Schemat dla dni wolnych pracownika
export const insertEmployeeNonWorkDaySchema = createInsertSchema(employeeNonWorkDays).omit({
  id: true,
  createdAt: true
}).extend({
  workDate: z.coerce.date().transform(date => date.toISOString().split('T')[0])
});

export type InsertEmployeeNonWorkDay = z.infer<typeof insertEmployeeNonWorkDaySchema>;
export type EmployeeNonWorkDay = typeof employeeNonWorkDays.$inferSelect;

// Typy dla operacji na hasłach
export type Password = z.infer<typeof passwordSchema>;
export type ChangePassword = z.infer<typeof changePasswordSchema>;
