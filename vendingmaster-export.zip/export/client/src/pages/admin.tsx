import React from 'react';
import { AdminPanel } from '@/components/vending-machine/AdminPanel';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { LogOut } from 'lucide-react';

export default function Admin() {
  const [_, setLocation] = useLocation();
  
  const handleLogout = () => {
    localStorage.removeItem('adminAuth');
    setLocation('/admin-login');
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      {/* Nagłówek */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="bg-blue-50 p-2 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z" />
                <line x1="3" y1="6" x2="21" y2="6" />
                <path d="M16 10a4 4 0 0 1-8 0" />
              </svg>
            </div>
            <h1 className="text-xl font-semibold flex items-center">
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent font-bold">
                IQSTORE
              </span>
              <span className="mx-1">-</span>
              <span className="text-gray-800">Panel Administracyjny</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-2 text-yellow-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
              </svg>
            </h1>
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              onClick={handleLogout}
              variant="ghost"
              className="text-gray-600"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Wyloguj
            </Button>
            <Button 
              onClick={() => setLocation('/')}
              variant="outline"
            >
              TRYB KIOSK
            </Button>
          </div>
        </div>
      </header>
      
      {/* Główna zawartość */}
      <main className="flex-grow">
        <AdminPanel />
      </main>
      
      {/* Footer */}
      <footer className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 mt-8 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 className="text-lg font-bold">IQSTORE</h3>
              <p className="text-sm opacity-80">System zarządzania automatem żywieniowym</p>
            </div>
            <div className="flex flex-col md:flex-row md:space-x-8 text-sm">
              <div className="mb-2 md:mb-0">
                <p className="font-semibold">Kontakt</p>
                <p>support@iqstore.pl</p>
              </div>
              <div>
                <p className="font-semibold">Wersja oprogramowania</p>
                <p>v1.2.12 &copy; {new Date().getFullYear()}</p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}