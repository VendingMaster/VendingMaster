import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import { Settings } from '@shared/schema';

const AdminLogin: React.FC = () => {
  const [pin, setPin] = useState('');
  const [machineName, setMachineName] = useState('');
  const [_, setLocation] = useLocation();
  const { toast } = useToast();

  // Pobierz ustawienia, aby zweryfikować dane logowania
  const { data: settings } = useQuery<Settings>({
    queryKey: ['/api/settings'],
    refetchOnWindowFocus: false
  });

  const handleLogin = () => {
    // Sprawdź, czy PIN i nazwa automatu są zgodne z ustawieniami
    if (settings && pin === settings.adminPin && machineName === settings.machineName) {
      // Logowanie udane - przejdź do panelu administratora
      localStorage.setItem('adminAuth', 'true'); // Prosta flaga autoryzacji
      setLocation('/admin');
    } else {
      // Logowanie nieudane - wyświetl komunikat o błędzie
      toast({
        title: 'Błąd logowania',
        description: 'Niepoprawny PIN lub nazwa automatu.',
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-1">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-blue-50 p-3 rounded-lg">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-5 0v-15A2.5 2.5 0 0 1 9.5 2Z"></path>
                <path d="M14.5 4A2.5 2.5 0 0 1 17 6.5v11a2.5 2.5 0 0 1-5 0v-11A2.5 2.5 0 0 1 14.5 4Z"></path>
                <path d="M4.5 8A2.5 2.5 0 0 1 7 10.5v7a2.5 2.5 0 0 1-5 0v-7A2.5 2.5 0 0 1 4.5 8Z"></path>
                <path d="M19.5 5A2.5 2.5 0 0 1 22 7.5v9a2.5 2.5 0 0 1-5 0v-9A2.5 2.5 0 0 1 19.5 5Z"></path>
              </svg>
            </div>
          </div>
          <CardTitle className="text-2xl text-center font-bold">Panel Administracyjny</CardTitle>
          <CardDescription className="text-center">
            Wprowadź nazwę automatu oraz PIN administratora, aby się zalogować
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="machine-name">Nazwa automatu</Label>
            <Input
              id="machine-name"
              type="text"
              value={machineName}
              onChange={(e) => setMachineName(e.target.value)}
              placeholder="Wprowadź nazwę automatu"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="admin-pin">PIN administratora</Label>
            <Input
              id="admin-pin"
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Wprowadź PIN administratora"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleLogin();
                }
              }}
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={() => setLocation('/')}>
            Powrót do trybu kiosk
          </Button>
          <Button onClick={handleLogin}>
            Zaloguj
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default AdminLogin;