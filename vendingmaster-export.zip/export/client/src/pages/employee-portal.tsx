import { EmployeePortal } from "@/components/vending-machine/EmployeePortal";

export default function EmployeePortalPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted">
      <EmployeePortal />
    </div>
  );
}