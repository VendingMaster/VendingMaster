import { KioskApp } from "@/components/vending-machine/KioskApp";

export default function Home() {
  return (
    <div className="min-h-screen">
      <KioskApp />
    </div>
  );
}
