import { useContext } from "react";
import { PortalContext, PortalContextType } from "@/components/vending-machine/EmployeePortal";

export const usePortalContext = (): PortalContextType => {
  const context = useContext(PortalContext);
  
  if (!context) {
    throw new Error("usePortalContext must be used within a PortalContextProvider");
  }
  
  return context;
};