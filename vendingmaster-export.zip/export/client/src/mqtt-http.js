/**
 * mqtt-http.js - Uproszczona implementacja MQTT przez HTTP
 * 
 * Ten skrypt wykorzystuje interfejs HTTP do wysyłania komend MQTT,
 * co pozwala na obejście ograniczeń związanych z WebSocket w przeglądarkach.
 */

(function() {
  console.log("MQTT HTTP: System gotowy do wysyłania komend");
  
  /**
   * Wysyła komendę MQTT za pomocą HTTP POST
   * @param {string} topic - temat MQTT
   * @param {string} message - wiadomość do wysłania
   * @returns {Promise<boolean>} - Promise zwracający true po pomyślnym wysłaniu
   */
  async function sendMqttViaHttp(topic, message) {
    try {
      console.log(`MQTT HTTP: Wysyłanie do tematu ${topic}: "${message}"`);
      
      // Utworzenie formularza do wysłania
      const formData = new FormData();
      formData.append('topic', topic);
      formData.append('message', message);
      formData.append('qos', '0');
      
      // Wysłanie żądania do serwera MQTT przez interfejs HTTP
      const response = await fetch('https://test.mosquitto.org/mqtt/publish', {
        method: 'POST',
        body: formData,
        mode: 'no-cors' // Musimy użyć no-cors ze względu na ograniczenia CORS
      });
      
      console.log(`✅ MQTT HTTP: Wysłano komendę MQTT`);
      return true;
    } catch (error) {
      console.error(`❌ MQTT HTTP: Błąd podczas wysyłania: ${error.message}`);
      return false;
    }
  }
  
  /**
   * Wysyła komendę otwarcia szuflady
   * @param {number} drawerNumber - numer szuflady do otwarcia (1-48)
   * @returns {Promise<boolean>} - Promise rozwiązywany po wysłaniu wiadomości
   */
  async function sendDrawerCommand(drawerNumber) {
    if (!drawerNumber || drawerNumber < 1 || drawerNumber > 48) {
      console.error(`❌ MQTT HTTP: Nieprawidłowy numer szuflady: ${drawerNumber}`);
      return false;
    }
    
    // Konwersja na surowy numer szuflady (bez formatowania) zgodnie z wymaganiami
    const rawDrawerNumber = parseInt(drawerNumber, 10).toString();
    console.log(`MQTT HTTP: Wysyłanie numeru szuflady: "${rawDrawerNumber}"`);
    
    try {
      // Wysyłamy komendę przez HTTP
      const result = await sendMqttViaHttp('/szuflada/otworz', rawDrawerNumber);
      
      if (result) {
        console.log(`✅ MQTT HTTP: Wysłano komendę otwarcia szuflady ${drawerNumber}`);
        return true;
      } else {
        // Próbujemy alternatywnej metody przez API
        try {
          const response = await fetch('/api/mqtt/drawer', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ drawerNumber: parseInt(drawerNumber, 10) })
          });
          
          if (response.ok) {
            console.log(`✅ MQTT HTTP: Wysłano komendę otwarcia szuflady ${drawerNumber} przez API`);
            return true;
          }
        } catch (apiError) {
          console.error(`❌ MQTT HTTP API: Błąd podczas wysyłania: ${apiError.message}`);
        }
      }
      
      return false;
    } catch (error) {
      console.error(`❌ MQTT HTTP: Błąd podczas wysyłania komendy szuflady: ${error.message}`);
      return false;
    }
  }
  
  // Eksportujemy funkcje do globalnego obiektu window
  window.sendMqttDrawerCommand = sendDrawerCommand;
})();