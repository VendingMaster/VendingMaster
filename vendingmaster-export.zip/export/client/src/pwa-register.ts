// Rejestracja Service Workera
export function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js')
        .then((registration) => {
          console.log('Service Worker zarejestrowany pomyślnie:', registration.scope);
          
          // Aktualizacja service workera, jeśli jest dostępna nowa wersja
          registration.addEventListener('updatefound', () => {
            // Nowy service worker został znaleziony i jest instalowany
            const newWorker = registration.installing;
            if (newWorker) {
              newWorker.addEventListener('statechange', () => {
                // Komunikat dla użytkownika o dostępności aktualizacji
                if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                  console.log('Nowa wersja aplikacji jest dostępna! Odśwież, aby zaktualizować.');
                  // Tutaj możesz dodać powiadomienie dla użytkownika
                }
              });
            }
          });
        })
        .catch((error) => {
          console.error('Błąd rejestracji Service Workera:', error);
        });
      
      // Obsługa komunikacji z Service Workerem
      navigator.serviceWorker.addEventListener('message', (event) => {
        console.log('Wiadomość od Service Workera:', event.data);
      });
    });
  }
  
  // Wykrywanie, czy aplikacja działa jako aplikacja PWA
  detectPwaMode();
}

// Wykrywanie trybu PWA
function detectPwaMode() {
  // Wykrywanie, czy aplikacja działa w trybie PWA
  if (window.matchMedia('(display-mode: standalone)').matches || window.matchMedia('(display-mode: fullscreen)').matches) {
    console.log('Aplikacja działa w trybie PWA');
    document.body.classList.add('pwa-mode');
    // Dodanie atrybutu dla stylowania CSS
    document.documentElement.setAttribute('data-pwa-mode', 'true');
  }
  
  // Nasłuchiwanie na zmiany trybu wyświetlania
  window.matchMedia('(display-mode: standalone)').addEventListener('change', (e) => {
    if (e.matches) {
      console.log('Aplikacja przełączyła się do trybu PWA');
      document.body.classList.add('pwa-mode');
      document.documentElement.setAttribute('data-pwa-mode', 'true');
    } else {
      console.log('Aplikacja nie jest już w trybie PWA');
      document.body.classList.remove('pwa-mode');
      document.documentElement.setAttribute('data-pwa-mode', 'false');
    }
  });
  
  // Nasłuchiwanie również na tryb fullscreen
  window.matchMedia('(display-mode: fullscreen)').addEventListener('change', (e) => {
    if (e.matches) {
      console.log('Aplikacja przełączyła się do trybu pełnoekranowego');
      document.body.classList.add('pwa-mode', 'fullscreen-mode');
      document.documentElement.setAttribute('data-pwa-mode', 'true');
    } else {
      document.body.classList.remove('fullscreen-mode');
    }
  });
}

// Sprawdzanie, czy PWA może być zainstalowana
export function checkPwaInstallable() {
  let deferredPrompt: any = null;

  // Wykrywanie, czy aplikacja może być zainstalowana na urządzeniu
  window.addEventListener('beforeinstallprompt', (e) => {
    // Zapobieganie automatycznemu pokazaniu komunikatu o instalacji
    e.preventDefault();
    // Przechowanie zdarzenia, aby pokazać je później
    deferredPrompt = e;
    // Informacja w konsoli
    console.log('Aplikacja może być zainstalowana jako PWA');
    // Pokazanie przycisku do instalacji
    showInstallPromotion();
  });

  // Wykrywanie, czy aplikacja została zainstalowana
  window.addEventListener('appinstalled', () => {
    console.log('Aplikacja została zainstalowana jako PWA');
    // Ukrycie przycisku instalacji
    const installButton = document.getElementById('pwa-install-button');
    if (installButton) {
      installButton.style.display = 'none';
    }
    // Wyczyszczenie referencji do zdarzenia promptu
    deferredPrompt = null;
  });

  function showInstallPromotion() {
    // Tutaj możesz dodać kod, który pokaże przycisk lub komunikat o możliwości instalacji
    const installButton = document.getElementById('pwa-install-button');
    if (installButton) {
      installButton.style.display = 'block';
      installButton.addEventListener('click', () => {
        if (deferredPrompt) {
          // Pokazanie komunikatu o instalacji
          deferredPrompt.prompt();
          // Czekaj na wybór użytkownika
          deferredPrompt.userChoice.then((choiceResult: { outcome: string }) => {
            if (choiceResult.outcome === 'accepted') {
              console.log('Użytkownik zaakceptował instalację PWA');
            } else {
              console.log('Użytkownik odrzucił instalację PWA');
            }
            deferredPrompt = null;
          });
        }
      });
    }
  }
}