import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { registerServiceWorker, checkPwaInstallable } from "./pwa-register";

// Funkcja inicjalizująca obsługę historii przeglądania
function initializeHistory() {
  // Inicjalizacja stanu historii dla przycisku powrotu
  if (!window.history.state) {
    // Gdy nie ma stanu historii, inicjalizujemy go z aktualną ścieżką
    const initialPath = window.location.pathname + window.location.search;
    window.history.replaceState(
      { 
        path: initialPath,
        timestamp: Date.now(), 
        scrollPosition: 0 
      }, 
      '', 
      initialPath
    );
    
    console.log('Inicjalizacja historii przeglądania:', initialPath);
  }
  
  // Obsługa przycisku powrotu (event popstate)
  window.addEventListener('popstate', (event) => {
    console.log('Nawigacja w historii:', event.state);
    
    // Jeśli nie ma stanu, znaczy że prawdopodobnie użytkownik wrócił do początkowej strony
    if (!event.state) {
      console.log('Brak stanu historii, prawdopodobnie początkowa strona');
      return;
    }
    
    // Odtwarzamy pozycję przewijania
    if (event.state.scrollPosition) {
      setTimeout(() => {
        window.scrollTo(0, event.state.scrollPosition);
      }, 100);
    }
    
    // Jeśli jesteśmy w aplikacji PWA, możemy wstrzyknąć odpowiednie wydarzenie
    // dla komponentu, który obsługuje nawigację wewnątrz aplikacji
    const navigationEvent = new CustomEvent('app-navigation', { 
      detail: { 
        path: event.state.path,
        isBackNavigation: true
      } 
    });
    window.dispatchEvent(navigationEvent);
  });
}

// Rejestracja Service Workera dla PWA
registerServiceWorker();

// Sprawdzenie możliwości instalacji PWA
checkPwaInstallable();

// Inicjalizacja obsługi historii przeglądania
initializeHistory();

// Renderowanie aplikacji
createRoot(document.getElementById("root")!).render(<App />);
