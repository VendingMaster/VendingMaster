import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom';
import { Button } from './button';

/**
 * Modal - komponent modalnego okna dialogowego
 */
interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
}

export function Modal({ isOpen, onClose, title, children, footer }: ModalProps) {
  const [modalRoot, setModalRoot] = useState<HTMLElement | null>(null);

  useEffect(() => {
    // Sprawdź czy element #modal-root istnieje
    let root = document.getElementById('modal-root');
    
    // Jeśli nie istnieje, utwórz go
    if (!root) {
      root = document.createElement('div');
      root.id = 'modal-root';
      document.body.appendChild(root);
      
      // Dodaj link do arkusza stylów
      const linkElement = document.createElement('link');
      linkElement.rel = 'stylesheet';
      linkElement.href = '/modal-fix.css';
      document.head.appendChild(linkElement);
    }
    
    setModalRoot(root);
    
    return () => {
      // Nie usuwamy elementu modal-root podczas odmontowywania komponentu,
      // ponieważ może być używany przez inne modalne okna
    };
  }, []);
  
  // Blokuj przewijanie, gdy modal jest otwarty
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);
  
  // Obsługa zamknięcia modala przez klawisz ESC
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    
    if (isOpen) {
      window.addEventListener('keydown', handleEsc);
    }
    
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [isOpen, onClose]);
  
  if (!isOpen || !modalRoot) return null;

  return ReactDOM.createPortal(
    <div className="modal-overlay" onClick={(e) => {
      // Zamykaj modal tylko gdy kliknięto bezpośrednio na overlay, nie na jego zawartość
      if (e.target === e.currentTarget) {
        onClose();
      }
    }}>
      <div className="modal-content">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">{title}</h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="mb-6">
          {children}
        </div>
        
        {footer ? (
          <div className="mt-6 flex justify-end gap-3">
            {footer}
          </div>
        ) : (
          <div className="mt-6 flex justify-end">
            <Button onClick={onClose}>
              Zamknij
            </Button>
          </div>
        )}
      </div>
    </div>,
    modalRoot
  );
}