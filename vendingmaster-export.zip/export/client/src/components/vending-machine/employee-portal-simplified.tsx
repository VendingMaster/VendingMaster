import { useState } from "react";
import { Brain, LogOut, Menu, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Toaster } from "@/components/ui/toaster";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ProductSelection } from "./employee-portal/ProductSelection";
import { MealHistory } from "./employee-portal/MealHistory";
import { Profile } from "./employee-portal/Profile";
import { Employee } from "@shared/schema";

export const EmployeePortal = () => {
  const { toast } = useToast();
  const [loginMethod, setLoginMethod] = useState<"rfid" | "email">("rfid");
  const [rfidInput, setRfidInput] = useState("");
  const [emailInput, setEmailInput] = useState("");
  const [passwordInput, setPasswordInput] = useState("");
  const [authenticated, setAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState("products");
  
  // Tworzenie hardkodowanego pracownika na potrzeby testów
  const sampleEmployee = {
    id: 1,
    firstName: "Jan",
    lastName: "Kowalski",
    email: "jan.kowalski@example.com",
    rfidCardNumber: "123456789",
    rfidCardFormat: "decimal",
    dietaryPreference: null
  } as Employee;
  
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null);

  const authenticateWithRfid = async () => {
    try {
      console.log(`Próba logowania przez RFID: ${rfidInput}`);
      
      if (!rfidInput) {
        toast({
          title: "Brak numeru karty",
          description: "Wprowadź numer karty RFID",
          variant: "destructive",
        });
        return;
      }

      // Uproszczone uwierzytelnianie - akceptuje dowolny numer karty
      setRfidInput("");
      setCurrentEmployee(sampleEmployee);
      setAuthenticated(true);
      toast({
        title: "Zalogowano pomyślnie",
        description: `Witaj, ${sampleEmployee.firstName} ${sampleEmployee.lastName}!`,
      });
    } catch (error) {
      console.error("RFID authentication error:", error);
      toast({
        title: "Błąd połączenia",
        description: "Wystąpił problem z połączeniem do serwera.",
        variant: "destructive",
      });
    }
  };

  const authenticateWithEmail = async () => {
    try {
      console.log(`Próba logowania przez email: ${emailInput}`);
      
      if (!emailInput || !passwordInput) {
        toast({
          title: "Wypełnij wszystkie pola",
          description: "Email i hasło są wymagane",
          variant: "destructive",
        });
        return;
      }

      // Uproszczone uwierzytelnianie - akceptuje dowolny email z hasłem "1308"
      if (passwordInput === "1308") {
        setEmailInput("");
        setPasswordInput("");
        setCurrentEmployee(sampleEmployee);
        setAuthenticated(true);
        toast({
          title: "Zalogowano pomyślnie",
          description: `Witaj, ${sampleEmployee.firstName} ${sampleEmployee.lastName}!`,
        });
      } else {
        toast({
          title: "Błąd logowania",
          description: "Nieprawidłowy email lub hasło.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Authentication error:", error);
      toast({
        title: "Błąd połączenia",
        description: "Wystąpił problem z połączeniem do serwera.",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    setAuthenticated(false);
    setCurrentEmployee(null);
    toast({
      title: "Wylogowano",
      description: "Zostałeś wylogowany z systemu.",
    });
  };

  return (
    <div className="flex flex-col min-h-screen">
      {/* Nagłówek */}
      <header className="sticky top-0 z-10 border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 max-w-screen-2xl items-center">
          <div className="flex items-center mr-4">
            <Brain className="w-6 h-6 mr-2 text-primary" />
            <span className="font-bold bg-gradient-to-r from-primary to-primary-foreground bg-clip-text text-transparent">
              IQSTORE
            </span>
            <span className="ml-2 text-sm text-muted-foreground">
              Portal pracownika
            </span>
          </div>

          <div className="flex flex-1 items-center justify-end space-x-4">
            {authenticated && currentEmployee && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col h-full">
                    <div className="flex-1">
                      <div className="flex items-center space-x-4 pb-6">
                        <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
                          <User className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-medium">{currentEmployee.firstName} {currentEmployee.lastName}</p>
                          <p className="text-sm text-muted-foreground">{currentEmployee.email || "-"}</p>
                        </div>
                      </div>
                      <nav className="grid gap-2">
                        <Button variant="ghost" className="justify-start" onClick={() => setActiveTab("products")}>
                          Wybór posiłków
                        </Button>
                        <Button variant="ghost" className="justify-start" onClick={() => setActiveTab("history")}>
                          Historia posiłków
                        </Button>
                        <Button variant="ghost" className="justify-start" onClick={() => setActiveTab("profile")}>
                          Mój profil
                        </Button>
                      </nav>
                    </div>
                    <div className="border-t pt-4">
                      <Button variant="outline" className="w-full" onClick={handleLogout}>
                        <LogOut className="mr-2 h-4 w-4" />
                        Wyloguj
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </div>
      </header>

      {/* Główna treść */}
      <main className="flex-1 container py-6">
        {authenticated && currentEmployee ? (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="products">Wybór posiłków</TabsTrigger>
              <TabsTrigger value="history">Historia</TabsTrigger>
              <TabsTrigger value="profile">Mój profil</TabsTrigger>
            </TabsList>
            
            <TabsContent value="products" className="space-y-4">
              <ScrollArea className="h-[calc(100vh-180px)]">
                <ProductSelection employee={currentEmployee} />
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="history" className="space-y-4">
              <ScrollArea className="h-[calc(100vh-180px)]">
                <MealHistory employee={currentEmployee} />
              </ScrollArea>
            </TabsContent>
            
            <TabsContent value="profile" className="space-y-4">
              <ScrollArea className="h-[calc(100vh-180px)]">
                <Profile employee={currentEmployee} />
              </ScrollArea>
            </TabsContent>
          </Tabs>
        ) : (
          <Card className="w-full max-w-md mx-auto mt-20">
            <CardHeader>
              <CardTitle className="text-center">Logowanie pracownika</CardTitle>
              <CardDescription className="text-center">
                Zaloguj się do portalu pracownika
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs 
                value={loginMethod} 
                onValueChange={(value) => setLoginMethod(value as "rfid" | "email")}
                className="w-full"
              >
                <TabsList className="grid w-full grid-cols-2 mb-4">
                  <TabsTrigger value="rfid">Karta RFID</TabsTrigger>
                  <TabsTrigger value="email">Email i hasło</TabsTrigger>
                </TabsList>
                
                <TabsContent value="rfid" className="space-y-4">
                  <div className="space-y-2">
                    <Input
                      type="text"
                      placeholder="Numer karty RFID"
                      value={rfidInput}
                      onChange={(e) => setRfidInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          authenticateWithRfid();
                        }
                      }}
                    />
                    <div className="text-center mt-4">
                      <Button
                        className="w-full"
                        onClick={authenticateWithRfid}
                      >
                        Zaloguj się kartą
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="email" className="space-y-4">
                  <div className="space-y-2">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="twoj.email@firma.pl"
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Hasło</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="••••••••"
                        value={passwordInput}
                        onChange={(e) => setPasswordInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            authenticateWithEmail();
                          }
                        }}
                      />
                    </div>
                    <div className="text-center mt-4">
                      <Button
                        className="w-full"
                        onClick={authenticateWithEmail}
                      >
                        Zaloguj się
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
            <CardFooter className="flex flex-col space-y-2">
              <div className="text-center text-sm text-muted-foreground">
                <p>Hasło tymczasowe dla wszystkich pracowników: 1308</p>
              </div>
            </CardFooter>
          </Card>
        )}
      </main>

      {/* Stopka */}
      <footer className="py-6 md:px-8 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-14 md:flex-row">
          <p className="text-center text-sm leading-loose text-muted-foreground">
            IQSTORE &copy; {new Date().getFullYear()} Benefit żywieniowy / automatyczna kantyna v1.2.12
          </p>
        </div>
      </footer>

      <Toaster />
    </div>
  );
};