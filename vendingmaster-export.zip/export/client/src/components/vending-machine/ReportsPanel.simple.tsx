import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Dane przykładowe dla celów demonstracyjnych
const dailySalesData = [
  { date: '14/03', Dania: 12, Sałatki: 8, Zupy: 5, Przekąski: 15, total: 40 },
  { date: '15/03', Dania: 15, Sałatki: 10, Zupy: 7, Przekąski: 8, total: 40 },
  { date: '16/03', Dania: 8, Sałatki: 14, Zupy: 6, Przekąski: 10, total: 38 },
  { date: '17/03', Dania: 10, Sałatki: 12, Zupy: 8, Przekąski: 5, total: 35 },
  { date: '18/03', Dania: 16, Sałatki: 7, Zupy: 4, Przekąski: 6, total: 33 },
  { date: '19/03', Dania: 18, Sałatki: 9, Zupy: 6, Przekąski: 12, total: 45 },
  { date: '20/03', Dania: 14, Sałatki: 11, Zupy: 8, Przekąski: 14, total: 47 },
];

// Funkcja pomocnicza do formatowania walut
function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pl-PL', { style: 'currency', currency: 'PLN' }).format(value);
}

const StatCard = ({ title, value, subtitle, trend }: { title: string, value: string, subtitle: string, trend: string }) => (
  <Card>
    <CardContent className="p-4">
      <div className="flex flex-col space-y-1.5">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <div className="flex items-baseline">
          <span className="text-2xl font-bold">{value}</span>
          {trend && (
            <span className={`ml-2 text-xs font-medium ${trend.startsWith('+') ? 'text-green-600' : trend.startsWith('-') ? 'text-red-600' : ''}`}>
              {trend}
            </span>
          )}
        </div>
        <p className="text-xs text-gray-500">{subtitle}</p>
      </div>
    </CardContent>
  </Card>
);

export const ReportsPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState('sales');

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-800">Raporty i Analizy</h3>
          <p className="text-gray-600 mt-1">
            Kompleksowe raporty sprzedaży i rezerwacji pracowników
          </p>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full">
          <TabsTrigger value="sales" className="flex-1">Sprzedaż</TabsTrigger>
          <TabsTrigger value="employees" className="flex-1">Rezerwacje pracowników</TabsTrigger>
        </TabsList>
        
        {/* TAB: Raporty sprzedaży */}
        <TabsContent value="sales" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard 
              title="Całkowita sprzedaż" 
              value={formatCurrency(15480)} 
              subtitle="W bieżącym miesiącu" 
              trend="+12.5%" 
            />
            <StatCard 
              title="Średnio dziennie" 
              value={formatCurrency(516)} 
              subtitle="Produktów" 
              trend="+4.3%" 
            />
            <StatCard 
              title="Najpopularniejszy produkt" 
              value="Devolaille" 
              subtitle="152 sprzedanych" 
              trend="+18.2%" 
            />
            <StatCard 
              title="Najlepsza godzina" 
              value="12:00 - 13:00" 
              subtitle="125 transakcji" 
              trend="" 
            />
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Sprzedaż według kategorii</CardTitle>
              <CardDescription>
                Zestawienie dzienne za ostatni tydzień
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] w-full">
                <div className="flex flex-col space-y-2">
                  {dailySalesData.map((item, index) => (
                    <div key={index} className="grid grid-cols-6 items-center">
                      <div className="font-medium">{item.date}</div>
                      <div className="text-center">{item.Dania}</div>
                      <div className="text-center">{item.Sałatki}</div>
                      <div className="text-center">{item.Zupy}</div>
                      <div className="text-center">{item.Przekąski}</div>
                      <div className="font-bold text-center">{item.total}</div>
                    </div>
                  ))}
                  <div className="grid grid-cols-6 items-center font-bold border-t pt-2">
                    <div>Suma</div>
                    <div className="text-center">{dailySalesData.reduce((sum, item) => sum + item.Dania, 0)}</div>
                    <div className="text-center">{dailySalesData.reduce((sum, item) => sum + item.Sałatki, 0)}</div>
                    <div className="text-center">{dailySalesData.reduce((sum, item) => sum + item.Zupy, 0)}</div>
                    <div className="text-center">{dailySalesData.reduce((sum, item) => sum + item.Przekąski, 0)}</div>
                    <div className="text-center">{dailySalesData.reduce((sum, item) => sum + item.total, 0)}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* TAB: Rezerwacje pracowników */}
        <TabsContent value="employees" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Rezerwacje pracowników</CardTitle>
              <CardDescription>
                Zestawienie rezerwacji posiłków pracowników
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="py-4 text-center">
                <p>Funkcja raportowania rezerwacji pracowników zostanie wkrótce udostępniona.</p>
                <p className="text-sm text-gray-500 mt-2">Dane są w trakcie przygotowania.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};