import React, { useState } from 'react';
import { ProductManagement } from './ProductManagement';
import { ChamberManagement } from './ChamberManagement';
import { EmployeeManagement } from './EmployeeManagement';
import { TemperaturePanel } from './TemperaturePanel';
import { SettingsPanel } from './SettingsPanel';
import { CategoryManagement } from './CategoryManagement';
import { ReportsPanel } from './ReportsPanel';
import { WarehouseManagement } from './WarehouseManagement';
import { MealReservationsView } from './MealReservationsView.fixed';
import { Settings } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import { 
  ShoppingBag, 
  Package, 
  Grid, 
  Tags, 
  BarChart3, 
  Users, 
  Thermometer, 
  Settings2,
  Brain,
  UtensilsCrossed
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'products' | 'categories' | 'warehouse' | 'chambers' | 'statistics' | 'employees' | 'meal-reservations' | 'temperature' | 'settings'>('products');
  
  // Pobieranie ustawień
  const { data: settings } = useQuery<Settings>({
    queryKey: ['/api/settings'],
    retry: false
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8 flex items-center">
        {settings?.adminLogo ? (
          <div className="mr-4">
            <img 
              src={settings.adminLogo} 
              alt="Logo automatu" 
              className="h-16 object-contain"
            />
          </div>
        ) : (
          <div className="mr-4 bg-blue-50 p-3 rounded-lg">
            <Brain size={32} className="text-blue-600" />
          </div>
        )}
        <div>
          <h2 className="text-2xl font-semibold text-gray-800 flex items-center">
            <span className="text-black font-bold">
              {settings?.machineName}
            </span>
          </h2>
          <div className="flex items-center justify-between">
            <p className="text-gray-600 mt-1">Zarządzaj produktami, pracownikami, przypisaniem szuflad i ustawieniami</p>
          </div>
        </div>
      </div>

      {/* Admin Navigation */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button 
            onClick={() => setActiveTab('products')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'products' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <ShoppingBag className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'products' ? 'text-blue-500' : ''}`} />
            Produkty
          </button>

          <button 
            onClick={() => setActiveTab('categories')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'categories' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Tags className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'categories' ? 'text-green-500' : ''}`} />
            Kategorie
          </button>
          <button 
            onClick={() => setActiveTab('warehouse')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'warehouse' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Package className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'warehouse' ? 'text-amber-500' : ''}`} />
            Magazyn
          </button>
          <button 
            onClick={() => setActiveTab('chambers')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'chambers' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Grid className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'chambers' ? 'text-purple-500' : ''}`} />
            Szuflady
          </button>
          <button 
            onClick={() => setActiveTab('statistics')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'statistics' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <BarChart3 className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'statistics' ? 'text-indigo-500' : ''}`} />
            Raporty
          </button>
          <button 
            onClick={() => setActiveTab('employees')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'employees' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Users className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'employees' ? 'text-pink-500' : ''}`} />
            Pracownicy
          </button>
          <button 
            onClick={() => setActiveTab('meal-reservations')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'meal-reservations' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <UtensilsCrossed className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'meal-reservations' ? 'text-orange-500' : ''}`} />
            Rezerwacje
          </button>
          <button 
            onClick={() => setActiveTab('temperature')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'temperature' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Thermometer className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'temperature' ? 'text-red-500' : ''}`} />
            Temperatura
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'settings' 
                ? 'border-primary text-primary' 
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <Settings2 className={`inline-block mr-1 h-4 w-4 ${activeTab !== 'settings' ? 'text-teal-500' : ''}`} />
            Ustawienia
          </button>
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'products' && <ProductManagement />}
      {activeTab === 'categories' && <CategoryManagement />}
      {activeTab === 'warehouse' && <WarehouseManagement />}
      {activeTab === 'chambers' && <ChamberManagement />}
      {activeTab === 'statistics' && <ReportsPanel />}
      {activeTab === 'employees' && <EmployeeManagement />}
      {activeTab === 'meal-reservations' && <MealReservationsView />}
      {activeTab === 'temperature' && <TemperaturePanel />}
      {activeTab === 'settings' && <SettingsPanel />}

    </div>
  );
};
