import React, { useState, useCallback, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MealReservation, Employee, Chamber } from '@shared/schema';
import { format, parseISO } from 'date-fns';
import { pl } from 'date-fns/locale';
import { Calendar as CalendarIcon, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

export const MealReservationsView: React.FC = () => {
  console.log("Rendering MealReservationsView component");
  const today = new Date();
  const [selectedDate, setSelectedDate] = useState<Date>(today);
  const formattedDate = selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '';

  // Pobieranie rezerwacji
  const { data: reservationData, isLoading: isLoadingReservations, refetch: refetchReservations } = useQuery<{
    success: boolean;
    reservations: MealReservation[];
  }>({
    queryKey: ['/api/meal-reservations', formattedDate],
    queryFn: async () => {
      try {
        console.log(`Pobieranie rezerwacji dla daty: ${formattedDate}`);
        const response = await fetch(`/api/meal-reservations?date=${formattedDate}`, {
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Pobrano dane rezerwacji:', data);
        return data;
      } catch (err) {
        console.error('Błąd pobierania rezerwacji:', err);
        throw err;
      }
    },
    enabled: !!formattedDate
  });
  
  // Stan dla sprawdzania, czy pracownicy pracują w danym dniu
  const [employeeWorkingStatus, setEmployeeWorkingStatus] = useState<{[key: number]: boolean}>({});
  const [isLoadingWorkDays, setIsLoadingWorkDays] = useState(false);

  // Pobieranie pracowników z dodatkowym stanem ładowania
  const { 
    data: employees,
    isLoading: isLoadingEmployees 
  } = useQuery<Employee[]>({
    queryKey: ['/api/employees'],
  });

  // Pobieranie szuflad z dodatkowym stanem ładowania
  const { 
    data: chambersData,
    isLoading: isLoadingChambers 
  } = useQuery<{ chambers: Chamber[] }>({
    queryKey: ['/api/chambers'],
  });

  // Upewnijmy się, że dane rezerwacji są poprawnie dostępne
  // Dodajemy debugowanie - sprawdzenie faktycznego stanu danych
  useEffect(() => {
    console.log("MealReservationsView: Stan danych rezerwacji:", {
      isLoadingReservations,
      isLoadingEmployees,
      isLoadingChambers,
      isLoadingWorkDays,
      employeesCount: employees?.length || 0,
      reservationsCount: reservationData?.reservations?.length || 0,
      chambersCount: chambersData?.chambers?.length || 0,
      formattedDate
    });
  }, [
    isLoadingReservations, 
    isLoadingEmployees, 
    isLoadingChambers, 
    isLoadingWorkDays, 
    employees, 
    reservationData, 
    chambersData, 
    formattedDate
  ]);
  
  // Dla kompatybilności - wymaga aktualizacji handleDateSelect
  const fetchEmployeeWorkStatus = useCallback(() => {
    // Ta funkcja teraz tylko zwiększa licznik dataReloadKey, co spowoduje uruchomienie głównego efektu
    console.log("[MealReservationsView] Żądanie odświeżenia statusu pracy");
    setDataReloadKey(prev => prev + 1);
  }, []);

  // Znacznik do śledzenia odświeżenia danych
  const [dataReloadKey, setDataReloadKey] = useState(0);
  
  // Używamy reloadId do śledzenia odświeżeń, żeby nie wywoływać zbyt często
  const reloadIdRef = React.useRef(0);

  // Jeden główny efekt który zarządza ładowaniem danych o statusie pracy
  React.useEffect(() => {
    // Warunek do uruchomienia efektu - potrzebujemy mieć datę i listę pracowników
    if (!formattedDate || !employees || employees.length === 0) return;
    
    // Zapisujemy aktualny ID odświeżenia w referencji
    const currentReloadId = ++reloadIdRef.current;
    
    // Funkcja, która faktycznie ładuje dane o pracy pracowników
    let isActive = true; // Flaga aby uniknąć aktualizacji stanu po odmontowaniu
    const loadWorkStatus = async () => {
      // Sprawdzamy, czy to najnowsze żądanie odświeżenia
      if (!isActive || reloadIdRef.current !== currentReloadId) return;
      
      // Tylko ustawiamy loading na true
      setIsLoadingWorkDays(true);
      console.log(`[MealReservationsView] Pobieranie statusu pracy dla ${employees.length} pracowników na datę ${formattedDate} (ID: ${currentReloadId})`);
      
      try {
        // Zapisujemy aktualny stan pracowników przed rozpoczęciem ładowania
        // i wykonujemy fetch tylko dla nowych pracowników lub przy zmianie daty
        const existingEmployeeIds = Object.keys(employeeWorkingStatus).map(Number);
        const newStatus = {...employeeWorkingStatus}; // Kopiujemy istniejący stan
        
        // Dla każdego pracownika sprawdzamy status oddzielnie w sekwencji (nie równolegle)
        for (const employee of employees) {
          // Sprawdzamy czy nadal mamy najnowsze żądanie
          if (!isActive || reloadIdRef.current !== currentReloadId) {
            console.log(`[MealReservationsView] Przerwano ładowanie danych, nowsze żądanie jest w toku (ID: ${reloadIdRef.current})`);
            return;
          }
          
          try {
            const response = await fetch(`/api/employee-work-days/${employee.id}/check/${formattedDate}`, {
              headers: { 'Accept': 'application/json' }
            });
            
            if (!response.ok) {
              throw new Error(`Błąd HTTP: ${response.status}`);
            }
            
            const data = await response.json();
            
            // Tylko aktualizujemy jeśli to najnowsze żądanie
            if (isActive && reloadIdRef.current === currentReloadId) {
              newStatus[employee.id] = data.isWorking;
            } else {
              return; // Przerwij - komponent odmontowany lub jest nowsze żądanie
            }
          } catch (error) {
            console.error(`[MealReservationsView] Błąd sprawdzania statusu pracy dla pracownika ${employee.id}:`, error);
            
            // Tylko aktualizujemy jeśli to najnowsze żądanie
            if (isActive && reloadIdRef.current === currentReloadId) {
              newStatus[employee.id] = false; // W razie błędu domyślnie nie pracuje
            } else {
              return; // Przerwij - komponent odmontowany lub jest nowsze żądanie
            }
          }
        }
        
        // Tylko aktualizujemy stan jeśli to najnowsze żądanie
        if (isActive && reloadIdRef.current === currentReloadId) {
          setEmployeeWorkingStatus(newStatus);
          setIsLoadingWorkDays(false);
          console.log(`[MealReservationsView] Zakończono ładowanie statusu pracowników (ID: ${currentReloadId})`);
        }
      } catch (error) {
        console.error('[MealReservationsView] Błąd podczas zbierania statusu pracy pracowników:', error);
        
        // Tylko aktualizujemy stan jeśli to najnowsze żądanie
        if (isActive && reloadIdRef.current === currentReloadId) {
          setIsLoadingWorkDays(false);
        }
      }
    };
    
    // Uruchamiamy ładowanie danych
    loadWorkStatus();
    
    // Funkcja czyszcząca - ustawiamy flagę isActive na false, aby uniknąć aktualizacji stanu po odmontowaniu
    return () => {
      isActive = false;
    };
    
  }, [formattedDate, employees, dataReloadKey, employeeWorkingStatus]); // Dodajemy employeeWorkingStatus jako zależność

  // Pobieranie informacji o rezerwacji dla danego pracownika
  const getReservationForEmployee = (employeeId: number) => {
    if (!reservationData?.reservations) {
      console.log('[MealReservationsView] Brak danych o rezerwacjach', reservationData);
      return null;
    }
    
    const result = reservationData.reservations.find(r => r.employeeId === employeeId && r.reservedForDate === formattedDate);
    return result;
  };

  // Pobieranie informacji o szufladzie przypisanej do pracownika
  const getChamberInfoForEmployee = (employeeId: number) => {
    if (!chambersData?.chambers) return 'Brak przydziału';
    
    // Najpierw sprawdź przypisane szuflady z ogólnych przypisań
    const assignedChamber = chambersData.chambers.find(c => c.employeeId === employeeId);
    if (assignedChamber) {
      return `Szuflada #${assignedChamber.id}`;
    }
    
    // Jeśli nie ma ogólnego przypisania, sprawdź przypisania z rezerwacji
    const reservation = getReservationForEmployee(employeeId);
    if (reservation && reservation.chamberId) {
      const chamber = chambersData.chambers.find(c => c.id === reservation.chamberId);
      return chamber ? `Szuflada #${chamber.id}` : 'Brak przydziału';
    }
    
    return 'Brak przydziału';
  };

  // Formatowanie metody przypisania
  const formatAssignmentType = (type: string | null | undefined) => {
    if (!type) return 'Samodzielny wybór'; // Domyślnie wszystkie rezerwacje są wybrane przez pracownika
    switch (type) {
      case 'manual': return 'Samodzielny wybór';
      case 'preference': return 'Wg preferencji';
      case 'random': return 'Losowo';
      default: return 'Samodzielny wybór'; // Domyślnie wszystkie rezerwacje są wybrane przez pracownika
    }
  };

  // Ręczne odświeżenie danych
  const handleRefresh = () => {
    refetchReservations();
    // Inkrementacja licznika dataReloadKey wymusi ponowne sprawdzenie wszystkich pracowników
    setDataReloadKey(prev => prev + 1);
  };

  // Funkcja obsługująca wybór daty
  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      // Reset stanu - wyczyść status pracowników
      setEmployeeWorkingStatus({});
      
      // Ustaw flagę ładowania na true, aby pokazać ekran ładowania
      setIsLoadingWorkDays(true);
      
      // Ustaw nową datę (to spowoduje odświeżenie danych)
      setSelectedDate(date);
      
      // Ręcznie wywołaj odświeżenie danych o rezerwacjach
      setTimeout(() => {
        refetchReservations();
        setDataReloadKey(prev => prev + 1);
      }, 100);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold tracking-tight">Rezerwacje posiłków</h2>
        <div className="flex items-center space-x-2">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-[240px] justify-start text-left font-normal",
                  !selectedDate && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? (
                  format(selectedDate, "PPP", { locale: pl })
                ) : (
                  <span>Wybierz datę</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                initialFocus
                locale={pl}
              />
            </PopoverContent>
          </Popover>
          <Button variant="outline" size="icon" onClick={handleRefresh}>
            <RefreshCcw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {isLoadingReservations || isLoadingWorkDays || isLoadingEmployees || isLoadingChambers ? (
        <div className="flex flex-col items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-2"></div>
          <div className="text-sm text-gray-500">Ładowanie danych...</div>
        </div>
      ) : !employees || employees.length === 0 ? (
        <div className="border rounded-md p-8 text-center text-gray-500">
          Brak danych o pracownikach do wyświetlenia
        </div>
      ) : (
        <div className="border rounded-md">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pracownik
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Szuflada
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Posiłek
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Metoda przypisania
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {employees?.map((employee) => {
                const reservation = getReservationForEmployee(employee.id);
                // W stanie przechowujemy informację czy pracownik pracuje
                const isWorking = employeeWorkingStatus[employee.id];
                
                // Używamy tylko wartości ze stanu, wywołania funkcji asynchronicznych
                // są obsługiwane przez useEffect powyżej
                
                return (
                  <tr key={employee.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {employee.firstName} {employee.lastName}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {getChamberInfoForEmployee(employee.id)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {isWorking === true ? (
                        reservation ? (
                          <div className="text-sm text-gray-900">
                            {reservation.productName || 'Brak informacji o produkcie'}
                          </div>
                        ) : (
                          <div className="text-sm text-orange-500">
                            Brak wyboru posiłku
                          </div>
                        )
                      ) : isWorking === false ? (
                        <div className="text-sm text-gray-500 italic">
                          Nie pracuje w tym dniu
                        </div>
                      ) : (
                        <div className="text-sm text-gray-400">
                          Ładowanie statusu...
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {reservation ? (
                        <div className="text-sm text-gray-900">
                          {formatAssignmentType(reservation.assignmentType)}
                        </div>
                      ) : (
                        <div className="text-sm text-gray-500">
                          -
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
              {!employees || employees.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                    Brak danych o pracownikach
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};