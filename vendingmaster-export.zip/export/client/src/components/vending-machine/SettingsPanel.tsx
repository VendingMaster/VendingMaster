import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useIsMobile } from '@/hooks/use-mobile';

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { ImageIcon, Trash2, Upload, CalendarClock, CalendarPlus, AlarmCheck, Monitor, ScreenShare } from 'lucide-react';

// Wstawiamy style bezpośrednio przez JavaScript
const injectStyles = () => {
  const styleId = 'settings-panel-styles';
  
  // Usuń stare style jeśli istnieją
  const existingStyle = document.getElementById(styleId);
  if (existingStyle) {
    existingStyle.remove();
  }
  
  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = `
    /* Reset dla Chrome Kiosk Mode */
    html, body, #root {
      height: auto; 
    }
    
    /* Główny kontener */
    .settings-container {
      width: 100%;
      padding: 0;
      margin: 0;
    }
    
    /* Nagłówek */
    .settings-header {
      padding: 1rem 1rem 0.5rem 1rem;
    }
    
    /* Siatka kart */
    .settings-cards {
      display: grid;
      grid-template-columns: 1fr;
      gap: 1rem;
      padding: 0 1rem;
      margin-bottom: 0;
    }
    
    @media (min-width: 768px) {
      .settings-cards {
        grid-template-columns: repeat(2, 1fr);
      }
    }
    
    /* Karta na pełną szerokość */
    .card-full-width {
      grid-column: 1 / -1;
    }
  `;
  document.head.appendChild(style);
};

// Schemat walidacji formularza
const settingsFormSchema = z.object({
  adminPin: z.string().min(1, { message: 'PIN jest wymagany' }),
  machineName: z.string().min(1, { message: 'Nazwa automatu jest wymagana' }),
  adminLogo: z.string().nullable(),
  minTemperature: z.number().min(1).max(20),
  maxTemperature: z.number().min(4).max(25),
  expiringDaysThreshold: z.number().min(0).max(30),
  expiredDaysThreshold: z.number().min(-30).max(0),
  inventoryBasedAssignment: z.boolean(),
  loadingModeRfidCardNumber: z.string().optional().nullable(),
  maxReservationDays: z.number().min(1).max(30),
  firstReservationDays: z.number().min(0).max(14),
  autoGenerateMealReservations: z.boolean().default(false),
  employeePortalBackgroundColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, { 
    message: "Kolor tła musi być w formacie HEX (np. #F7EEE2)" 
  }),
  employeePortalButtonColor: z.string().regex(/^#[0-9A-Fa-f]{6}$/, { 
    message: "Kolor przycisków musi być w formacie HEX (np. #91AD41)" 
  }),
  // Dodane ustawienia dla wygaszacza ekranu
  screensaverEnabled: z.boolean().default(false),
  screensaverTimeoutSeconds: z.number().min(10).max(3600),
  screensaverImageUrl: z.string().nullable(),
  otherSettings: z.string().optional(),
});

// Typ wywodzony ze schematu
type SettingsFormValues = z.infer<typeof settingsFormSchema>;

// Główny komponent panelu ustawień
// Predefiniowane kolory do wyboru
const predefinedColors = [
  '#F7EEE2', '#91AD41', '#F8F9FA', '#E9ECEF', '#DEE2E6', 
  '#CED4DA', '#ADB5BD', '#6C757D', '#495057', '#343A40',
  '#FF6B6B', '#F06595', '#CC5DE8', '#845EF7', '#5C7CFA',
  '#339AF0', '#22B8CF', '#20C997', '#51CF66', '#94D82D',
  '#FCC419', '#FF922B'
];

export const SettingsPanel: React.FC = () => {
  const queryClient = useQueryClient();
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [showBackgroundColorPicker, setShowBackgroundColorPicker] = useState<boolean>(false);
  const [showButtonColorPicker, setShowButtonColorPicker] = useState<boolean>(false);
  const isMobile = useIsMobile();
  const [isKioskMode, setIsKioskMode] = useState<boolean>(false);

  // Wykrywanie trybu kiosk
  useEffect(() => {
    // Sprawdź czy jesteśmy w trybie kiosk Chrome
    const isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
    const isFullScreen = window.innerWidth === screen.width && window.innerHeight === screen.height;
    const isKiosk = isChrome && isFullScreen && !window.menubar?.visible;
    
    setIsKioskMode(isKiosk);
    console.log("Kiosk mode detected:", isKiosk);
  }, []);

  // Dodajemy specjalny handler dla trybu kiosk
  useEffect(() => {
    if (isKioskMode) {
      // Dodaj obsługę ręcznego scrollowania dla trybu kiosk
      const container = document.querySelector('.settings-container');
      if (container) {
        console.log("Adding wheel event listeners for kiosk mode");
        
        const handleWheel = (e: WheelEvent) => {
          e.preventDefault();
          const delta = e.deltaY || e.detail || 0;
          window.scrollBy(0, delta);
        };
        
        container.addEventListener('wheel', handleWheel, { passive: false });
        return () => {
          container.removeEventListener('wheel', handleWheel);
        };
      }
    }
  }, [isKioskMode]);

  // Wstrzyknij style do DOM
  useEffect(() => {
    injectStyles();
    
    // Wyczyść style przy demontażu komponentu
    return () => {
      const styleElement = document.getElementById('settings-panel-styles');
      if (styleElement) {
        styleElement.remove();
      }
    };
  }, [isMobile, isKioskMode]);

  // Interfejs dla obiektu ustawień
  interface Settings {
    id: number;
    adminPin: string;
    machineName: string;
    adminLogo: string | null;
    minTemperature: number;
    maxTemperature: number;
    expiringDaysThreshold: number;
    expiredDaysThreshold: number;
    inventoryBasedAssignment: boolean;
    loadingModeRfidCardNumber: string | null;
    maxReservationDays: number;
    firstReservationDays: number;
    autoGenerateMealReservations: boolean;
    employeePortalBackgroundColor: string;
    employeePortalButtonColor: string;
    // Dodane pola wygaszacza ekranu
    screensaverEnabled: boolean;
    screensaverTimeoutSeconds: number;
    screensaverImageUrl: string | null;
    otherSettings: Record<string, any>;
  }

  // Pobierz aktualne ustawienia
  const { data: settings, isLoading } = useQuery<Settings>({
    queryKey: ['/api/settings'],
  });

  // Utwórz formularz z wartościami domyślnymi
  const form = useForm<SettingsFormValues>({
    resolver: zodResolver(settingsFormSchema),
    defaultValues: {
      adminPin: '',
      machineName: 'IQSTORE',
      adminLogo: null,
      minTemperature: 10,
      maxTemperature: 24,
      expiringDaysThreshold: 0,
      expiredDaysThreshold: -1,
      inventoryBasedAssignment: false,
      loadingModeRfidCardNumber: null,
      maxReservationDays: 7,
      firstReservationDays: 2,
      autoGenerateMealReservations: false,
      employeePortalBackgroundColor: '#F7EEE2',
      employeePortalButtonColor: '#91AD41',
      // Domyślne wartości wygaszacza ekranu
      screensaverEnabled: false,
      screensaverTimeoutSeconds: 60,
      screensaverImageUrl: null,
      otherSettings: ''
    },
    mode: 'onChange'
  });

  // Aktualizuj formularz kiedy dane zostaną pobrane
  // Stan screesavera
  const [screensaverImagePreview, setScreensaverImagePreview] = useState<string | null>(null);

  useEffect(() => {
    if (settings) {
      const formValues: SettingsFormValues = {
        adminPin: settings.adminPin || '',
        machineName: settings.machineName || 'IQSTORE',
        adminLogo: settings.adminLogo,
        minTemperature: settings.minTemperature || 10,
        maxTemperature: settings.maxTemperature || 24,
        expiringDaysThreshold: settings.expiringDaysThreshold ?? 0,
        expiredDaysThreshold: settings.expiredDaysThreshold ?? -1,
        inventoryBasedAssignment: settings.inventoryBasedAssignment ?? false,
        loadingModeRfidCardNumber: settings.loadingModeRfidCardNumber,
        maxReservationDays: settings.maxReservationDays ?? 7,
        firstReservationDays: settings.firstReservationDays ?? 2,
        autoGenerateMealReservations: settings.autoGenerateMealReservations ?? false,
        employeePortalBackgroundColor: settings.employeePortalBackgroundColor || '#F7EEE2',
        employeePortalButtonColor: settings.employeePortalButtonColor || '#91AD41',
        // Inicjalizacja wygaszacza ekranu
        screensaverEnabled: settings.screensaverEnabled ?? false,
        screensaverTimeoutSeconds: settings.screensaverTimeoutSeconds ?? 60,
        screensaverImageUrl: settings.screensaverImageUrl,
        otherSettings: typeof settings.otherSettings === 'object' ? JSON.stringify(settings.otherSettings) : ''
      };
      
      form.reset(formValues);
      
      // Ustaw podgląd logo i obrazu wygaszacza, jeśli istnieją
      if (settings.adminLogo) {
        setLogoPreview(settings.adminLogo);
      }
      
      if (settings.screensaverImageUrl) {
        setScreensaverImagePreview(settings.screensaverImageUrl);
      }
    }
  }, [settings, form]);
  
  // Funkcja do obsługi wczytywania plików obrazów dla logo
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Sprawdzenie typu pliku
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Błąd",
        description: "Wybrany plik nie jest obrazem.",
        variant: "destructive"
      });
      return;
    }
    
    // Sprawdzenie rozmiaru pliku (500KB)
    if (file.size > 500 * 1024) {
      toast({
        title: "Błąd",
        description: "Maksymalny rozmiar pliku to 500KB.",
        variant: "destructive"
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        const dataUrl = event.target.result as string;
        setLogoPreview(dataUrl);
        form.setValue('adminLogo', dataUrl);
        form.trigger('adminLogo');
      }
    };
    reader.readAsDataURL(file);
  };

  // Funkcja do usuwania logo
  const resetLogo = () => {
    setLogoPreview(null);
    form.setValue('adminLogo', null);
    form.trigger('adminLogo');
  };
  
  // Funkcja do przesyłania obrazu wygaszacza ekranu
  const handleScreensaverImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Sprawdzenie typu pliku
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Błąd",
        description: "Wybrany plik nie jest obrazem.",
        variant: "destructive"
      });
      return;
    }

    // Zezwalamy na większe pliki dla wygaszacza ekranu (5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Błąd",
        description: "Maksymalny rozmiar pliku to 5MB.",
        variant: "destructive"
      });
      return;
    }

    // Wykorzystanie endpointu serwerowego do przesłania obrazu
    const formData = new FormData();
    formData.append('screensaverImage', file);

    try {
      const response = await fetch('/api/settings/screensaver-image', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Błąd przesyłania: ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success && result.imageUrl) {
        setScreensaverImagePreview(result.imageUrl);
        form.setValue('screensaverImageUrl', result.imageUrl);
        form.trigger('screensaverImageUrl');
        
        toast({
          title: "Sukces",
          description: "Obraz wygaszacza ekranu został pomyślnie zaktualizowany.",
        });
      }
    } catch (error) {
      console.error('Błąd przesyłania obrazu wygaszacza ekranu:', error);
      toast({
        title: "Błąd",
        description: "Nie udało się przesłać obrazu wygaszacza ekranu.",
        variant: "destructive"
      });
    }
  };

  // Funkcja do usuwania obrazu wygaszacza ekranu
  const resetScreensaverImage = () => {
    setScreensaverImagePreview(null);
    form.setValue('screensaverImageUrl', null);
    form.trigger('screensaverImageUrl');
  };
  
  // Funkcja do obsługi wyboru koloru z palety
  const handleColorChange = (color: string, fieldName: 'employeePortalBackgroundColor' | 'employeePortalButtonColor') => {
    form.setValue(fieldName, color);
    form.trigger(fieldName);
  };
  
  // Funkcja do obsługi wyboru koloru z predefiniowanych opcji
  const handlePredefinedColorSelect = (color: string, fieldName: 'employeePortalBackgroundColor' | 'employeePortalButtonColor') => {
    form.setValue(fieldName, color);
    form.trigger(fieldName);
    
    // Nie zamykamy już selektora po wyborze koloru
    // Pozwala to użytkownikowi precyzyjnie wybrać kolor
  };

  // Mutacja do aktualizacji ustawień
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: SettingsFormValues) => {
      return apiRequest('/api/settings', {
        method: 'PATCH',
        data: {
          ...data,
          otherSettings: data.otherSettings ? JSON.parse(data.otherSettings) : {}
        }
      });
    },
    onSuccess: () => {
      // Odśwież wszystkie powiązane zapytania
      queryClient.invalidateQueries({ queryKey: ['/api/settings'] });
      
      // Odśwież również zapytania, które mogą zależeć od ustawień trybu magazynowego
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/diagnostics'] });
      
      // Po zmianie ustawień wymuś przeładowanie strony
      setTimeout(() => {
        window.location.reload();
      }, 1000);
      
      toast({
        title: 'Sukces',
        description: 'Ustawienia zostały zaktualizowane. Strona zostanie przeładowana za chwilę...',
      });
    },
    onError: (error) => {
      toast({
        title: 'Błąd aktualizacji',
        description: 'Nie udało się zapisać zmian.',
        variant: 'destructive'
      });
      console.error('Error updating settings:', error);
    }
  });

  // Obsługa zapisu formularza
  const onSubmit = (data: SettingsFormValues) => {
    updateSettingsMutation.mutate(data);
  };

  // Pokaż spinner podczas ładowania
  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="settings-container">
      <div className="settings-header">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">Zarządzanie Ustawieniami</h3>
        <p className="text-gray-600 text-base">Konfiguracja parametrów automatu</p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <div className="settings-cards mb-12">
              {/* Ustawienia ogólne */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium">Ustawienia ogólne</CardTitle>
                  <CardDescription className="text-sm">Podstawowe informacje o automacie</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="adminPin"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium">PIN administratora</FormLabel>
                          <FormControl>
                            <Input
                              type="password"
                              placeholder="Wprowadź PIN"
                              className="h-9"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Dostęp do funkcji administracyjnych
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="machineName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium">Nazwa automatu</FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Nazwa automatu"
                              className="h-9"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Nazwa w interfejsie użytkownika
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="adminLogo"
                    render={({ field: { value, onChange, ...rest } }) => (
                      <FormItem className="pt-2">
                        <FormLabel className="text-sm font-medium">Logo administracyjne</FormLabel>
                        <div className="flex items-center gap-3">
                          {logoPreview ? (
                            <div className="relative w-16 h-16 border rounded-md overflow-hidden">
                              <img 
                                src={logoPreview} 
                                alt="Logo" 
                                className="w-full h-full object-contain"
                              />
                              <Button
                                type="button"
                                variant="destructive"
                                size="icon"
                                className="absolute top-0 right-0 h-5 w-5"
                                onClick={resetLogo}
                              >
                                <Trash2 className="h-2 w-2" />
                              </Button>
                            </div>
                          ) : (
                            <div className="w-16 h-16 border rounded-md flex items-center justify-center bg-muted">
                              <ImageIcon className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                          <div className="flex flex-col gap-1">
                            <label htmlFor="logo-upload" className="cursor-pointer">
                              <div className="flex items-center gap-1 px-3 py-1 text-sm bg-primary text-primary-foreground rounded-md hover:bg-primary/90">
                                <Upload className="h-3 w-3" />
                                <span>Wczytaj</span>
                              </div>
                              <input
                                id="logo-upload"
                                type="file"
                                className="hidden"
                                accept="image/*"
                                onChange={handleImageUpload}
                              />
                            </label>
                            <FormDescription className="text-xs">
                              Logo w panelu (max 500KB)
                            </FormDescription>
                          </div>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
              
              {/* Zakres temperatur */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium">Zakres temperatur</CardTitle>
                  <CardDescription className="text-sm">Monitoring temperatury</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 pt-0">
                  <div className="space-y-2">
                    <FormField
                      control={form.control}
                      name="minTemperature"
                      render={({ field: { value, onChange, ...fieldProps } }) => (
                        <FormItem className="mb-0">
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium mb-0">Minimalna temperatura</FormLabel>
                            <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                              {value}°C
                            </span>
                          </div>
                          <FormControl>
                            <Slider
                              min={1}
                              max={20}
                              step={0.5}
                              value={[value]}
                              onValueChange={(vals) => onChange(vals[0])}
                              {...fieldProps}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="maxTemperature"
                      render={({ field: { value, onChange, ...fieldProps } }) => (
                        <FormItem className="mb-0">
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium mb-0">Maksymalna temperatura</FormLabel>
                            <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                              {value}°C
                            </span>
                          </div>
                          <FormControl>
                            <Slider
                              min={4}
                              max={25}
                              step={0.5}
                              value={[value]}
                              onValueChange={(vals) => onChange(vals[0])}
                              {...fieldProps}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="rounded-md bg-muted/30 p-3 mt-2">
                    <h4 className="text-sm font-medium mb-1">Legenda kolorów:</h4>
                    <div className="grid grid-cols-2 gap-x-1 gap-y-0.5 text-xs">
                      <div className="flex gap-1 items-center">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span>Prawidłowa</span>
                      </div>
                      <div className="flex gap-1 items-center">
                        <div className="w-3 h-3 bg-amber-500 rounded-full"></div>
                        <span>Bliska granicznej (±1°C)</span>
                      </div>
                      <div className="flex gap-1 items-center">
                        <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                        <span>Poza zakresem</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Ustawienia rezerwacji posiłków */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium">Ustawienia rezerwacji posiłków</CardTitle>
                  <CardDescription className="text-sm">Konfiguracja systemu rezerwacji posiłków dla pracowników</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 pt-0">
                  <div className="space-y-2">
                    <FormField
                      control={form.control}
                      name="maxReservationDays"
                      render={({ field: { value, onChange, ...fieldProps } }) => (
                        <FormItem className="mb-0">
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium mb-0">Maksymalny czas rezerwacji</FormLabel>
                            <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                              {value} {value === 1 ? "dzień" : "dni"}
                            </span>
                          </div>
                          <FormControl>
                            <Slider
                              min={1}
                              max={30}
                              step={1}
                              value={[value]}
                              onValueChange={(vals) => onChange(vals[0])}
                              {...fieldProps}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Maksymalna liczba dni, na które można rezerwować posiłki
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="firstReservationDays"
                      render={({ field: { value, onChange, ...fieldProps } }) => (
                        <FormItem className="mb-0">
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium mb-0">Pierwsza rezerwacja</FormLabel>
                            <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                              {value} {value === 1 ? "dzień" : "dni"}
                            </span>
                          </div>
                          <FormControl>
                            <Slider
                              min={0}
                              max={14}
                              step={1}
                              value={[value]}
                              onValueChange={(vals) => onChange(vals[0])}
                              {...fieldProps}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Liczba dni, na ile wcześniej pracownik może dokonać pierwszej rezerwacji
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="mt-4">
                    <FormField
                      control={form.control}
                      name="autoGenerateMealReservations"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel className="text-sm font-medium">Automatyczne generowanie rezerwacji</FormLabel>
                            <FormDescription className="text-xs">
                              Automatycznie generuj rezerwacje posiłków dla pracowników, którzy są w pracy, ale nie dokonali rezerwacji
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="rounded-md bg-muted/30 p-3 mt-4">
                    <h4 className="text-sm font-medium mb-1">Informacje o rezerwacjach:</h4>
                    <div className="grid grid-cols-1 gap-y-0.5 text-xs">
                      <div className="flex gap-1 items-center">
                        <CalendarClock className="h-3 w-3 text-primary" />
                        <span>Maksymalna liczba dni to okres, na który można dokonać rezerwacji.</span>
                      </div>
                      <div className="flex gap-1 items-center">
                        <CalendarPlus className="h-3 w-3 text-primary" />
                        <span>Pierwsza rezerwacja to wyprzedzenie, z jakim można zaplanować posiłki.</span>
                      </div>
                      <div className="flex gap-1 items-center">
                        <AlarmCheck className="h-3 w-3 text-primary" />
                        <span>Zmiany obowiązują dla nowych rezerwacji.</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Wygląd panelu pracownika */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium">Dostosowanie wyglądu portalu pracownika</CardTitle>
                  <CardDescription className="text-sm">Kolory portalu pracownika</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 pt-0">
                  <div className="space-y-4">
                    <FormField
                      control={form.control}
                      name="employeePortalBackgroundColor"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium">Kolor tła</FormLabel>
                            <div className="flex items-center gap-2">
                              <div 
                                className="w-6 h-6 rounded border cursor-pointer" 
                                style={{ backgroundColor: field.value }}
                                onClick={() => setShowBackgroundColorPicker(!showBackgroundColorPicker)}
                              />
                              <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                                {field.value}
                              </span>
                            </div>
                          </div>
                          {showBackgroundColorPicker && (
                            <div className="relative">
                              <div className="absolute right-0 mt-2 p-3 bg-white shadow-lg rounded-md z-50">
                                <div className="mb-2">
                                  <label className="block text-xs font-medium mb-1">Wybierz kolor:</label>
                                  <input 
                                    type="color" 
                                    className="w-full h-8 cursor-pointer rounded"
                                    value={field.value}
                                    onChange={(e) => handleColorChange(e.target.value, 'employeePortalBackgroundColor')}
                                  />
                                </div>
                                <div className="mt-3 grid grid-cols-5 gap-2 mb-2">
                                  <p className="col-span-5 text-xs mb-1">Popularne kolory:</p>
                                  {predefinedColors.map((color) => (
                                    <div
                                      key={color}
                                      className="w-6 h-6 rounded border cursor-pointer"
                                      style={{ backgroundColor: color }}
                                      onClick={() => handlePredefinedColorSelect(color, 'employeePortalBackgroundColor')}
                                    />
                                  ))}
                                </div>
                                <div className="flex justify-end">
                                  <button
                                    type="button"
                                    className="text-xs text-gray-500"
                                    onClick={() => setShowBackgroundColorPicker(false)}
                                  >
                                    Zamknij
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}
                          <FormControl>
                            <Input 
                              type="text" 
                              placeholder="#F7EEE2" 
                              className="h-9"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Kolor tła całego panelu pracownika (domyślnie: #F7EEE2)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="employeePortalButtonColor"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium">Kolor przycisków</FormLabel>
                            <div className="flex items-center gap-2">
                              <div 
                                className="w-6 h-6 rounded border cursor-pointer" 
                                style={{ backgroundColor: field.value }}
                                onClick={() => setShowButtonColorPicker(!showButtonColorPicker)}
                              />
                              <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                                {field.value}
                              </span>
                            </div>
                          </div>
                          {showButtonColorPicker && (
                            <div className="relative">
                              <div className="absolute right-0 mt-2 p-3 bg-white shadow-lg rounded-md z-50">
                                <div className="mb-2">
                                  <label className="block text-xs font-medium mb-1">Wybierz kolor:</label>
                                  <input 
                                    type="color" 
                                    className="w-full h-8 cursor-pointer rounded"
                                    value={field.value}
                                    onChange={(e) => handleColorChange(e.target.value, 'employeePortalButtonColor')}
                                  />
                                </div>
                                <div className="mt-3 grid grid-cols-5 gap-2 mb-2">
                                  <p className="col-span-5 text-xs mb-1">Popularne kolory:</p>
                                  {predefinedColors.map((color) => (
                                    <div
                                      key={color}
                                      className="w-6 h-6 rounded border cursor-pointer"
                                      style={{ backgroundColor: color }}
                                      onClick={() => handlePredefinedColorSelect(color, 'employeePortalButtonColor')}
                                    />
                                  ))}
                                </div>
                                <div className="flex justify-end">
                                  <button
                                    type="button"
                                    className="text-xs text-gray-500"
                                    onClick={() => setShowButtonColorPicker(false)}
                                  >
                                    Zamknij
                                  </button>
                                </div>
                              </div>
                            </div>
                          )}
                          <FormControl>
                            <Input 
                              type="text" 
                              placeholder="#91AD41" 
                              className="h-9"
                              {...field}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Kolor przycisków w panelu pracownika (domyślnie: #91AD41)
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="mt-2 rounded-md bg-muted/30 p-3">
                    <h4 className="text-sm font-medium mb-1">Podgląd kolorów:</h4>
                    <div className="p-3 rounded-md mb-2" style={{ backgroundColor: form.watch('employeePortalBackgroundColor') }}>
                      <div className="text-xs mb-2">Przykładowe tło portalu</div>
                      <button
                        className="px-3 py-1.5 text-white text-xs rounded-md"
                        style={{ backgroundColor: form.watch('employeePortalButtonColor') }}
                      >
                        Przykładowy przycisk
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Kolory będą widoczne dla pracowników w portalu pracownika. Upewnij się, że wybrane kolory zapewniają dobry kontrast.
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              {/* Ustawienia magazynu - karta na pełną szerokość */}
              {/* Ustawienia wygaszacza ekranu */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium">Wygaszacz ekranu</CardTitle>
                  <CardDescription className="text-sm">Konfiguracja wygaszacza ekranu w trybie kiosk</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 pt-0">
                  {/* Włączenie/wyłączenie wygaszacza */}
                  <FormField
                    control={form.control}
                    name="screensaverEnabled"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Wygaszacz ekranu
                          </FormLabel>
                          <FormDescription>
                            Aktywuj wygaszacz ekranu w trybie kiosk
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  {/* Czas nieaktywności przed uruchomieniem wygaszacza */}
                  <FormField
                    control={form.control}
                    name="screensaverTimeoutSeconds"
                    render={({ field: { value, onChange, ...fieldProps } }) => (
                      <FormItem className="mb-0">
                        <div className="flex justify-between items-center">
                          <FormLabel className="text-sm font-medium mb-0">Czas nieaktywności (sekundy)</FormLabel>
                          <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                            {value} {value === 1 ? "sekunda" : value < 5 ? "sekundy" : "sekund"}
                          </span>
                        </div>
                        <FormControl>
                          <Slider
                            min={10}
                            max={300}
                            step={10}
                            value={[value]}
                            onValueChange={(vals) => onChange(vals[0])}
                            {...fieldProps}
                          />
                        </FormControl>
                        <FormDescription className="text-xs mt-1">
                          Po tym czasie nieaktywności uruchomi się wygaszacz ekranu
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Przesyłanie obrazu wygaszacza */}
                  <FormField
                    control={form.control}
                    name="screensaverImageUrl"
                    render={({ field: { value, onChange, ...rest } }) => (
                      <FormItem className="pt-2">
                        <FormLabel className="text-sm font-medium">Obraz wygaszacza ekranu</FormLabel>
                        <div className="flex items-center gap-3">
                          {screensaverImagePreview ? (
                            <div className="relative w-40 h-24 border rounded-md overflow-hidden">
                              <img 
                                src={screensaverImagePreview} 
                                alt="Wygaszacz ekranu" 
                                className="w-full h-full object-cover"
                              />
                              <Button
                                type="button"
                                variant="destructive"
                                size="icon"
                                className="absolute top-0 right-0 h-5 w-5"
                                onClick={resetScreensaverImage}
                              >
                                <Trash2 className="h-2 w-2" />
                              </Button>
                            </div>
                          ) : (
                            <div className="w-40 h-24 border rounded-md flex items-center justify-center bg-muted">
                              <Monitor className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                          <div className="flex flex-col gap-1">
                            <label htmlFor="screensaver-upload" className="cursor-pointer">
                              <div className="flex items-center gap-1 px-3 py-1 text-sm bg-primary text-primary-foreground rounded-md hover:bg-primary/90">
                                <ScreenShare className="h-3 w-3" />
                                <span>Wczytaj</span>
                              </div>
                              <input
                                id="screensaver-upload"
                                type="file"
                                className="hidden"
                                accept="image/*"
                                onChange={handleScreensaverImageUpload}
                              />
                            </label>
                            <FormDescription className="text-xs">
                              Obraz wygaszacza ekranu (max 5MB)
                            </FormDescription>
                          </div>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
              
              {/* Ustawienia magazynu */}
              <Card className="card-full-width">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base font-medium">Ustawienia magazynu</CardTitle>
                  <CardDescription className="text-sm">Konfiguracja terminów ważności i funkcji magazynowych</CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="expiringDaysThreshold"
                      render={({ field: { value, onChange, ...fieldProps } }) => (
                        <FormItem>
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium">Próg "Kończących się termin"</FormLabel>
                            <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                              {value} {value === 1 ? "dzień" : "dni"}
                            </span>
                          </div>
                          <FormControl>
                            <Slider
                              min={0}
                              max={30}
                              step={1}
                              value={[value]}
                              onValueChange={(vals) => onChange(vals[0])}
                              {...fieldProps}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Produkty wygasające w ciągu {value} {value === 1 ? "dnia" : "dni"} = "Kończące się termin"
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="expiredDaysThreshold"
                      render={({ field: { value, onChange, ...fieldProps } }) => (
                        <FormItem>
                          <div className="flex justify-between items-center">
                            <FormLabel className="text-sm font-medium">Próg "Przeterminowanych"</FormLabel>
                            <span className="bg-muted px-2 py-0.5 rounded-md font-mono text-sm">
                              {value} {value === -1 ? "dzień" : "dni"}
                            </span>
                          </div>
                          <FormControl>
                            <Slider
                              min={-30}
                              max={0}
                              step={1}
                              value={[value]}
                              onValueChange={(vals) => onChange(vals[0])}
                              {...fieldProps}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            Produkty przeterminowane o więcej niż {Math.abs(value)} {Math.abs(value) === 1 ? "dzień" : "dni"} = "Przeterminowane"
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="rounded-md bg-muted/30 p-3 text-xs">
                      <h4 className="text-sm font-medium mb-1">Legenda statusów produktów:</h4>
                      <div className="space-y-1">
                        <div className="flex gap-1.5 items-start">
                          <div className="w-3 h-3 bg-green-500 rounded-full mt-0.5"></div>
                          <span>W terminie: ≥ {form.watch('expiringDaysThreshold')} {form.watch('expiringDaysThreshold') === 1 ? "dzień" : "dni"} w przyszłości</span>
                        </div>
                        <div className="flex gap-1.5 items-start">
                          <div className="w-3 h-3 bg-amber-500 rounded-full mt-0.5"></div>
                          <span>Kończące się: od {form.watch('expiredDaysThreshold') + 1} {Math.abs(form.watch('expiredDaysThreshold') + 1) === 1 ? "dnia" : "dni"} w przeszłości do {form.watch('expiringDaysThreshold')} {form.watch('expiringDaysThreshold') === 1 ? "dnia" : "dni"} w przyszłości</span>
                        </div>
                        <div className="flex gap-1.5 items-start">
                          <div className="w-3 h-3 bg-red-500 rounded-full mt-0.5"></div>
                          <span>Przeterminowane: ≥ {Math.abs(form.watch('expiredDaysThreshold'))} {Math.abs(form.watch('expiredDaysThreshold')) === 1 ? "dzień" : "dni"} w przeszłości</span>
                        </div>
                      </div>
                    </div>

                    <FormField
                      control={form.control}
                      name="inventoryBasedAssignment"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-md border p-3">
                          <div className="space-y-0.5">
                            <FormLabel className="text-sm font-medium">Przypisywanie bazujące na magazynie</FormLabel>
                            <FormDescription className="text-xs">
                              Po włączeniu, możliwe będzie przypisanie do szuflad tylko produktów dostępnych w magazynie.
                              {field.value && (
                                <div className="mt-1 p-1.5 bg-amber-50 border border-amber-200 rounded-md text-amber-700 text-xs">
                                  <strong>Tryb aktywny:</strong> System automatycznie odlicza produkty z magazynu
                                  podczas wydawania. Wymagana min. jedna sztuka na każdą szufladę z danym produktem.
                                </div>
                              )}
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="mt-4">
                    <FormField
                      control={form.control}
                      name="loadingModeRfidCardNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm font-medium">Karta RFID dla trybu załadunkowego</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Wprowadź numer karty RFID (opcjonalnie)"
                              className="h-9"
                              {...field}
                              value={field.value || ''}
                            />
                          </FormControl>
                          <FormDescription className="text-xs">
                            To pole definiuje numer karty RFID, która umożliwia uruchomienie trybu załadunkowego bez
                            potwierdzenia w panelu administracyjnym. Przybliżenie tej karty do czytnika automatycznie
                            uruchomi sekwencyjne otwieranie szuflad, co ułatwia szybkie uzupełnianie towarów.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="flex justify-end mt-8 mr-4 mb-4">
              <Button 
                type="submit" 
                disabled={updateSettingsMutation.isPending}
                className="px-6 py-2 bg-gradient-to-r from-primary to-primary-dark"
              >
                {updateSettingsMutation.isPending ? (
                  <>
                    <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
                    Zapisywanie...
                  </>
                ) : (
                  'Zapisz zmiany'
                )}
              </Button>
            </div>
          </form>
        </Form>
    </div>
  );
}