import React from 'react';
import { Button } from "@/components/ui/button";
import { Product } from '@shared/schema';
import { Modal } from "@/components/ui/modal";

interface AllergensModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
}

export const AllergensModal: React.FC<AllergensModalProps> = ({ isOpen, onClose, product }) => {
  if (!product || !product.allergens) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Alergeny"
    >
      <div className="flex items-start gap-3 mb-4">
        <div className="p-2 rounded-full bg-orange-100 mt-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <div>
          <h3 className="font-medium text-gray-800 mb-1">Informacja o alergenach dla produktu</h3>
          <p className="text-gray-600 text-sm mb-2">{product.name}</p>
        </div>
      </div>
      
      <div className="bg-orange-50 p-4 rounded-md text-gray-700 whitespace-pre-line border border-orange-100">
        {product.allergens}
      </div>
    </Modal>
  );
};