import React from 'react';
import { Button } from "@/components/ui/button";
import { Product } from '@shared/schema';
import { Modal } from "@/components/ui/modal";

interface IngredientsModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
}

export const IngredientsModal: React.FC<IngredientsModalProps> = ({ isOpen, onClose, product }) => {
  if (!product || !product.ingredients) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Pełny skład produktu"
    >
      <h3 className="font-medium text-primary mb-2">{product.name}</h3>
      
      <div className="bg-gray-50 p-4 rounded-md text-gray-700 whitespace-pre-line">
        {product.ingredients}
      </div>
    </Modal>
  );
};