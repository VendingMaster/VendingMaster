import React from 'react';
import { Button } from "@/components/ui/button";
import { Product, DietaryPreference } from '@shared/schema';
import { Modal } from "@/components/ui/modal";

interface DietaryPreferencesModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product | null;
  dietaryPreferences: DietaryPreference[];
}

export const DietaryPreferencesModal: React.FC<DietaryPreferencesModalProps> = ({ 
  isOpen, 
  onClose, 
  product, 
  dietaryPreferences 
}) => {
  if (!product || dietaryPreferences.length === 0) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Preferencje dietetyczne"
    >
      <div className="flex items-start gap-3 mb-4">
        <div className="p-2 rounded-full bg-purple-100 mt-1">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        </div>
        <div>
          <h3 className="font-medium text-gray-800 mb-1">Preferencje dietetyczne</h3>
          <p className="text-gray-600 text-sm mb-2">{product.name}</p>
        </div>
      </div>
      
      <div className="bg-purple-50 p-4 rounded-md text-gray-700 border border-purple-100">
        <div className="flex flex-wrap gap-2">
          {dietaryPreferences.map((preference: string, index: number) => (
            <div key={index} className="px-3 py-1.5 bg-white rounded-full border border-purple-200 text-purple-800 text-sm font-medium">
              {preference}
            </div>
          ))}
        </div>
      </div>
    </Modal>
  );
};