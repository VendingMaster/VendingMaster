import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Inventory, Product } from "@shared/schema";

// Rozszerzony typ Inventory o informacje o produkcie
interface InventoryWithProduct extends Inventory {
  product?: Product;
}

interface UsageModalProps {
  item: InventoryWithProduct | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const UsageModal: React.FC<UsageModalProps> = ({
  item,
  isOpen,
  onClose,
  onSuccess
}) => {
  const { toast } = useToast();
  const [quantity, setQuantity] = useState<number>(1);
  const [reason, setReason] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Reset state when modal opens with a new item
  React.useEffect(() => {
    if (isOpen && item) {
      setQuantity(1);
      setReason("");
      setError(null);
    }
  }, [isOpen, item]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!item) return;

    // Walidacja
    if (quantity <= 0) {
      setError("Ilość musi być większa od zera");
      return;
    }

    if (quantity > item.quantity) {
      setError(`Ilość nie może być większa niż dostępna (${item.quantity})`);
      return;
    }

    if (!reason.trim()) {
      setError("Podaj powód rozchodu");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const response = await apiRequest(`/api/inventory/${item.id}/use`, {
        method: "POST",
        data: {
          quantity,
          reason
        }
      });

      if (response.success) {
        toast({
          title: "Rozchód zarejestrowany",
          description: `Pomyślnie zarejestrowano rozchód ${quantity} szt. produktu`,
        });
        onSuccess();
        onClose();
      } else {
        setError(response.message || "Wystąpił błąd podczas rejestracji rozchodu");
      }
    } catch (error) {
      console.error("Błąd podczas rejestracji rozchodu:", error);
      setError("Wystąpił błąd podczas rejestracji rozchodu");
    } finally {
      setIsSubmitting(false);
    }
  };

  const productName = item?.product?.name || "produkt";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Rejestracja rozchodu</DialogTitle>
            <DialogDescription>
              Zarejestruj rozchód produktu: {productName}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            {error && (
              <div className="text-red-500 text-sm">{error}</div>
            )}

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="quantity" className="text-right">
                Ilość
              </Label>
              <Input
                id="quantity"
                type="number"
                min={1}
                max={item?.quantity || 1}
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                className="col-span-3"
              />
            </div>

            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="reason" className="text-right">
                Powód
              </Label>
              <Textarea
                id="reason"
                placeholder="Podaj powód rozchodu produktu"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="col-span-3"
              />
            </div>
          </div>

          <DialogFooter>
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              disabled={isSubmitting}
            >
              Anuluj
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting}
            >
              {isSubmitting ? "Przetwarzanie..." : "Zarejestruj rozchód"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};