import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  pin?: string;
  onPinChange?: (pin: string) => void;
  onSubmit?: () => void;
}

export const AdminModal: React.FC<AdminModalProps> = ({ 
  isOpen, 
  onClose, 
  pin, 
  onPinChange, 
  onSubmit 
}) => {
  const [internalPin, setInternalPin] = useState('');
  const { toast } = useToast();

  // Używamy wewnętrznego stanu, jeśli nie dostarczono zewnętrznego
  const adminPin = pin !== undefined ? pin : internalPin;
  const handlePinChange = (value: string) => {
    if (onPinChange) {
      onPinChange(value);
    } else {
      setInternalPin(value);
    }
  };

  const handleSubmit = () => {
    if (onSubmit) {
      onSubmit();
    } else if (adminPin === '1308') {
      window.location.href = '/admin';
    } else {
      toast({
        title: "Błąd",
        description: "Nieprawidłowy kod PIN. Spróbuj ponownie.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Panel Administratora</DialogTitle>
          <DialogDescription>
            Wprowadź kod PIN, aby uzyskać dostęp do panelu administratora.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="pin">Kod PIN</Label>
            <Input
              id="pin"
              type="password"
              value={adminPin}
              onChange={(e) => handlePinChange(e.target.value)}
              className="text-lg tracking-widest text-center"
              maxLength={4}
              autoFocus
            />
          </div>
        </div>
        
        <DialogFooter className="gap-2 sm:justify-end">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
          >
            Anuluj
          </Button>
          <Button type="button" onClick={handleSubmit}>
            Zaloguj
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};