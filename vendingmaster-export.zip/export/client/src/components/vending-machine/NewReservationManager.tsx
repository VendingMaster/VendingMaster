import React, { useState } from 'react';
import { format } from 'date-fns';
import { pl } from 'date-fns/locale';

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { CalendarIcon, RefreshCw } from 'lucide-react';
import { ReservationCalendarView, DailyEmployeeReservations } from './ReservationCalendarView';

export const NewReservationManager: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isRefreshing, setIsRefreshing] = useState(false);
  
  // Handler for date selection
  const handleDateSelect = (date: Date) => {
    setSelectedDate(date);
  };
  
  // Handler for refresh button
  const handleRefresh = () => {
    setIsRefreshing(true);
    
    // Symulacja odświeżania danych
    setTimeout(() => {
      setIsRefreshing(false);
      // W rzeczywistej aplikacji tutaj byłoby odświeżanie zapytań z useQuery
    }, 500);
  };
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Rezerwacje posiłków</h2>
          <p className="text-muted-foreground">
            Wyświetlanie rezerwacji posiłków dla pracowników
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            Odśwież
          </Button>
          
          <Button variant="outline">
            <CalendarIcon className="mr-2 h-4 w-4" />
            {format(selectedDate, 'd MMMM yyyy', { locale: pl })}
          </Button>
        </div>
      </div>
      
      <Separator />
      
      {/* Main content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Calendar column */}
        <div>
          <ReservationCalendarView 
            selectedDate={selectedDate} 
            onSelectDate={handleDateSelect} 
          />
        </div>
        
        {/* Employee reservations column */}
        <div className="md:col-span-2">
          <DailyEmployeeReservations 
            selectedDate={selectedDate} 
            onSelectDate={handleDateSelect}
          />
        </div>
      </div>
    </div>
  );
};