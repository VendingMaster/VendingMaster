import React, { useState, useMemo, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Product, PRODUCT_CATEGORIES } from '@shared/schema';
import { ProductForm } from './ProductForm';
import { calculateGrossPrice, formatPrice } from '@/lib/utils';
import { 
  PencilIcon, 
  TrashIcon, 
  PlusIcon, 
  ChevronDownIcon, 
  ChevronUpIcon, 
  DownloadIcon,
  UploadIcon,
  FileIcon,
  Star,
  StarHalf,
  MessageSquare,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

// Typ dla danych ocen produktów
type ProductRating = {
  productId: number;
  averageRating: number;
  count: number;
};

// Typ dla szczegółowej oceny produktu
type DetailedRating = {
  id: number;
  reservationId: number;
  employeeId: number;
  productId: number;
  rating: number;
  comment?: string;
  createdAt: string;
  employee?: {
    firstName: string;
    lastName: string;
  };
};

export const ProductManagement: React.FC = () => {
  const [isFormVisible, setIsFormVisible] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>(() => {
    // Inicjalizujemy domyślnie wszystkie kategorie jako rozwinięte
    return PRODUCT_CATEGORIES.reduce((acc, category) => {
      acc[category] = true; // true - rozwinięta, false - zwinięta
      return acc;
    }, {} as Record<string, boolean>);
  });
  
  // Stan dla modalu ocen
  const [isRatingsDialogOpen, setIsRatingsDialogOpen] = useState(false);
  const [selectedProductForRatings, setSelectedProductForRatings] = useState<{id: number, name: string} | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  // Pobieranie ocen produktów
  const { data: productRatings } = useQuery<ProductRating[]>({
    queryKey: ['/api/product-ratings'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/product-ratings');
        if (!response.ok) {
          throw new Error('Błąd podczas pobierania ocen produktów');
        }
        return await response.json();
      } catch (error) {
        console.error('Błąd pobierania ocen produktów:', error);
        return [];
      }
    }
  });
  
  // Pobieranie szczegółowych ocen dla wybranego produktu
  const { data: detailedRatings, isLoading: isLoadingDetailedRatings } = useQuery<{success: boolean, ratings: DetailedRating[]}>({
    queryKey: ['/api/product-ratings', selectedProductForRatings?.id, 'details'],
    queryFn: async () => {
      if (!selectedProductForRatings) return { success: false, ratings: [] };
      
      try {
        const response = await fetch(`/api/product-ratings/${selectedProductForRatings.id}/details`);
        if (!response.ok) {
          throw new Error('Błąd podczas pobierania szczegółowych ocen produktu');
        }
        return await response.json();
      } catch (error) {
        console.error('Błąd pobierania szczegółowych ocen:', error);
        throw error;
      }
    },
    enabled: !!selectedProductForRatings?.id,
  });
  
  // Obsługa kliknięcia w oceny produktu
  const handleRatingsClick = (product: Product) => {
    // Sprawdź, czy produkt ma jakiekolwiek oceny
    const productRating = productRatings?.find(r => r.productId === product.id);
    if (!productRating || productRating.count === 0) {
      toast({
        title: "Brak ocen",
        description: "Ten produkt nie ma jeszcze żadnych ocen",
      });
      return;
    }
    
    // Ustaw wybrany produkt i otwórz dialog
    setSelectedProductForRatings({
      id: product.id,
      name: product.name
    });
    setIsRatingsDialogOpen(true);
  };
  
  // Grupuj produkty według kategorii
  const groupedProducts = useMemo(() => {
    if (!products) return {};
    
    return products.reduce((groups, product) => {
      const category = product.category;
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(product);
      return groups;
    }, {} as Record<string, Product[]>);
  }, [products]);
  
  // Funkcja przełączania widoczności kategorii
  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  // Mutacja do obsługi widoczności produktu w portalu pracownika
  const visibilityMutation = useMutation({
    mutationFn: async ({ productId, visible }: { productId: number, visible: boolean }) => {
      return await apiRequest(`/api/products/${productId}`, { 
        method: 'PATCH',
        data: { visibleInEmployeePortal: visible }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Widoczność zaktualizowana",
        description: "Widoczność produktu została zaktualizowana",
      });
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się zaktualizować widoczności produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  const handleToggleVisibility = (productId: number, visible: boolean) => {
    visibilityMutation.mutate({ productId, visible });
  };
  
  // Mutacja do usuwania produktu
  const deleteMutation = useMutation({
    mutationFn: async (productId: number) => {
      return await apiRequest(`/api/products/${productId}`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      toast({
        title: "Produkt usunięty",
        description: "Produkt został pomyślnie usunięty",
      });
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się usunąć produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  const handleAddProduct = () => {
    setSelectedProduct(null);
    setIsFormVisible(true);
  };

  const handleEditProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsFormVisible(true);
  };

  const handleDeleteProduct = async (productId: number) => {
    if (window.confirm('Czy na pewno chcesz usunąć ten produkt? Zostanie on również usunięty ze wszystkich szuflad.')) {
      deleteMutation.mutate(productId);
    }
  };

  // Mutacja do obsługi importu CSV
  const importMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      try {
        const response = await fetch('/api/products/import-csv', {
          method: 'POST',
          body: formData,
        });
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Błąd podczas importu pliku CSV');
        }
        return await response.json();
      } catch (error) {
        throw error;
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      toast({
        title: "Import zakończony",
        description: data.message,
      });
      setIsImporting(false);
      setUploadError(null);
    },
    onError: (error) => {
      setUploadError(error instanceof Error ? error.message : 'Nieznany błąd podczas importu');
      toast({
        title: "Błąd importu",
        description: error instanceof Error ? error.message : 'Nieznany błąd podczas importu',
        variant: "destructive",
      });
      setIsImporting(false);
    }
  });

  // Obsługa wyboru pliku CSV do importu
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files && event.target.files[0];
    if (!file) {
      return;
    }

    // Sprawdzenie typu pliku
    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
      setUploadError('Wybierz plik CSV');
      toast({
        title: "Nieprawidłowy format pliku",
        description: "Wybierz plik CSV",
        variant: "destructive",
      });
      return;
    }

    setIsImporting(true);
    setUploadError(null);

    const formData = new FormData();
    formData.append('file', file);
    importMutation.mutate(formData);
  };

  // Funkcja do pobrania szablonu CSV - generujemy i pobieramy plik dynamicznie
  const handleDownloadTemplate = () => {
    // Zamiast otwierać link, generujemy zawartość szablonu CSV
    const headers = ['name', 'shortDescription', 'longDescription', 'price', 'category', 'weight', 'vatRate', 'purchasePrice', 'allergens', 'ingredients', 'nutritionalValues', 'preparationTime', 'dietaryPreferences', 'imageUrl'];
    
    // Przykładowe dane
    const exampleRow = ['Nazwa produktu', 'Krótki opis', 'Długi opis produktu', '10.99', 'Dania główne', '350', '8', '7.50', 'gluten, mleko', 'Składnik 1, Składnik 2', 'Białko: 10g, Węglowodany: 30g', '15', 'wegetariańskie, bezglutenowe', 'https://przyklad.com/zdjecie.jpg'];
    
    // Utwórz zawartość CSV
    const csvContent = [
      headers.join(';'),
      exampleRow.join(';')
    ].join('\n');
    
    // Dodaj Byte Order Mark (BOM) dla poprawnego kodowania znaków UTF-8
    const BOM = '\uFEFF';
    const csvWithBOM = BOM + csvContent;
    
    // Stwórz Blob i pobierz plik
    const blob = new Blob([csvWithBOM], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'template-produkty.csv');
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Pobieranie rozpoczęte",
      description: "Pobieranie szablonu CSV zostało rozpoczęte"
    });
  };

  return (
    <div>
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <div>
            <h3 className="text-lg font-medium text-gray-800">Zarządzanie Produktami</h3>
            <p className="text-gray-600 mt-1">Dodawanie i edycja produktów dostępnych w automacie</p>
          </div>
          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={handleDownloadTemplate}
              className="flex items-center gap-1"
            >
              <DownloadIcon className="h-4 w-4" />
              <span>Pobierz szablon CSV</span>
            </Button>
            
            <Button 
              variant="outline" 
              onClick={() => fileInputRef.current?.click()}
              disabled={isImporting}
              className="flex items-center gap-1"
            >
              <UploadIcon className="h-4 w-4" />
              <span>{isImporting ? 'Importowanie...' : 'Importuj z CSV'}</span>
            </Button>
            
            <Button onClick={handleAddProduct} className="bg-green-500 hover:bg-green-600">
              <PlusIcon className="h-5 w-5 mr-1" />
              Dodaj Produkt
            </Button>
          </div>
        </div>
        
        {/* Komunikat błędu importu */}
        {uploadError && (
          <div className="mt-2 p-2 text-sm text-red-600 bg-red-50 rounded-md">
            {uploadError}
          </div>
        )}
        
        {/* Ukryty input do wyboru pliku */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".csv"
          className="hidden"
        />
      </div>

      {/* Products List */}
      <div className="bg-white shadow overflow-hidden rounded-md">
        {isLoading ? (
          <div className="space-y-4 p-4">
            {[...Array(3)].map((_, index) => (
              <div key={index} className="flex items-center space-x-4">
                <Skeleton className="h-12 w-12 rounded-md" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
                <Skeleton className="h-8 w-16" />
              </div>
            ))}
          </div>
        ) : !products || products.length === 0 ? (
          <div className="py-8 text-center text-gray-500">
            Brak dostępnych produktów. Kliknij "Dodaj Produkt", aby utworzyć nowy.
          </div>
        ) : (
          <div className="divide-y divide-gray-200">
            {/* Wyświetlanie produktów pogrupowanych według kategorii */}
            {PRODUCT_CATEGORIES.map(category => {
              const categoryProducts = groupedProducts[category] || [];
              // Jeśli kategoria nie ma produktów, nie wyświetlamy jej
              if (categoryProducts.length === 0) return null;
              
              return (
                <div key={category} className="category-section">
                  {/* Nagłówek kategorii */}
                  <div 
                    className="flex items-center justify-between px-4 py-3 bg-gray-50 cursor-pointer"
                    onClick={() => toggleCategory(category)}
                  >
                    <div className="flex items-center">
                      <h3 className="text-base font-medium text-gray-700">{category}</h3>
                      <Badge className="ml-2" variant="outline">{categoryProducts.length}</Badge>
                    </div>
                    {expandedCategories[category] 
                      ? <ChevronUpIcon className="h-5 w-5 text-gray-500" /> 
                      : <ChevronDownIcon className="h-5 w-5 text-gray-500" />
                    }
                  </div>
                  
                  {/* Lista produktów w kategorii */}
                  {expandedCategories[category] && (
                    <ul className="divide-y divide-gray-100">
                      {categoryProducts.map(product => (
                        <li key={product.id}>
                          <div className="px-4 py-4 flex items-center sm:px-6">
                            <div className="min-w-0 flex-1 sm:flex sm:items-center sm:justify-between">
                              <div className="flex items-center">
                                <div className="flex-shrink-0 h-12 w-12 bg-gray-100 rounded-md overflow-hidden">
                                  <img 
                                    src={product.imageUrl} 
                                    alt={product.name} 
                                    className="h-full w-full object-cover" 
                                  />
                                </div>
                                <div className="ml-4">
                                  <div className="flex flex-col gap-1">
                                    <div className="flex items-center">
                                      <h4 className="text-sm font-medium text-gray-900">{product.name}</h4>
                                      {productRatings?.find(r => r.productId === product.id) && (
                                        <div 
                                          className="flex items-center ml-2 cursor-pointer hover:bg-gray-100 p-1 rounded"
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleRatingsClick(product);
                                          }}
                                          title="Kliknij, aby zobaczyć szczegółowe oceny"
                                        >
                                          <div className="flex items-center text-yellow-400">
                                            {Array.from({ length: 5 }).map((_, index) => {
                                              const rating = productRatings?.find(r => r.productId === product.id);
                                              const ratingValue = rating?.averageRating || 0;
                                              
                                              // Pełne gwiazdki
                                              if (index < Math.floor(ratingValue)) {
                                                return <Star key={index} className="h-3.5 w-3.5 fill-current" />;
                                              }
                                              
                                              // Połowa gwiazdki
                                              if (index === Math.floor(ratingValue) && ratingValue % 1 >= 0.3) {
                                                return <StarHalf key={index} className="h-3.5 w-3.5 fill-current" />;
                                              }
                                              
                                              // Pusta gwiazdka
                                              return <Star key={index} className="h-3.5 w-3.5 text-gray-300" />;
                                            })}
                                          </div>
                                          <span className="ml-1 text-xs text-gray-600 flex items-center">
                                            ({productRatings?.find(r => r.productId === product.id)?.count || 0})
                                            <MessageSquare className="ml-1 h-3 w-3 text-gray-500" />
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                    <p className="text-sm text-gray-500">{product.shortDescription}</p>
                                  </div>
                                </div>
                              </div>
                              <div className="mt-4 flex-shrink-0 sm:mt-0 sm:ml-5">
                                <div className="flex space-x-1">
                                  <p className="text-sm font-medium text-primary">
                                    {formatPrice(calculateGrossPrice(product.price, product.vatRate))} zł
                                    <span className="text-xs text-gray-500 ml-1">
                                      brutto (VAT {product.vatRate || "8%"})
                                    </span>
                                  </p>
                                </div>
                              </div>
                            </div>
                            <div className="ml-5 flex-shrink-0 flex space-x-4 items-center">
                              <div className="flex items-center" title="Widoczność w portalu pracownika">
                                <Switch 
                                  id={`visibility-${product.id}`}
                                  checked={product.visibleInEmployeePortal ?? true}
                                  onCheckedChange={(checked) => handleToggleVisibility(product.id, checked)}
                                  className="mr-2"
                                />
                                <Label htmlFor={`visibility-${product.id}`} className="text-xs font-medium text-gray-500">
                                  {product.visibleInEmployeePortal ? "Widoczny" : "Ukryty"}
                                </Label>
                              </div>

                              <div className="flex space-x-2">
                                <button 
                                  className="p-1 rounded-full text-gray-400 hover:text-gray-500"
                                  onClick={() => handleEditProduct(product)}
                                >
                                  <PencilIcon className="h-5 w-5" />
                                </button>
                                <button 
                                  className="p-1 rounded-full text-gray-400 hover:text-red-500"
                                  onClick={() => handleDeleteProduct(product.id)}
                                  disabled={deleteMutation.isPending}
                                >
                                  <TrashIcon className="h-5 w-5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Total Products Count */}
      <div className="mt-6 border-t border-gray-200 pt-4">
        <p className="text-sm text-gray-600 font-medium">
          Łączna ilość produktów: {products?.length || 0}
        </p>
      </div>

      {/* Product Form Modal */}
      <ProductForm 
        product={selectedProduct}
        isOpen={isFormVisible}
        onClose={() => setIsFormVisible(false)}
      />
      
      {/* Modal z oceną produktu */}
      <Dialog open={isRatingsDialogOpen} onOpenChange={setIsRatingsDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              <span>Oceny produktu: {selectedProductForRatings?.name}</span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 mt-4 max-h-[400px] overflow-y-auto pr-2">
            {isLoadingDetailedRatings ? (
              <div className="space-y-4">
                {[...Array(3)].map((_, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-1/3" />
                      <Skeleton className="h-4 w-2/3" />
                      <Skeleton className="h-4 w-5/6" />
                    </div>
                  </div>
                ))}
              </div>
            ) : detailedRatings?.ratings && detailedRatings.ratings.length > 0 ? (
              <>
                {detailedRatings.ratings.map((rating) => (
                  <div key={rating.id} className="bg-gray-50 p-4 rounded-lg space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="text-sm font-medium">
                          {rating.employee ? `${rating.employee.firstName} ${rating.employee.lastName}` : 'Anonim'}
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(rating.createdAt).toLocaleDateString('pl-PL', { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </div>
                      </div>
                      <div className="flex items-center text-yellow-400">
                        {Array.from({ length: 5 }).map((_, index) => (
                          <Star 
                            key={index} 
                            className={`h-4 w-4 ${index < rating.rating ? 'fill-current' : 'text-gray-300'}`} 
                          />
                        ))}
                      </div>
                    </div>
                    
                    {rating.comment && (
                      <div className="text-sm mt-2 bg-white p-3 rounded border border-gray-100">
                        {rating.comment}
                      </div>
                    )}
                  </div>
                ))}
              </>
            ) : (
              <div className="text-center py-8 text-gray-500">
                Brak szczegółowych ocen dla tego produktu.
              </div>
            )}
          </div>
          
          <div className="mt-4 flex justify-end">
            <Button onClick={() => setIsRatingsDialogOpen(false)}>
              Zamknij
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
