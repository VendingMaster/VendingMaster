import React, { useState, useEffect } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertCircle, RefreshCw, Download, FileSpreadsheet, AlertTriangle } from 'lucide-react';

// Interfejs dla danych temperaturowych
interface TemperatureData {
  time: string;
  temperature: number;
  humidity?: number;  // Opcjonalne pole wilgotności
  timestamp?: Date;   // Opcjonalne pole timestamp dla sortowania i formatowania
}

// Symulacja danych temperaturowych
const generateRandomTemperatureData = (count: number, range: '1h' | '24h' | '7d' | '30d' = '24h'): TemperatureData[] => {
  const data: TemperatureData[] = [];
  const now = new Date();
  
  // Określ interwał czasowy na podstawie zakresu
  let interval: number;
  let unit: 'minutes' | 'hours' | 'days' = 'minutes';
  
  switch (range) {
    case '1h':
      interval = 5; // Co 5 minut
      unit = 'minutes';
      break;
    case '24h':
      interval = 15; // Co 15 minut
      unit = 'minutes';
      break;
    case '7d':
      interval = 1; // Co godzinę
      unit = 'hours';
      break;
    case '30d':
      interval = 4; // Co 4 godziny
      unit = 'hours';
      break;
    default:
      interval = 15;
      unit = 'minutes';
  }
  
  for (let i = count - 1; i >= 0; i--) {
    const time = new Date(now);
    
    if (unit === 'minutes') {
      time.setMinutes(time.getMinutes() - i * interval);
    } else if (unit === 'hours') {
      time.setHours(time.getHours() - i * interval);
    } else {
      time.setDate(time.getDate() - i * interval);
    }
    
    // Temperatura między 2°C a 6°C z małymi wahaniami dzień/noc
    let baseTemp = 4;
    if (range === '7d' || range === '30d') {
      const hour = time.getHours();
      if (hour >= 8 && hour <= 18) {
        baseTemp += 0.3; // Dzień nieco cieplejszy
      }
    }
    const temperature = +(baseTemp + (Math.random() * 1.5 - 0.75)).toFixed(1);
    
    // Format czasu zależy od zakresu
    let timeString: string;
    if (range === '1h' || range === '24h') {
      timeString = time.toLocaleTimeString('pl-PL', { 
        hour: '2-digit', 
        minute: '2-digit'
      });
    } else if (range === '7d') {
      timeString = time.toLocaleDateString('pl-PL', { 
        day: '2-digit',
        month: '2-digit'
      }) + ' ' + time.toLocaleTimeString('pl-PL', { 
        hour: '2-digit'
      });
    } else {
      timeString = time.toLocaleDateString('pl-PL', { 
        day: '2-digit',
        month: '2-digit'
      });
    }
    
    data.push({ 
      time: timeString, 
      temperature,
      humidity: Math.round(40 + Math.random() * 40),
      timestamp: time
    });
  }
  
  return data;
};

export const TemperaturePanel: React.FC = () => {
  const [temperatureData, setTemperatureData] = useState<TemperatureData[]>([]);
  // Zakres czasu do wyświetlenia: 1h, 24h, 7d, 30d
  const [timeRange, setTimeRange] = useState<'1h' | '24h' | '7d' | '30d'>('24h');
  // Stan do śledzenia, czy zakres czasu został zmieniony przez użytkownika
  const [timeRangeChanged, setTimeRangeChanged] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState(false);
  const [minTemperature, setMinTemperature] = useState<number>(10);
  const [maxTemperature, setMaxTemperature] = useState<number>(24);
  
  // Funkcja do ładowania danych na podstawie wybranego zakresu czasu
  const loadData = async () => {
    setIsLoading(true);
    console.log(`Ładowanie danych dla zakresu: ${timeRange}...`);
    
    try {
      // Obliczamy daty początku i końca na podstawie wybranego zakresu czasu
      const endDate = new Date();
      const startDate = new Date();
      
      switch (timeRange) {
        case '1h':
          startDate.setHours(endDate.getHours() - 1);
          break;
        case '24h':
          startDate.setHours(endDate.getHours() - 24);
          break;
        case '7d':
          startDate.setDate(endDate.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(endDate.getDate() - 30);
          break;
        default:
          startDate.setHours(endDate.getHours() - 24);
      }
      
      console.log(`Pobieranie danych z okresu: ${startDate.toISOString()} -> ${endDate.toISOString()}`);
      
      // Pobieramy dane z API z określonego zakresu czasowego
      const response = await fetch(`/api/temperature/range?start=${startDate.toISOString()}&end=${endDate.toISOString()}`);
      const readings = await response.json();
      
      if (Array.isArray(readings) && readings.length > 0) {
        console.log(`Odebrano ${readings.length} odczytów z API`);
        
        // Dane powinny już być odfiltrowane przez backend, ale dla pewności sprawdzamy daty
        const validReadings = readings.every((reading: any) => {
          const readingTime = new Date(reading.timestamp);
          return !isNaN(readingTime.getTime());
        });
        
        if (!validReadings) {
          console.warn("Niektóre odczyty mają nieprawidłowe znaczniki czasowe");
        }
        
        console.log(`Otrzymano ${readings.length} odczytów z wybranego zakresu czasu`);
        
        // Przekształcamy dane do formatu używanego przez wykres
        const formattedData = readings.map((reading: any) => {
          // Jeśli mamy timestamp jako string, konwertujemy na Date
          const readingTime = reading.time instanceof Date 
            ? reading.time 
            : reading.timestamp 
              ? new Date(reading.timestamp) 
              : new Date();
          
          // Format czasu zależy od wybranego zakresu
          let timeFormat: string;
          if (timeRange === '1h' || timeRange === '24h') {
            timeFormat = readingTime.toLocaleTimeString('pl-PL', { 
              hour: '2-digit', 
              minute: '2-digit'
            });
          } else if (timeRange === '7d') {
            // Dla 7 dni pokazujemy dzień i godzinę
            timeFormat = readingTime.toLocaleDateString('pl-PL', { 
              day: '2-digit',
              month: '2-digit'
            }) + ' ' + readingTime.toLocaleTimeString('pl-PL', { 
              hour: '2-digit'
            });
          } else {
            // Dla 30 dni pokazujemy tylko datę
            timeFormat = readingTime.toLocaleDateString('pl-PL', { 
              day: '2-digit',
              month: '2-digit'
            });
          }
              
          return {
            time: timeFormat,
            temperature: reading.temperature,
            humidity: reading.humidity,
            timestamp: readingTime // Zachowujemy oryginalny timestamp dla sortowania
          };
        });
        
        // Sortujemy dane według timestamp (od najnowszego do najstarszego)
        formattedData.sort((a: any, b: any) => {
          return b.timestamp.getTime() - a.timestamp.getTime();
        });
        
        // Ograniczamy liczbę punktów dla danego zakresu
        let limitedData = formattedData;
        if (timeRange === '1h' && formattedData.length > 60) {
          limitedData = formattedData.slice(0, 60);
          console.log(`Ograniczono liczbę punktów dla zakresu 1h do ${limitedData.length}`);
        } else if (timeRange === '24h' && formattedData.length > 288) {
          limitedData = formattedData.slice(0, 288);
          console.log(`Ograniczono liczbę punktów dla zakresu 24h do ${limitedData.length}`);
        }
        
        // Sprawdzamy, czy mamy aktualne dane (z ostatnich 2 minut)
        const newestReading = readings.length > 0 ? readings[0] : null;
        if (newestReading && Math.abs(new Date(newestReading.timestamp).getTime() - Date.now()) < 120000) {
          setDataSource('realtime');
          setLastTimestamp(newestReading.timestamp);
        } else {
          setDataSource('historic');
          setLastTimestamp(newestReading?.timestamp || null);
        }
        
        console.log(`Ustawiam ${limitedData.length} punktów danych na wykresie`);
        setTemperatureData(limitedData);
        setTimeRangeChanged(false); // Zresetuj flagę zmiany zakresu
      } else {
        // Jeśli nie ma danych lub wystąpił błąd, używamy symulowanych danych
        console.log('Brak danych z czujników - używamy symulowanych danych');
        let dataCount;
        switch (timeRange) {
          case '1h': dataCount = 12; break;  // Odczyt co 5 minut
          case '24h': dataCount = 96; break; // Odczyt co 15 minut
          case '7d': dataCount = 168; break; // Odczyt co godzinę
          case '30d': dataCount = 180; break; // Odczyt co 4 godziny
          default: dataCount = 96;
        }
        
        setDataSource('simulated');
        setLastTimestamp(null);
        const newData = generateRandomTemperatureData(dataCount, timeRange);
        setTemperatureData(newData);
        setTimeRangeChanged(false); // Zresetuj flagę zmiany zakresu
      }
    } catch (error) {
      console.error('Błąd podczas pobierania danych temperatury:', error);
      // W przypadku błędu używamy symulowanych danych
      let dataCount;
      switch (timeRange) {
        case '1h': dataCount = 12; break;  // Odczyt co 5 minut
        case '24h': dataCount = 96; break; // Odczyt co 15 minut
        case '7d': dataCount = 168; break; // Odczyt co godzinę
        case '30d': dataCount = 180; break; // Odczyt co 4 godziny
        default: dataCount = 96;
      }
      setDataSource('simulated');
      setLastTimestamp(null);
      const newData = generateRandomTemperatureData(dataCount, timeRange);
      setTemperatureData(newData);
      setTimeRangeChanged(false); // Zresetuj flagę zmiany zakresu
    } finally {
      setIsLoading(false);
    }
  };
  
  // Zmienna do przechowywania informacji o ostatnich danych
  const [dataSource, setDataSource] = useState<'realtime' | 'historic' | 'simulated'>('simulated');
  const [lastTimestamp, setLastTimestamp] = useState<string | null>(null);
  
  // Ładowanie ustawień temperatury
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch('/api/settings');
        const data = await response.json();
        
        if (data) {
          setMinTemperature(data.minTemperature || 10);
          setMaxTemperature(data.maxTemperature || 24);
          console.log(`Załadowano ustawienia temperatur: min=${data.minTemperature}°C, max=${data.maxTemperature}°C`);
        }
      } catch (error) {
        console.error('Błąd podczas pobierania ustawień temperatury:', error);
      }
    };
    
    fetchSettings();
  }, []);

  // Ładowanie danych przy pierwszym renderowaniu oraz przy zmianie zakresu czasu
  useEffect(() => {
    loadData();
    
    // Ustaw automatyczne odświeżanie co 30 sekund
    const refreshInterval = setInterval(() => {
      console.log("Automatyczne odświeżanie danych temperatury...");
      loadData();
    }, 30000); // 30 sekund
    
    // Sprzątanie - usunięcie interwału przy odmontowaniu komponentu
    return () => clearInterval(refreshInterval);
  }, [timeRange]);
  
  // Znalezienie minimalnej i maksymalnej temperatury na wykresie
  const minTemp = Math.min(...temperatureData.map(d => d.temperature));
  const maxTemp = Math.max(...temperatureData.map(d => d.temperature));
  
  // Sprawdzenie, czy wszystkie temperatury są w bezpiecznym zakresie
  const allTempsInSafeRange = temperatureData.every(d => 
    d.temperature >= minTemperature && d.temperature <= maxTemperature
  );
  
  // Liczba odczytów poza bezpiecznym zakresem
  const outOfRangeCount = temperatureData.filter(d => 
    d.temperature < minTemperature || d.temperature > maxTemperature
  ).length;
  
  // Sprawdzenie, czy wystąpił gwałtowny skok temperatury (więcej niż 1°C w ciągu jednego odczytu)
  let tempChangeAlert = false;
  let maxTempChange = 0;
  
  if (temperatureData.length > 1) {
    for (let i = 0; i < temperatureData.length - 1; i++) {
      const tempChange = Math.abs(temperatureData[i].temperature - temperatureData[i+1].temperature);
      if (tempChange > maxTempChange) maxTempChange = tempChange;
      if (tempChange >= 1.0) {
        tempChangeAlert = true;
        break;
      }
    }
  }
  
  // Funkcja do generowania pliku Excel z danymi temperaturowymi
  const generateExcel = () => {
    // Tworzenie CSV zawartości
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Dodanie nagłówków
    csvContent += "Data,Godzina,Temperatura (°C)";
    if (temperatureData.some(d => d.humidity !== undefined)) {
      csvContent += ",Wilgotność (%)";
    }
    csvContent += "\n";
    
    // Dodanie danych
    const now = new Date();
    const dateStr = now.toLocaleDateString('pl-PL'); // Format: DD.MM.YYYY
    
    temperatureData.forEach(data => {
      csvContent += `${dateStr},${data.time},${data.temperature}`;
      if (data.humidity !== undefined) {
        csvContent += `,${data.humidity}`;
      }
      csvContent += "\n";
    });
    
    // Tworzenie elementu do pobrania
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    
    // Ustalenie nazwy pliku
    const fileName = `temperatura_${now.toISOString().split('T')[0]}.csv`;
    link.setAttribute("download", fileName);
    
    // Symulacja kliknięcia w link
    document.body.appendChild(link);
    link.click();
    
    // Czyszczenie
    document.body.removeChild(link);
  };
  
  return (
    <div>
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-800 mb-3">Monitoring Temperatury</h3>
        <p className="text-gray-600 text-sm">Wyświetla historię temperatur w automacie w czasie rzeczywistym.</p>
      </div>
      
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Select 
            value={timeRange} 
            onValueChange={(value: '1h' | '24h' | '7d' | '30d') => {
              console.log(`Zmiana zakresu czasu na: ${value}`);
              setTimeRangeChanged(true);
              setTimeRange(value);
              // Będzie załadowany automatycznie przez useEffect
            }}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Wybierz okres" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1h">1 godzina</SelectItem>
              <SelectItem value="24h">24 godziny</SelectItem>
              <SelectItem value="7d">7 dni</SelectItem>
              <SelectItem value="30d">30 dni</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center gap-1"
            onClick={loadData}
            disabled={isLoading}
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
            Odśwież
          </Button>
        </div>
        
        {!allTempsInSafeRange && (
          <div className="flex items-center text-red-500 text-sm">
            <AlertCircle className="h-4 w-4 mr-1" />
            Wykryto temperatury poza bezpiecznym zakresem {minTemperature}°C - {maxTemperature}°C
          </div>
        )}
      </div>
      
      <Card className="p-6">
        <div className="mb-4">
          <div className="flex items-center justify-between">
            <h4 className="text-lg font-medium">Wykres Temperatury</h4>
            <div className="flex items-center">
              <div className="flex items-center mr-4">
                <div className="h-3 w-3 rounded-full bg-blue-500 mr-1"></div>
                <span className="text-sm text-gray-600">Temperatura (°C)</span>
              </div>
              {temperatureData.some(d => d.humidity !== undefined) && (
                <div className="flex items-center">
                  <div className="h-3 w-3 rounded-full bg-green-500 mr-1"></div>
                  <span className="text-sm text-gray-600">Wilgotność (%)</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center justify-between mt-2">
            <div className="text-sm text-gray-500">
              <span className="font-medium">{minTemp.toFixed(1)}°C</span> min / <span className="font-medium">{maxTemp.toFixed(1)}°C</span> max
              {temperatureData.length > 0 && (
                <div className="mt-1">
                  Liczba pomiarów: <span className="font-medium">{temperatureData.length}</span>
                </div>
              )}
            </div>
            <div className="text-sm text-gray-500">
              Ostatnia aktualizacja: <span className="font-medium">
                {lastTimestamp 
                  ? new Date(lastTimestamp).toLocaleTimeString('pl-PL') 
                  : new Date().toLocaleTimeString('pl-PL')
                }
              </span>
              {temperatureData.length > 0 && (
                <div className="mt-1">
                  Dane: {
                    dataSource === 'realtime' 
                      ? <span className="text-green-500">Aktualne (z czujnika)</span>
                      : dataSource === 'historic'
                        ? <span>Historyczne</span> 
                        : <span className="text-yellow-500">Symulowane</span>
                  }
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={temperatureData}
              margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="time" 
                tick={{ fontSize: 12 }} 
                interval={
                  timeRange === '1h' ? Math.max(1, Math.floor(temperatureData.length / 12)) :
                  timeRange === '7d' ? Math.max(1, Math.floor(temperatureData.length / 24)) :
                  timeRange === '30d' ? Math.max(1, Math.floor(temperatureData.length / 15)) :
                  Math.max(1, Math.floor(temperatureData.length / 8))
                }
              />
              {/* Oś Y dla temperatury */}
              <YAxis 
                domain={[Math.floor(Math.min(1.5, minTemp - 0.5)), Math.ceil(Math.max(6.5, maxTemp + 0.5))]}
                tick={{ fontSize: 12 }}
                tickFormatter={(value) => `${value}°C`}
              />
              
              {/* Oś Y dla wilgotności */}
              {temperatureData.some(d => d.humidity !== undefined) && (
                <YAxis 
                  yAxisId="right" 
                  orientation="right"
                  domain={[0, 100]}
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `${value}%`}
                />
              )}
              <Tooltip 
                formatter={(value: number, name: string) => {
                  if (name === 'Temperatura') return [`${value}°C`, name];
                  if (name === 'Wilgotność') return [`${value}%`, name];
                  return [value, name];
                }}
                labelFormatter={(label) => `Czas: ${label}`}
              />
              <Legend />
              
              {/* Linie referencyjne dla bezpiecznego zakresu */}
              <ReferenceLine 
                y={minTemperature} 
                stroke="red" 
                strokeDasharray="3 3" 
                label={{ 
                  value: `Min ${minTemperature}°C`, 
                  position: 'insideBottomLeft', 
                  fill: 'red', 
                  fontSize: 12 
                }} 
              />
              <ReferenceLine 
                y={maxTemperature} 
                stroke="red" 
                strokeDasharray="3 3" 
                label={{ 
                  value: `Max ${maxTemperature}°C`, 
                  position: 'insideTopLeft', 
                  fill: 'red', 
                  fontSize: 12 
                }} 
              />
              
              <Line 
                type="monotone" 
                dataKey="temperature" 
                stroke="#3b82f6" 
                strokeWidth={2}
                activeDot={{ r: 5 }}
                animationDuration={500}
                name="Temperatura"
                // Kolorowanie punktów w zależności od tego, czy są w zakresie czy nie
                dot={(props) => {
                  const temp = props.payload.temperature;
                  return (
                    <circle
                      key={`temp-dot-${props.cx}-${props.cy}`}
                      cx={props.cx}
                      cy={props.cy}
                      r={3}
                      fill={temp >= minTemperature && temp <= maxTemperature ? "#3b82f6" : "#ef4444"}
                    />
                  );
                }}
              />
              
              {temperatureData.some(d => d.humidity !== undefined) && (
                <Line 
                  type="monotone" 
                  dataKey="humidity" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  activeDot={{ r: 4 }}
                  animationDuration={500}
                  name="Wilgotność"
                  yAxisId="right"
                />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <div className="text-sm text-gray-500">
            Dane są pobierane z czujników co 15 minut.
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            className="flex items-center gap-1"
            onClick={generateExcel}
            disabled={temperatureData.length === 0}
          >
            <FileSpreadsheet className="h-4 w-4" />
            Eksportuj do Excel
          </Button>
        </div>
      </Card>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="p-6">
          <h4 className="text-lg font-medium mb-4">Statystyki Temperatur</h4>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Średnia temperatura:</span>
              <span className="font-medium">
                {(temperatureData.reduce((sum, item) => sum + item.temperature, 0) / temperatureData.length).toFixed(1)}°C
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Minimalna temperatura:</span>
              <span className="font-medium">{minTemp.toFixed(1)}°C</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Maksymalna temperatura:</span>
              <span className="font-medium">{maxTemp.toFixed(1)}°C</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Odchylenie standardowe:</span>
              <span className="font-medium">
                {(Math.sqrt(
                  temperatureData.reduce((sum, item) => {
                    const avg = temperatureData.reduce((s, i) => s + i.temperature, 0) / temperatureData.length;
                    return sum + Math.pow(item.temperature - avg, 2);
                  }, 0) / temperatureData.length
                )).toFixed(2)}°C
              </span>
            </div>
            {outOfRangeCount > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Odczyty poza zakresem:</span>
                <span className="font-medium text-red-500">
                  {outOfRangeCount} z {temperatureData.length} ({((outOfRangeCount / temperatureData.length) * 100).toFixed(1)}%)
                </span>
              </div>
            )}
            
            {/* Statystyki wilgotności, jeśli dostępne */}
            {temperatureData.some(d => d.humidity !== undefined) && (
              <>
                <div className="border-t border-gray-200 my-3 pt-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 font-medium">Statystyki wilgotności:</span>
                  </div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Średnia wilgotność:</span>
                  <span className="font-medium">
                    {(temperatureData.reduce((sum, item) => sum + (item.humidity || 0), 0) / temperatureData.length).toFixed(1)}%
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Min/Max wilgotność:</span>
                  <span className="font-medium">
                    {Math.min(...temperatureData.map(d => d.humidity || 0)).toFixed(1)}% / {Math.max(...temperatureData.map(d => d.humidity || 0)).toFixed(1)}%
                  </span>
                </div>
              </>
            )}
          </div>
        </Card>
        
        <Card className="p-6">
          <h4 className="text-lg font-medium mb-4">Informacje o Systemie</h4>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Częstotliwość odczytu:</span>
              <span className="font-medium">Co 15 minut</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Ostatni odczyt:</span>
              <span className="font-medium">
                {temperatureData.length > 0 
                  ? `${temperatureData[0].time} (${temperatureData[0].temperature}°C${temperatureData[0].humidity ? `, ${temperatureData[0].humidity}% wilg.` : ''})`
                  : 'N/A'
                }
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Status systemu:</span>
              <span className={`font-medium ${allTempsInSafeRange ? 'text-green-500' : 'text-red-500'}`}>
                {allTempsInSafeRange ? 'Optymalny' : 'Wymaga uwagi'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Bezpieczny zakres:</span>
              <span className="font-medium">{minTemperature}°C - {maxTemperature}°C</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Największa zmiana:</span>
              <span className={`font-medium ${maxTempChange >= 1.0 ? 'text-amber-500' : ''}`}>
                {maxTempChange.toFixed(1)}°C {maxTempChange >= 1.0 && '⚠️'}
              </span>
            </div>
            {tempChangeAlert && (
              <div className="mt-2 p-2 bg-amber-50 border border-amber-200 rounded-md text-amber-700 text-sm">
                <div className="flex items-center">
                  <AlertTriangle className="h-4 w-4 mr-1" />
                  <span>Wykryto gwałtowną zmianę temperatury (≥1°C)</span>
                </div>
                <p className="mt-1 text-xs">Sprawdź czy drzwi urządzenia są prawidłowo zamknięte.</p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};