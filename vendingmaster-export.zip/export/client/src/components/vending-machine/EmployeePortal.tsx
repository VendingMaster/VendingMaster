import React, { useState, useEffect, createContext, useRef } from "react";
import { Brain, LogOut, Menu, User, ShoppingBasket, History, UserCircle, Download, Maximize, Minimize, ClipboardList, Apple, Loader2 } from "lucide-react";

import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Toaster } from "@/components/ui/toaster";
import { useToast } from "@/hooks/use-toast";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProductSelection } from "@/components/vending-machine/employee-portal/ProductSelection";
import { MealHistory } from "@/components/vending-machine/employee-portal/MealHistory";
import { Orders } from "@/components/vending-machine/employee-portal/Orders";
import { DietaryPreferences } from "@/components/vending-machine/employee-portal/DietaryPreferences";
import { Profile } from "@/components/vending-machine/employee-portal/Profile";
import { Employee, Settings } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQuery } from "@tanstack/react-query";

// Kontekst do dzielenia informacji między komponentami
export interface EditReservation {
  id: number;
  productId: number;
  reservedForDate: string;
}

export interface PortalContextType {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedReservationDate: string | null;
  setSelectedReservationDate: (date: string | null) => void;
  editReservation: EditReservation | null;
  setEditReservation: (reservation: EditReservation | null) => void;
}

export const PortalContext = createContext<PortalContextType | null>(null);

export const EmployeePortal: React.FC = () => {
  const { toast } = useToast();
  const [emailInput, setEmailInput] = useState<string>("");
  const [passwordInput, setPasswordInput] = useState<string>("");
  const [authenticated, setAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>("products");
  const [selectedReservationDate, setSelectedReservationDate] = useState<string | null>(null);
  const [editReservation, setEditReservation] = useState<EditReservation | null>(null);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState<boolean>(false);
  
  // Po zmianie zakładki przewijamy stronę do góry
  // Użyjemy tutaj referencji do głównego kontenera treści oraz do każdej zakładki
  const mainContentRef = useRef<HTMLDivElement>(null);
  const productsTabRef = useRef<HTMLDivElement>(null);
  const ordersTabRef = useRef<HTMLDivElement>(null);
  const historyTabRef = useRef<HTMLDivElement>(null);
  const dietaryTabRef = useRef<HTMLDivElement>(null);
  const profileTabRef = useRef<HTMLDivElement>(null);
  
  // Zaawansowana funkcja przewijania strony do góry
  const scrollToTop = () => {
    console.log("Wywołano funkcję scrollToTop");
    
    // Funkcja przewijania wszystkich możliwych elementów
    const scrollAllElements = () => {
      // Przewijanie głównych elementów dokumentu
      document.documentElement.scrollTop = 0; // Firefox
      document.body.scrollTop = 0; // Safari
      window.scrollTo({
        top: 0,
        behavior: 'auto'
      }); // Chrome/inne
      
      // Przewijanie głównego kontenera
      if (mainContentRef.current) {
        mainContentRef.current.scrollTop = 0;
      }
      
      // Przewijanie dla widocznej zakładki
      const scrollActiveTabContent = () => {
        // Użyj odpowiedniej referencji w zależności od aktywnej zakładki
        let activeTabRef = null;
        
        switch (activeTab) {
          case 'products':
            activeTabRef = productsTabRef;
            break;
          case 'orders':
            activeTabRef = ordersTabRef;
            break;
          case 'history':
            activeTabRef = historyTabRef;
            break;
          case 'dietary':
            activeTabRef = dietaryTabRef;
            break;
          case 'profile':
            activeTabRef = profileTabRef;
            break;
        }
        
        // Jeśli mamy referencję do aktywnej zakładki, przewiń jej zawartość
        if (activeTabRef && activeTabRef.current) {
          console.log(`Przewijanie zakładki ${activeTab}`);
          activeTabRef.current.scrollTop = 0;
        }
        
        // Dodatkowo spróbuj przewinąć kontener z ID
        const portalContentId = `portal-content-${activeTab}`;
        const portalContent = document.getElementById(portalContentId);
        if (portalContent) {
          console.log(`Przewijanie elementu o ID: ${portalContentId}`);
          portalContent.scrollTop = 0;
          
          // Przewinięcie również all divs wewnątrz tego kontenera
          const divs = portalContent.querySelectorAll('div');
          divs.forEach(div => {
            div.scrollTop = 0;
          });
        }
      };
      
      scrollActiveTabContent();
    };
    
    // Natychmiastowe przewinięcie
    scrollAllElements();
    
    // Sekwencja późniejszych przewijanek (rozwiązuje problemy z opóźnionym renderowaniem)
    const intervals = [10, 50, 150, 300, 500];
    
    // Utwórz timeouty dla każdego interwału
    intervals.forEach(delay => {
      setTimeout(() => {
        console.log(`Przewijanie - ${delay}ms`);
        scrollAllElements();
      }, delay);
    });
    
    // Ostatnia próba po jeszcze dłuższym czasie (dla zapewnienia, że wszystko się załadowało)
    setTimeout(() => {
      console.log("Finalne przewijanie - 800ms");
      scrollAllElements();
      
      // Ostatnia desperacka próba - wymuszenie przewijania okien
      document.querySelectorAll('div, section, main').forEach(el => {
        if (el instanceof HTMLElement) {
          el.scrollTop = 0;
        }
      });
    }, 800);
  };
  
  // Efekt do przewijania na górę przy zmianie zakładki
  useEffect(() => {
    console.log(`Zmieniono zakładkę na: ${activeTab} - wymuszam przewijanie do góry`);
    
    // Natychmiastowe wymuszenie przewijania do góry
    window.scrollTo(0, 0);
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
    
    // Resetowanie historii przewijania - to wymusza przewijanie do góry niezależnie od wcześniejszej pozycji
    if ('scrollRestoration' in history) {
      history.scrollRestoration = 'manual';
    }
    
    // Wyśrodkowanie na naszej kotwicy
    const anchor = document.getElementById('top-anchor');
    if (anchor) {
      anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
    }
    
    // Możemy też spróbować sztuczki z użyciem position:fixed aby wymusić przewinięcie,
    // a następnie przywrócenie normalnego zachowania
    document.body.style.position = 'fixed';
    document.body.style.top = '0';
    setTimeout(() => {
      document.body.style.position = '';
      document.body.style.top = '';
      window.scrollTo(0, 0);
    }, 10);
    
    // Seria przewijanek z opóźnieniami, które pomogą obsłużyć sytuację,
    // gdy zakładka wymaga czasu na załadowanie
    const delays = [50, 100, 200, 300, 500];
    delays.forEach(delay => {
      setTimeout(() => {
        window.scrollTo(0, 0);
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        
        if (anchor) {
          anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
        }
        
        // Również przewiń zakładkę, jeśli istnieje
        const tabContent = document.getElementById(`portal-content-${activeTab}`);
        if (tabContent) {
          tabContent.scrollTop = 0;
        }
      }, delay);
    });
    
    // Nie zmieniamy już hashu URL, bo to powoduje przeładowanie strony
    // Zamiast tego, możemy użyć history.pushState aby zaktualizować URL bez przeładowania
    const url = new URL(window.location.href);
    url.searchParams.set('tab', activeTab);
    // Dodajemy tab do stanu historii, aby przycisk wstecz działał poprawnie
    history.pushState({ tab: activeTab }, '', `#${activeTab}`);
  }, [activeTab]);
  
  // Dodajemy nasłuchiwanie na zmianę hasha URL, aby wymuszać przewijanie
  useEffect(() => {
    const handleHashChange = () => {
      console.log("Zmieniono hash URL - wymuszam przewijanie");
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
    };
    
    // Obsługa przycisku wstecz w przeglądarce
    const handlePopState = (event: PopStateEvent) => {
      console.log("Wykryto naciśnięcie przycisku wstecz", event.state);
      
      if (event.state && event.state.tab) {
        // Ustawiamy odpowiednią zakładkę na podstawie stanu historii
        setActiveTab(event.state.tab);
      } else {
        // Jeśli nie ma stanu, sprawdzamy hash URL
        const hash = window.location.hash.replace('#', '');
        if (hash && ['products', 'orders', 'history', 'dietary', 'profile'].includes(hash)) {
          setActiveTab(hash);
        } else {
          // Domyślnie wracamy do zakładki produktów
          setActiveTab('products');
        }
      }
      
      // Przewijamy stronę do góry
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
    };
    
    window.addEventListener('hashchange', handleHashChange);
    window.addEventListener('popstate', handlePopState);
    
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);
  
  // Obsługa instalacji PWA
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      // Zapobieganie automatycznemu pokazaniu komunikatu o instalacji
      e.preventDefault();
      // Przechowanie zdarzenia, aby pokazać je później
      setDeferredPrompt(e);
      // Ustawienie flagi, że aplikacja może być zainstalowana
      setIsInstallable(true);
    };
    
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);
  
  // Funkcja obsługująca instalację PWA
  const handleInstallClick = () => {
    if (!deferredPrompt) {
      return;
    }
    
    // Pokazanie komunikatu o instalacji
    deferredPrompt.prompt();
    
    // Czekaj na wybór użytkownika
    deferredPrompt.userChoice.then((choiceResult: { outcome: string }) => {
      if (choiceResult.outcome === 'accepted') {
        toast({
          title: "Instalacja rozpoczęta",
          description: "Dziękujemy za zainstalowanie naszej aplikacji!",
        });
      }
      // Reset stanu promptu
      setDeferredPrompt(null);
      setIsInstallable(false);
    });
  };
  
  // Stan pełnego ekranu
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Automatyczne uruchamianie trybu pełnoekranowego
  useEffect(() => {
    // Funkcja do przejścia na pełny ekran
    const goFullScreen = () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
          console.error(`Błąd przejścia do trybu pełnoekranowego: ${err.message}`);
        });
      }
    };
    
    // Próba automatycznego uruchomienia trybu pełnoekranowego po 1 sekundzie
    const timeoutId = setTimeout(goFullScreen, 1000);
    
    // Sprawdzanie stanu pełnego ekranu
    const checkFullscreen = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', checkFullscreen);
    
    // Zdefiniowanie obsługi zdarzeń dotykowych, aby umożliwić wejście w tryb pełnoekranowy na urządzeniach mobilnych
    const handleUserGesture = () => {
      if (!document.fullscreenElement) {
        goFullScreen();
      }
      // Usunięcie nasłuchiwaczy po pierwszym dotknięciu
      document.removeEventListener('touchstart', handleUserGesture);
      document.removeEventListener('click', handleUserGesture);
    };
    
    // Dodanie nasłuchiwaczy na zdarzenia dotykowe
    document.addEventListener('touchstart', handleUserGesture);
    document.addEventListener('click', handleUserGesture);
    
    // Sprawdź stan początkowy
    checkFullscreen();
    
    return () => {
      clearTimeout(timeoutId);
      document.removeEventListener('fullscreenchange', checkFullscreen);
      document.removeEventListener('touchstart', handleUserGesture);
      document.removeEventListener('click', handleUserGesture);
    };
  }, []);
  
  // Funkcja przełączająca tryb pełnoekranowy
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(err => {
        toast({
          title: "Błąd",
          description: "Nie udało się aktywować trybu pełnoekranowego",
          variant: "destructive"
        });
        console.error(`Błąd przejścia do trybu pełnoekranowego: ${err.message}`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => {
          setIsFullscreen(false);
        });
      }
    }
  };
  
  // Pobieranie ustawień z serwera
  const { data: settings } = useQuery<Settings>({
    queryKey: ["/api/settings"],
    staleTime: 1000 * 60 * 5, // 5 minut
  });
  
  // Tworzenie hardkodowanego pracownika na potrzeby testów
  const sampleEmployee = {
    id: 1,
    firstName: "Jan",
    lastName: "Kowalski",
    email: "jan.kowalski@example.com",
    rfidCardNumber: "123456789",
    rfidCardFormat: "decimal",
    dietaryPreference: null
  } as Employee;
  
  const [currentEmployee, setCurrentEmployee] = useState<Employee | null>(null);

  // Inicjalizacja danych pracownika z localStorage przy starcie
  // Oraz obsługa parametrów URL dla zmiany zakładek
  useEffect(() => {
    try {
      // Sprawdź parametry URL, aby ustawić aktywną zakładkę
      const params = new URLSearchParams(window.location.search);
      const tabParam = params.get('tab');
      
      if (tabParam && ['products', 'orders', 'history', 'dietary', 'profile'].includes(tabParam)) {
        console.log(`Ustawiam zakładkę na podstawie parametru URL: ${tabParam}`);
        setActiveTab(tabParam);
      }
      
      // Próba pobrania danych pracownika z localStorage
      const savedEmployeeData = localStorage.getItem('currentEmployee');
      
      if (savedEmployeeData) {
        try {
          const parsedEmployee = JSON.parse(savedEmployeeData) as Employee;
          
          // Sprawdź, czy wszystkie wymagane pola są obecne
          if (parsedEmployee && 
              parsedEmployee.id && 
              parsedEmployee.firstName && 
              parsedEmployee.lastName) {
                
            setCurrentEmployee(parsedEmployee);
            setAuthenticated(true);
            // Ustaw zakładkę "Posiłki" jako domyślną po zalogowaniu
            setActiveTab("products");
            console.log('Przywrócono dane pracownika z localStorage:', parsedEmployee);
            
            // Wyświetl toast z informacją o zalogowaniu
            toast({
              title: "Sesja przywrócona",
              description: `Witaj ponownie, ${parsedEmployee.firstName} ${parsedEmployee.lastName}!`,
            });
          } else {
            console.warn('Niepełne dane pracownika w localStorage');
            localStorage.removeItem('currentEmployee');
          }
        } catch (parseError) {
          console.error('Błąd parsowania danych z localStorage:', parseError);
          localStorage.removeItem('currentEmployee');
        }
      }
    } catch (error) {
      console.error('Błąd podczas odczytywania danych z localStorage:', error);
    }
  }, []);

  // Funkcja uwierzytelniająca za pomocą emaila i hasła
  const authenticateWithEmail = async () => {
    try {
      console.log(`Próba logowania przez email: ${emailInput}`);
      
      if (!emailInput || !passwordInput) {
        toast({
          title: "Wypełnij wszystkie pola",
          description: "Email i hasło są wymagane",
          variant: "destructive",
        });
        return;
      }
      
      setIsLoading(true);
      
      try {
        // Wysyłamy żądanie uwierzytelnienia do serwera API
        const response = await fetch('/api/employees/authenticate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: emailInput,
            password: passwordInput,
          }),
        });
        
        // Analizujemy odpowiedź
        const data = await response.json();
        
        if (!response.ok || !data.success) {
          console.log('Błąd logowania:', data.message);
          toast({
            title: "Błąd logowania",
            description: data.message || "Nieprawidłowy email lub hasło.",
            variant: "destructive",
          });
          return;
        }
        
        console.log('Uwierzytelnienie zakończone sukcesem:', data);
        
        // Pobieramy dane pracownika po uwierzytelnieniu
        const employeeResponse = await fetch(`/api/employees/${data.employeeId}`);
        
        if (!employeeResponse.ok) {
          throw new Error('Nie udało się pobrać danych pracownika');
        }
        
        const employeeData = await employeeResponse.json();
        console.log('Pobrane dane pracownika:', employeeData);
        
        // Zapisujemy dane pracownika w localStorage
        try {
          localStorage.setItem('currentEmployee', JSON.stringify(employeeData));
          console.log('Dane pracownika zapisane w localStorage:', employeeData);
        } catch (error) {
          console.error('Błąd podczas zapisywania danych do localStorage:', error);
        }
        
        setEmailInput("");
        setPasswordInput("");
        setCurrentEmployee(employeeData);
        setAuthenticated(true);
        // Ustaw zakładkę "Posiłki" jako domyślną po zalogowaniu
        setActiveTab("products");
        
        // Pokazujemy informację o zalogowaniu
        toast({
          title: "Zalogowano pomyślnie",
          description: `Witaj, ${employeeData.firstName} ${employeeData.lastName}!`,
        });
        
        // Jeśli wymagana jest zmiana hasła, pokazujemy dodatkowy komunikat
        if (data.passwordResetRequired) {
          setTimeout(() => {
            toast({
              title: "Wymagana zmiana hasła",
              description: "Prosimy o zmianę hasła w zakładce Profil.",
              variant: "destructive",
              duration: 6000,
            });
          }, 1000);
        }
      } catch (error) {
        console.error("Błąd podczas logowania:", error);
        toast({
          title: "Błąd połączenia",
          description: "Wystąpił problem z połączeniem do serwera.",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    } catch (error) {
      console.error("Authentication error:", error);
      setIsLoading(false);
      toast({
        title: "Błąd połączenia",
        description: "Wystąpił problem z połączeniem do serwera.",
        variant: "destructive",
      });
    }
  };

  // Funkcja wylogowania
  const handleLogout = () => {
    // Usuwamy dane pracownika z localStorage
    try {
      localStorage.removeItem('currentEmployee');
      console.log('Dane pracownika usunięte z localStorage');
    } catch (error) {
      console.error('Błąd podczas usuwania danych z localStorage:', error);
    }
    
    setAuthenticated(false);
    setCurrentEmployee(null);
    toast({
      title: "Wylogowano",
      description: "Zostałeś wylogowany z systemu.",
    });
  };

  return (
    <div className="flex flex-col min-h-screen"
         style={{
           backgroundColor: settings?.employeePortalBackgroundColor || '#F7EEE2',
         }}>
      {/* Nagłówek */}
      <header className="sticky top-0 z-10 border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="w-full flex justify-between items-center">
            <div className="flex items-center pl-2.5">
              {settings?.adminLogo ? (
                <img 
                  src={settings.adminLogo} 
                  alt="Logo" 
                  className="h-8 w-auto mr-2" 
                />
              ) : (
                <div className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-sm mr-2">
                  <span className="text-gray-400 text-xs">logo</span>
                </div>
              )}
              <span className="font-medium text-sm">
                {settings?.machineName || "Gastro Magazyn"} - Portal pracownika
              </span>
            </div>
            
            {authenticated && currentEmployee && (
              <div className="flex items-center">
                <div className="hidden md:flex mr-2">
                  <span className="text-sm">{currentEmployee.firstName} {currentEmployee.lastName}</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={toggleFullscreen}
                  title={isFullscreen ? "Zamknij tryb pełnoekranowy" : "Włącz tryb pełnoekranowy"}
                >
                  {isFullscreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
                  <span className="sr-only">Tryb pełnoekranowy</span>
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Główna treść */}
      <main ref={mainContentRef} className="flex-1 container py-2.5 pb-20">
        {authenticated && currentEmployee ? (
          <PortalContext.Provider value={{
            activeTab,
            setActiveTab,
            selectedReservationDate,
            setSelectedReservationDate,
            editReservation,
            setEditReservation
          }}>
            <div className="px-2.5">
              <div className="pb-16 w-full">
                {/* Używamy key={activeTab} aby wymusić ponowne renderowanie iframe przy każdej zmianie zakładki */}
                {/* Użycie key do wymuszenia pełnego ponownego renderowania przy zmianie zakładki */}
                <div 
                  key={`tab-${activeTab}-${Date.now()}`} // Dodanie unikalnego timestampu pomaga wymusić pełne odświeżenie
                  className="w-full"
                  style={{ overflow: 'auto', height: '100%' }}
                >
                  {/* Pusty div na samej górze jako kotwica do przewijania */}
                  <div 
                    id="top-anchor" 
                    className="block w-full" 
                    style={{ height: '1px', position: 'relative', top: '-65px' }}
                    ref={el => {
                      // Po wyrenderowaniu od razu przewijamy do tej kotwicy
                      if (el) {
                        setTimeout(() => {
                          el.scrollIntoView({ behavior: 'auto', block: 'start' });
                          window.scrollTo(0, 0);
                          document.documentElement.scrollTop = 0;
                          document.body.scrollTop = 0;
                        }, 0);
                      }
                    }}
                  ></div>
                  
                  {activeTab === "products" && (
                    <div className="w-full" id="portal-content-products" ref={productsTabRef}>
                      <ProductSelection employee={currentEmployee} />
                    </div>
                  )}
                  {activeTab === "orders" && (
                    <div className="w-full" id="portal-content-orders" ref={ordersTabRef}>
                      <Orders employee={currentEmployee} />
                    </div>
                  )}
                  {activeTab === "history" && (
                    <div className="w-full" id="portal-content-history" ref={historyTabRef}>
                      <MealHistory employee={currentEmployee} />
                    </div>
                  )}
                  {activeTab === "dietary" && (
                    <div className="w-full" id="portal-content-dietary" ref={dietaryTabRef}>
                      <DietaryPreferences employee={currentEmployee} />
                    </div>
                  )}
                  {activeTab === "profile" && (
                    <div className="w-full" id="portal-content-profile" ref={profileTabRef}>
                      <Profile employee={currentEmployee} onLogout={handleLogout} />
                    </div>
                  )}
                </div>
              </div>
            </div>
          </PortalContext.Provider>
        ) : (
          <div className="w-full max-w-md mx-auto mt-10 px-2.5">
            {/* Logo administracyjne nad formularzem logowania */}
            <div className="flex justify-center items-center mb-6">
              <div className="flex flex-col items-center">
                <div className="w-36 h-36 flex items-center justify-center bg-white p-3 rounded-lg shadow-lg">
                  {settings?.adminLogo ? (
                    <img 
                      src={settings.adminLogo} 
                      alt="Logo administratora" 
                      className="w-full h-auto object-contain"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-gray-400 text-lg">Brak logo</span>
                    </div>
                  )}
                </div>
                <h2 className="mt-3 text-lg font-bold">
                  {settings?.machineName || "Gastro Magazyn"}
                </h2>
              </div>
            </div>
            
            <Card className="backdrop-blur-sm bg-white/90 shadow-xl mx-2.5 p-2.5">
              <CardHeader>
                <CardTitle className="text-center">Logowanie pracownika</CardTitle>
                <CardDescription className="text-center">
                  Zaloguj się do portalu pracownika
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="twoj.email@firma.pl"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Hasło</Label>
                    <Input
                      id="password"
                      type="password"
                      placeholder="••••••••"
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          authenticateWithEmail();
                        }
                      }}
                    />
                  </div>
                  <div className="text-center mt-4">
                    <Button
                      className="w-full text-white hover:opacity-90"
                      style={{ backgroundColor: settings?.employeePortalButtonColor || '#91AD41' }}
                      onClick={authenticateWithEmail}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Logowanie...
                        </>
                      ) : (
                        "Zaloguj się"
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col space-y-2">
                <div className="text-center text-sm text-muted-foreground">
                  <p>Wprowadź swój email i hasło do logowania</p>
                </div>
                
                {/* Przyciski dodatkowe */}
                <div className="flex space-x-2">
                  {isInstallable && (
                    <Button 
                      id="pwa-install-button" 
                      variant="outline" 
                      className="mt-2 flex-1 flex items-center justify-center"
                      onClick={handleInstallClick}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Zainstaluj aplikację
                    </Button>
                  )}
                  
                  <Button 
                    variant="outline" 
                    className="mt-2 flex-1 flex items-center justify-center"
                    onClick={toggleFullscreen}
                  >
                    {isFullscreen ? (
                      <>
                        <Minimize className="mr-2 h-4 w-4" />
                        Zamknij pełny ekran
                      </>
                    ) : (
                      <>
                        <Maximize className="mr-2 h-4 w-4" />
                        Pełny ekran
                      </>
                    )}
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </div>
        )}
      </main>

      {/* Dolny pasek nawigacyjny */}
      {authenticated && currentEmployee && (
        <div className="fixed bottom-0 left-0 right-0 z-10 border-t border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container h-14">
            <div className="grid h-full grid-cols-5 items-center">
              <a
                href="#products"
                className={`flex flex-col items-center justify-center no-underline ${
                  activeTab === "products" ? "" : "text-muted-foreground"
                }`}
                style={
                  activeTab === "products" 
                  ? { color: settings?.employeePortalButtonColor || '#91AD41' } 
                  : {}
                }
                onClick={(e) => {
                  e.preventDefault();
                  
                  // Reset pozycji strony przed zmianą zakładki
                  window.scrollTo(0, 0);
                  document.documentElement.scrollTop = 0;
                  document.body.scrollTop = 0;
                  
                  // Zmieniamy aktywną zakładkę bez przeładowania strony
                  setActiveTab("products");
                  
                  // Wykonaj dodatkowe przewijanie po zmianie zakładki
                  setTimeout(() => {
                    const anchor = document.getElementById('top-anchor');
                    if (anchor) {
                      anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
                    }
                    window.scrollTo(0, 0);
                    document.documentElement.scrollTop = 0;
                    document.body.scrollTop = 0;
                  }, 50);
                }}
              >
                <ShoppingBasket className="h-5 w-5" />
                <span className="text-xs mt-0.5">Posiłki</span>
              </a>
              <a
                href="#orders"
                className={`flex flex-col items-center justify-center no-underline ${
                  activeTab === "orders" ? "" : "text-muted-foreground"
                }`}
                style={
                  activeTab === "orders" 
                  ? { color: settings?.employeePortalButtonColor || '#91AD41' } 
                  : {}
                }
                onClick={(e) => {
                  e.preventDefault();
                  
                  // Reset pozycji strony przed zmianą zakładki
                  window.scrollTo(0, 0);
                  document.documentElement.scrollTop = 0;
                  document.body.scrollTop = 0;
                  
                  // Zmieniamy aktywną zakładkę bez przeładowania strony
                  setActiveTab("orders");
                  
                  // Wykonaj dodatkowe przewijanie po zmianie zakładki
                  setTimeout(() => {
                    const anchor = document.getElementById('top-anchor');
                    if (anchor) {
                      anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
                    }
                    window.scrollTo(0, 0);
                    document.documentElement.scrollTop = 0;
                    document.body.scrollTop = 0;
                  }, 50);
                }}
              >
                <ClipboardList className="h-5 w-5" />
                <span className="text-xs mt-0.5">Zamówienia</span>
              </a>
              <a
                href="#history"
                className={`flex flex-col items-center justify-center no-underline ${
                  activeTab === "history" ? "" : "text-muted-foreground"
                }`}
                style={
                  activeTab === "history" 
                  ? { color: settings?.employeePortalButtonColor || '#91AD41' } 
                  : {}
                }
                onClick={(e) => {
                  e.preventDefault();
                  
                  // Reset pozycji strony przed zmianą zakładki
                  window.scrollTo(0, 0);
                  document.documentElement.scrollTop = 0;
                  document.body.scrollTop = 0;
                  
                  // Zmieniamy aktywną zakładkę bez przeładowania strony
                  setActiveTab("history");
                  
                  // Wykonaj dodatkowe przewijanie po zmianie zakładki
                  setTimeout(() => {
                    const anchor = document.getElementById('top-anchor');
                    if (anchor) {
                      anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
                    }
                    window.scrollTo(0, 0);
                    document.documentElement.scrollTop = 0;
                    document.body.scrollTop = 0;
                  }, 50);
                }}
              >
                <History className="h-5 w-5" />
                <span className="text-xs mt-0.5">Historia</span>
              </a>
              <a
                href="#dietary"
                className={`flex flex-col items-center justify-center no-underline ${
                  activeTab === "dietary" ? "" : "text-muted-foreground"
                }`}
                style={
                  activeTab === "dietary" 
                  ? { color: settings?.employeePortalButtonColor || '#91AD41' } 
                  : {}
                }
                onClick={(e) => {
                  e.preventDefault();
                  
                  // Reset pozycji strony przed zmianą zakładki
                  window.scrollTo(0, 0);
                  document.documentElement.scrollTop = 0;
                  document.body.scrollTop = 0;
                  
                  // Zmieniamy aktywną zakładkę bez przeładowania strony
                  setActiveTab("dietary");
                  
                  // Wykonaj dodatkowe przewijanie po zmianie zakładki
                  setTimeout(() => {
                    const anchor = document.getElementById('top-anchor');
                    if (anchor) {
                      anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
                    }
                    window.scrollTo(0, 0);
                    document.documentElement.scrollTop = 0;
                    document.body.scrollTop = 0;
                  }, 50);
                }}
              >
                <Apple className="h-5 w-5" />
                <span className="text-xs mt-0.5">Preferencje</span>
              </a>
              <a
                href="#profile"
                className={`flex flex-col items-center justify-center no-underline ${
                  activeTab === "profile" ? "" : "text-muted-foreground"
                }`}
                style={
                  activeTab === "profile" 
                  ? { color: settings?.employeePortalButtonColor || '#91AD41' } 
                  : {}
                }
                onClick={(e) => {
                  e.preventDefault();
                  
                  // Reset pozycji strony przed zmianą zakładki
                  window.scrollTo(0, 0);
                  document.documentElement.scrollTop = 0;
                  document.body.scrollTop = 0;
                  
                  // Zmieniamy aktywną zakładkę bez przeładowania strony
                  setActiveTab("profile");
                  
                  // Wykonaj dodatkowe przewijanie po zmianie zakładki
                  setTimeout(() => {
                    const anchor = document.getElementById('top-anchor');
                    if (anchor) {
                      anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
                    }
                    window.scrollTo(0, 0);
                    document.documentElement.scrollTop = 0;
                    document.body.scrollTop = 0;
                  }, 50);
                }}
              >
                <UserCircle className="h-5 w-5" />
                <span className="text-xs mt-0.5">Profil</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Stopka */}
      <footer className={`py-6 md:px-8 md:py-0 ${authenticated && currentEmployee ? 'hidden' : ''}`}>
        <div className="container flex flex-col items-center justify-between gap-4 md:h-14 md:flex-row">
          <p className="text-center text-sm leading-loose text-gray-700">
            {settings?.machineName || "Gastro Magazyn"} &copy; {new Date().getFullYear()}
          </p>
        </div>
      </footer>

      <Toaster />
    </div>
  );
};