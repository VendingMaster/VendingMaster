import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { format, subDays } from "date-fns";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { InsertDelivery, InsertInventory, Product } from "@shared/schema";
import { AlertCircle, Calendar, ExternalLink, Info, Package, Truck, RefreshCw, Trash, FileText, ShoppingBag, XCircle, ArchiveX, Calendar as CalendarIcon, ClipboardList } from "lucide-react";

import { UsageModal } from "./modals/UsageModal";
import ProductCell from "./ProductCell";

// Schemat formularza dostawy
const deliveryFormSchema = z.object({
  deliveryNumber: z.string().min(3, "Numer dostawy jest wymagany"),
  deliveryDate: z.string().min(1, "Data dostawy jest wymagana"),
  items: z.array(
    z.object({
      productId: z.number().min(1, "Produkt jest wymagany"),
      quantity: z.number().min(1, "Ilość musi być większa od zera"),
      expiryDate: z.string().min(1, "Data ważności jest wymagana"),
      batchNumber: z.string().optional(),
    })
  ).min(1, "Dodaj co najmniej jeden produkt"),
  notes: z.string().optional(),
});

type DeliveryFormValues = z.infer<typeof deliveryFormSchema>;

// Rozbudowana wersja komponentu Magazyn z funkcją przyjmowania dostawy
export const WarehouseManagement: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDeliveryDialogOpen, setIsDeliveryDialogOpen] = useState(false);
  const [isEditDeliveryDialogOpen, setIsEditDeliveryDialogOpen] = useState(false);
  const [deliveryToEdit, setDeliveryToEdit] = useState<any>(null);
  
  // Stan wyboru sekcji i zakładek
  const [mainSection, setMainSection] = useState<'inventory' | 'documents'>('inventory');
  const [inventoryTab, setInventoryTab] = useState("wszystkie");
  const [documentsTab, setDocumentsTab] = useState("dostawy");

  // Formularz przyjmowania dostawy
  const form = useForm<DeliveryFormValues>({
    resolver: zodResolver(deliveryFormSchema),
    defaultValues: {
      deliveryNumber: `D-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
      deliveryDate: new Date().toISOString().split("T")[0],
      items: [
        {
          productId: 0,
          quantity: 1,
          expiryDate: new Date().toISOString().split("T")[0],
          batchNumber: "",
        }
      ],
      notes: "",
    },
  });

  // Obsługa tablicy produktów w formularzu dostawy
  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  // Pobieranie produktów w magazynie
  const { data: inventoryItems = [], isLoading, refetch } = useQuery({
    queryKey: ["/api/inventory"],
    queryFn: async () => {
      try {
        const data = await apiRequest<any[]>("/api/inventory");
        
        if (!data || data.length === 0) return [];
        
        // Pobieramy informacje o produktach
        const itemsWithProducts = await Promise.all(
          data.map(async (item) => {
            try {
              const product = await apiRequest<Product>(`/api/products/${item.productId}`);
              return { ...item, product };
            } catch (error) {
              console.error(`Błąd podczas pobierania produktu ${item.productId}:`, error);
              return { ...item, product: null };
            }
          })
        );
        
        return itemsWithProducts;
      } catch (error) {
        console.error("Błąd podczas pobierania danych magazynu:", error);
        return [];
      }
    }
  });
  
  // Pobieranie pogrupowanych produktów w magazynie
  const { data: groupedItems = [], isLoading: isLoadingGrouped } = useQuery({
    queryKey: ["/api/inventory/grouped"],
    queryFn: async () => {
      try {
        return await apiRequest<any[]>("/api/inventory/grouped");
      } catch (error) {
        console.error("Błąd podczas pobierania pogrupowanych produktów:", error);
        return [];
      }
    }
  });
  
  // Pobieranie wszystkich dostaw
  const { data: deliveries = [], isLoading: isLoadingDeliveries } = useQuery({
    queryKey: ["/api/deliveries"],
    queryFn: async () => {
      try {
        return await apiRequest<any[]>("/api/deliveries");
      } catch (error) {
        console.error("Błąd podczas pobierania dostaw:", error);
        return [];
      }
    }
  });
  
  // Stan przechowujący produkty dla każdej dostawy
  const [deliveryItems, setDeliveryItems] = useState<Record<number, any[]>>({});
  
  // Ładowanie danych dostaw przy pierwszym renderowaniu
  React.useEffect(() => {
    if (deliveries.length > 0) {
      // Ładujemy produkty dla wszystkich dostaw przy pierwszym renderowaniu
      deliveries.forEach(delivery => {
        if (!deliveryItems[delivery.id]) {
          loadDeliveryItems(delivery.id);
        }
      });
    }
  }, [deliveries, deliveryItems]);

  // Pobieranie listy produktów z kończącym się terminem
  const { data: expiringItems = [] } = useQuery({
    queryKey: ["/api/inventory/expiring"],
    queryFn: async () => {
      try {
        const data = await apiRequest<any[]>("/api/inventory/expiring");
        
        if (!data || data.length === 0) return [];
        
        return data;
      } catch (error) {
        console.error("Błąd podczas pobierania produktów z kończącym się terminem:", error);
        return [];
      }
    }
  });
  
  // Pobieranie listy produktów przeterminowanych
  const { data: expiredItems = [] } = useQuery({
    queryKey: ["/api/inventory/expired"],
    queryFn: async () => {
      try {
        const data = await apiRequest<any[]>("/api/inventory/expired");
        
        if (!data || data.length === 0) return [];
        
        return data;
      } catch (error) {
        console.error("Błąd podczas pobierania produktów przeterminowanych:", error);
        return [];
      }
    }
  });

  // Pobieranie listy produktów w terminie
  const { data: inDateItems = [] } = useQuery({
    queryKey: ["/api/inventory/indate"],
    queryFn: async () => {
      try {
        const data = await apiRequest<any[]>("/api/inventory/indate");
        
        if (!data || data.length === 0) return [];
        
        // Pobieramy informacje o produktach
        const itemsWithProducts = await Promise.all(
          data.map(async (item) => {
            try {
              const product = await apiRequest<Product>(`/api/products/${item.productId}`);
              return { ...item, product };
            } catch (error) {
              console.error(`Błąd podczas pobierania produktu ${item.productId}:`, error);
              return { ...item, product: null };
            }
          })
        );
        
        return itemsWithProducts;
      } catch (error) {
        console.error("Błąd podczas pobierania produktów w terminie:", error);
        return [];
      }
    }
  });
  
  // Pobieranie listy zutylizowanych produktów
  const { data: disposedItems = [] } = useQuery({
    queryKey: ["/api/inventory/disposed"],
    queryFn: async () => {
      try {
        const data = await apiRequest<any[]>("/api/inventory/disposed");
        
        if (!data || data.length === 0) return [];
        
        // Pobieramy informacje o produktach
        const itemsWithProducts = await Promise.all(
          data.map(async (item) => {
            try {
              const product = await apiRequest<Product>(`/api/products/${item.productId}`);
              return { ...item, product };
            } catch (error) {
              console.error(`Błąd podczas pobierania produktu ${item.productId}:`, error);
              return { ...item, product: null };
            }
          })
        );
        
        return itemsWithProducts;
      } catch (error) {
        console.error("Błąd podczas pobierania zutylizowanych produktów:", error);
        return [];
      }
    }
  });
  
  // Pobieranie listy rozchodów
  const { data: usageItems = [], isLoading: isLoadingUsages } = useQuery({
    queryKey: ["/api/usages"],
    queryFn: async () => {
      try {
        const data = await apiRequest<any[]>("/api/usages");
        
        if (!data || data.length === 0) return [];
        
        // Pobieramy informacje o produktach
        const itemsWithProducts = await Promise.all(
          data.map(async (item) => {
            try {
              const product = await apiRequest<Product>(`/api/products/${item.productId}`);
              return { ...item, product };
            } catch (error) {
              console.error(`Błąd podczas pobierania produktu ${item.productId}:`, error);
              return { ...item, product: null };
            }
          })
        );
        
        return itemsWithProducts;
      } catch (error) {
        console.error("Błąd podczas pobierania listy rozchodów:", error);
        return [];
      }
    }
  });
  
  // Stan dialogu dla utylizacji produktu
  const [disposeDialogOpen, setDisposeDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [disposeQuantity, setDisposeQuantity] = useState<number | undefined>(undefined);
  
  // Stan dialogu dla rozchodu produktu
  const [usageDialogOpen, setUsageDialogOpen] = useState(false);
  
  // Mutacja utylizacji produktu
  const disposeMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: number, quantity?: number }) => {
      return await apiRequest(`/api/inventory/${id}/dispose`, {
        method: "POST",
        data: { quantity },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/expiring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/expired"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/indate"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/disposed"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/grouped"] });
      
      toast({
        title: "Sukces",
        description: "Produkt został pomyślnie zutylizowany",
      });
      
      setDisposeDialogOpen(false);
      setSelectedItem(null);
      setDisposeQuantity(undefined);
    },
    onError: (error) => {
      console.error("Błąd podczas utylizacji produktu:", error);
      toast({
        title: "Błąd",
        description: "Nie udało się zutylizować produktu",
        variant: "destructive",
      });
    },
  });
  
  // Obsługa utylizacji produktu
  const handleDisposeProduct = () => {
    if (!selectedItem) return;
    
    disposeMutation.mutate({
      id: selectedItem.id,
      quantity: disposeQuantity
    });
  };
  
  // Otwiera dialog utylizacji produktu
  const openDisposeDialog = (item: any) => {
    setSelectedItem(item);
    setDisposeQuantity(item.quantity);
    setDisposeDialogOpen(true);
  };
  
  // Otwiera dialog rozchodu produktu
  const openUsageDialog = (item: any) => {
    setSelectedItem(item);
    setUsageDialogOpen(true);
  };
  
  // Obsługa sukcesu rozchodu produktu
  const handleUsageSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
    queryClient.invalidateQueries({ queryKey: ["/api/inventory/expiring"] });
    queryClient.invalidateQueries({ queryKey: ["/api/inventory/expired"] });
    queryClient.invalidateQueries({ queryKey: ["/api/inventory/indate"] });
    queryClient.invalidateQueries({ queryKey: ["/api/inventory/grouped"] });
  };
  


  // Pobieranie listy produktów do wyboru w formularzu
  const { data: products = [] } = useQuery({
    queryKey: ["/api/products"],
    queryFn: async () => apiRequest<Product[]>("/api/products")
  });
  
  // Funkcja ładująca produkty dla danej dostawy
  const loadDeliveryItems = async (deliveryId: number) => {
    try {
      // Sprawdź, czy już pobraliśmy produkty dla tej dostawy i czy deliveryId jest poprawne
      if (!deliveryId || deliveryItems[deliveryId]) {
        return;
      }
      
      // Pobierz produkty z dedykowanego endpointu - wymaga poprawnego deliveryId
      const items = await apiRequest<any[]>(`/api/deliveries/${deliveryId}/items`);
      
      // Unikamy problemów z równoczesną aktualizacją stanu podczas renderowania
      if (Array.isArray(items)) {
        setDeliveryItems(prev => ({
          ...prev,
          [deliveryId]: items || []
        }));
      } else {
        console.error("Nieprawidłowa odpowiedź z endpointu /api/deliveries/:id/items");
      }
    } catch (error) {
      console.error(`Błąd podczas pobierania produktów dla dostawy ${deliveryId}:`, error);
      // Dodaj pustą tablicę dla tej dostawy aby uniknąć ponawiania żądań
      setDeliveryItems(prev => ({
        ...prev,
        [deliveryId]: []
      }));
      toast({
        title: "Błąd",
        description: "Nie udało się pobrać produktów z dostawy",
        variant: "destructive",
      });
    }
  };
  
  // Funkcja otwierająca dialog edycji dostawy
  const openEditDeliveryDialog = (delivery: any) => {
    setDeliveryToEdit(delivery);
    setIsEditDeliveryDialogOpen(true);
  };

  // Mutacja dodawania dostawy do magazynu
  const addDeliveryMutation = useMutation({
    mutationFn: async (data: DeliveryFormValues) => {
      // Najpierw tworzymy dostawę
      const delivery: InsertDelivery = {
        deliveryNumber: data.deliveryNumber,
        deliveryDate: data.deliveryDate,
        notes: data.notes || null,
      };
      
      const createdDelivery = await apiRequest("/api/deliveries", {
        method: "POST",
        data: delivery,
      });
      
      // Następnie dodajemy produkty powiązane z tą dostawą
      const deliveryPromises = data.items.map(item => {
        const inventoryItem: InsertInventory = {
          productId: item.productId,
          quantity: item.quantity,
          expiryDate: item.expiryDate,
          batchNumber: item.batchNumber || null,
          notes: data.notes || null,
          deliveryId: createdDelivery.id,
        };
        return apiRequest("/api/inventory", {
          method: "POST",
          data: inventoryItem,
        });
      });
      
      return Promise.all(deliveryPromises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/inventory"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/expiring"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/expired"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/indate"] });
      queryClient.invalidateQueries({ queryKey: ["/api/inventory/grouped"] });
      queryClient.invalidateQueries({ queryKey: ["/api/deliveries"] });
      toast({
        title: "Sukces",
        description: "Dostawa została przyjęta do magazynu",
      });
      setIsDeliveryDialogOpen(false);
      form.reset({
        deliveryNumber: `D-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
        deliveryDate: new Date().toISOString().split("T")[0],
        items: [
          {
            productId: 0,
            quantity: 1,
            expiryDate: new Date().toISOString().split("T")[0],
            batchNumber: "",
          }
        ],
        notes: "",
      });
    },
    onError: (error) => {
      console.error("Błąd podczas przyjmowania dostawy:", error);
      toast({
        title: "Błąd",
        description: "Nie udało się przyjąć dostawy do magazynu",
        variant: "destructive",
      });
    },
  });

  // Formatowanie daty z YYYY-MM-DD na DD.MM.YYYY
  const formatDate = (dateString: string): string => {
    if (!dateString) return "-";
    const [year, month, day] = dateString.split("-");
    return day && month && year ? `${day}.${month}.${year}` : dateString;
  };

  // Pobieranie ustawień
  const { data: settings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: async () => apiRequest("/api/settings")
  });

  // Sprawdzanie statusu ważności produktu
  const isExpired = (expiryDate: string): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiry = new Date(expiryDate);
    
    // Jeśli mamy dostępny próg expiredDaysThreshold z ustawień
    if (settings && typeof settings.expiredDaysThreshold === 'number') {
      const thresholdDate = new Date();
      thresholdDate.setDate(today.getDate() + settings.expiredDaysThreshold);
      return expiry <= thresholdDate;
    }
    
    // Domyślnie: produkt przeterminowany, gdy data ważności < dzisiaj
    return expiry < today;
  };

  const isCloseToExpiry = (expiryDate: string): boolean => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expiry = new Date(expiryDate);
    
    // Sprawdź czy produkt jest przeterminowany
    if (isExpired(expiryDate)) {
      return false; // Jeśli przeterminowany, to nie jest "kończący się termin"
    }
    
    // Jeśli mamy dostępny próg expiringDaysThreshold z ustawień
    if (settings && typeof settings.expiringDaysThreshold === 'number') {
      const thresholdDate = new Date();
      thresholdDate.setDate(today.getDate() + settings.expiringDaysThreshold);
      return expiry <= thresholdDate;
    }
    
    // Domyślnie: produkt kończy się termin, gdy data ważności <= 7 dni od dziś
    const sevenDaysFromNow = new Date();
    sevenDaysFromNow.setDate(today.getDate() + 7);
    return expiry <= sevenDaysFromNow;
  };

  // Obsługa formularza dostawy
  const onSubmit = (data: DeliveryFormValues) => {
    addDeliveryMutation.mutate(data);
  };

  // Resetowanie formularza i otwarcie dialogu
  const handleAddDelivery = () => {
    form.reset({
      deliveryNumber: `D-${new Date().toISOString().slice(0, 10).replace(/-/g, "")}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
      deliveryDate: new Date().toISOString().split("T")[0],
      items: [
        {
          productId: 0,
          quantity: 1,
          expiryDate: new Date().toISOString().split("T")[0],
          batchNumber: "",
        }
      ],
      notes: "",
    });
    setIsDeliveryDialogOpen(true);
  };

  // Dodanie nowego produktu do dostawy
  const handleAddProductToDelivery = () => {
    append({
      productId: 0,
      quantity: 1,
      expiryDate: new Date().toISOString().split("T")[0],
      batchNumber: "",
    });
  };

  return (
    <div className="container mx-auto pb-8">
      <h1 className="text-3xl font-bold tracking-tight mb-4">Magazyn</h1>
      
      {/* Wybór sekcji głównej */}
      <div className="flex space-x-2 mb-6">
        <Button 
          variant={mainSection === 'inventory' ? 'default' : 'outline'} 
          onClick={() => setMainSection('inventory')}
          className="flex items-center"
        >
          <Package className="mr-2 h-4 w-4" />
          Magazyn produktów
        </Button>
        <Button 
          variant={mainSection === 'documents' ? 'default' : 'outline'} 
          onClick={() => setMainSection('documents')}
          className="flex items-center"
        >
          <FileText className="mr-2 h-4 w-4" />
          Dokumenty magazynowe
        </Button>
      </div>
      
      {/* Sekcja Magazyn produktów */}
      {mainSection === 'inventory' && (
        <div className="space-y-4">
          <div className="flex justify-between mb-4">
            <h2 className="text-xl font-semibold">Zarządzanie magazynem</h2>
            <div className="flex space-x-2">
              <Button
                onClick={() => refetch()} 
                variant="outline" 
                size="icon"
                className="h-9 w-9"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
              <Button 
                onClick={handleAddDelivery} 
                className="bg-green-500 hover:bg-green-600"
              >
                <Truck className="mr-2 h-4 w-4" /> Przyjmij dostawę
              </Button>
            </div>
          </div>
          
          {/* Zakładki dla magazynu */}
          <Tabs value={inventoryTab} onValueChange={setInventoryTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="wszystkie">Wszystkie</TabsTrigger>
              <TabsTrigger value="w-terminie" className="relative">
                W terminie
                {inDateItems.length > 0 && (
                  <Badge variant="outline" className="ml-2 text-green-600 border-green-600">
                    {inDateItems.reduce((sum, item) => sum + item.quantity, 0)}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="kończące-się" className="relative">
                Kończące się termin
                {expiringItems.length > 0 && (
                  <Badge variant="outline" className="ml-2 text-yellow-600 border-yellow-600">
                    {expiringItems.reduce((sum, item) => sum + item.quantity, 0)}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="przeterminowane" className="relative">
                Przeterminowane
                {expiredItems.length > 0 && (
                  <Badge variant="destructive" className="ml-2">
                    {expiredItems.reduce((sum, item) => sum + item.quantity, 0)}
                  </Badge>
                )}
              </TabsTrigger>
            </TabsList>
            
            {/* Zawartość zakładki "Wszystkie" */}
            <TabsContent value="wszystkie" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Stan magazynu</CardTitle>
                  <CardDescription>
                    Produkty pogrupowane według nazwy i daty ważności
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingGrouped ? (
                    <div className="flex justify-center py-8">
                      <p>Ładowanie danych magazynu...</p>
                    </div>
                  ) : groupedItems.length === 0 ? (
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Brak produktów</AlertTitle>
                      <AlertDescription>
                        W magazynie nie ma jeszcze żadnych produktów. Dodaj produkty, klikając przycisk "Przyjmij dostawę".
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Nr partii</TableHead>
                          <TableHead>Termin ważności</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Akcje</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {groupedItems.map((item: any) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">
                              {item.product?.name || `Produkt ID: ${item.productId}`}
                            </TableCell>
                            <TableCell>{item.batchNumber || '-'}</TableCell>
                            <TableCell>
                              <span className={`font-medium ${
                                isExpired(item.expiryDate) 
                                  ? 'text-red-600' 
                                  : isCloseToExpiry(item.expiryDate) 
                                    ? 'text-yellow-600'
                                    : 'text-green-600'
                              }`}>
                                {formatDate(item.expiryDate)}
                              </span>
                            </TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>
                              {isExpired(item.expiryDate) ? (
                                <Badge variant="destructive">Przeterminowany</Badge>
                              ) : isCloseToExpiry(item.expiryDate) ? (
                                <Badge variant="outline" className="border-yellow-600 text-yellow-600">
                                  Kończy się termin
                                </Badge>
                              ) : (
                                <Badge variant="outline" className="border-green-600 text-green-600">
                                  W terminie
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => openUsageDialog(item)}
                                >
                                  Rozchód
                                </Button>
                                <Button 
                                  variant="destructive" 
                                  size="sm"
                                  onClick={() => openDisposeDialog(item)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Zawartość zakładki "Kończące się termin" */}
            <TabsContent value="kończące-się" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Produkty kończące się termin</CardTitle>
                  <CardDescription>
                    Produkty, których termin ważności upływa w najbliższym czasie (według ustawień)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {expiringItems.length === 0 ? (
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertTitle>Brak produktów</AlertTitle>
                      <AlertDescription>
                        W magazynie nie ma żadnych produktów z kończącym się terminem ważności.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Nr partii</TableHead>
                          <TableHead>Termin ważności</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Akcje</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {expiringItems.map((item: any) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">
                              {item.product?.name || `Produkt ID: ${item.productId}`}
                            </TableCell>
                            <TableCell>{item.batchNumber || '-'}</TableCell>
                            <TableCell>
                              <span className="text-yellow-600 font-medium">
                                {formatDate(item.expiryDate)}
                              </span>
                            </TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => openUsageDialog(item)}
                                >
                                  Rozchód
                                </Button>
                                <Button 
                                  variant="destructive" 
                                  size="sm"
                                  onClick={() => openDisposeDialog(item)}
                                >
                                  <Trash className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Zawartość zakładki "Przeterminowane" */}
            <TabsContent value="przeterminowane" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Produkty przeterminowane</CardTitle>
                  <CardDescription>
                    Produkty uznane za przeterminowane (według ustawień)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {expiredItems.length === 0 ? (
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertTitle>Brak produktów</AlertTitle>
                      <AlertDescription>
                        W magazynie nie ma żadnych przeterminowanych produktów.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Nr partii</TableHead>
                          <TableHead>Termin ważności</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Akcje</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {expiredItems.map((item: any) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">
                              {item.product?.name || `Produkt ID: ${item.productId}`}
                            </TableCell>
                            <TableCell>{item.batchNumber || '-'}</TableCell>
                            <TableCell>
                              <span className="text-red-600 font-medium">
                                {formatDate(item.expiryDate)}
                              </span>
                            </TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button 
                                  variant="destructive" 
                                  size="sm"
                                  onClick={() => openDisposeDialog(item)}
                                >
                                  Utylizuj
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Zawartość zakładki "W terminie" */}
            <TabsContent value="w-terminie" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Produkty w terminie</CardTitle>
                  <CardDescription>
                    Wszystkie produkty z aktualnym terminem ważności
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {inDateItems.length === 0 ? (
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertTitle>Brak produktów</AlertTitle>
                      <AlertDescription>
                        W magazynie nie ma żadnych produktów z aktualnym terminem ważności.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Nr partii</TableHead>
                          <TableHead>Termin ważności</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Akcje</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {inDateItems.map((item: any) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">
                              {item.product?.name || `Produkt ID: ${item.productId}`}
                            </TableCell>
                            <TableCell>{item.batchNumber || '-'}</TableCell>
                            <TableCell>
                              <span className="text-green-600 font-medium">
                                {formatDate(item.expiryDate)}
                              </span>
                            </TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={() => openUsageDialog(item)}
                                >
                                  Rozchód
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}
      
      {/* Sekcja Dokumenty magazynowe */}
      {mainSection === 'documents' && (
        <div className="space-y-4">
          <div className="flex justify-between mb-4">
            <h2 className="text-xl font-semibold">Dokumenty magazynowe</h2>
            <div className="flex space-x-2">
              <Button
                onClick={() => {
                  queryClient.invalidateQueries({ queryKey: ["/api/deliveries"] });
                  queryClient.invalidateQueries({ queryKey: ["/api/usages"] });
                }} 
                variant="outline" 
                size="icon"
                className="h-9 w-9"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
              <Button 
                onClick={handleAddDelivery} 
                className="bg-green-500 hover:bg-green-600"
              >
                <Truck className="mr-2 h-4 w-4" /> Przyjmij dostawę
              </Button>
            </div>
          </div>
          
          {/* Zakładki dla dokumentów */}
          <Tabs value={documentsTab} onValueChange={setDocumentsTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="dostawy">Dostawy</TabsTrigger>
              <TabsTrigger value="rozchody">Rozchody</TabsTrigger>
            </TabsList>
            
            {/* Zawartość zakładki "Dostawy" */}
            <TabsContent value="dostawy" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Dostawy</CardTitle>
                  <CardDescription>
                    Historia dostaw z podziałem na produkty
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingDeliveries ? (
                    <div className="flex justify-center py-8">
                      <p>Ładowanie dostaw...</p>
                    </div>
                  ) : deliveries.length === 0 ? (
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertTitle>Brak dostaw</AlertTitle>
                      <AlertDescription>
                        Nie zarejestrowano jeszcze żadnych dostaw. Kliknij "Przyjmij dostawę", aby dodać pierwszą.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <div className="space-y-6">
                      {deliveries.map((delivery: any) => (
                          <Card key={delivery.id} className="overflow-hidden border-0 shadow-md">
                            <CardHeader className="bg-muted/50 py-3">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h3 className="text-lg font-semibold">Dostawa #{delivery.deliveryNumber}</h3>
                                  <p className="text-sm text-muted-foreground">
                                    Data: {formatDate(delivery.deliveryDate)}
                                  </p>
                                </div>
                                <div className="flex items-center space-x-2">
                                  {delivery.notes && (
                                    <Badge variant="outline">
                                      <Info className="h-4 w-4 mr-1" /> Uwagi
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              {delivery.notes && (
                                <p className="text-sm italic mt-2 bg-muted p-2 rounded-md">
                                  {delivery.notes}
                                </p>
                              )}
                            </CardHeader>
                            <CardContent className="p-0">
                              {!deliveryItems[delivery.id] ? (
                                <div className="flex justify-center py-4">
                                  <p>Ładowanie produktów z dostawy...</p>
                                </div>
                              ) : deliveryItems[delivery.id].length === 0 ? (
                                <div className="flex justify-center py-4">
                                  <p>Brak produktów w tej dostawie</p>
                                </div>
                              ) : (
                                <Table>
                                  <TableHeader>
                                    <TableRow>
                                      <TableHead>Produkt</TableHead>
                                      <TableHead>Nr partii</TableHead>
                                      <TableHead>Termin ważności</TableHead>
                                      <TableHead>Ilość</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {deliveryItems[delivery.id]?.map((item: any) => (
                                      <TableRow key={item.id}>
                                        <TableCell className="font-medium">
                                          {item.product?.name || `Produkt ID: ${item.productId}`}
                                        </TableCell>
                                        <TableCell>{item.batchNumber || '-'}</TableCell>
                                        <TableCell>
                                          <span className={`font-medium ${
                                            isExpired(item.expiryDate) 
                                              ? 'text-red-600' 
                                              : isCloseToExpiry(item.expiryDate) 
                                                ? 'text-yellow-600'
                                                : 'text-green-600'
                                          }`}>
                                            {formatDate(item.expiryDate)}
                                          </span>
                                        </TableCell>
                                        <TableCell>{item.quantity}</TableCell>
                                      </TableRow>
                                    ))}
                                  </TableBody>
                                </Table>
                              )}
                            </CardContent>
                          </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Zawartość zakładki "Rozchody" */}
            <TabsContent value="rozchody" className="mt-0">
              <Card>
                <CardHeader>
                  <CardTitle>Rozchody</CardTitle>
                  <CardDescription>
                    Historia rozchodów produktów z magazynu
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingUsages ? (
                    <div className="flex justify-center py-8">
                      <p>Ładowanie historii rozchodów...</p>
                    </div>
                  ) : usageItems.length === 0 ? (
                    <Alert>
                      <Info className="h-4 w-4" />
                      <AlertTitle>Brak rozchodów</AlertTitle>
                      <AlertDescription>
                        Nie zarejestrowano jeszcze żadnych rozchodów produktów.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data</TableHead>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Nr partii</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Powód</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {usageItems.map((item: any) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              {item.usageDate ? formatDate(item.usageDate) : '-'}
                            </TableCell>
                            <TableCell className="font-medium">
                              {item.product?.name || `Produkt ID: ${item.productId}`}
                            </TableCell>
                            <TableCell>{item.batchNumber || '-'}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>
                              <Badge variant="outline">
                                {item.reason || 'Brak powodu'}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      )}
      
      {/* Dialog przyjmowania dostawy */}
      <Dialog open={isDeliveryDialogOpen} onOpenChange={setIsDeliveryDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Przyjęcie dostawy</DialogTitle>
            <DialogDescription>
              Wprowadź dane dostawy oraz produkty, które zostały dostarczone.
            </DialogDescription>
          </DialogHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="deliveryNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Numer dostawy</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="deliveryDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data dostawy</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="border rounded-md p-4">
                <div className="flex justify-between items-center mb-4">
                  <h4 className="font-semibold">Produkty w dostawie</h4>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleAddProductToDelivery}
                  >
                    Dodaj produkt
                  </Button>
                </div>
                
                {fields.map((field, index) => (
                  <div key={field.id} className="space-y-4 p-4 border rounded-md mb-4 bg-muted/20">
                    <div className="flex justify-between items-center">
                      <h5 className="font-medium">Produkt #{index + 1}</h5>
                      {fields.length > 1 && (
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => remove(index)}
                          className="text-red-500 h-8 px-2"
                        >
                          <XCircle className="h-4 w-4 mr-1" /> Usuń
                        </Button>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name={`items.${index}.productId`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Produkt</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(parseInt(value))}
                              defaultValue={field.value.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Wybierz produkt" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {products.map((product) => (
                                  <SelectItem key={product.id} value={product.id.toString()}>
                                    {product.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`items.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Ilość</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                min="1"
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                                value={field.value}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name={`items.${index}.expiryDate`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Termin ważności</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name={`items.${index}.batchNumber`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Numer partii</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                ))}
              </div>
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Uwagi do dostawy</FormLabel>
                    <FormControl>
                      <Textarea {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => setIsDeliveryDialogOpen(false)}
                >
                  Anuluj
                </Button>
                <Button 
                  type="submit" 
                  disabled={addDeliveryMutation.isPending}
                >
                  {addDeliveryMutation.isPending ? "Przyjmowanie..." : "Przyjmij dostawę"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      
      {/* Dialog utylizacji produktu */}
      <Dialog open={disposeDialogOpen} onOpenChange={setDisposeDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Utylizacja produktu</DialogTitle>
            <DialogDescription>
              Podaj ilość produktu do utylizacji.
            </DialogDescription>
          </DialogHeader>
          
          {selectedItem && (
            <div className="space-y-4">
              <div className="flex flex-col space-y-2">
                <p className="font-semibold">{selectedItem.product?.name || `Produkt ID: ${selectedItem.productId}`}</p>
                <p className="text-sm text-muted-foreground">
                  Termin ważności: {formatDate(selectedItem.expiryDate)}
                </p>
                <p className="text-sm text-muted-foreground">
                  Numer partii: {selectedItem.batchNumber || '-'}
                </p>
                <p className="text-sm">
                  Dostępna ilość: <span className="font-semibold">{selectedItem.quantity}</span>
                </p>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="disposeQuantity" className="text-sm font-medium">
                  Ilość do utylizacji
                </label>
                <Input
                  id="disposeQuantity"
                  type="number"
                  min="1"
                  max={selectedItem.quantity}
                  value={disposeQuantity !== undefined ? disposeQuantity : selectedItem.quantity}
                  onChange={(e) => setDisposeQuantity(parseInt(e.target.value))}
                />
                <p className="text-xs text-muted-foreground">
                  Maksymalna ilość: {selectedItem.quantity}
                </p>
              </div>
              
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Uwaga</AlertTitle>
                <AlertDescription>
                  Utylizacja jest operacją nieodwracalną. Utylizowane produkty zostaną oznaczone jako niedostępne w magazynie.
                </AlertDescription>
              </Alert>
            </div>
          )}
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setDisposeDialogOpen(false)}
            >
              Anuluj
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDisposeProduct}
              disabled={disposeMutation.isPending}
            >
              {disposeMutation.isPending ? "Utylizowanie..." : "Utylizuj produkt"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Modal rozchodu produktu */}
      <UsageModal
        item={selectedItem}
        isOpen={usageDialogOpen}
        onClose={() => setUsageDialogOpen(false)}
        onSuccess={handleUsageSuccess}
      />
    </div>
  );
};