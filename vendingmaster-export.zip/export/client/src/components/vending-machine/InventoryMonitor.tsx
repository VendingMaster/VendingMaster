import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Skeleton } from '@/components/ui/skeleton';
import { Product, Chamber } from '@shared/schema';

// Definicje typów dla danych z API diagnostycznego
interface ProductAssignment {
  productId: number;
  productName: string;
  chambersCount: number;
  totalAvailable: number;
  sufficient: boolean;
}

interface InventoryDiagnostics {
  inventoryBasedAssignment: boolean;
  productAssignments: ProductAssignment[];
}

interface InventoryItem {
  id: number;
  productId: number;
  batchNumber: string | null;
  expiryDate: string;
  quantity: number;
  usedQuantity: number | null;
  disposedQuantity: number | null;
  available: number;
}

interface ProductGroup {
  productId: number;
  productName: string;
  items: InventoryItem[];
  totalQuantity: number;
  availableQuantity: number;
}

interface InventoryStatus {
  summary: {
    totalItems: number;
    totalQuantity: number;
    availableQuantity: number;
    usedQuantity: number;
  };
  products: ProductGroup[];
}

export const InventoryMonitor: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('assignments');
  const queryClient = useQueryClient();

  // Używamy stanu do wymuszenia odświeżania
  const [refreshTimestamp, setRefreshTimestamp] = useState<number>(Date.now());

  // Pobierz diagnostykę magazynu
  const { data: inventoryDiagnostics, isLoading: diagnosticsLoading, refetch: refetchDiagnostics } = useQuery<InventoryDiagnostics>({
    queryKey: ['/api/diagnostics/inventory', refreshTimestamp],
    refetchInterval: 30000, // odświeżaj co 30 sekund
    staleTime: 0,  // zawsze uznaj dane za nieaktualne
    gcTime: 0,     // nie cachuj wyników
  });

  // Pobierz szczegółowy status magazynu
  const { data: inventoryStatus, isLoading: statusLoading, refetch: refetchStatus } = useQuery<InventoryStatus>({
    queryKey: ['/api/diagnostics/inventory-status', refreshTimestamp],
    refetchInterval: 30000, // odświeżaj co 30 sekund
    staleTime: 0,  // zawsze uznaj dane za nieaktualne
    gcTime: 0,     // nie cachuj wyników
  });

  // Pobierz szuflady
  const { data: chambers, isLoading: chambersLoading, refetch: refetchChambers } = useQuery<Chamber[]>({
    queryKey: ['/api/chambers', refreshTimestamp],
    staleTime: 0,
    gcTime: 0,
  });

  // Subskrybuj zmiany w magazynie i szufladach
  useEffect(() => {
    // Funkcja do odświeżania danych przy zmianach w systemie
    const refreshOnChanges = () => {
      refetchDiagnostics();
      refetchStatus();
      refetchChambers();
      // Aktualizuj znacznik czasu, aby wymusić odświeżenie wszystkich zapytań
      setRefreshTimestamp(Date.now());
    };

    // WebSocket dla powiadomień o zmianach magazynu
    const setupWebSocketListener = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      console.log(`[WebSocket Monitor] Łączenie z ${wsUrl} dla nasłuchiwania zmian magazynu...`);
      
      const ws = new WebSocket(wsUrl);
      
      ws.addEventListener('message', (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log('[WebSocket Monitor] Odebrano wiadomość:', message);
          
          // Obsługa powiadomienia o zmianie stanu magazynu
          if (message.type === 'inventory_changed') {
            console.log('[WebSocket Monitor] Odebrano powiadomienie o zmianie stanu magazynu. Odświeżam dane...');
            
            // Unieważniamy powiązane zapytania
            queryClient.invalidateQueries({ queryKey: ['/api/diagnostics/inventory'] });
            queryClient.invalidateQueries({ queryKey: ['/api/diagnostics/inventory-status'] });
            queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
            
            // Odświeżamy dane
            refreshOnChanges();
          }
        } catch (error) {
          console.error('[WebSocket Monitor] Błąd przetwarzania wiadomości:', error);
        }
      });
      
      ws.addEventListener('open', () => {
        console.log('[WebSocket Monitor] Połączono z serwerem dla nasłuchiwania zmian magazynu');
      });
      
      ws.addEventListener('error', (error) => {
        console.error('[WebSocket Monitor] Błąd połączenia:', error);
      });
      
      ws.addEventListener('close', () => {
        console.log('[WebSocket Monitor] Rozłączono z serwerem');
      });
      
      return () => {
        ws.close();
      };
    };
    
    // Subskrybuj queryClient, aby wiedzieć kiedy nastąpiły zmiany w danych
    const unsubscribe = queryClient.getQueryCache().subscribe(() => {
      const queryKeys = [
        '/api/chambers', 
        '/api/inventory', 
        '/api/deliveries',
        '/api/usages'
      ];
      
      // Sprawdź, czy którykolwiek z obserwowanych zasobów został zmieniony
      const matchingQueries = queryClient.getQueryCache().findAll({
        predicate: query => 
          queryKeys.some(key => 
            Array.isArray(query.queryKey) && 
            query.queryKey[0] === key && 
            query.state.dataUpdateCount > 0
          )
      });
      
      if (matchingQueries.length > 0) {
        console.log('Wykryto zmiany w danych, odświeżanie monitora magazynu');
        refreshOnChanges();
      }
    });

    // Uruchom nasłuchiwanie WebSocket
    const wsCleanup = setupWebSocketListener();

    // Funkcja czyszcząca
    return () => {
      unsubscribe();
      wsCleanup();
    };
  }, [queryClient, refetchDiagnostics, refetchStatus, refetchChambers]);

  // Funkcja do odświeżania danych
  const handleRefresh = () => {
    refetchDiagnostics();
    refetchStatus();
    refetchChambers();
    setRefreshTimestamp(Date.now());
    
    toast({
      title: "Odświeżono",
      description: "Dane zostały zaktualizowane",
    });
  };
  
  // Funkcja do wyświetlania statusu zgodności magazynu z przypisanymi szufladami
  const renderInventoryStatus = () => {
    if (!inventoryDiagnostics || !chambers) return null;
    
    // Sprawdź czy mamy wystarczającą ilość produktów dla wszystkich szuflad
    const hasInsufficientProducts = inventoryDiagnostics.productAssignments.some(p => !p.sufficient);
    
    // Policz liczbę szuflad z przypisanymi produktami
    const chambersWithProducts = chambers.filter(c => c.productId !== null).length;
    
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium">Status magazynu</h3>
          <Badge variant={hasInsufficientProducts ? "destructive" : "default"}>
            {hasInsufficientProducts 
              ? "Niewystarczająca ilość produktów" 
              : "Stan magazynu poprawny"}
          </Badge>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-slate-100 p-3 rounded-md">
            <div className="text-sm text-slate-500">Tryb magazynowy</div>
            <div className="font-semibold">
              {inventoryDiagnostics.inventoryBasedAssignment ? "Włączony" : "Wyłączony"}
            </div>
          </div>
          <div className="bg-slate-100 p-3 rounded-md">
            <div className="text-sm text-slate-500">Szuflady z produktami</div>
            <div className="font-semibold">
              {chambersWithProducts}
            </div>
          </div>
        </div>
        
        <div className="border rounded-md overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Produkt
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Szuflady
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Dostępne
                </th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {inventoryDiagnostics.productAssignments.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-4 text-center text-sm text-gray-500">
                    Brak przypisanych produktów do szuflad
                  </td>
                </tr>
              ) : (
                inventoryDiagnostics.productAssignments.map(product => (
                  <tr key={product.productId}>
                    <td className="px-4 py-3 text-sm">{product.productName}</td>
                    <td className="px-4 py-3 text-sm">{product.chambersCount}</td>
                    <td className="px-4 py-3 text-sm">{product.totalAvailable}</td>
                    <td className="px-4 py-3 text-sm">
                      <Badge 
                        variant={product.sufficient ? "default" : "destructive"} 
                        className={`whitespace-nowrap ${product.sufficient ? "bg-green-500 hover:bg-green-600" : ""}`}
                      >
                        {product.sufficient ? "Wystarczająca ilość" : "Za mało produktów"}
                      </Badge>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    );
  };
  
  // Funkcja do wyświetlania szczegółowych informacji o magazynie
  const renderInventoryDetails = () => {
    if (!inventoryStatus) return null;
    
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-slate-100 p-3 rounded-md">
            <div className="text-sm text-slate-500">Łącznie pozycji</div>
            <div className="font-semibold">{inventoryStatus.summary.totalItems}</div>
          </div>
          <div className="bg-slate-100 p-3 rounded-md">
            <div className="text-sm text-slate-500">Łącznie ilość</div>
            <div className="font-semibold">{inventoryStatus.summary.totalQuantity} szt.</div>
          </div>
          <div className="bg-slate-100 p-3 rounded-md">
            <div className="text-sm text-slate-500">Dostępne</div>
            <div className="font-semibold">{inventoryStatus.summary.availableQuantity} szt.</div>
          </div>
          <div className="bg-slate-100 p-3 rounded-md">
            <div className="text-sm text-slate-500">Zużyte</div>
            <div className="font-semibold">{inventoryStatus.summary.usedQuantity} szt.</div>
          </div>
        </div>
        
        <h3 className="text-lg font-medium pt-2">Produkty w magazynie</h3>
        
        {inventoryStatus.products.length === 0 ? (
          <div className="text-center py-6 text-gray-500">
            Brak produktów w magazynie
          </div>
        ) : (
          <div className="space-y-4">
            {inventoryStatus.products.map(product => (
              <Card key={product.productId}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-base">{product.productName}</CardTitle>
                  <CardDescription>
                    Dostępne: {product.availableQuantity} szt. | Łącznie: {product.totalQuantity} szt.
                  </CardDescription>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="border rounded-md overflow-hidden">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Partia
                          </th>
                          <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Termin ważności
                          </th>
                          <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Ilość / Dostępne
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {product.items.map(item => (
                          <tr key={item.id}>
                            <td className="px-3 py-2 text-xs">{item.batchNumber || "-"}</td>
                            <td className="px-3 py-2 text-xs">{new Date(item.expiryDate).toLocaleDateString('pl-PL')}</td>
                            <td className="px-3 py-2 text-xs">{item.quantity} / {item.available}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    );
  };
  
  const isLoading = diagnosticsLoading || statusLoading || chambersLoading;
  
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Monitor Magazynu</h2>
        <Button onClick={handleRefresh} variant="outline" size="sm" disabled={isLoading}>
          {isLoading ? "Ładowanie..." : "Odśwież"}
        </Button>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="assignments">Przypisania szuflad</TabsTrigger>
          <TabsTrigger value="inventory">Stan magazynu</TabsTrigger>
        </TabsList>
        
        <TabsContent value="assignments" className="pt-4">
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          ) : (
            renderInventoryStatus()
          )}
        </TabsContent>
        
        <TabsContent value="inventory" className="pt-4">
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          ) : (
            renderInventoryDetails()
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};