import * as React from 'react';
import { useState, useEffect } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Employee, 
  InsertEmployee, 
  RFID_CARD_FORMATS, 
  rfidCardFormatSchema, 
  rfidCardNumberSchema,
  DIETARY_PREFERENCES,
  dietaryPreferenceSchema
} from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';

interface EmployeeFormProps {
  employee: Employee | null;
  isOpen: boolean;
  onClose: () => void;
}

// Rozszerzamy schemat o dodatkowe walidacje - modyfikujemy typ dietaryPreference
// Tworzymy unię typów dla preferencji dietetycznych - dozwolone: wartości z DIETARY_PREFERENCES, pusty string lub null
const dietaryPreferenceType = dietaryPreferenceSchema.optional().nullable().or(z.literal(''));

const extendedSchema = z.object({
  firstName: z.string().min(2, { message: "Imię musi zawierać minimum 2 znaki" }),
  lastName: z.string().min(2, { message: "Nazwisko musi zawierać minimum 2 znaki" }),
  rfidCardNumber: rfidCardNumberSchema,
  rfidCardFormat: rfidCardFormatSchema,
  email: z.string().email({ message: "Niepoprawny format adresu email" }).optional().or(z.literal('')),
  dietaryPreference: dietaryPreferenceType,
});

type FormData = z.infer<typeof extendedSchema>;

export const EmployeeForm: React.FC<EmployeeFormProps> = ({ employee, isOpen, onClose }) => {
  const { toast } = useToast();
  const [localEmployee, setLocalEmployee] = useState<Employee | null>(employee);
  
  console.log('EmployeeForm - renderowanie, isOpen:', isOpen);
  console.log('EmployeeForm - employee:', employee);
  
  // Zaktualizuj dane pracownika, gdy zmienią się właściwości
  useEffect(() => {
    console.log('EmployeeForm - useEffect [employee] - aktualizacja employee:', employee);
    setLocalEmployee(employee);
  }, [employee]);

  // Inicjalizuj formularz
  const form = useForm<FormData>({
    resolver: zodResolver(extendedSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      rfidCardNumber: '',
      rfidCardFormat: 'decimal',
      email: '',
      dietaryPreference: null,
    },
  });

  // Resetowanie formularza przy otwarciu i zmianie pracownika
  useEffect(() => {
    console.log('EmployeeForm - useEffect [isOpen, localEmployee, form]');
    console.log('isOpen:', isOpen);
    console.log('localEmployee:', localEmployee);
    
    if (isOpen) {
      console.log('Resetowanie formularza z wartościami:');
      const resetValues = {
        firstName: localEmployee?.firstName || '',
        lastName: localEmployee?.lastName || '',
        rfidCardNumber: localEmployee?.rfidCardNumber || '',
        rfidCardFormat: (localEmployee?.rfidCardFormat as "decimal" | "hex") || 'decimal',
        email: localEmployee?.email || '',
        dietaryPreference: localEmployee?.dietaryPreference as any || null,
      };
      console.log('Wartości do resetu:', resetValues);
      form.reset(resetValues);
      console.log('Formularz zresetowany');
    }
  }, [isOpen, localEmployee, form]);

  // Mutacja do dodawania nowego pracownika
  const createMutation = useMutation({
    mutationFn: async (data: InsertEmployee) => {
      return await apiRequest('/api/employees', {
        method: 'POST',
        data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      toast({
        title: "Sukces",
        description: "Pracownik został pomyślnie dodany.",
      });
      form.reset();
      onClose();
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się dodać pracownika. Spróbuj ponownie.",
        variant: "destructive",
      });
    },
  });
  
  // Mutacja do aktualizacji istniejącego pracownika
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; employee: InsertEmployee }) => {
      return await apiRequest(`/api/employees/${data.id}`, {
        method: 'PUT',
        data: data.employee,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      toast({
        title: "Sukces",
        description: "Dane pracownika zostały zaktualizowane.",
      });
      form.reset();
      onClose();
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się zaktualizować danych pracownika. Spróbuj ponownie.",
        variant: "destructive",
      });
    },
  });

  // Obsługa przesyłania formularza
  const onSubmit = (formData: FormData) => {
    console.log('Przesyłanie formularza:', formData);
    
    // Konwertuj dane formularza na InsertEmployee
    const employeeData: InsertEmployee = {
      firstName: formData.firstName,
      lastName: formData.lastName,
      rfidCardNumber: formData.rfidCardNumber,
      rfidCardFormat: formData.rfidCardFormat,
      email: formData.email || "",
      dietaryPreference: formData.dietaryPreference === "" ? null : formData.dietaryPreference as any,
    };
    
    if (localEmployee) {
      updateMutation.mutate({ id: localEmployee.id, employee: employeeData });
    } else {
      createMutation.mutate(employeeData);
    }
  };

  // Obsługa zamknięcia
  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{localEmployee ? 'Edytuj pracownika' : 'Dodaj nowego pracownika'}</DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="firstName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Imię</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Jan" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="lastName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nazwisko</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Kowalski" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="rfidCardNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Numer karty RFID</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="1234567890" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="rfidCardFormat"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Format karty</FormLabel>
                    <Select 
                      onValueChange={field.onChange} 
                      value={field.value}
                      defaultValue="decimal"
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Wybierz format" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {RFID_CARD_FORMATS.map((format) => (
                          <SelectItem key={format} value={format}>
                            {format === 'decimal' ? 'Decimal (123456)' : 'HEX (1A2B3C)'}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Format, w którym zapisany jest numer karty
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" {...field} placeholder="jan.kowalski@przykład.pl" />
                  </FormControl>
                  <FormDescription>
                    Opcjonalny adres email pracownika
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="dietaryPreference"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Preferencja dietetyczna</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    value={field.value || ""}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Wybierz preferencję dietetyczną" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="">Brak preferencji</SelectItem>
                      {DIETARY_PREFERENCES.map((preference) => (
                        <SelectItem key={preference} value={preference}>
                          {preference}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Wybierz preferowaną dietę dla tego pracownika
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <DialogFooter>
              <Button type="button" variant="outline" onClick={handleClose}>
                Anuluj
              </Button>
              <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending}>
                {(createMutation.isPending || updateMutation.isPending) ? 'Zapisywanie...' : 
                 localEmployee ? 'Zapisz zmiany' : 'Dodaj pracownika'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};