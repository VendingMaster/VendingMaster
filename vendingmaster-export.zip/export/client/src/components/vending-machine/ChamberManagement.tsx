import React, { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Chamber, Product, Employee } from '@shared/schema';
import { ChamberAssignment } from './ChamberAssignment';
import { LoadingReport } from './LoadingReport';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Download, Upload, Box, FileText } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter 
} from '@/components/ui/dialog';

export const ChamberManagement: React.FC = () => {
  const [filter, setFilter] = useState<'pack' | 'emergency'>('pack');
  const [selectedChamberId, setSelectedChamberId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const [importStatus, setImportStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [importResult, setImportResult] = useState<{ imported: number; skipped: number; errors?: string[] } | null>(null);
  // Stan dla trybu załadunkowego
  const [loadingModeActive, setLoadingModeActive] = useState(false);
  const [loadingModeDialogOpen, setLoadingModeDialogOpen] = useState(false);
  const [currentLoadingDrawer, setCurrentLoadingDrawer] = useState(0);
  const [totalDrawersCount, setTotalDrawersCount] = useState(48);
  // Stan dla raportu załadunku
  const [showLoadingReport, setShowLoadingReport] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: chambersData, isLoading: chambersLoading } = useQuery<{chambers: Chamber[], timestamp: number}>({
    queryKey: ['/api/chambers'],
    staleTime: 0,
    refetchInterval: 2000 // Odświeżaj co 2 sekundy
  });
  
  // Ekstrahuj tablicę szuflad z odpowiedzi API
  const chambers = chambersData?.chambers || [];

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  const { data: employees } = useQuery<Employee[]>({
    queryKey: ['/api/employees'],
  });

  // Obsługa trybu załadunkowego poprzez WebSocket
  useEffect(() => {
    // Funkcja obsługująca wiadomości WebSocket
    const handleWebSocketMessage = (event: MessageEvent) => {
      try {
        const message = JSON.parse(event.data);
        console.log('[WebSocket] Odebrano wiadomość:', message);
        
        // Obsługa różnych typów wiadomości związanych z trybem załadunkowym
        switch(message.type) {
          case 'loading_mode_authorized':
            // Obsługa wiadomości o autoryzacji trybu załadunkowego przez RFID
            console.log('[WebSocket] Otrzymano autoryzację trybu załadunkowego przez RFID');
            
            // Automatycznie uruchamiamy tryb załadunkowy bez potwierdzenia
            if (!loadingModeActive) {
              console.log('[WebSocket] Uruchamianie trybu załadunkowego...');
              toast({
                title: "Tryb załadunkowy aktywowany",
                description: "Tryb załadunkowy został aktywowany przez autoryzowaną kartę RFID.",
              });
              
              // Oznaczamy, że tryb załadunkowy jest aktywny
              setLoadingModeActive(true);
            } else {
              console.log('[WebSocket] Tryb załadunkowy już aktywny - pomijam uruchomienie');
            }
            break;
            
          case 'loading_mode_progress':
            // Obsługa postępu trybu załadunkowego
            console.log(`[WebSocket] Postęp trybu załadunkowego: szuflada ${message.currentDrawer}/${message.totalDrawers}`);
            setCurrentLoadingDrawer(message.currentDrawer);
            setTotalDrawersCount(message.totalDrawers);
            break;
            
          case 'loading_mode_completed':
            // Obsługa zakończenia trybu załadunkowego
            console.log('[WebSocket] Zakończono tryb załadunkowy');
            setLoadingModeActive(false);
            setCurrentLoadingDrawer(0);
            toast({
              title: "Tryb załadunkowy zakończony",
              description: "Wszystkie szuflady zostały sekwencyjnie otwarte.",
            });
            break;
            
          case 'drawer_opened':
            // Obsługa komunikatu o otwarciu szuflady
            console.log(`[WebSocket] Szuflada ${message.drawerNumber} została otwarta`);
            break;
        }
      } catch (error) {
        console.error('[WebSocket] Błąd przetwarzania wiadomości:', error);
      }
    };

    // Funkcja do nasłuchiwania na wiadomości WebSocket
    const setupWebSocketListener = () => {
      // Określamy adres URL WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      // Tworzymy nowe połączenie WebSocket do nasłuchiwania
      const ws = new WebSocket(wsUrl);
      
      // Ustawiamy obsługę wiadomości
      ws.addEventListener('message', handleWebSocketMessage);
      
      // Zwracamy funkcję czyszczącą
      return () => {
        ws.removeEventListener('message', handleWebSocketMessage);
        ws.close();
      };
    };
    
    // Uruchamiamy nasłuchiwanie
    const cleanup = setupWebSocketListener();
    
    // Zwracamy funkcję czyszczącą
    return cleanup;
  }, [loadingModeActive, toast]); // Zależności dla useEffect
  
  // W widoku awaryjnym wszystkie szuflady są dostępne
  const filteredChambers = chambers;

  const getProductById = (id: number | null) => {
    if (!id || !products) return null;
    return products.find(product => product.id === id);
  };
  
  const getEmployeeById = (id: number | null) => {
    if (!id || !employees) return null;
    return employees.find(employee => employee.id === id);
  };

  const handleChamberClick = (id: number) => {
    if (filter === 'emergency') {
      // W trybie awaryjnym otwieramy szufladę bezpośrednio
      handleEmergencyOpen(id);
    } else {
      // W trybie pakowania otwieramy modal do przypisania produktu
      setSelectedChamberId(id);
      setIsModalOpen(true);
    }
  };

  // Funkcja do awaryjnego otwierania szuflady
  const handleEmergencyOpen = (chamberId: number) => {
    console.log(`Wysyłanie komendy awaryjnego otwarcia szuflady ${chamberId}...`);
    
    // Wysłanie żądania do API otwarcia szuflady (poprawny endpoint GET)
    fetch(`/api/mqtt/drawer/open/${chamberId}`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Cache-Control': 'no-cache'
      }
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        toast({
          title: "Szuflada otwarta awaryjnie",
          description: `Komora ${chamberId} została otwarta awaryjnie.`,
        });
      } else {
        throw new Error(data.message || 'Nie udało się otworzyć szuflady');
      }
    })
    .catch(error => {
      toast({
        title: "Błąd",
        description: `Nie udało się otworzyć szuflady: ${error.message || 'Nieznany błąd'}`,
        variant: "destructive",
      });
    });
  };
  
  // Obsługa importu CSV dla szuflad
  const handleImportCSV = async (file: File) => {
    if (!file) return;
    
    // Reset stanu importu
    setImportStatus('uploading');
    setImportProgress(0);
    setImportResult(null);
    
    // Przygotowanie formularza
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      // Symulacja postępu (faktyczny postęp nie jest dostępny z fetch)
      const progressInterval = setInterval(() => {
        setImportProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 200);
      
      // Wysłanie pliku
      const response = await apiRequest('/api/chambers/import/csv', {
        method: 'POST',
        body: formData,
        headers: {},
      });
      
      // Zatrzymanie symulacji postępu i ustawienie 100%
      clearInterval(progressInterval);
      setImportProgress(100);
      
      if (response.success) {
        setImportStatus('success');
        setImportResult({
          imported: response.imported,
          skipped: response.skipped,
          errors: response.errors || []
        });
        
        // Odświeżenie listy szuflad
        queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
        
        toast({
          title: "Import zakończony pomyślnie",
          description: `Zaimportowano ${response.imported} szuflad, pominięto ${response.skipped}.`,
        });
      } else {
        throw new Error(response.message || 'Błąd podczas importu');
      }
    } catch (error) {
      setImportStatus('error');
      toast({
        title: "Błąd importu",
        description: error instanceof Error ? error.message : 'Nieznany błąd',
        variant: "destructive",
      });
    }
  };
  
  // Otwórz okno wyboru pliku
  const openFileSelector = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };
  
  // Obsługa zmiany pliku
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      setImportDialogOpen(true);
      handleImportCSV(file);
    }
  };
  
  // Pobieranie szablonu CSV
  const downloadTemplate = () => {
    window.location.href = '/api/chambers/template/csv';
  };

  // Funkcja do obsługi trybu załadunkowego
  const startLoadingMode = () => {
    // Otwieramy dialog potwierdzenia
    setLoadingModeDialogOpen(true);
  };

  // Funkcja do rzeczywistego uruchomienia trybu załadunkowego po potwierdzeniu
  const executeLoadingMode = () => {
    console.log('[Loading Mode] Rozpoczynanie trybu załadunkowego...');
    setLoadingModeActive(true);
    setCurrentLoadingDrawer(1); // Zaczynamy od pierwszej szuflady
    
    toast({
      title: "Tryb załadunkowy aktywowany",
      description: "Szuflady będą otwierane sekwencyjnie co 2 sekundy.",
    });
    
    // Zamykamy dialog potwierdzenia
    setLoadingModeDialogOpen(false);
    
    // Funkcja otwierająca kolejne szuflady z opóźnieniem
    const openDrawersSequentially = (currentDrawer: number) => {
      console.log(`[Loading Mode] Otwieranie szuflady ${currentDrawer} z ${totalDrawersCount}...`);
      
      if (currentDrawer > totalDrawersCount) {
        // Wszystkie szuflady zostały otwarte
        console.log('[Loading Mode] Wszystkie szuflady zostały otwarte - kończenie trybu załadunkowego');
        setLoadingModeActive(false);
        setCurrentLoadingDrawer(0);
        toast({
          title: "Tryb załadunkowy zakończony",
          description: `Wszystkie ${totalDrawersCount} szuflad zostało sekwencyjnie otwartych.`,
        });
        return;
      }
      
      // Aktualizujemy obecnie otwieraną szufladę
      setCurrentLoadingDrawer(currentDrawer);
      
      // Wysyłamy żądanie otwarcia szuflady
      console.log(`[Loading Mode] Wysyłam żądanie otwarcia szuflady ${currentDrawer}...`);
      fetch(`/api/mqtt/drawer/open/${currentDrawer}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        }
      })
      .then(response => response.json())
      .then(data => {
        console.log(`[Loading Mode] Odpowiedź dla szuflady ${currentDrawer}:`, data);
        
        if (!data.success) {
          throw new Error(data.message || `Nie udało się otworzyć szuflady ${currentDrawer}`);
        }
        
        console.log(`[Loading Mode] Szuflada ${currentDrawer} została otwarta. Oczekiwanie 2 sekundy przed otwarciem następnej...`);
        
        // Ustawiamy timer na otwarcie następnej szuflady za 2 sekundy
        setTimeout(() => {
          openDrawersSequentially(currentDrawer + 1);
        }, 2000);
      })
      .catch(error => {
        console.error(`[Loading Mode] Błąd przy otwieraniu szuflady ${currentDrawer}:`, error);
        
        toast({
          title: "Błąd",
          description: `Nie udało się otworzyć szuflady ${currentDrawer}: ${error.message || 'Nieznany błąd'}`,
          variant: "destructive",
        });
        
        // Mimo błędu próbujemy kontynuować z następną szufladą
        console.log(`[Loading Mode] Kontynuuję z następną szufladą mimo błędu...`);
        setTimeout(() => {
          openDrawersSequentially(currentDrawer + 1);
        }, 2000);
      });
    };
    
    // Rozpoczynamy otwieranie szuflad
    console.log('[Loading Mode] Rozpoczynam sekwencję otwierania szuflad...');
    openDrawersSequentially(1);
  };

  const isLoading = chambersLoading || productsLoading;

  // Importy dla ikon
  const PlusIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 5v14M5 12h14"/>
    </svg>
  );
  
  const LockIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
      <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
    </svg>
  );
  
  const CheckIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  );
  
  const AlertIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
      <line x1="12" y1="9" x2="12" y2="13"></line>
      <line x1="12" y1="17" x2="12.01" y2="17"></line>
    </svg>
  );
  
  const PersonIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
      <circle cx="12" cy="7" r="4"></circle>
    </svg>
  );

  // Renderowanie każdej komórki (szuflady)
  const renderChamberCell = (chamber: Chamber) => {
    const hasProduct = chamber.productId !== null;
    const hasEmployee = chamber.employeeId !== null;
    const product = hasProduct ? getProductById(chamber.productId) : null;
    const employee = hasEmployee ? getEmployeeById(chamber.employeeId) : null;
    const isEmergencyMode = filter === 'emergency';
    
    // W trybie awaryjnym wszystkie szuflady są dostępne do otwarcia
    // W trybie pakowania, szuflady pracowników są wyłączone
    const isDisabled = !isEmergencyMode && hasEmployee;
    
    // Ustalamy kolor gradientu dla szuflady w zależności od jej stanu
    let gradientColors = '';
    let iconComponent = null;
    let borderStyle = '';
    let shadowStyle = '';
    
    if (isEmergencyMode) {
      gradientColors = 'bg-gradient-to-br from-red-50 to-red-100';
      iconComponent = <AlertIcon />;
      borderStyle = 'border-red-300';
      shadowStyle = 'shadow-sm hover:shadow-md shadow-red-200/50';
    } else if (hasEmployee) {
      gradientColors = 'bg-gradient-to-br from-blue-50 to-blue-100';
      iconComponent = <PersonIcon />;
      borderStyle = 'border-blue-300';
      shadowStyle = 'shadow-sm hover:shadow-md shadow-blue-200/50';
    } else if (hasProduct) {
      if (chamber.isAvailable) {
        gradientColors = 'bg-gradient-to-br from-green-50 to-green-100';
        iconComponent = <CheckIcon />;
        borderStyle = 'border-green-300';
        shadowStyle = 'shadow-sm hover:shadow-md shadow-green-200/50';
      } else {
        gradientColors = 'bg-gradient-to-br from-amber-50 to-amber-100';
        iconComponent = <LockIcon />;
        borderStyle = 'border-amber-300';
        shadowStyle = 'shadow-sm hover:shadow-md shadow-amber-200/50';
      }
    } else {
      gradientColors = 'bg-gradient-to-br from-gray-50 to-gray-100';
      iconComponent = <PlusIcon />;
      borderStyle = 'border-gray-300';
      shadowStyle = 'shadow-sm hover:shadow-md shadow-gray-200/50';
    }
    
    return (
      <div key={chamber.id} className="chamber-cell h-16 relative">
        <button 
          className={`w-full h-full flex items-center justify-between px-4 rounded-md text-sm border 
                     transition-all duration-200 ${gradientColors} ${borderStyle} ${shadowStyle} 
                     ${isDisabled ? 'opacity-80 cursor-not-allowed' : 'hover:translate-y-[-2px]'}
                     focus:outline-none focus:ring-2 focus:ring-opacity-50 
                     ${isEmergencyMode ? 'focus:ring-red-400' : 'focus:ring-primary'}`}
          onClick={() => !isDisabled && handleChamberClick(chamber.id)}
          disabled={isDisabled}
          title={isEmergencyMode 
                  ? `Kliknij, aby awaryjnie otworzyć szufladę #${chamber.id}` 
                  : hasEmployee 
                    ? `Przypisana do pracownika: ${employee?.firstName} ${employee?.lastName}` 
                    : hasProduct 
                      ? product?.name 
                      : 'Pusta'}
        >
          {/* Efekt trójwymiarowy szuflady (górna krawędź) */}
          <div className={`absolute top-0 left-0 right-0 h-[3px] rounded-t-md ${
            isEmergencyMode ? 'bg-red-200' : 
            hasEmployee ? 'bg-blue-200' : 
            hasProduct 
              ? (chamber.isAvailable ? 'bg-green-200' : 'bg-amber-200') 
              : 'bg-gray-200'
          }`}></div>
          
          {/* Numer szuflady */}
          <div className="flex items-center">
            <span className={`font-medium text-base ${
              isEmergencyMode ? 'text-red-700' : 
              hasEmployee ? 'text-blue-700' : 
              hasProduct 
                ? (chamber.isAvailable ? 'text-green-700' : 'text-amber-700') 
                : 'text-gray-700'
            }`}>#{chamber.id.toString().padStart(2, '0')}</span>
          </div>
          
          {/* Status szuflady */}
          <div className="flex items-center gap-2">
            <span className={`text-sm font-medium ${
              isEmergencyMode ? 'text-red-600' : 
              hasEmployee ? 'text-blue-600' : 
              hasProduct 
                ? (chamber.isAvailable ? 'text-green-600' : 'text-amber-600') 
                : 'text-gray-500'
            }`}>
              {isEmergencyMode 
                ? 'Otwórz'
                : hasEmployee 
                  ? 'Dla pracownika' 
                  : hasProduct 
                    ? (chamber.isAvailable 
                      ? product?.name
                      : 'Niedostępna') 
                    : 'Pusta'}
            </span>
            <span className="text-xs">
              {iconComponent}
            </span>
          </div>
          
          {/* Efekt cienia dolnej krawędzi */}
          <div className={`absolute bottom-[1px] left-[1px] right-[1px] h-[2px] opacity-30 rounded-b-md ${
            isEmergencyMode ? 'bg-red-300' : 
            hasEmployee ? 'bg-blue-300' : 
            hasProduct 
              ? (chamber.isAvailable ? 'bg-green-300' : 'bg-amber-300') 
              : 'bg-gray-300'
          }`}></div>
        </button>
      </div>
    );
  };

  return (
    <div>
      <div className="mb-6">
        <div className="flex flex-wrap justify-between items-center">
          <div>
            <h3 className="text-lg font-medium text-gray-800">Zarządzanie Szufladami</h3>
            <p className="text-gray-600 mt-1">
              {filter === 'emergency' 
                ? "Tryb awaryjny: kliknij na szufladę, aby otworzyć ją bez zmiany przypisanych produktów."
                : "Przypisz produkty do konkretnych szuflad w automacie lub zarządzaj istniejącymi przypisaniami."}
            </p>
          </div>
          
          {/* Przyciski importu i pobierania szablonu CSV */}
          <div className="flex gap-2 mt-2 sm:mt-0">
            <Button
              variant="outline"
              onClick={downloadTemplate}
              className="bg-white text-black border-gray-300 hover:bg-gray-100 flex items-center gap-2 whitespace-nowrap"
            >
              <Download size={16} />
              <span>Pobierz szablon CSV</span>
            </Button>
            <Button
              variant="outline"
              onClick={openFileSelector}
              className="bg-white text-black border-gray-300 hover:bg-gray-100 flex items-center gap-2 whitespace-nowrap"
            >
              <Upload size={16} />
              <span>Importuj z CSV</span>
            </Button>
            
            {/* Ukryte pole input dla pliku CSV */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".csv"
              className="hidden"
            />
          </div>
        </div>
      </div>

      {/* Filter Buttons */}
      <div className="bg-white p-6 rounded-lg shadow">
        <div className="flex flex-wrap gap-2 mb-6">
          <Button 
            variant={filter === 'pack' ? 'default' : 'outline'}
            onClick={() => setFilter('pack')}
            className={filter === 'pack' 
              ? 'bg-gray-200 text-gray-900 hover:bg-gray-300 border-gray-300'
              : 'bg-white hover:bg-gray-100 text-gray-800 border-gray-300'
            }
          >
            Zapakuj Szuflady
          </Button>
          <Button 
            variant={filter === 'emergency' ? 'default' : 'outline'}
            onClick={() => setFilter('emergency')}
            className={filter === 'emergency' 
              ? 'bg-gray-200 text-gray-900 hover:bg-gray-300 border-gray-300'
              : 'bg-white hover:bg-gray-100 text-gray-800 border-gray-300'
            }
          >
            Otwórz Awaryjnie
          </Button>
          
          {/* Przycisk trybu załadunkowego */}
          <Button 
            variant="outline"
            onClick={startLoadingMode}
            className="mr-2 bg-gradient-to-r from-amber-50 to-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200"
            disabled={loadingModeActive}
          >
            {loadingModeActive 
              ? `Szuflada ${currentLoadingDrawer}/${totalDrawersCount}` 
              : "Tryb załadunkowy"}
            {loadingModeActive && (
              <span className="ml-2 inline-block w-4 h-4 rounded-full bg-amber-500 animate-pulse"></span>
            )}
          </Button>
          
          {/* Przycisk generowania raportu załadunku */}
          <Button 
            variant="outline"
            onClick={() => setShowLoadingReport(true)}
            className="ml-auto bg-gradient-to-r from-green-50 to-green-100 text-green-800 border-green-300 hover:bg-green-200"
          >
            <FileText className="w-4 h-4 mr-2" />
            Generuj raport załadunku
          </Button>
        </div>

        {/* Chamber Grid */}
        {isLoading ? (
          <div className="flex flex-col gap-4">
            <div className="flex gap-4">
              {/* Kolumna 1 - 15 szuflad */}
              <div className="flex flex-col gap-2 w-1/4">
                {[...Array(15)].map((_, index) => (
                  <div key={index} className="h-14">
                    <Skeleton className="h-full w-full rounded-md" />
                  </div>
                ))}
              </div>
              
              {/* Kolumna 2 - 9 szuflad */}
              <div className="flex flex-col gap-2 w-1/4">
                {[...Array(9)].map((_, index) => (
                  <div key={index} className="h-14">
                    <Skeleton className="h-full w-full rounded-md" />
                  </div>
                ))}
              </div>
              
              {/* Kolumna 3 - 9 szuflad */}
              <div className="flex flex-col gap-2 w-1/4">
                {[...Array(9)].map((_, index) => (
                  <div key={index} className="h-14">
                    <Skeleton className="h-full w-full rounded-md" />
                  </div>
                ))}
              </div>
              
              {/* Kolumna 4 - 15 szuflad */}
              <div className="flex flex-col gap-2 w-1/4">
                {[...Array(15)].map((_, index) => (
                  <div key={index} className="h-14">
                    <Skeleton className="h-full w-full rounded-md" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex gap-4">
            {/* Kolumna 1 - 15 szuflad (1-15) */}
            <div className="flex flex-col gap-2 w-1/4">
              {filteredChambers?.filter(c => c.id >= 1 && c.id <= 15).map(renderChamberCell)}
            </div>
            
            {/* Kolumna 2 - 9 szuflad (16-24) z przerwą przed szufladą #20 */}
            <div className="flex flex-col gap-2 w-1/4">
              {/* Pierwsza część kolumny 2 (16-19) */}
              {filteredChambers?.filter(c => c.id >= 16 && c.id <= 19).map(renderChamberCell)}
              
              {/* Przerwa na 6 szuflad + dodatkowa przestrzeń dla wyrównania */}
              <div className="h-[26.5rem] flex items-center justify-center text-gray-400 text-sm border border-dashed border-gray-300 rounded-md">
                <span>Strefa serwisowa</span>
              </div>
              
              {/* Druga część kolumny 2 (20-24) */}
              {filteredChambers?.filter(c => c.id >= 20 && c.id <= 24).map(renderChamberCell)}
            </div>
            
            {/* Kolumna 3 - 9 szuflad (25-33) z przerwą przed szufladą #29 */}
            <div className="flex flex-col gap-2 w-1/4">
              {/* Pierwsza część kolumny 3 (25-28) */}
              {filteredChambers?.filter(c => c.id >= 25 && c.id <= 28).map(renderChamberCell)}
              
              {/* Przerwa na 6 szuflad + dodatkowa przestrzeń dla wyrównania */}
              <div className="h-[26.5rem] flex items-center justify-center text-gray-400 text-sm border border-dashed border-gray-300 rounded-md">
                <span>Strefa serwisowa</span>
              </div>
              
              {/* Druga część kolumny 3 (29-33) */}
              {filteredChambers?.filter(c => c.id >= 29 && c.id <= 33).map(renderChamberCell)}
            </div>
            
            {/* Kolumna 4 - 15 szuflad (34-48) */}
            <div className="flex flex-col gap-2 w-1/4">
              {filteredChambers?.filter(c => c.id >= 34 && c.id <= 48).map(renderChamberCell)}
            </div>
          </div>
        )}
      </div>
      
      {/* Modal for Chamber Assignment */}
      {isModalOpen && selectedChamberId && (
        <ChamberAssignment 
          chamberId={selectedChamberId}
          isOpen={isModalOpen}
          onClose={() => {
            setIsModalOpen(false);
            setSelectedChamberId(null);
          }}
        />
      )}

      {/* Dialog do wyświetlania postępu importu CSV */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Import szuflad z pliku CSV</DialogTitle>
            <DialogDescription>
              {importStatus === 'uploading' 
                ? 'Trwa importowanie szuflad...' 
                : importStatus === 'success'
                  ? `Import zakończony. Zaimportowano ${importResult?.imported || 0} szuflad, pominięto ${importResult?.skipped || 0}.`
                  : importStatus === 'error'
                    ? 'Wystąpił błąd podczas importu.'
                    : 'Przygotowanie do importu szuflad...'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            {importStatus === 'uploading' && (
              <div className="space-y-2">
                <Progress value={importProgress} className="w-full" />
                <p className="text-sm text-center text-gray-500">{importProgress}%</p>
              </div>
            )}
            
            {importStatus === 'success' && importResult?.errors && importResult.errors.length > 0 && (
              <div className="mt-2 max-h-40 overflow-y-auto">
                <h4 className="font-medium text-amber-600 mb-2">Ostrzeżenia:</h4>
                <ul className="list-disc pl-4 text-sm space-y-1">
                  {importResult.errors.map((error, index) => (
                    <li key={index} className="text-gray-700">{error}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button onClick={() => setImportDialogOpen(false)}>
              {importStatus === 'success' || importStatus === 'error' ? 'Zamknij' : 'Anuluj'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog potwierdzenia trybu załadunkowego */}
      <Dialog open={loadingModeDialogOpen} onOpenChange={setLoadingModeDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Tryb załadunkowy</DialogTitle>
            <DialogDescription>
              Tryb załadunkowy spowoduje sekwencyjne otwarcie wszystkich {totalDrawersCount} szuflad 
              z 2-sekundowym opóźnieniem między każdą z nich. Czy na pewno chcesz kontynuować?
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <p className="text-sm text-amber-600">
              Uwaga: Wszystkie szuflady zostaną po kolei otwarte. Upewnij się, że jesteś gotowy 
              na obsługę każdej szuflady przed jej zamknięciem.
            </p>
          </div>
          
          <DialogFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => setLoadingModeDialogOpen(false)}
            >
              Anuluj
            </Button>
            <Button
              onClick={executeLoadingMode}
              className="bg-amber-500 hover:bg-amber-600 text-white"
            >
              Uruchom tryb załadunkowy
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Raport załadunku */}
      {showLoadingReport && (
        <div className="fixed inset-0 bg-white z-50 overflow-auto">
          <LoadingReport />
          <Button
            className="fixed top-4 right-4 bg-gray-100 text-gray-800 hover:bg-gray-200 z-10"
            onClick={() => setShowLoadingReport(false)}
          >
            Zamknij raport
          </Button>
        </div>
      )}
    </div>
  );
};