import React, { useRef, useEffect, useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  Product, 
  InsertProduct, 
  PRODUCT_CATEGORIES, 
  VAT_RATES, 
  DIETARY_PREFERENCES, 
  DietaryPreference 
} from '@shared/schema';

interface ProductFormProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ProductForm: React.FC<ProductFormProps> = ({ product, isOpen, onClose }) => {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Dodajemy stan ceny brutto do użycia w UI, ale nie wysyłamy go do API
  const [priceGross, setPriceGross] = useState<number>(0);
  const [priceMode, setPriceMode] = useState<'net' | 'gross'>('gross');
  
  const [formData, setFormData] = useState<InsertProduct>({
    name: '',
    shortDescription: '',
    longDescription: '',
    price: 0, // Cena netto w API
    purchasePrice: 0, // Cena zakupu
    category: "Obiady",
    vatRate: "8%",
    imageUrl: 'https://via.placeholder.com/150',
    weight: 0,
    totalCalories: 0,
    ingredients: '',
    allergens: '',
    sku: '', // Kod SKU (obowiązkowy)
    ean: '', // Kod EAN (opcjonalny)
    dietaryPreferences: [], // Preferencje dietetyczne
    nutritionFacts: {
      energyValue: 0,
      fat: 0,
      saturatedFat: 0,
      carbs: 0,
      sugars: 0,
      protein: 0,
      salt: 0
    }
  });

  // Funkcja przeliczająca cenę netto na brutto
  const calculateGrossPrice = (netPrice: number, vatRate: string): number => {
    const vatValue = parseFloat(vatRate.replace('%', '')) / 100;
    return parseFloat((netPrice * (1 + vatValue)).toFixed(2));
  };
  
  // Funkcja przeliczająca cenę brutto na netto
  const calculateNetPrice = (grossPrice: number, vatRate: string): number => {
    const vatValue = parseFloat(vatRate.replace('%', '')) / 100;
    return parseFloat((grossPrice / (1 + vatValue)).toFixed(2));
  };
  
  useEffect(() => {
    if (product) {
      // Ensure product.nutritionFacts is treated as the correct type
      const nutritionFacts = product.nutritionFacts as {
        energyValue: number;
        fat: number;
        saturatedFat: number;
        carbs: number;
        sugars: number;
        protein: number;
        salt: number;
      };
      
      const netPrice = product.price;
      const vatRateToUse = product.vatRate as any || "8%";
      const grossPrice = calculateGrossPrice(netPrice, vatRateToUse);
      
      setPriceGross(grossPrice);
      setFormData({
        name: product.name,
        shortDescription: product.shortDescription,
        longDescription: product.longDescription,
        price: netPrice,
        purchasePrice: product.purchasePrice || 0,
        category: product.category as any, // Rzutowanie, aby zapewnić zgodność z typem
        vatRate: vatRateToUse, // Domyślnie 8% dla żywności, jeśli nie istnieje
        imageUrl: product.imageUrl,
        weight: product.weight || 0,
        totalCalories: product.totalCalories || 0,
        ingredients: product.ingredients || '',
        allergens: product.allergens || '',
        sku: product.sku || '',
        ean: product.ean || '',
        dietaryPreferences: (product.dietaryPreferences || []) as DietaryPreference[],
        nutritionFacts: {
          energyValue: nutritionFacts.energyValue,
          fat: nutritionFacts.fat,
          saturatedFat: nutritionFacts.saturatedFat,
          carbs: nutritionFacts.carbs,
          sugars: nutritionFacts.sugars,
          protein: nutritionFacts.protein,
          salt: nutritionFacts.salt
        }
      });
    } else {
      // Reset form when adding a new product
      setPriceGross(0);
      setFormData({
        name: '',
        shortDescription: '',
        longDescription: '',
        price: 0,
        purchasePrice: 0,
        category: "Obiady",
        vatRate: "8%",
        imageUrl: 'https://via.placeholder.com/150',
        weight: 0,
        totalCalories: 0,
        ingredients: '',
        allergens: '',
        sku: '',
        ean: '',
        dietaryPreferences: [],
        nutritionFacts: {
          energyValue: 0,
          fat: 0,
          saturatedFat: 0,
          carbs: 0,
          sugars: 0,
          protein: 0,
          salt: 0
        }
      });
    }
  }, [product, isOpen]);

  const createMutation = useMutation({
    mutationFn: async (data: InsertProduct) => {
      return await apiRequest('/api/products', { method: 'POST', data });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      onClose();
      toast({
        title: "Sukces",
        description: "Produkt został pomyślnie utworzony",
      });
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się utworzyć produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; product: InsertProduct }) => {
      return await apiRequest(`/api/products/${data.id}`, { method: 'PUT', data: data.product });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      onClose();
      toast({
        title: "Sukces",
        description: "Produkt został pomyślnie zaktualizowany",
      });
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się zaktualizować produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  // Efekt do aktualizacji ceny brutto przy zmianie ceny netto lub stawki VAT
  useEffect(() => {
    if (priceMode === 'net') {
      // Aktualizacja ceny brutto na podstawie netto
      const grossPrice = calculateGrossPrice(formData.price, formData.vatRate);
      setPriceGross(grossPrice);
    }
  }, [formData.price, formData.vatRate, priceMode]);
  
  // Obsługa zmiany stawki VAT
  const handleVatRateChange = (value: string) => {
    const newVatRate = value as any;
    setFormData({...formData, vatRate: newVatRate});
    
    if (priceMode === 'net') {
      // Przelicz brutto na podstawie nowego VAT i aktualnej ceny netto
      const newGrossPrice = calculateGrossPrice(formData.price, newVatRate);
      setPriceGross(newGrossPrice);
    } else {
      // Przelicz netto na podstawie nowego VAT i aktualnej ceny brutto
      const newNetPrice = calculateNetPrice(priceGross, newVatRate);
      setFormData(prev => ({...prev, price: newNetPrice}));
    }
  };
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name.startsWith('nutritionFacts.')) {
      const nutritionKey = name.split('.')[1] as keyof typeof formData.nutritionFacts;
      setFormData({
        ...formData,
        nutritionFacts: {
          ...formData.nutritionFacts,
          [nutritionKey]: parseFloat(value) || 0
        }
      });
    } else if (name === 'price') {
      // Obsługa zmiany ceny netto
      const netPrice = parseFloat(value) || 0;
      setFormData({
        ...formData,
        price: netPrice
      });
      
      if (priceMode === 'net') {
        // Aktualizacja ceny brutto na podstawie netto
        const grossPrice = calculateGrossPrice(netPrice, formData.vatRate);
        setPriceGross(grossPrice);
      }
    } else if (name === 'priceGross') {
      // Obsługa zmiany ceny brutto
      const grossPrice = parseFloat(value) || 0;
      setPriceGross(grossPrice);
      
      if (priceMode === 'gross') {
        // Aktualizacja ceny netto na podstawie brutto
        const netPrice = calculateNetPrice(grossPrice, formData.vatRate);
        setFormData(prev => ({...prev, price: netPrice}));
      }
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setFormData({
            ...formData,
            imageUrl: event.target.result as string
          });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImageField = () => {
    setFormData({
      ...formData,
      imageUrl: ''
    });
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (product) {
      updateMutation.mutate({ id: product.id, product: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const generateRandomImage = () => {
    const randomId = Math.floor(Math.random() * 1000);
    setFormData({
      ...formData,
      imageUrl: `https://picsum.photos/id/${randomId}/200`
    });
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>{product ? 'Edytuj Produkt' : 'Dodaj Nowy Produkt'}</DialogTitle>
          <DialogDescription>Wypełnij formularz, aby {product ? 'zaktualizować' : 'dodać'} produkt do automatu.</DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4">
            {/* Sekcja podstawowych informacji o produkcie */}
            <div className="col-span-1 md:col-span-2 mt-2 mb-2 border border-gray-200 rounded-md p-4 bg-gray-50">
              <h3 className="text-base font-medium text-gray-800 mb-3">Podstawowe informacje</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="category">Kategoria</Label>
                  <Select
                    value={formData.category}
                    onValueChange={(value) => setFormData({...formData, category: value as any})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz kategorię" />
                    </SelectTrigger>
                    <SelectContent>
                      {PRODUCT_CATEGORIES.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex space-x-3">
                  <div className="flex-1">
                    <Label htmlFor="sku">SKU <span className="text-red-500">*</span></Label>
                    <Input 
                      id="sku"
                      name="sku"
                      value={formData.sku}
                      onChange={handleChange}
                      required
                      placeholder="Kod produktu"
                    />
                  </div>
                  <div className="flex-1">
                    <Label htmlFor="ean">EAN</Label>
                    <Input 
                      id="ean"
                      name="ean"
                      value={formData.ean}
                      onChange={handleChange}
                      placeholder="Kod EAN"
                    />
                  </div>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="name">Nazwa Produktu</Label>
                  <Input 
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="shortDescription">Krótki Opis</Label>
                  <Input 
                    id="shortDescription"
                    name="shortDescription"
                    value={formData.shortDescription}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="longDescription">Pełny Opis</Label>
                <Textarea 
                  id="longDescription"
                  name="longDescription"
                  rows={3}
                  value={formData.longDescription}
                  onChange={handleChange}
                  required
                />
              </div>
            </div>
            
            {/* Sekcja zdjęcia produktu */}
            <div className="col-span-1 md:col-span-2 mt-2 mb-2 border border-gray-200 rounded-md p-4 bg-gray-50">
              <h3 className="text-base font-medium text-gray-800 mb-3">Zdjęcie Produktu</h3>
              
              <div className="flex items-start gap-4">
                <div className="flex-1">
                  <div className="mb-3">
                    <Label htmlFor="fileInput" className="mb-2 block">Wybierz plik ze zdjęciem</Label>
                    <Input 
                      id="fileInput"
                      type="file"
                      ref={fileInputRef}
                      accept="image/*"
                      onChange={handleImageUpload}
                    />
                  </div>
                  <div>
                    <Label htmlFor="imageUrl" className="mb-2 block">Lub wpisz adres URL obrazu</Label>
                    <Input 
                      id="imageUrl"
                      name="imageUrl"
                      placeholder="https://"
                      value={formData.imageUrl}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="w-32 h-32 bg-gray-100 rounded-md overflow-hidden border border-gray-200 flex items-center justify-center">
                  {formData.imageUrl ? (
                    <img
                      src={formData.imageUrl}
                      alt="Podgląd"
                      className="max-h-full max-w-full object-contain"
                    />
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  )}
                </div>
              </div>
              <div className="mt-3">
                <Button 
                  type="button" 
                  variant="outline"
                  size="sm"
                  onClick={clearImageField}
                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                >
                  Wyczyść zdjęcie
                </Button>
              </div>
            </div>
            
            {/* Sekcja cenowa */}
            <div className="col-span-1 md:col-span-2 mt-2 mb-2 border border-gray-200 rounded-md p-4 bg-gray-50">
              <h3 className="text-base font-medium text-gray-800 mb-3">Cena produktu</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <Label htmlFor="priceMode" className="text-sm">Tryb wprowadzania ceny</Label>
                  </div>
                  <Select
                    value={priceMode}
                    onValueChange={(value) => setPriceMode(value as 'net' | 'gross')}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz tryb" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="net">Podaj cenę netto</SelectItem>
                      <SelectItem value="gross">Podaj cenę brutto</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <Label htmlFor="vatRate" className="text-sm">Stawka VAT</Label>
                  </div>
                  <Select
                    value={formData.vatRate}
                    onValueChange={handleVatRateChange}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Wybierz stawkę VAT" />
                    </SelectTrigger>
                    <SelectContent>
                      {VAT_RATES.map((rate) => (
                        <SelectItem key={rate} value={rate}>
                          {rate}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div></div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <Label htmlFor="price" className="text-sm">Cena netto (zł)</Label>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      priceMode === 'net' 
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-500'
                    }`}>
                      {priceMode === 'net' ? 'EDYTOWANA' : 'WYLICZONA'}
                    </span>
                  </div>
                  <Input 
                    id="price"
                    name="price"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.price}
                    onChange={handleChange}
                    required
                    disabled={priceMode !== 'net'}
                    className={priceMode === 'net' ? 'border-blue-300 focus:border-blue-500' : ''}
                  />
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <Label htmlFor="priceGross" className="text-sm">Cena brutto (zł)</Label>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      priceMode === 'gross' 
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-500'
                    }`}>
                      {priceMode === 'gross' ? 'EDYTOWANA' : 'WYLICZONA'}
                    </span>
                  </div>
                  <Input 
                    id="priceGross"
                    name="priceGross"
                    type="number"
                    min="0"
                    step="0.01"
                    value={priceGross}
                    onChange={handleChange}
                    required
                    disabled={priceMode !== 'gross'}
                    className={priceMode === 'gross' ? 'border-blue-300 focus:border-blue-500' : ''}
                  />
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <Label htmlFor="vatAmount" className="text-sm">Kwota VAT (zł)</Label>
                  </div>
                  <Input 
                    id="vatAmount"
                    name="vatAmount"
                    type="number"
                    readOnly
                    value={(priceGross - formData.price).toFixed(2)}
                    className="bg-gray-50"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <Label htmlFor="purchasePrice" className="text-sm">Cena zakupu netto (zł)</Label>
                  </div>
                  <Input 
                    id="purchasePrice"
                    name="purchasePrice"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.purchasePrice || ""}
                    onChange={handleChange}
                    className="border-yellow-200 focus:border-yellow-400"
                  />
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <Label htmlFor="profit" className="text-sm">Marża netto (zł)</Label>
                  </div>
                  <Input 
                    id="profit"
                    name="profit"
                    type="number"
                    readOnly
                    value={(formData.price - (formData.purchasePrice || 0)).toFixed(2)}
                    className="bg-gray-50"
                  />
                </div>
              </div>
            </div>
            
            {/* Sekcja preferencji dietetycznych */}
            <div className="col-span-1 md:col-span-2 mt-2 mb-2 border border-gray-200 rounded-md p-4 bg-gray-50">
              <h3 className="text-base font-medium text-gray-800 mb-3">Preferencje dietetyczne</h3>
              
              <div className="mb-4">
                <Label className="mb-2 block">Wybierz preferencje dietetyczne, którym odpowiada produkt</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                  {DIETARY_PREFERENCES.map((preference) => (
                    <div key={preference} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`preference-${preference}`}
                        checked={formData.dietaryPreferences.includes(preference)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setFormData({
                              ...formData,
                              dietaryPreferences: [...formData.dietaryPreferences, preference]
                            });
                          } else {
                            setFormData({
                              ...formData,
                              dietaryPreferences: formData.dietaryPreferences.filter(p => p !== preference)
                            });
                          }
                        }}
                        className="h-4 w-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                      />
                      <label htmlFor={`preference-${preference}`} className="text-sm text-gray-700">
                        {preference}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Sekcja informacji o produkcie */}
            <div className="col-span-1 md:col-span-2 mt-2 mb-2 border border-gray-200 rounded-md p-4 bg-gray-50">
              <h3 className="text-base font-medium text-gray-800 mb-3">Informacje o produkcie</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <Label htmlFor="weight">Waga porcji (g)</Label>
                  <Input 
                    id="weight"
                    name="weight"
                    type="number"
                    min="0"
                    step="1"
                    value={formData.weight || ""}
                    onChange={(e) => setFormData({
                      ...formData,
                      weight: e.target.value ? parseInt(e.target.value) : null
                    })}
                  />
                </div>
                
                <div>
                  <Label htmlFor="totalCalories">Kaloryczność całej porcji (kcal)</Label>
                  <Input 
                    id="totalCalories"
                    name="totalCalories"
                    type="number"
                    min="0"
                    step="1"
                    value={formData.totalCalories || ""}
                    onChange={(e) => setFormData({
                      ...formData,
                      totalCalories: e.target.value ? parseInt(e.target.value) : null
                    })}
                  />
                </div>
              </div>
              
              <div className="mb-4">
                <Label htmlFor="ingredients">Pełny skład produktu</Label>
                <Textarea 
                  id="ingredients"
                  name="ingredients"
                  rows={3}
                  placeholder="Wprowadź listę składników produktu..."
                  value={formData.ingredients || ''}
                  onChange={handleChange}
                />
              </div>
              
              <div className="mb-4">
                <Label htmlFor="allergens">Alergeny</Label>
                <Textarea 
                  id="allergens"
                  name="allergens"
                  rows={2}
                  placeholder="Wprowadź informacje o alergenach..."
                  value={formData.allergens || ''}
                  onChange={handleChange}
                />
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-gray-700 mb-2">Wartości odżywcze (na 100g)</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div>
                    <Label className="text-xs" htmlFor="nutritionFacts.energyValue">Wart. energ. (kcal)</Label>
                    <Input 
                      id="nutritionFacts.energyValue"
                      name="nutritionFacts.energyValue"
                      type="number"
                      min="0"
                      value={formData.nutritionFacts.energyValue || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-xs" htmlFor="nutritionFacts.fat">Tłuszcz (g)</Label>
                    <Input 
                      id="nutritionFacts.fat"
                      name="nutritionFacts.fat"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutritionFacts.fat || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-xs" htmlFor="nutritionFacts.saturatedFat">Kwasy nasycone (g)</Label>
                    <Input 
                      id="nutritionFacts.saturatedFat"
                      name="nutritionFacts.saturatedFat"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutritionFacts.saturatedFat || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-xs" htmlFor="nutritionFacts.carbs">Węglowodany (g)</Label>
                    <Input 
                      id="nutritionFacts.carbs"
                      name="nutritionFacts.carbs"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutritionFacts.carbs || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-xs" htmlFor="nutritionFacts.sugars">Cukry (g)</Label>
                    <Input 
                      id="nutritionFacts.sugars"
                      name="nutritionFacts.sugars"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutritionFacts.sugars || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-xs" htmlFor="nutritionFacts.protein">Białko (g)</Label>
                    <Input 
                      id="nutritionFacts.protein"
                      name="nutritionFacts.protein"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutritionFacts.protein || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div>
                    <Label className="text-xs" htmlFor="nutritionFacts.salt">Sól (g)</Label>
                    <Input 
                      id="nutritionFacts.salt"
                      name="nutritionFacts.salt"
                      type="number"
                      min="0"
                      step="0.1"
                      value={formData.nutritionFacts.salt || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter className="px-4 pb-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={isPending}>
              Anuluj
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? 'Zapisywanie...' : 'Zapisz Produkt'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
