import React, { useState, useEffect } from 'react';
import { 
  Employee, 
  InsertEmployee, 
  RFID_CARD_FORMATS, 
  DIETARY_PREFERENCES 
} from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface SimpleEmployeeEditorProps {
  employee: Employee | null;
  onCancel: () => void;
  onSave: () => void;
}

export const SimpleEmployeeEditor: React.FC<SimpleEmployeeEditorProps> = ({ 
  employee, 
  onCancel, 
  onSave 
}) => {
  const { toast } = useToast();
  
  // Dane formularza
  const [firstName, setFirstName] = useState(employee?.firstName || '');
  const [lastName, setLastName] = useState(employee?.lastName || '');
  const [rfidCardNumber, setRfidCardNumber] = useState(employee?.rfidCardNumber || '');
  const [rfidCardFormat, setRfidCardFormat] = useState<'decimal' | 'hex'>(
    (employee?.rfidCardFormat as 'decimal' | 'hex') || 'decimal'
  );
  const [email, setEmail] = useState(employee?.email || '');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [dietaryPreference, setDietaryPreference] = useState<string | null>(
    employee?.dietaryPreference || null
  );
  const [isLoading, setIsLoading] = useState(false);

  // Resetuj dane formularza gdy zmieni się pracownik
  useEffect(() => {
    if (employee) {
      setFirstName(employee.firstName || '');
      setLastName(employee.lastName || '');
      setRfidCardNumber(employee.rfidCardNumber || '');
      setRfidCardFormat((employee.rfidCardFormat as 'decimal' | 'hex') || 'decimal');
      setEmail(employee.email || '');
      setPassword(''); // Hasło zawsze resetujemy
      setConfirmPassword(''); // Potwierdzenie hasła również resetujemy
      setDietaryPreference(employee.dietaryPreference || null);
    } else {
      setFirstName('');
      setLastName('');
      setRfidCardNumber('');
      setRfidCardFormat('decimal');
      setEmail('');
      setPassword('');
      setConfirmPassword('');
      setDietaryPreference(null);
    }
  }, [employee]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsLoading(true);
      
      // Walidacja
      if (!firstName || !lastName) {
        toast({
          title: 'Błąd',
          description: 'Uzupełnij wymagane pola formularza',
          variant: 'destructive',
        });
        return;
      }
      
      // Walidacja hasła - jeśli wprowadzono hasło, to musi być zgodne z potwierdzeniem
      if (password && password !== confirmPassword) {
        toast({
          title: 'Błąd',
          description: 'Hasło i potwierdzenie hasła nie są zgodne',
          variant: 'destructive',
        });
        return;
      }
      
      const employeeData: InsertEmployee = {
        firstName,
        lastName,
        rfidCardNumber: rfidCardNumber || undefined, // Pole jest opcjonalne
        rfidCardFormat,
        email: email || '',
        dietaryPreference: dietaryPreference as any,
      };
      
      // Jeśli wprowadzono hasło, dodajemy je do danych wraz z potwierdzeniem
      if (password) {
        employeeData.password = password;
        employeeData.confirmPassword = confirmPassword;
      }
      
      if (employee) {
        // Aktualizacja
        await apiRequest(`/api/employees/${employee.id}`, {
          method: 'PUT',
          data: employeeData,
        });
        
        toast({
          title: 'Sukces',
          description: 'Dane pracownika zostały zaktualizowane',
        });
      } else {
        // Dodawanie
        await apiRequest('/api/employees', {
          method: 'POST',
          data: employeeData,
        });
        
        toast({
          title: 'Sukces',
          description: 'Nowy pracownik został dodany',
        });
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      onSave();
      
    } catch (error) {
      console.error('Błąd zapisywania pracownika:', error);
      toast({
        title: 'Błąd',
        description: 'Wystąpił błąd podczas zapisywania danych',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-1">
          Imię*
          <input
            type="text"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
            required
          />
        </label>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">
          Nazwisko*
          <input
            type="text"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
            required
          />
        </label>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">
            Numer karty RFID
            <input
              type="text"
              value={rfidCardNumber}
              onChange={(e) => setRfidCardNumber(e.target.value)}
              className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
              placeholder="Opcjonalnie"
            />
          </label>
        </div>
        
        <div>
          <label className="block text-sm font-medium mb-1">
            Format karty
            <select
              value={rfidCardFormat}
              onChange={(e) => setRfidCardFormat(e.target.value as 'decimal' | 'hex')}
              className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
            >
              {RFID_CARD_FORMATS.map((format) => (
                <option key={format} value={format}>
                  {format === 'decimal' ? 'Decimal (123456)' : 'HEX (1A2B3C)'}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">
          Email*
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
            required
          />
        </label>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">
          Hasło {employee ? '(zostaw puste, aby nie zmieniać)' : '*'}
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
            required={!employee} // Wymagane tylko przy dodawaniu nowego pracownika
            placeholder={employee ? 'Opcjonalnie' : 'Wymagane dla nowego pracownika'}
          />
        </label>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">
          Potwierdź hasło {employee ? '(zostaw puste, aby nie zmieniać)' : '*'}
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
            required={!employee} // Wymagane tylko przy dodawaniu nowego pracownika
            placeholder={employee ? 'Opcjonalnie' : 'Wymagane dla nowego pracownika'}
          />
        </label>
      </div>
      
      <div>
        <label className="block text-sm font-medium mb-1">
          Preferencja dietetyczna
          <select
            value={dietaryPreference || ''}
            onChange={(e) => setDietaryPreference(e.target.value || null)}
            className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md"
          >
            <option value="">Brak preferencji</option>
            {DIETARY_PREFERENCES.map((preference) => (
              <option key={preference} value={preference}>
                {preference}
              </option>
            ))}
          </select>
        </label>
      </div>
      
      <div className="flex justify-end space-x-2 pt-2">
        <button
          type="button"
          onClick={onCancel}
          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          disabled={isLoading}
        >
          Anuluj
        </button>
        <button
          type="submit"
          className="px-4 py-2 bg-green-500 rounded-md text-white hover:bg-green-600"
          disabled={isLoading}
        >
          {isLoading ? 'Zapisywanie...' : employee ? 'Zapisz zmiany' : 'Dodaj pracownika'}
        </button>
      </div>
    </form>
  );
};