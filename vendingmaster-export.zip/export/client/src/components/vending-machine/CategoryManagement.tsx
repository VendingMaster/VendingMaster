import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription,
  DialogClose
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import { Category, PRODUCT_CATEGORIES } from '@shared/schema';
import { Pencil, Trash2, Plus } from 'lucide-react';

// Definiujemy predefiniowane emoji dla kategorii
const CATEGORY_EMOJIS = {
  "Obiady": "🍽️",
  "Śniadania": "☕",
  "Zupy": "🍲",
  "Sałatki": "🥗",
  "Napoje": "🥤",
  "Przekąski": "🍪",
  "Inne": "🛒"
};

interface CategoryFormData {
  name: string;
  icon?: string | null;
  displayOrder?: number;
}

export const CategoryManagement: React.FC = () => {
  const queryClient = useQueryClient();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [categoryFormData, setCategoryFormData] = useState<CategoryFormData>({ name: '', icon: null });
  const [currentCategory, setCurrentCategory] = useState<Category | null>(null);
  const [iconPreview, setIconPreview] = useState<string | null>(null);

  // Pobieranie kategorii
  const { data: categories, isLoading, error } = useQuery({
    queryKey: ['/api/categories'],
    select: (data: Category[]) => data,
  });

  // Tworzenie nowej kategorii
  const createMutation = useMutation({
    mutationFn: async (data: CategoryFormData) => {
      return await apiRequest<Category>('/api/categories', {
        method: 'POST',
        data,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setIsAddDialogOpen(false);
      setCategoryFormData({ name: '', icon: null });
      setIconPreview(null);
      toast({
        title: "Sukces",
        description: "Kategoria została utworzona",
      });
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: "Nie udało się utworzyć kategorii",
        variant: "destructive",
      });
      console.error("Błąd tworzenia kategorii:", error);
    }
  });

  // Aktualizacja kategorii
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; category: CategoryFormData }) => {
      return await apiRequest<Category>(`/api/categories/${data.id}`, {
        method: 'PUT',
        data: data.category,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setIsEditDialogOpen(false);
      setCurrentCategory(null);
      setCategoryFormData({ name: '', icon: null });
      setIconPreview(null);
      toast({
        title: "Sukces",
        description: "Kategoria została zaktualizowana",
      });
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: "Nie udało się zaktualizować kategorii",
        variant: "destructive",
      });
      console.error("Błąd aktualizacji kategorii:", error);
    }
  });

  // Usuwanie kategorii
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest(`/api/categories/${id}`, {
        method: 'DELETE',
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/categories'] });
      setIsDeleteDialogOpen(false);
      setCurrentCategory(null);
      toast({
        title: "Sukces",
        description: "Kategoria została pomyślnie usunięta",
      });
    },
    onError: (error: any) => {
      const errorMessage = error?.response?.data?.message || "Nie udało się usunąć kategorii";
      toast({
        title: "Błąd usuwania kategorii",
        description: errorMessage,
        variant: "destructive",
      });
      console.error("Błąd usuwania kategorii:", error);
    }
  });

  // Obsługa formularza
  const handleAddCategory = () => {
    createMutation.mutate(categoryFormData);
  };

  const handleEditCategory = () => {
    if (currentCategory) {
      updateMutation.mutate({ 
        id: currentCategory.id, 
        category: categoryFormData 
      });
    }
  };

  const handleDeleteCategory = () => {
    if (currentCategory) {
      deleteMutation.mutate(currentCategory.id);
    }
  };

  // Funkcja do obsługi wczytywania plików obrazów
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Sprawdzenie typu pliku
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Błąd",
        description: "Proszę wybrać plik obrazu (jpg, png, svg, gif).",
        variant: "destructive",
      });
      return;
    }

    // Sprawdzenie rozmiaru pliku (limit 500KB)
    if (file.size > 500 * 1024) {
      toast({
        title: "Błąd",
        description: "Rozmiar obrazu nie może przekraczać 500KB.",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setIconPreview(dataUrl);
      setCategoryFormData(prev => ({ ...prev, icon: dataUrl }));
    };
    reader.readAsDataURL(file);
  };

  // Funkcja do resetowania podglądu ikony
  const resetIcon = () => {
    setIconPreview(null);
    setCategoryFormData(prev => ({ ...prev, icon: null }));
  };

  const openEditDialog = (category: Category) => {
    setCurrentCategory(category);
    setCategoryFormData({ 
      name: category.name,
      icon: category.icon,
      displayOrder: category.displayOrder || 0
    });
    setIconPreview(category.icon);
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (category: Category) => {
    setCurrentCategory(category);
    setIsDeleteDialogOpen(true);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-800">Zarządzanie Kategoriami</h3>
          <p className="text-gray-600 mt-1">Tworzenie i edycja kategorii produktów w automacie</p>
        </div>
        <Button 
          onClick={() => setIsAddDialogOpen(true)} 
          className="bg-green-500 hover:bg-green-600 flex items-center gap-2"
        >
          <Plus size={16} /> Dodaj Kategorię
        </Button>
      </div>

      {/* Categories List */}
      <div className="bg-white shadow overflow-hidden rounded-md">
        {isLoading ? (
          <div className="space-y-4 p-4">
            {[...Array(3)].map((_, index) => (
              <div key={index} className="flex items-center space-x-4">
                <Skeleton className="h-12 w-12 rounded-md" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-1/4" />
                </div>
                <Skeleton className="h-8 w-16" />
              </div>
            ))}
          </div>
        ) : !categories || categories.length === 0 ? (
          <div className="py-8 text-center text-gray-500">
            Brak dostępnych kategorii. Kliknij "Dodaj Kategorię", aby utworzyć nową.
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {categories.map((category) => (
              <li key={category.id}>
                <div className="px-4 py-4 flex items-center sm:px-6">
                  <div className="min-w-0 flex-1 sm:flex sm:items-center sm:justify-between">
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-12 w-12 bg-gray-100 rounded-md overflow-hidden flex items-center justify-center">
                        {category.icon ? (
                          category.icon.startsWith('data:') ? (
                            <img 
                              src={category.icon} 
                              alt={`Ikona dla ${category.name}`} 
                              className="h-full w-full object-contain" 
                            />
                          ) : (
                            <span className="text-4xl">{category.icon}</span>
                          )
                        ) : (
                          <div className="flex items-center justify-center h-full w-full bg-gray-200">
                            <span className="text-xs text-gray-500">Brak</span>
                          </div>
                        )}
                      </div>
                      <div className="ml-4">
                        <h4 className="text-sm font-medium text-gray-900">{category.name}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-500 mt-1">
                          <span>ID: {category.id}</span>
                          <span>Kolejność: {category.displayOrder || 0}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="ml-5 flex-shrink-0 flex space-x-2">
                    <button 
                      className="p-1 rounded-full text-gray-400 hover:text-gray-500"
                      onClick={() => openEditDialog(category)}
                    >
                      <Pencil className="h-5 w-5" />
                    </button>
                    <button 
                      className="p-1 rounded-full text-gray-400 hover:text-red-500"
                      onClick={() => openDeleteDialog(category)}
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Total Categories Count */}
      <div className="mt-6 border-t border-gray-200 pt-4">
        <p className="text-sm text-gray-600 font-medium">
          Łączna ilość kategorii: {categories?.length || 0}
        </p>
      </div>

      {/* Dialog dodawania kategorii */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Dodaj nową kategorię
            </DialogTitle>
            <DialogDescription>
              Wprowadź nazwę dla nowej kategorii produktów.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            {/* Nazwa kategorii */}
            <div className="grid grid-cols-5 items-center gap-4">
              <Label htmlFor="name" className="text-right font-medium">
                Nazwa
              </Label>
              <Input
                id="name"
                value={categoryFormData.name}
                onChange={(e) => setCategoryFormData(prev => ({ ...prev, name: e.target.value }))}
                className="col-span-4 shadow-sm focus:ring-2 focus:ring-blue-200"
                placeholder="Np. Lunch, Przekąski, Napoje"
              />
            </div>
            
            {/* Ikona kategorii */}
            <div className="grid grid-cols-5 items-start gap-4 border-t pt-4">
              <Label htmlFor="icon" className="text-right font-medium mt-4">
                Ikona
              </Label>
              <div className="col-span-4 space-y-6">
                {/* Predefiniowane emoji dla kategorii */}
                <div className="space-y-3 bg-gray-50 p-4 rounded-lg border">
                  <Label className="font-medium text-gray-800">Wybierz emoji dla kategorii</Label>
                  <div className="flex mb-2 items-center">
                    <div className="w-16 h-16 mr-4 bg-white border rounded-lg flex items-center justify-center shadow-sm">
                      <span className="text-4xl">
                        {categoryFormData.icon || "👆"}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-500 mb-1">Aktualne wybrane emoji</p>
                      <p className="text-lg font-medium">{categoryFormData.icon || "Nie wybrano"}</p>
                    </div>
                  </div>
                  
                  <RadioGroup
                    value={categoryFormData.icon || ""}
                    onValueChange={(value) => {
                      setCategoryFormData(prev => ({ ...prev, icon: value }));
                      setIconPreview(value);
                    }}
                    className="grid grid-cols-8 gap-2"
                  >
                    {Object.entries(CATEGORY_EMOJIS).map(([category, emoji]) => (
                      <div 
                        key={category} 
                        className={`relative w-10 h-10 flex items-center justify-center border rounded-md hover:bg-blue-50 transition-colors cursor-pointer ${
                          categoryFormData.icon === emoji ? 'border-blue-500 bg-blue-50 shadow-sm' : 'border-gray-200'
                        }`}
                        title={category}
                        onClick={() => {
                          setCategoryFormData(prev => ({ ...prev, icon: emoji }));
                          setIconPreview(emoji);
                        }}
                      >
                        <RadioGroupItem 
                          value={emoji} 
                          id={`emoji-${category}`} 
                          className="sr-only"
                        />
                        <span className="text-2xl">{emoji}</span>
                        {categoryFormData.icon === emoji && (
                          <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full" />
                        )}
                      </div>
                    ))}
                  </RadioGroup>
                </div>
                
                {/* Wgrywanie własnej ikony */}
                <div className="space-y-3 bg-gray-50 p-4 rounded-lg border">
                  <Label className="font-medium text-gray-800">Lub wgraj własną ikonę</Label>
                  <Input
                    id="icon"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="bg-white shadow-sm"
                  />
                  <div className="text-xs text-gray-500 mt-1">
                    Zalecany rozmiar ikony: 600x600px lub 800x600px, maksymalnie 500KB.<br/>
                    Obsługiwane formaty: JPG, PNG, SVG, GIF.
                  </div>
                </div>
                
                {/* Przycisk do usunięcia ikony */}
                {iconPreview && (
                  <div className="flex justify-end mt-3">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={resetIcon}
                      className="text-gray-600"
                    >
                      Usuń wybrane emoji
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter className="border-t pt-4 mt-2">
            <Button 
              variant="outline" 
              onClick={() => {
                setIsAddDialogOpen(false);
                resetIcon();
                setCategoryFormData({ name: '', icon: null });
              }}
              className="border-gray-300"
            >
              Anuluj
            </Button>
            <Button 
              onClick={handleAddCategory} 
              disabled={!categoryFormData.name.trim() || createMutation.isPending}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {createMutation.isPending ? "Zapisywanie..." : "Zapisz"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog edycji kategorii */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Edytuj kategorię
            </DialogTitle>
            <DialogDescription>
              Zmień nazwę lub ikonę wybranej kategorii produktów.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-6 py-4">
            {/* Nazwa kategorii */}
            <div className="grid grid-cols-5 items-center gap-4">
              <Label htmlFor="edit-name" className="text-right font-medium">
                Nazwa
              </Label>
              <Input
                id="edit-name"
                value={categoryFormData.name}
                onChange={(e) => setCategoryFormData(prev => ({ ...prev, name: e.target.value }))}
                className="col-span-4 shadow-sm focus:ring-2 focus:ring-blue-200"
                placeholder="Wprowadź nazwę kategorii"
              />
            </div>
            
            {/* Kolejność wyświetlania */}
            <div className="grid grid-cols-5 items-center gap-4">
              <Label htmlFor="edit-order" className="text-right font-medium">
                Kolejność
              </Label>
              <div className="col-span-4 space-y-2">
                <Input
                  id="edit-order"
                  type="number"
                  min="0"
                  value={categoryFormData.displayOrder || 0}
                  onChange={(e) => setCategoryFormData(prev => ({ 
                    ...prev, 
                    displayOrder: parseInt(e.target.value) || 0 
                  }))}
                  className="shadow-sm focus:ring-2 focus:ring-blue-200"
                />
                <div className="text-xs text-gray-500 italic">
                  Niższa liczba = wyższa pozycja w widoku kiosku (0 = najwyżej)
                </div>
              </div>
            </div>
            
            {/* Ikona kategorii */}
            <div className="grid grid-cols-5 items-start gap-4 border-t pt-4">
              <Label htmlFor="edit-icon" className="text-right font-medium mt-4">
                Ikona
              </Label>
              <div className="col-span-4 space-y-6">
                {/* Predefiniowane emoji dla kategorii */}
                <div className="space-y-3 bg-gray-50 p-4 rounded-lg border">
                  <Label className="font-medium text-gray-800">Wybierz emoji dla kategorii</Label>
                  <div className="flex mb-2 items-center">
                    <div className="w-16 h-16 mr-4 bg-white border rounded-lg flex items-center justify-center shadow-sm">
                      <span className="text-4xl">
                        {categoryFormData.icon || "👆"}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-500 mb-1">Aktualne wybrane emoji</p>
                      <p className="text-lg font-medium">{categoryFormData.icon || "Nie wybrano"}</p>
                    </div>
                  </div>
                  
                  <RadioGroup
                    value={categoryFormData.icon || ""}
                    onValueChange={(value) => {
                      setCategoryFormData(prev => ({ ...prev, icon: value }));
                      setIconPreview(value);
                    }}
                    className="grid grid-cols-8 gap-2"
                  >
                    {Object.entries(CATEGORY_EMOJIS).map(([category, emoji]) => (
                      <div 
                        key={category} 
                        className={`relative w-10 h-10 flex items-center justify-center border rounded-md hover:bg-blue-50 transition-colors cursor-pointer ${
                          categoryFormData.icon === emoji ? 'border-blue-500 bg-blue-50 shadow-sm' : 'border-gray-200'
                        }`}
                        title={category}
                        onClick={() => {
                          setCategoryFormData(prev => ({ ...prev, icon: emoji }));
                          setIconPreview(emoji);
                        }}
                      >
                        <RadioGroupItem 
                          value={emoji} 
                          id={`edit-emoji-${category}`} 
                          className="sr-only"
                        />
                        <span className="text-2xl">{emoji}</span>
                        {categoryFormData.icon === emoji && (
                          <div className="absolute -top-1 -right-1 w-3 h-3 bg-blue-500 rounded-full" />
                        )}
                      </div>
                    ))}
                  </RadioGroup>
                </div>
                
                {/* Wgrywanie własnej ikony */}
                <div className="space-y-3 bg-gray-50 p-4 rounded-lg border">
                  <Label className="font-medium text-gray-800">Lub wgraj własną ikonę</Label>
                  <Input
                    id="edit-icon"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="bg-white shadow-sm"
                  />
                  <div className="text-xs text-gray-500 mt-1">
                    Zalecany rozmiar ikony: 600x600px lub 800x600px, maksymalnie 500KB.<br/>
                    Obsługiwane formaty: JPG, PNG, SVG, GIF.
                  </div>
                </div>
                
                {/* Przycisk do usunięcia ikony */}
                {iconPreview && (
                  <div className="flex justify-end mt-3">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={resetIcon}
                      className="text-gray-600"
                    >
                      Usuń wybrane emoji
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          <DialogFooter className="border-t pt-4 mt-2">
            <Button 
              variant="outline" 
              onClick={() => {
                setIsEditDialogOpen(false);
                resetIcon();
                setCategoryFormData({ name: '', icon: null });
              }}
              className="border-gray-300"
            >
              Anuluj
            </Button>
            <Button 
              onClick={handleEditCategory} 
              disabled={!categoryFormData.name.trim() || updateMutation.isPending}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {updateMutation.isPending ? "Zapisywanie..." : "Zapisz zmiany"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog potwierdzenia usunięcia */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent className="max-w-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-bold bg-gradient-to-r from-red-600 to-rose-600 bg-clip-text text-transparent">
              Usunąć kategorię?
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-4 py-2">
              <p className="text-gray-700 text-base">
                Czy na pewno chcesz usunąć kategorię 
                <strong className="ml-1 font-semibold text-black">
                  "{currentCategory?.name || ""}"
                </strong>
                ?
              </p>
              
              {currentCategory?.icon && (
                <div className="flex items-center space-x-3 mt-2 p-3 bg-gray-50 rounded-lg border">
                  <span className="font-medium">Ikona kategorii:</span>
                  <div className="h-12 w-12 bg-white rounded-md flex items-center justify-center shadow-sm border">
                    {currentCategory.icon.startsWith('data:') ? (
                      <img 
                        src={currentCategory.icon} 
                        alt={`Ikona dla ${currentCategory.name}`} 
                        className="h-full w-full object-contain"
                      />
                    ) : (
                      <span className="text-3xl">{currentCategory.icon}</span>
                    )}
                  </div>
                </div>
              )}
              
              <div className="bg-red-50 border border-red-200 text-red-700 p-3 rounded-lg mt-4">
                <p className="font-medium flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  Uwaga
                </p>
                <p className="text-sm mt-1 ml-7">
                  Ta operacja jest nieodwracalna. Usunięcie kategorii wpłynie również na produkty przypisane do tej kategorii.
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="border-t pt-4 mt-2">
            <AlertDialogCancel className="border-gray-300">
              Anuluj
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteCategory} 
              className="bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-700 hover:to-rose-700"
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Usuwanie...
                </span>
              ) : "Usuń kategorię"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};