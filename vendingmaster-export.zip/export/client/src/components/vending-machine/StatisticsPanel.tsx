import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, 
  ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell 
} from 'recharts';

// Funkcja pomocnicza do formatowania walut
function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pl-PL', { style: 'currency', currency: 'PLN' }).format(value);
}

// Dane przykładowe dla celów demonstracyjnych
const dailySalesData = [
  { date: '14/03', Dania: 12, Sałatki: 8, Zupy: 5, Przekąski: 15, total: 40 },
  { date: '15/03', Dania: 15, Sałatki: 10, Zupy: 7, Przekąski: 8, total: 40 },
  { date: '16/03', Dania: 8, Sałatki: 14, Zupy: 6, Przekąski: 10, total: 38 },
  { date: '17/03', Dania: 10, Sałatki: 12, Zupy: 8, Przekąski: 5, total: 35 },
  { date: '18/03', Dania: 16, Sałatki: 7, Zupy: 4, Przekąski: 6, total: 33 },
  { date: '19/03', Dania: 18, Sałatki: 9, Zupy: 6, Przekąski: 12, total: 45 },
  { date: '20/03', Dania: 14, Sałatki: 11, Zupy: 8, Przekąski: 14, total: 47 },
];

const weeklySalesData = [
  { week: '8-14/03', Dania: 82, Sałatki: 64, Zupy: 48, Przekąski: 75, total: 269 },
  { week: '15-21/03', Dania: 95, Sałatki: 72, Zupy: 52, Przekąski: 68, total: 287 },
  { week: '22-28/03', Dania: 77, Sałatki: 68, Zupy: 45, Przekąski: 70, total: 260 },
  { week: '29/03-4/04', Dania: 88, Sałatki: 58, Zupy: 50, Przekąski: 80, total: 276 },
];

const monthlySalesData = [
  { month: 'Styczeń', Dania: 320, Sałatki: 280, Zupy: 210, Przekąski: 350, total: 1160 },
  { month: 'Luty', Dania: 290, Sałatki: 240, Zupy: 180, Przekąski: 320, total: 1030 },
  { month: 'Marzec', Dania: 350, Sałatki: 260, Zupy: 200, Przekąski: 310, total: 1120 },
];

const topProductsData = [
  { name: 'Sałatka z kurczakiem', value: 160, color: '#8884d8' },
  { name: 'Zupa pomidorowa', value: 120, color: '#83a6ed' },
  { name: 'Devolaille z ziemniakami', value: 200, color: '#8dd1e1' },
  { name: 'Kanapka z szynką', value: 130, color: '#82ca9d' },
  { name: 'Surówka z marchewki', value: 90, color: '#a4de6c' },
];

const categoryRevenueData = [
  { name: 'Dania główne', revenue: 5600, color: '#8884d8' },
  { name: 'Sałatki', revenue: 3200, color: '#83a6ed' },
  { name: 'Zupy', revenue: 2100, color: '#8dd1e1' },
  { name: 'Przekąski', revenue: 4200, color: '#82ca9d' },
];

const hourlyDistributionData = [
  { hour: '7-9', transactions: 45 },
  { hour: '9-11', transactions: 80 },
  { hour: '11-13', transactions: 125 },
  { hour: '13-15', transactions: 110 },
  { hour: '15-17', transactions: 85 },
  { hour: '17-19', transactions: 60 },
  { hour: '19-21', transactions: 30 },
];

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D'];

export const StatisticsPanel: React.FC = () => {
  const [period, setPeriod] = useState('daily');
  const [reportType, setReportType] = useState('sales');

  // Określenie danych na podstawie wybranego okresu
  const getSalesData = () => {
    switch (period) {
      case 'daily':
        return dailySalesData;
      case 'weekly':
        return weeklySalesData;
      case 'monthly':
        return monthlySalesData;
      default:
        return dailySalesData;
    }
  };

  // Określenie etykiety osi X na podstawie wybranego okresu
  const getXAxisLabel = () => {
    switch (period) {
      case 'daily':
        return 'Dzień';
      case 'weekly':
        return 'Tydzień';
      case 'monthly':
        return 'Miesiąc';
      default:
        return 'Dzień';
    }
  };

  // Określenie klucza daty/okresu na podstawie wybranego okresu
  const getXAxisDataKey = () => {
    switch (period) {
      case 'daily':
        return 'date';
      case 'weekly':
        return 'week';
      case 'monthly':
        return 'month';
      default:
        return 'date';
    }
  };

  // Używamy globalnej funkcji formatCurrency zdefiniowanej na początku pliku

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-800">Zarządzanie Statystykami</h3>
          <p className="text-gray-600 mt-1">
            Analiza sprzedaży produktów w automacie sprzedażowym
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <div>
            <Label htmlFor="period-select">Okres</Label>
            <Select
              value={period}
              onValueChange={setPeriod}
            >
              <SelectTrigger id="period-select" className="w-[180px]">
                <SelectValue placeholder="Wybierz okres" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Dzienne</SelectItem>
                <SelectItem value="weekly">Tygodniowe</SelectItem>
                <SelectItem value="monthly">Miesięczne</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="report-type">Typ raportu</Label>
            <Select
              value={reportType}
              onValueChange={setReportType}
            >
              <SelectTrigger id="report-type" className="w-[180px]">
                <SelectValue placeholder="Wybierz typ raportu" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sales">Ilość sprzedaży</SelectItem>
                <SelectItem value="revenue">Przychód</SelectItem>
                <SelectItem value="products">Popularne produkty</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <Tabs defaultValue="chart" className="w-full">
        <TabsList className="grid w-full md:w-[400px] grid-cols-3">
          <TabsTrigger value="chart">Wykres</TabsTrigger>
          <TabsTrigger value="summary">Podsumowanie</TabsTrigger>
          <TabsTrigger value="details">Szczegóły</TabsTrigger>
        </TabsList>
        
        <TabsContent value="chart" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>{reportType === 'sales' ? 'Sprzedaż wg kategorii' : reportType === 'revenue' ? 'Przychód wg kategorii' : 'Popularne produkty'}</CardTitle>
              <CardDescription>
                {period === 'daily' ? 'Dane z ostatnich 7 dni' : 
                 period === 'weekly' ? 'Dane z ostatnich 4 tygodni' : 'Dane z ostatnich 3 miesięcy'}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <div className="h-[400px] w-full p-4">
                {reportType === 'products' ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={topProductsData}
                        cx="50%"
                        cy="50%"
                        labelLine={true}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={120}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {topProductsData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [value, 'Ilość']} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={getSalesData()}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 30,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey={getXAxisDataKey()} 
                        label={{ value: getXAxisLabel(), position: 'insideBottom', offset: -10 }} 
                      />
                      <YAxis 
                        label={{ 
                          value: reportType === 'sales' ? 'Ilość sprzedaży' : 'Przychód (PLN)', 
                          angle: -90, 
                          position: 'insideLeft' 
                        }} 
                      />
                      <Tooltip formatter={(value) => reportType === 'revenue' ? formatCurrency(value as number) : value} />
                      <Legend />
                      <Bar dataKey="Dania" fill="#0088FE" />
                      <Bar dataKey="Sałatki" fill="#00C49F" />
                      <Bar dataKey="Zupy" fill="#FFBB28" />
                      <Bar dataKey="Przekąski" fill="#FF8042" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Podział sprzedaży wg kategorii</CardTitle>
                <CardDescription>Udział procentowy sprzedaży w kategoriach</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryRevenueData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="revenue"
                      >
                        {categoryRevenueData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [formatCurrency(Number(value)), 'Przychód']} />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Rozkład dziennej sprzedaży</CardTitle>
                <CardDescription>Liczba transakcji w przedziałach godzinowych</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={hourlyDistributionData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 30,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="hour" label={{ value: 'Godziny', position: 'insideBottom', offset: -10 }} />
                      <YAxis label={{ value: 'Liczba transakcji', angle: -90, position: 'insideLeft' }} />
                      <Tooltip />
                      <Line type="monotone" dataKey="transactions" stroke="#8884d8" activeDot={{ r: 8 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="summary" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard title="Całkowita sprzedaż" value={reportType === 'revenue' ? formatCurrency(15480) : "1,245"} subtitle="W bieżącym miesiącu" trend="+12.5%" />
            <StatCard title="Średnio dziennie" value={reportType === 'revenue' ? formatCurrency(516) : "41.5"} subtitle="Produktów" trend="+4.3%" />
            <StatCard title="Najpopularniejszy produkt" value="Devolaille" subtitle="152 sprzedanych" trend="+18.2%" />
            <StatCard title="Najlepsza godzina" value="12:00 - 13:00" subtitle="125 transakcji" trend="" />
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Najlepiej sprzedające się produkty</CardTitle>
              <CardDescription>Ostatni miesiąc</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 text-sm font-medium">
                  <div>Produkt</div>
                  <div className="text-right">Ilość</div>
                  <div className="text-right">Przychód</div>
                </div>
                <div className="space-y-2">
                  <ProductRow product="Devolaille z ziemniakami" quantity={152} revenue={2584} />
                  <ProductRow product="Sałatka z kurczakiem" quantity={138} revenue={1518} />
                  <ProductRow product="Zupa pomidorowa" quantity={120} revenue={840} />
                  <ProductRow product="Kanapka z szynką" quantity={105} revenue={1050} />
                  <ProductRow product="Surówka z marchewki" quantity={98} revenue={686} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="details" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Szczegółowa analiza</CardTitle>
              <CardDescription>Dane sprzedażowe wg dni tygodnia</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-8 text-sm font-medium">
                  <div>Dzień tygodnia</div>
                  <div className="text-right">Dania</div>
                  <div className="text-right">Sałatki</div>
                  <div className="text-right">Zupy</div>
                  <div className="text-right">Przekąski</div>
                  <div className="text-right">Razem</div>
                  <div className="text-right">Przychód</div>
                  <div className="text-right">Średnia</div>
                </div>
                <div className="space-y-2">
                  <DetailRow day="Poniedziałek" data={{ dania: 68, salatki: 42, zupy: 31, przekaski: 54 }} />
                  <DetailRow day="Wtorek" data={{ dania: 72, salatki: 46, zupy: 28, przekaski: 58 }} />
                  <DetailRow day="Środa" data={{ dania: 86, salatki: 52, zupy: 36, przekaski: 64 }} />
                  <DetailRow day="Czwartek" data={{ dania: 78, salatki: 54, zupy: 32, przekaski: 60 }} />
                  <DetailRow day="Piątek" data={{ dania: 92, salatki: 58, zupy: 30, przekaski: 72 }} />
                  <DetailRow day="Sobota" data={{ dania: 46, salatki: 32, zupy: 18, przekaski: 38 }} />
                  <DetailRow day="Niedziela" data={{ dania: 28, salatki: 20, zupy: 12, przekaski: 24 }} />
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Prognozy sprzedaży</CardTitle>
              <CardDescription>Przewidywana sprzedaż na następny tydzień</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={[
                      { day: 'Pon', actual: 195, forecast: 205 },
                      { day: 'Wt', actual: 204, forecast: 210 },
                      { day: 'Śr', actual: 238, forecast: 245 },
                      { day: 'Czw', actual: 224, forecast: 230 },
                      { day: 'Pt', actual: 252, forecast: 265 },
                      { day: 'Sob', actual: 134, forecast: 140 },
                      { day: 'Nd', actual: 84, forecast: 90 },
                    ]}
                    margin={{ top: 20, right: 30, left: 20, bottom: 30 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="actual" stroke="#8884d8" name="Rzeczywista sprzedaż" />
                    <Line type="monotone" dataKey="forecast" stroke="#82ca9d" name="Prognoza" strokeDasharray="5 5" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

// Komponent karty statystyk
const StatCard: React.FC<{ title: string; value: string; subtitle: string; trend: string }> = ({ 
  title, value, subtitle, trend 
}) => {
  const isTrendPositive = trend.startsWith('+');
  
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex flex-col space-y-1.5">
          <p className="text-sm font-medium leading-none text-gray-600">{title}</p>
          <div className="flex items-center justify-between">
            <p className="text-2xl font-bold">{value}</p>
            {trend && (
              <span className={`text-xs font-medium ${isTrendPositive ? 'text-green-500' : 'text-red-500'}`}>
                {trend}
              </span>
            )}
          </div>
          <p className="text-xs text-gray-600">{subtitle}</p>
        </div>
      </CardContent>
    </Card>
  );
};

// Komponent wiersza produktu
const ProductRow: React.FC<{ product: string; quantity: number; revenue: number }> = ({ 
  product, quantity, revenue 
}) => (
  <div className="grid grid-cols-3 items-center py-2 border-b border-gray-100">
    <div className="font-medium">{product}</div>
    <div className="text-right">{quantity}</div>
    <div className="text-right">{formatCurrency(revenue)}</div>
  </div>
);

// Komponent wiersza szczegółów
const DetailRow: React.FC<{ 
  day: string; 
  data: { dania: number; salatki: number; zupy: number; przekaski: number } 
}> = ({ day, data }) => {
  const total = data.dania + data.salatki + data.zupy + data.przekaski;
  const revenue = (data.dania * 17) + (data.salatki * 11) + (data.zupy * 7) + (data.przekaski * 10);
  const average = revenue / total;
  
  return (
    <div className="grid grid-cols-8 items-center py-2 border-b border-gray-100">
      <div className="font-medium">{day}</div>
      <div className="text-right">{data.dania}</div>
      <div className="text-right">{data.salatki}</div>
      <div className="text-right">{data.zupy}</div>
      <div className="text-right">{data.przekaski}</div>
      <div className="text-right font-medium">{total}</div>
      <div className="text-right font-medium">{formatCurrency(revenue)}</div>
      <div className="text-right">{formatCurrency(average)}</div>
    </div>
  );
};