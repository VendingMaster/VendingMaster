import * as React from 'react';
import { useState, useEffect } from 'react';
import { KioskView } from './KioskView';
import { AdminPanel } from './AdminPanel';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '../ui/dialog';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery } from '@tanstack/react-query';
import { UserRound } from 'lucide-react';

export const VendingMachineApp: React.FC = () => {
  const [view, setView] = useState<'kiosk' | 'admin'>('kiosk');
  const [isPinDialogOpen, setIsPinDialogOpen] = useState(false);
  const [pin, setPin] = useState('');
  const { toast } = useToast();
  
  // Pobierz ustawienia aplikacji
  const { data: settings } = useQuery({
    queryKey: ['/api/settings'],
    refetchOnWindowFocus: false
  });

  // Obsługa weryfikacji PIN-u - PIN ustawiony na stałe na 1308
  const handlePinSubmit = () => {
    if (pin === '1308') {
      setView('admin');
      setIsPinDialogOpen(false);
      setPin('');
    } else {
      toast({
        title: 'Niepoprawny PIN',
        description: 'Wprowadzony PIN jest nieprawidłowy. Spróbuj ponownie.',
        variant: 'destructive'
      });
    }
  };
  
  // Przekierowanie do portalu pracownika
  const handleEmployeePortalRedirect = () => {
    window.location.href = '/employee-portal';
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Przyciski nawigacyjne w rogach ekranu - widoczne tylko w trybie kiosku */}
      {view === 'kiosk' && (
        <>
          {/* Przycisk administratora w lewym górnym rogu */}
          <div className="absolute top-0 left-0 z-50 p-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsPinDialogOpen(true)}
              className="bg-transparent hover:bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center p-0"
              title="Panel administratora"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400">
                <circle cx="12" cy="12" r="3"></circle>
                <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
              </svg>
            </Button>
          </div>
          
          {/* Przycisk portalu pracownika w prawym górnym rogu */}
          <div className="absolute top-0 right-0 z-50 p-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleEmployeePortalRedirect}
              className="bg-transparent hover:bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center p-0"
              title="Portal pracownika"
            >
              <UserRound className="h-4 w-4 text-gray-400" />
            </Button>
          </div>
        </>
      )}

      {/* Nawigacja - widoczna tylko w trybie administracyjnym */}
      {view === 'admin' && (
        <header className="bg-white shadow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className="bg-blue-50 p-2 rounded-lg">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-5 0v-15A2.5 2.5 0 0 1 9.5 2Z"></path>
                  <path d="M14.5 4A2.5 2.5 0 0 1 17 6.5v11a2.5 2.5 0 0 1-5 0v-11A2.5 2.5 0 0 1 14.5 4Z"></path>
                  <path d="M4.5 8A2.5 2.5 0 0 1 7 10.5v7a2.5 2.5 0 0 1-5 0v-7A2.5 2.5 0 0 1 4.5 8Z"></path>
                  <path d="M19.5 5A2.5 2.5 0 0 1 22 7.5v9a2.5 2.5 0 0 1-5 0v-9A2.5 2.5 0 0 1 19.5 5Z"></path>
                </svg>
              </div>
              <h1 className="text-xl font-semibold flex items-center">
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent font-bold">
                  IQSTORE
                </span>
                <span className="mx-1">-</span>
                <span className="text-gray-800">
                  Benefit żywieniowy / automatyczna kantyna
                </span>
                <span className="text-xs text-gray-500 ml-2">v1.2.12</span>
              </h1>
            </div>
            <Button 
              onClick={() => setView('kiosk')}
              variant="outline"
            >
              TRYB KIOSK
            </Button>
          </div>
        </header>
      )}

      {/* Main Content Area */}
      <main className={`flex-grow ${view === 'kiosk' ? 'pt-0' : ''}`}>
        {view === 'kiosk' ? <KioskView /> : <AdminPanel />}
      </main>

      {/* Footer dla trybu administratora */}
      {view === 'admin' && (
        <footer className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-4 mt-8 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="mb-4 md:mb-0">
                <h3 className="text-lg font-bold">IQSTORE</h3>
                <p className="text-sm opacity-80">System zarządzania automatem żywieniowym</p>
              </div>
              <div className="flex flex-col md:flex-row md:space-x-8 text-sm">
                <div className="mb-2 md:mb-0">
                  <p className="font-semibold">Kontakt</p>
                  <p>support@iqstore.pl</p>
                </div>
                <div>
                  <p className="font-semibold">Wersja oprogramowania</p>
                  <p>v1.2.12 &copy; {new Date().getFullYear()}</p>
                </div>
              </div>
            </div>
          </div>
        </footer>
      )}

      {/* Dialog weryfikacji PIN */}
      <Dialog open={isPinDialogOpen} onOpenChange={setIsPinDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Dostęp do panelu administracyjnego</DialogTitle>
            <DialogDescription>Wprowadź kod PIN, aby uzyskać dostęp do panelu administratora</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Label htmlFor="admin-pin">Kod PIN administratora</Label>
            <Input
              id="admin-pin"
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Wprowadź PIN administratora"
              className="mt-2"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handlePinSubmit();
                }
              }}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPinDialogOpen(false)}>
              Anuluj
            </Button>
            <Button onClick={handlePinSubmit}>
              Zaloguj
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
