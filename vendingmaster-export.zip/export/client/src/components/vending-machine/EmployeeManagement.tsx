import * as React from 'react';
import { useState, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Employee, Chamber } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Trash2, UserCog, Box, Plus, X, Upload, Download, FileText, Calendar } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { EmployeeChamberAssignment } from './EmployeeChamberAssignment';
import { EmployeeWorkDayCalendar } from './EmployeeWorkDayCalendar';
import { SimpleEmployeeEditor } from './SimpleEmployeeEditor';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

export const EmployeeManagement: React.FC = () => {
  const { toast } = useToast();
  const [isAddEmployeeOpen, setIsAddEmployeeOpen] = useState(false);
  const [isEditEmployeeOpen, setIsEditEmployeeOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isAssignChamberOpen, setIsAssignChamberOpen] = useState(false);
  const [isWorkCalendarOpen, setIsWorkCalendarOpen] = useState(false);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [importProgress, setImportProgress] = useState(0);
  const [importResult, setImportResult] = useState<{
    imported: number;
    skipped: number;
    errors: string[] | null;
  } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Pobieranie listy pracowników
  const { data: employees = [], isLoading, isError, refetch: refetchEmployees } = useQuery({
    queryKey: ['/api/employees'],
    queryFn: async () => {
      return await apiRequest<Employee[]>('/api/employees');
    },
    staleTime: 0 // Zawsze pobieraj świeże dane
  });
  
  // Pobieranie szuflad, aby uzyskać informację o przypisanych komorach
  const { data: chambersData = { chambers: [], timestamp: 0 }, refetch: refetchChambers } = useQuery({
    queryKey: ['/api/chambers'],
    queryFn: async () => {
      const response = await apiRequest<{chambers: Chamber[], timestamp: number}>('/api/chambers');
      return response;
    },
    staleTime: 0 // Zawsze pobieraj świeże dane
  });
  
  // Ekstrahuj tablicę szuflad z odpowiedzi
  const chambers = chambersData.chambers || [];
  
  // Mutacja do importu CSV
  const importCsvMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      setImportProgress(10);
      const result = await apiRequest('/api/employees/import/csv', {
        method: 'POST',
        body: formData,
        // Nie ustawiamy 'Content-Type' - fetch ustawi poprawny z boundary dla FormData
      });
      setImportProgress(100);
      return result;
    },
    onSuccess: (data) => {
      setImportResult(data);
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      toast({
        title: 'Import zakończony',
        description: `Zaimportowano ${data.imported} pracowników, pominięto ${data.skipped}.`,
      });
    },
    onError: (error) => {
      setImportProgress(0);
      setImportResult(null);
      toast({
        title: 'Błąd importu',
        description: 'Nie udało się zaimportować pliku CSV.',
        variant: 'destructive',
      });
    }
  });
  
  // Pobieranie szablonu CSV
  const handleDownloadTemplate = () => {
    window.location.href = '/api/employees/template/csv';
  };
  
  // Usuwanie pracownika
  const deleteEmployee = async (id: number) => {
    try {
      await apiRequest(`/api/employees/${id}`, {
        method: 'DELETE'
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      
      toast({
        title: 'Sukces',
        description: 'Pracownik został usunięty.',
      });
    } catch (error) {
      toast({
        title: 'Błąd',
        description: 'Nie udało się usunąć pracownika.',
        variant: 'destructive',
      });
    }
  };
  
  const handleAddEmployee = () => {
    setSelectedEmployee(null);
    setIsAddEmployeeOpen(true);
  };
  
  const handleEditEmployee = (employee: Employee) => {
    try {
      console.log('Edytowanie pracownika (start):', employee);
      console.log('Dane pracownika:', JSON.stringify(employee));
      
      // Najpierw zamknij form, jeśli był otwarty
      setIsEditEmployeeOpen(false);
      
      // Następnie ustaw wybranego pracownika
      const employeeCopy = { ...employee };
      console.log('Utworzono kopię pracownika:', employeeCopy);
      
      // Użyj setTimeout, aby zapewnić kolejność operacji
      setTimeout(() => {
        setSelectedEmployee(employeeCopy);
        console.log('setSelectedEmployee zakończone, wartość:', employeeCopy.id);
        
        setTimeout(() => {
          setIsEditEmployeeOpen(true);
          console.log('setIsEditEmployeeOpen zakończone, wartość:', true);
          console.log('Edytowanie pracownika (koniec): Modal powinien być otwarty');
        }, 50);
      }, 50);
      
    } catch (error) {
      console.error('Błąd podczas edycji pracownika:', error);
    }
  };
  
  const handleDeleteClick = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsDeleteDialogOpen(true);
  };
  
  const handleAssignChamberClick = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsAssignChamberOpen(true);
  };
  
  const handleWorkCalendarClick = (employee: Employee) => {
    // Najpierw zamykamy kalendarz, jeśli był otwarty
    setIsWorkCalendarOpen(false);
    
    // Resetujemy stan wybranego pracownika
    setSelectedEmployee(null);
    
    // Używamy setTimeout, aby zapewnić, że komponenty zostaną prawidłowo odmontowane i zamontowane
    setTimeout(() => {
      console.log(`Otwieranie kalendarza dla pracownika ${employee.id} (${employee.firstName} ${employee.lastName})`);
      setSelectedEmployee(employee);
      
      // Odświeżamy cache danych dla tego pracownika przed otwarciem kalendarza
      queryClient.invalidateQueries({
        queryKey: ['/api/employee-work-days', employee.id]
      });
      
      setTimeout(() => {
        setIsWorkCalendarOpen(true);
      }, 50);
    }, 50);
  };
  
  const confirmDelete = () => {
    if (selectedEmployee) {
      deleteEmployee(selectedEmployee.id);
    }
    setIsDeleteDialogOpen(false);
  };
  
  // Obsługa importu CSV
  const handleImportClick = () => {
    setImportProgress(0);
    setImportResult(null);
    setIsImportDialogOpen(true);
  };
  
  const handleFileSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!fileInputRef.current?.files?.length) {
      toast({
        title: 'Brak pliku',
        description: 'Wybierz plik CSV do importu.',
        variant: 'destructive',
      });
      return;
    }
    
    const file = fileInputRef.current.files[0];
    const formData = new FormData();
    formData.append('file', file);
    
    importCsvMutation.mutate(formData);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-800">Zarządzanie Pracownikami</h3>
          <p className="text-gray-600 mt-1">Dodawanie i edycja pracowników korzystających z automatu</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={handleDownloadTemplate}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Download className="h-4 w-4" /> Pobierz szablon CSV
          </Button>
          <Button 
            onClick={handleImportClick}
            variant="outline"
            className="flex items-center gap-2 bg-white text-black hover:bg-gray-50"
          >
            <Upload className="h-4 w-4" /> Importuj z CSV
          </Button>
          <Button 
            onClick={handleAddEmployee} 
            className="bg-green-500 hover:bg-green-600 flex items-center gap-2"
          >
            <Plus className="h-4 w-4" /> Dodaj Pracownika
          </Button>
        </div>
      </div>

      {/* Employees List */}
      <div className="bg-white shadow overflow-hidden rounded-md">
        {isLoading ? (
          <div className="space-y-4 p-4">
            {[...Array(3)].map((_, index) => (
              <div key={index} className="flex items-center space-x-4">
                <Skeleton className="h-12 w-12 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
                <Skeleton className="h-8 w-16" />
              </div>
            ))}
          </div>
        ) : isError ? (
          <div className="text-center py-4 text-red-500">
            Wystąpił błąd podczas pobierania danych pracowników
          </div>
        ) : employees.length === 0 ? (
          <div className="py-8 text-center text-gray-500">
            Brak zdefiniowanych pracowników. Kliknij "Dodaj Pracownika", aby dodać pierwszego pracownika.
          </div>
        ) : (
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="py-3 font-medium">Imię i Nazwisko</TableHead>
                <TableHead className="py-3 font-medium">Nr karty RFID</TableHead>
                <TableHead className="py-3 font-medium">Format</TableHead>
                <TableHead className="py-3 font-medium">Email</TableHead>
                <TableHead className="py-3 font-medium">Nr szuflady</TableHead>
                <TableHead className="py-3 font-medium text-right">Akcje</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees.map((employee) => {
                // Znajdź przypisane szuflady dla danego pracownika
                const assignedChambers = chambers.filter(chamber => 
                  chamber.employeeId === employee.id
                );
                
                const chamberIds = assignedChambers.map(chamber => chamber.id).join(", ");
                
                return (
                  <TableRow key={employee.id} className="hover:bg-gray-50">
                    <TableCell className="py-4">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-gray-100 rounded-full overflow-hidden flex items-center justify-center border">
                          <UserCog className="h-5 w-5 text-gray-400" />
                        </div>
                        <div className="ml-3">
                          <span className="font-medium text-gray-900">{`${employee.firstName} ${employee.lastName}`}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="py-4">
                      <Badge variant="outline">{employee.rfidCardNumber}</Badge>
                    </TableCell>
                    <TableCell className="py-4">
                      <Badge variant="secondary">{employee.rfidCardFormat}</Badge>
                    </TableCell>
                    <TableCell className="py-4 text-gray-600">
                      {employee.email || "-"}
                    </TableCell>
                    <TableCell className="py-4">
                      {assignedChambers.length > 0 ? (
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          {chamberIds}
                        </Badge>
                      ) : (
                        <span className="text-gray-400 text-sm">Brak</span>
                      )}
                    </TableCell>
                    <TableCell className="py-4 text-right">
                      <div className="flex justify-end space-x-2">
                        <button 
                          className="p-1 rounded-full text-gray-400 hover:text-gray-600"
                          onClick={() => handleEditEmployee(employee)}
                          title="Edytuj pracownika"
                        >
                          <UserCog className="h-5 w-5" />
                        </button>
                        <button 
                          className="p-1 rounded-full text-gray-400 hover:text-gray-600"
                          onClick={() => handleAssignChamberClick(employee)}
                          title="Przypisz szuflady"
                        >
                          <Box className="h-5 w-5" />
                        </button>
                        <button 
                          className="p-1 rounded-full text-gray-400 hover:text-green-500"
                          onClick={() => handleWorkCalendarClick(employee)}
                          title="Kalendarz dni pracy"
                        >
                          <Calendar className="h-5 w-5" />
                        </button>
                        <button 
                          className="p-1 rounded-full text-gray-400 hover:text-red-500"
                          onClick={() => handleDeleteClick(employee)}
                          title="Usuń pracownika"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}

        {/* Total Employees Count */}
        <div className="mt-6 border-t border-gray-200 pt-4">
          <p className="text-sm text-gray-600 font-medium">
            Łączna ilość pracowników: {employees?.length || 0}
          </p>
        </div>
      </div>
      
      {/* Formularze i dialogi */}
      {/* Formularz dodawania lub edycji pracownika */}
      {isAddEmployeeOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 shadow-lg max-w-md w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">Dodaj nowego pracownika</h3>
              <button 
                onClick={() => setIsAddEmployeeOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <SimpleEmployeeEditor
              employee={null}
              onCancel={() => setIsAddEmployeeOpen(false)}
              onSave={() => {
                setIsAddEmployeeOpen(false);
                queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
              }}
            />
          </div>
        </div>
      )}
      
      {isEditEmployeeOpen && selectedEmployee && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 shadow-lg max-w-md w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">Edytuj pracownika</h3>
              <button 
                onClick={() => {
                  setIsEditEmployeeOpen(false);
                  setSelectedEmployee(null);
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <SimpleEmployeeEditor
              employee={selectedEmployee}
              onCancel={() => {
                setIsEditEmployeeOpen(false);
                setSelectedEmployee(null);
              }}
              onSave={() => {
                setIsEditEmployeeOpen(false);
                setSelectedEmployee(null);
                queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
              }}
            />
          </div>
        </div>
      )}
      
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Potwierdź usunięcie</AlertDialogTitle>
            <AlertDialogDescription>
              Czy na pewno chcesz usunąć pracownika {selectedEmployee ? `${selectedEmployee.firstName} ${selectedEmployee.lastName}` : ''}? Ta operacja jest nieodwracalna.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Anuluj</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground">
              Usuń
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {selectedEmployee && (
        <EmployeeChamberAssignment
          employee={selectedEmployee}
          isOpen={isAssignChamberOpen}
          onClose={() => {
            setIsAssignChamberOpen(false);
            // Wymuszamy odświeżenie danych o pracownikach i szufladach
            queryClient.refetchQueries({ queryKey: ['/api/chambers'] });
            queryClient.refetchQueries({ queryKey: ['/api/employees'] });
          }}
        />
      )}
      
      {/* Dialog importu CSV */}
      {isImportDialogOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 shadow-lg max-w-md w-full mx-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold">Import pracowników z CSV</h3>
              <button 
                onClick={() => setIsImportDialogOpen(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <Card className="mb-4">
              <CardHeader className="py-4">
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <FileText className="h-5 w-5 text-blue-500" /> 
                  Instrukcja importu
                </CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-gray-600 space-y-2">
                <ol className="list-decimal pl-5 space-y-1">
                  <li>Pobierz szablon CSV za pomocą przycisku "Pobierz szablon CSV"</li>
                  <li>Wypełnij plik danymi pracowników</li>
                  <li>Obowiązkowe pola: <span className="font-medium">firstName</span> i <span className="font-medium">lastName</span></li>
                  <li>Zapisz plik i zaimportuj go poniżej</li>
                </ol>
              </CardContent>
            </Card>
            
            <form onSubmit={handleFileSubmit}>
              <div className="mb-4">
                <input
                  type="file"
                  ref={fileInputRef}
                  accept=".csv"
                  className="block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-md file:border-0
                    file:text-sm file:font-semibold
                    file:bg-blue-50 file:text-blue-700
                    hover:file:bg-blue-100"
                />
              </div>
              
              {importProgress > 0 && (
                <div className="mb-4">
                  <p className="text-sm text-gray-600 mb-1">Postęp importu:</p>
                  <Progress value={importProgress} className="h-2" />
                </div>
              )}
              
              {importResult && (
                <div className="mb-4 p-3 bg-gray-50 rounded-md">
                  <h4 className="font-medium">Wynik importu:</h4>
                  <p className="text-sm text-gray-600">Zaimportowano: <span className="font-medium text-green-600">{importResult.imported}</span> pracowników</p>
                  <p className="text-sm text-gray-600">Pominięto: <span className="font-medium text-amber-600">{importResult.skipped}</span> pracowników</p>
                  
                  {importResult.errors && importResult.errors.length > 0 && (
                    <div className="mt-2">
                      <p className="text-sm font-medium text-red-600 mb-1">Błędy:</p>
                      <ul className="text-xs text-red-600 pl-4 list-disc">
                        {importResult.errors.map((error, index) => (
                          <li key={index}>{error}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
              
              <div className="flex justify-end gap-2 mt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsImportDialogOpen(false)}
                >
                  Anuluj
                </Button>
                <Button
                  type="submit"
                  className="bg-blue-500 hover:bg-blue-600"
                  disabled={importCsvMutation.isPending}
                >
                  {importCsvMutation.isPending ? 'Importowanie...' : 'Importuj'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
      
      {/* Kalendarz dni pracy pracownika */}
      {selectedEmployee && (
        <EmployeeWorkDayCalendar
          employee={selectedEmployee}
          isOpen={isWorkCalendarOpen}
          onClose={() => setIsWorkCalendarOpen(false)}
        />
      )}
    </div>
  );
};