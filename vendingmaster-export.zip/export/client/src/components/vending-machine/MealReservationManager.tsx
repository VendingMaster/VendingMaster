import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format, addDays, parseISO, isToday, isTomorrow, isValid } from 'date-fns';
import { pl } from 'date-fns/locale';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

// UI Komponenty
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Calendar as CalendarIcon, 
  Check, 
  Clock, 
  UserCheck, 
  ChefHat, 
  FileSpreadsheet, 
  Search,
  Info,
  ShoppingCart,
  AlertCircle,
  Utensils
} from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from '@/components/ui/alert';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';

// Typy dla komponentu
type AutoGenerateResult = {
  success: boolean;
  message: string;
  generatedCount: number;
  errors: Array<{ employeeId: number; message: string }>;
  reservations: Array<any>;
};

type Employee = {
  id: number;
  firstName: string;
  lastName: string;
  email?: string;
  position?: string;
  department?: string;
  photoUrl?: string | null;
  dietaryPreferences?: string[];
  rfidCardNumber?: string | null;
};

type MealReservation = {
  id: number;
  employeeId: number;
  productId: number;
  reservedForDate: string;
  chamberId?: number | null;
  productName?: string;
  productImage?: string;
  shortDescription?: string;
  weight?: number;
  calories?: number;
  hasRating?: boolean;
};

// Prosty komponent wyświetlający informacje o posiłku (lub brak)
const MealDetail: React.FC<{ meal: MealReservation | null }> = ({ meal }) => {
  if (!meal) {
    return (
      <div className="border rounded-md p-2 text-center text-muted-foreground">
        <p>Brak zamówienia</p>
      </div>
    );
  }

  return (
    <div className="border rounded-md p-2">
      <p className="font-medium">{meal.productName || `Produkt #${meal.productId}`}</p>
      {meal.chamberId && (
        <span className="text-xs text-muted-foreground">
          Szuflada: {meal.chamberId}
        </span>
      )}
    </div>
  );
};

// Uproszczony komponent wyświetlający informacje o pracowniku wraz z jego posiłkiem
const EmployeeReservationRow: React.FC<{ 
  employee: Employee;
  reservation: MealReservation | null;
  date: string;
}> = ({ employee, reservation, date }) => {
  return (
    <div className="px-4 py-2 border-b last:border-0 hover:bg-accent/10 transition-colors">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarFallback>{employee.firstName[0]}{employee.lastName[0]}</AvatarFallback>
          </Avatar>
          <div>
            <h3 className="font-medium">{employee.firstName} {employee.lastName}</h3>
          </div>
        </div>

        <div>
          {reservation ? (
            <span className="text-sm">{reservation.productName || `Produkt #${reservation.productId}`}</span>
          ) : (
            <span className="text-sm text-muted-foreground">Brak zamówienia</span>
          )}
        </div>
      </div>
    </div>
  );
};


export const MealReservationManager: React.FC = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [activeTab, setActiveTab] = useState('overview');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isResultDialogOpen, setIsResultDialogOpen] = useState(false);
  const [generationResult, setGenerationResult] = useState<AutoGenerateResult | null>(null);
  
  // Pobierz dane konfiguracyjne
  const { data: settings } = useQuery({
    queryKey: ['/api/settings'],
    queryFn: async () => await apiRequest('/api/settings'),
  });

  // Pobierz listę pracowników
  const { data: employees = [], isLoading: isLoadingEmployees } = useQuery({
    queryKey: ['/api/employees'],
    queryFn: async () => {
      const response = await apiRequest('/api/employees');
      return response as Employee[];
    },
  });

  // Pobierz liczbę rezerwacji na dzisiaj i jutro
  const today = format(new Date(), 'yyyy-MM-dd');
  const tomorrow = format(addDays(new Date(), 1), 'yyyy-MM-dd');
  
  const { data: todayReservations = [] } = useQuery({
    queryKey: ['/api/meal-reservations', { date: today }],
    queryFn: async () => {
      const response = await apiRequest(`/api/meal-reservations?date=${today}`);
      return response;
    },
  });
  
  const { data: tomorrowReservations = [] } = useQuery({
    queryKey: ['/api/meal-reservations', { date: tomorrow }],
    queryFn: async () => {
      const response = await apiRequest(`/api/meal-reservations?date=${tomorrow}`);
      return response;
    },
  });

  // Pobierz rezerwacje dla wybranej daty
  const formattedSelectedDate = selectedDate ? format(selectedDate, 'yyyy-MM-dd') : today;
  
  const { data: selectedDateReservations = [], isLoading: isLoadingReservations } = useQuery({
    queryKey: ['/api/meal-reservations', { date: formattedSelectedDate }],
    queryFn: async () => {
      const response = await apiRequest(`/api/meal-reservations?date=${formattedSelectedDate}`);
      // Obsługa różnych formatów odpowiedzi API
      if (Array.isArray(response)) {
        return response;
      } else if (response && response.reservations && Array.isArray(response.reservations)) {
        return response.reservations;
      } else if (response && response.success) {
        return [];
      } else {
        console.error('Nieoczekiwany format odpowiedzi API:', response);
        return [];
      }
    },
    enabled: !!selectedDate,
  });
  
  // Mutacja dla funkcji automatycznego generowania rezerwacji
  const autoGenerateMutation = useMutation({
    mutationFn: async (date: string) => {
      return await apiRequest<AutoGenerateResult>('/api/meal-reservations/auto-generate', {
        method: 'POST',
        body: JSON.stringify({ date }),
        headers: {
          'Content-Type': 'application/json',
        },
      });
    },
    onSuccess: (data) => {
      setGenerationResult(data);
      setIsResultDialogOpen(true);
      
      // Odśwież dane rezerwacji po automatycznym wygenerowaniu
      const formattedSelectedDate = selectedDate 
        ? format(selectedDate, 'yyyy-MM-dd')
        : format(new Date(), 'yyyy-MM-dd');
      
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations', { date: formattedSelectedDate }] });
      
      // Jeśli wygenerowano dla dzisiaj lub jutra, odśwież zapytania
      if (formattedSelectedDate === today) {
        queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations', { date: today }] });
      } else if (formattedSelectedDate === tomorrow) {
        queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations', { date: tomorrow }] });
      }
      
      toast({
        title: 'Sukces',
        description: `${data.generatedCount} rezerwacji zostało automatycznie wygenerowanych`,
        variant: 'default',
      });
    },
    onError: (error) => {
      toast({
        title: 'Błąd',
        description: 'Wystąpił problem podczas generowania rezerwacji',
        variant: 'destructive',
      });
      console.error('Auto-generate error:', error);
    },
  });
  
  // Obsługa przycisku generowania
  const handleAutoGenerate = () => {
    if (!selectedDate) {
      toast({
        title: 'Wybierz datę',
        description: 'Musisz wybrać datę, aby wygenerować automatyczne rezerwacje',
        variant: 'destructive',
      });
      return;
    }
    
    const formattedDate = format(selectedDate, 'yyyy-MM-dd');
    autoGenerateMutation.mutate(formattedDate);
    setIsDialogOpen(false);
  };
  
  // Przygotowanie danych do wyświetlenia - łączenie pracowników z ich rezerwacjami
  const employeesWithReservations = employees.map(employee => {
    const reservation = selectedDateReservations.find((res: MealReservation) => res.employeeId === employee.id) || null;
    return {
      employee,
      reservation
    };
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-2">
        <h2 className="text-2xl font-bold tracking-tight">Zarządzanie rezerwacjami posiłków</h2>
        <p className="text-muted-foreground">
          Przeglądaj oraz generuj automatyczne rezerwacje posiłków dla pracowników.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="overview">Rezerwacje</TabsTrigger>
          <TabsTrigger value="generator">Generator rezerwacji</TabsTrigger>
        </TabsList>
        
        {/* Zakładka z rezerwacjami pracowników */}
        <TabsContent value="overview" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium">
              Rezerwacje posiłków na dzień {selectedDate ? format(selectedDate, 'd MMMM yyyy', { locale: pl }) : today}
            </h3>
            
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="ml-auto">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  Wybierz datę
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  initialFocus
                  locale={pl}
                />
              </PopoverContent>
            </Popover>
          </div>
          
          <Card>
            <CardContent className="p-0 pt-6">
              {isLoadingEmployees || isLoadingReservations ? (
                <div className="flex justify-center items-center p-8">
                  <p>Ładowanie danych...</p>
                </div>
              ) : employeesWithReservations.length === 0 ? (
                <div className="text-center p-8">
                  <AlertCircle className="mx-auto h-10 w-10 text-muted-foreground opacity-20 mb-2" />
                  <h3 className="text-lg font-medium">Brak danych</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    Nie znaleziono pracowników ani rezerwacji na ten dzień.
                  </p>
                </div>
              ) : (
                <ScrollArea className="h-[600px]">
                  <div className="space-y-1">
                    {employeesWithReservations.map(({ employee, reservation }) => (
                      <EmployeeReservationRow 
                        key={employee.id} 
                        employee={employee} 
                        reservation={reservation}
                        date={formattedSelectedDate}
                      />
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Zakładka z generatorem rezerwacji */}
        <TabsContent value="generator" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {/* Karta z rezerwacjami na dziś */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Dzisiejsze rezerwacje
                </CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{todayReservations.length}</div>
                <p className="text-xs text-muted-foreground">
                  {format(new Date(), 'd MMMM yyyy', { locale: pl })}
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  size="sm" 
                  className="w-full" 
                  variant="outline"
                  onClick={() => {
                    setSelectedDate(new Date());
                    setIsDialogOpen(true);
                  }}
                >
                  <UserCheck className="mr-2 h-4 w-4" />
                  Generuj dla dzisiaj
                </Button>
              </CardFooter>
            </Card>

            {/* Karta z rezerwacjami na jutro */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Jutrzejsze rezerwacje
                </CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{tomorrowReservations.length}</div>
                <p className="text-xs text-muted-foreground">
                  {format(addDays(new Date(), 1), 'd MMMM yyyy', { locale: pl })}
                </p>
              </CardContent>
              <CardFooter>
                <Button 
                  size="sm"
                  className="w-full" 
                  variant="outline"
                  onClick={() => {
                    setSelectedDate(addDays(new Date(), 1));
                    setIsDialogOpen(true);
                  }}
                >
                  <UserCheck className="mr-2 h-4 w-4" />
                  Generuj dla jutra
                </Button>
              </CardFooter>
            </Card>

            {/* Karta z wyborem daty */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Wybierz inną datę
                </CardTitle>
                <CalendarIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full justify-start text-left font-normal"
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate ? (
                        format(selectedDate, 'PPP', { locale: pl })
                      ) : (
                        <span>Wybierz datę</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      initialFocus
                      locale={pl}
                    />
                  </PopoverContent>
                </Popover>
              </CardContent>
              <CardFooter>
                <Button 
                  size="sm"
                  className="w-full" 
                  onClick={() => setIsDialogOpen(true)}
                  disabled={!selectedDate}
                >
                  <ChefHat className="mr-2 h-4 w-4" />
                  Generuj dla wybranej daty
                </Button>
              </CardFooter>
            </Card>
          </div>

          <Alert>
            <FileSpreadsheet className="h-4 w-4" />
            <AlertTitle>Informacja o automatycznym generowaniu</AlertTitle>
            <AlertDescription>
              Funkcja automatycznie wygeneruje zamówienia posiłków dla pracowników, którzy:
              <ul className="list-disc pl-5 mt-2">
                <li>Pracują w wybranym dniu (na podstawie kalendarza dni pracy)</li>
                <li>Nie złożyli jeszcze zamówienia na ten dzień</li>
              </ul>
              System uwzględni preferencje żywieniowe pracownika, jeśli zostały określone.
            </AlertDescription>
          </Alert>
          </TabsContent>
      </Tabs>

      {/* Dialog potwierdzenia */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Potwierdź automatyczne generowanie</DialogTitle>
            <DialogDescription>
              Czy na pewno chcesz automatycznie wygenerować rezerwacje posiłków dla dnia:
              <p className="font-semibold mt-2">
                {selectedDate
                  ? format(selectedDate, 'EEEE, d MMMM yyyy', { locale: pl })
                  : "Nie wybrano daty"}
              </p>
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Anuluj
            </Button>
            <Button onClick={handleAutoGenerate} disabled={autoGenerateMutation.isPending}>
              {autoGenerateMutation.isPending 
                ? "Generowanie..." 
                : "Wygeneruj rezerwacje"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog z wynikami generowania */}
      <Dialog open={isResultDialogOpen} onOpenChange={setIsResultDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Wynik generowania rezerwacji</DialogTitle>
            <DialogDescription>
              {generationResult?.success 
                ? `Pomyślnie wygenerowano ${generationResult.generatedCount} nowych rezerwacji posiłków.`
                : "Wystąpiły problemy podczas generowania rezerwacji."}
            </DialogDescription>
          </DialogHeader>
          
          {generationResult && (
            <div className="py-4">
              <div className="flex space-x-4 mb-4">
                <div className="text-center flex-1">
                  <p className="text-sm text-muted-foreground">Wygenerowano</p>
                  <p className="text-2xl font-bold">{generationResult.generatedCount}</p>
                </div>
                <Separator orientation="vertical" />
                <div className="text-center flex-1">
                  <p className="text-sm text-muted-foreground">Błędy</p>
                  <p className="text-2xl font-bold">{generationResult.errors?.length || 0}</p>
                </div>
              </div>
              
              {generationResult.reservations && generationResult.reservations.length > 0 && (
                <>
                  <h4 className="font-medium mb-2">Utworzone rezerwacje:</h4>
                  <ScrollArea className="h-[180px] rounded-md border p-2">
                    {generationResult.reservations.map((reservation) => (
                      <div key={reservation.id} className="flex items-center justify-between py-2 border-b last:border-b-0">
                        <div>
                          <p className="text-sm">
                            ID Pracownika: {reservation.employeeId}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            ID Produktu: {reservation.productId}
                          </p>
                        </div>
                        <Badge variant="outline" className="ml-auto">
                          <Check className="h-3.5 w-3.5 mr-1" />
                          Utworzono
                        </Badge>
                      </div>
                    ))}
                  </ScrollArea>
                </>
              )}
              
              {generationResult.errors && generationResult.errors.length > 0 && (
                <>
                  <h4 className="font-medium mt-4 mb-2">Błędy:</h4>
                  <ScrollArea className="h-[120px] rounded-md border p-2">
                    {generationResult.errors.map((error, index) => (
                      <div key={index} className="py-2 border-b last:border-b-0">
                        <p className="text-sm text-red-600">
                          ID Pracownika: {error.employeeId}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {error.message}
                        </p>
                      </div>
                    ))}
                  </ScrollArea>
                </>
              )}
            </div>
          )}
          
          <DialogFooter>
            <Button onClick={() => setIsResultDialogOpen(false)}>
              Zamknij
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};