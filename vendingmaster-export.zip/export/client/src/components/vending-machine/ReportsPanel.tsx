import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Skeleton } from '@/components/ui/skeleton';
import { useQuery } from '@tanstack/react-query';

// Funkcja do eksportu danych do CSV z obsługą polskich znaków
function exportToCSV(data: any[], fileName: string) {
  // Przygotuj nagłówki kolumn
  const headers = ['ID', 'Pracownik', 'Produkt', 'Data', 'Cena (PLN)', 'Status'];
  
  // Przygotuj wiersze danych
  const rows = data.map(item => [
    item.id.toString(),
    item.employee,
    item.product,
    item.date,
    item.price.toString().replace('.', ','),
    item.status
  ]);
  
  // Połącz nagłówki i wiersze
  const csvContent = [
    headers.join(';'),
    ...rows.map(row => row.join(';'))
  ].join('\n');
  
  // Przygotuj BOM (Byte Order Mark) dla UTF-8, aby polskie znaki były poprawnie wyświetlane
  const BOM = '\uFEFF';
  const csvWithBOM = BOM + csvContent;
  
  // Utwórz obiekt Blob z prawidłowym kodowaniem
  const blob = new Blob([csvWithBOM], { type: 'text/csv;charset=utf-8;' });
  
  // Utwórz URL dla Bloba
  const url = URL.createObjectURL(blob);
  
  // Utwórz tymczasowy link do pobrania pliku
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${fileName}.csv`);
  link.style.visibility = 'hidden';
  
  // Dodaj link do dokumentu, kliknij go i usuń
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Funkcja pomocnicza do formatowania walut
function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pl-PL', { style: 'currency', currency: 'PLN' }).format(value);
}

// Typy danych sprzedaży
type MonthlySalesData = {
  name: string;
  Sprzedaż: number;
};

type CategorySalesData = {
  name: string;
  value: number;
};

type HourlySalesData = {
  name: string;
  Sprzedaż: number;
};

type DailySalesData = {
  date: string;
  [category: string]: number | string;
  total: number;
};

type SalesStatistics = {
  totalSales: number;
  totalSalesChange: number;
  averageDaily: number;
  averageDailyChange: number;
  bestSellingProduct: {
    id: number;
    name: string;
    quantity: number;
  };
  bestHour: {
    time: string;
    transactions: number;
  };
};

// Kolory dla wykresu kołowego
const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

// Przykładowe dane rezerwacji
const reservationsData = [
  { id: 1, employee: 'Jan Kowalski', product: 'Zupa pomidorowa', date: '01.04.2025', month: 'Kwiecień 2025', price: 18.50, status: 'Zrealizowana' },
  { id: 2, employee: 'Jan Kowalski', product: 'Bułka QLTOWA', date: '31.03.2025', month: 'Marzec 2025', price: 7.90, status: 'Zrealizowana' },
  { id: 3, employee: 'Anna Nowak', product: 'Sałatka grecka', date: '01.04.2025', month: 'Kwiecień 2025', price: 22.50, status: 'Oczekująca' },
  { id: 4, employee: 'Piotr Wiśniewski', product: 'Devolaille z ziemniakami', date: '02.04.2025', month: 'Kwiecień 2025', price: 26.90, status: 'Oczekująca' },
  { id: 5, employee: 'Jan Kowalski', product: 'Devolaille z ziemniakami', date: '15.03.2025', month: 'Marzec 2025', price: 26.90, status: 'Zrealizowana' },
  { id: 6, employee: 'Jan Kowalski', product: 'Kompot owocowy', date: '15.03.2025', month: 'Marzec 2025', price: 5.00, status: 'Zrealizowana' },
  { id: 7, employee: 'Anna Nowak', product: 'Bułka QLTOWA', date: '22.03.2025', month: 'Marzec 2025', price: 7.90, status: 'Zrealizowana' },
  { id: 8, employee: 'Jan Kowalski', product: 'Sałatka grecka', date: '28.03.2025', month: 'Marzec 2025', price: 22.50, status: 'Zrealizowana' },
];

const StatCard = ({ title, value, subtitle, trend }: { title: string, value: string, subtitle: string, trend: string }) => (
  <Card>
    <CardContent className="p-4">
      <div className="flex flex-col space-y-1.5">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <div className="flex items-baseline">
          <span className="text-2xl font-bold">{value}</span>
          {trend && (
            <span className={`ml-2 text-xs font-medium ${trend.startsWith('+') ? 'text-green-600' : trend.startsWith('-') ? 'text-red-600' : ''}`}>
              {trend}
            </span>
          )}
        </div>
        <p className="text-xs text-gray-500">{subtitle}</p>
      </div>
    </CardContent>
  </Card>
);

type MealReservation = {
  id: number;
  employee: string; // imię i nazwisko pracownika
  product: string;  // nazwa produktu
  date: string;     // data w formacie DD.MM.YYYY
  month?: string;   // miesiąc - opcjonalnie, obliczane z daty
  price: number;    // cena produktu
  status: string;   // status zamówienia
};

export const ReportsPanel: React.FC = () => {
  const [activeTab, setActiveTab] = useState('sales');
  const [showResults, setShowResults] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [filteredData, setFilteredData] = useState<MealReservation[]>([]);
  const [allReservations, setAllReservations] = useState<MealReservation[]>([]);
  const { toast } = useToast();
  
  // Pobieranie danych sprzedaży z API
  const { data: monthlySalesData, isLoading: isMonthlyLoading } = useQuery<MonthlySalesData[]>({
    queryKey: ['/api/sales/monthly'],
    refetchOnWindowFocus: false,
  });
  
  const { data: hourlySalesData, isLoading: isHourlyLoading } = useQuery<HourlySalesData[]>({
    queryKey: ['/api/sales/hourly'],
    refetchOnWindowFocus: false,
  });
  
  const { data: categorySalesData, isLoading: isCategoryLoading } = useQuery<CategorySalesData[]>({
    queryKey: ['/api/sales/categories'],
    refetchOnWindowFocus: false,
  });
  
  const { data: dailySalesData, isLoading: isDailyLoading } = useQuery<DailySalesData[]>({
    queryKey: ['/api/sales/daily'],
    refetchOnWindowFocus: false,
  });
  
  const { data: salesStatistics, isLoading: isStatsLoading } = useQuery<SalesStatistics>({
    queryKey: ['/api/sales/statistics'],
    refetchOnWindowFocus: false,
  });
  
  // Sprawdzenie czy dane sprzedaży są ładowane
  const isSalesDataLoading = isMonthlyLoading || isHourlyLoading || isCategoryLoading || isDailyLoading || isStatsLoading;
  
  // Stan lokalny do śledzenia stanu ładowania danych rezerwacji
  const [isReservationsLoading, setIsReservationsLoading] = useState(false);
  
  // Pobieranie danych o rezerwacjach z API
  useEffect(() => {
    const fetchReservations = async () => {
      setIsReservationsLoading(true);
      try {
        const response = await fetch('/api/meal-reservations');
        const data = await response.json();
        
        if (data.success && data.reservations) {
          // Pobierz dane o pracownikach, aby pobrać ich imiona i nazwiska
          const employeesResponse = await fetch('/api/employees');
          const employeesData = await employeesResponse.json();
          
          // Pobierz dane o produktach, aby pobrać ich nazwy i ceny
          const productsResponse = await fetch('/api/products');
          const productsData = await productsResponse.json();
          
          // Lista rezerwacji do przetworzenia
          const reservationPromises = data.reservations.map(async (reservation: any) => {
            // Pobierz szczegóły rezerwacji indywidualnie, aby uzyskać status
            const detailResponse = await fetch(`/api/meal-reservations/${reservation.id}`);
            const detailData = await detailResponse.json();
            
            const employee = employeesData.find((emp: any) => emp.id === reservation.employeeId);
            const product = productsData.find((prod: any) => prod.id === reservation.productId);
            
            // Zamień format daty z YYYY-MM-DD na DD.MM.YYYY
            const dateObj = new Date(reservation.reservedForDate);
            const formattedDate = `${dateObj.getDate().toString().padStart(2, '0')}.${(dateObj.getMonth() + 1).toString().padStart(2, '0')}.${dateObj.getFullYear()}`;
            
            // Określ miesiąc po polsku
            const months = ['Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec', 'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'];
            const monthName = `${months[dateObj.getMonth()]} ${dateObj.getFullYear()}`;
            
            // Mapuj statusy z API na statusy wyświetlane
            let status;
            if (detailData.reservation && detailData.reservation.status) {
              switch (detailData.reservation.status) {
                case 'cancelled':
                  status = 'Anulowana';
                  break;
                case 'fulfilled':
                  status = 'Zrealizowana';
                  break;
                case 'active':
                  status = 'Aktywna';
                  break;
                default:
                  // Pobierz dzisiejszą datę (północ)
                  const today = new Date();
                  today.setHours(0, 0, 0, 0);
                  
                  // Pobierz datę rezerwacji
                  const reservationDate = new Date(reservation.reservedForDate);
                  reservationDate.setHours(0, 0, 0, 0);
                  
                  // Jeśli data rezerwacji jest dzisiejsza lub wcześniejsza
                  if (reservationDate <= today) {
                    status = 'Zrealizowana';
                  } else {
                    status = 'Aktywna';
                  }
              }
            } else {
              // Zabezpieczenie w przypadku braku statusu
              status = 'Aktywna';
            }
            
            return {
              id: reservation.id,
              employee: employee ? `${employee.firstName} ${employee.lastName}` : 'Nieznany pracownik',
              product: product ? product.name : 'Nieznany produkt',
              date: formattedDate,
              month: monthName,
              price: product ? product.price : 0,
              status
            };
          });
          
          // Poczekaj na wszystkie zapytania o szczegóły
          const formattedReservations = await Promise.all(reservationPromises);
          
          setAllReservations(formattedReservations);
        } else {
          toast({
            title: "Błąd pobierania danych",
            description: "Nie udało się pobrać danych o rezerwacjach",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Błąd pobierania danych:", error);
        toast({
          title: "Błąd połączenia",
          description: "Wystąpił problem z połączeniem z serwerem",
          variant: "destructive",
        });
      } finally {
        setIsReservationsLoading(false);
      }
    };
    
    fetchReservations();
  }, [toast]);
  
  // Pomocnicza funkcja do konwersji formatu daty
  const parseDate = (dateStr: string) => {
    // Konwertuj z formatu DD.MM.YYYY na obiekt Date
    if (dateStr) {
      const [day, month, year] = dateStr.split('.');
      if (day && month && year) {
        return new Date(`${year}-${month}-${day}`);
      }
    }
    return null;
  };

  // Funkcja filtrująca dane na podstawie wybranych kryteriów
  const handleGenerateReport = () => {
    let filtered = [...allReservations];
    
    // Filtruj wg pracownika
    if (selectedEmployee) {
      filtered = filtered.filter(item => item.employee === selectedEmployee);
    }
    
    // Filtruj wg statusu
    if (selectedStatus) {
      filtered = filtered.filter(item => item.status === selectedStatus);
    }
    
    // Filtrowanie po datach
    if (dateFrom) {
      const fromDate = new Date(dateFrom);
      fromDate.setHours(0, 0, 0, 0);
      
      filtered = filtered.filter(item => {
        const itemDate = parseDate(item.date);
        return itemDate && itemDate >= fromDate;
      });
    }
    
    if (dateTo) {
      const toDate = new Date(dateTo);
      toDate.setHours(23, 59, 59, 999);
      
      filtered = filtered.filter(item => {
        const itemDate = parseDate(item.date);
        return itemDate && itemDate <= toDate;
      });
    }
    
    // Zaktualizuj dane i pokaż wyniki
    setFilteredData(filtered);
    setShowResults(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-800">Raporty i Analizy</h3>
          <p className="text-gray-600 mt-1">
            Kompleksowe raporty sprzedaży i rezerwacji pracowników
          </p>
        </div>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="w-full">
          <TabsTrigger value="sales" className="flex-1">Sprzedaż</TabsTrigger>
          <TabsTrigger value="employees" className="flex-1">Posiłki pracownicze</TabsTrigger>
        </TabsList>
        
        {/* TAB: Raporty sprzedaży */}
        <TabsContent value="sales" className="space-y-6">
          {isSalesDataLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-8 w-32" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard 
                title="Całkowita sprzedaż" 
                value={salesStatistics ? formatCurrency(salesStatistics.totalSales) : '-'} 
                subtitle="W bieżącym miesiącu" 
                trend={salesStatistics ? `${salesStatistics.totalSalesChange >= 0 ? '+' : ''}${salesStatistics.totalSalesChange.toFixed(1)}%` : ''}
              />
              <StatCard 
                title="Średnio dziennie" 
                value={salesStatistics ? formatCurrency(salesStatistics.averageDaily) : '-'} 
                subtitle="Produktów" 
                trend={salesStatistics ? `${salesStatistics.averageDailyChange >= 0 ? '+' : ''}${salesStatistics.averageDailyChange.toFixed(1)}%` : ''}
              />
              <StatCard 
                title="Najpopularniejszy produkt" 
                value={salesStatistics && salesStatistics.bestSellingProduct ? salesStatistics.bestSellingProduct.name : '-'} 
                subtitle={salesStatistics && salesStatistics.bestSellingProduct ? `${salesStatistics.bestSellingProduct.quantity} sprzedanych` : ''} 
                trend="" 
              />
              <StatCard 
                title="Najlepsza godzina" 
                value={salesStatistics && salesStatistics.bestHour ? salesStatistics.bestHour.time : '-'} 
                subtitle={salesStatistics && salesStatistics.bestHour ? `${salesStatistics.bestHour.transactions} transakcji` : ''} 
                trend="" 
              />
            </div>
          )}
          
          {/* Wykres miesięcznych przychodów */}
          <Card>
            <CardHeader>
              <CardTitle>Przychody miesięczne</CardTitle>
              <CardDescription>
                Ostatnie 6 miesięcy
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={monthlySalesData || []}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                    <Legend />
                    <Line type="monotone" dataKey="Sprzedaż" stroke="#8884d8" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* Wykresy dzienne i kategorie */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Wykres kołowy kategorii */}
            <Card>
              <CardHeader>
                <CardTitle>Udział kategorii w sprzedaży</CardTitle>
                <CardDescription>
                  Procentowy podział sprzedaży
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categorySalesData || []}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {(categorySalesData || []).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => `${value}%`} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Wykres sprzedaży godzinowej */}
            <Card>
              <CardHeader>
                <CardTitle>Sprzedaż według godzin</CardTitle>
                <CardDescription>
                  Rozkład dziennej sprzedaży
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[300px] w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={hourlySalesData || []}
                      margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="Sprzedaż" fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Zestawienie sprzedaży w tabeli */}
          <Card>
            <CardHeader>
              <CardTitle>Sprzedaż według kategorii</CardTitle>
              <CardDescription>
                Zestawienie dzienne za ostatni tydzień
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="w-full overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-50">
                      <th className="py-2 px-4 text-left border-b">Data</th>
                      <th className="py-2 px-4 text-center border-b">Dania</th>
                      <th className="py-2 px-4 text-center border-b">Sałatki</th>
                      <th className="py-2 px-4 text-center border-b">Zupy</th>
                      <th className="py-2 px-4 text-center border-b">Przekąski</th>
                      <th className="py-2 px-4 text-center border-b font-bold">Suma</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(dailySalesData || []).map((item, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="py-2 px-4 border-b font-medium">{item.date}</td>
                        <td className="py-2 px-4 text-center border-b">{item.Dania || 0}</td>
                        <td className="py-2 px-4 text-center border-b">{item.Sałatki || 0}</td>
                        <td className="py-2 px-4 text-center border-b">{item.Zupy || 0}</td>
                        <td className="py-2 px-4 text-center border-b">{item.Przekąski || 0}</td>
                        <td className="py-2 px-4 text-center border-b font-bold">{item.total}</td>
                      </tr>
                    ))}
                    <tr className="bg-gray-100">
                      <td className="py-2 px-4 border-b font-bold">Suma</td>
                      <td className="py-2 px-4 text-center border-b font-bold">{(dailySalesData || []).reduce((sum, item) => sum + (Number(item.Dania) || 0), 0)}</td>
                      <td className="py-2 px-4 text-center border-b font-bold">{(dailySalesData || []).reduce((sum, item) => sum + (Number(item.Sałatki) || 0), 0)}</td>
                      <td className="py-2 px-4 text-center border-b font-bold">{(dailySalesData || []).reduce((sum, item) => sum + (Number(item.Zupy) || 0), 0)}</td>
                      <td className="py-2 px-4 text-center border-b font-bold">{(dailySalesData || []).reduce((sum, item) => sum + (Number(item.Przekąski) || 0), 0)}</td>
                      <td className="py-2 px-4 text-center border-b font-bold">{(dailySalesData || []).reduce((sum, item) => sum + item.total, 0)}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* TAB: Posiłki pracownicze */}
        <TabsContent value="employees" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Raport posiłków pracowniczych</CardTitle>
              <CardDescription>
                Wybierz filtry aby wygenerować raport
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div>
                {/* Filtry raportu */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  <div>
                    <label htmlFor="employee-filter" className="block text-sm font-medium text-gray-700 mb-1">
                      Pracownik
                    </label>
                    <select
                      id="employee-filter"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                      value={selectedEmployee}
                      onChange={(e) => setSelectedEmployee(e.target.value)}
                    >
                      <option value="">Wszyscy pracownicy</option>
                      {allReservations
                        .map(res => res.employee)
                        .filter((employee, index, self) => self.indexOf(employee) === index)
                        .map(employee => (
                          <option key={employee} value={employee}>{employee}</option>
                        ))
                      }
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="status-filter" className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <select
                      id="status-filter"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                      value={selectedStatus}
                      onChange={(e) => setSelectedStatus(e.target.value)}
                    >
                      <option value="">Wszystkie statusy</option>
                      <option value="Zrealizowana">Zrealizowane</option>
                      <option value="Aktywna">Aktywne</option>
                      <option value="Anulowana">Anulowane</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="date-from" className="block text-sm font-medium text-gray-700 mb-1">
                      Data od
                    </label>
                    <input
                      type="date"
                      id="date-from"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                      value={dateFrom}
                      onChange={(e) => setDateFrom(e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="date-to" className="block text-sm font-medium text-gray-700 mb-1">
                      Data do
                    </label>
                    <input
                      type="date"
                      id="date-to"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
                      value={dateTo}
                      onChange={(e) => setDateTo(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="mb-6 flex justify-end">
                  <button 
                    className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded shadow transition flex items-center"
                    onClick={handleGenerateReport}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V7.414A2 2 0 0015.414 6L12 2.586A2 2 0 0010.586 2H6zm5 6a1 1 0 10-2 0v2H7a1 1 0 100 2h2v2a1 1 0 102 0v-2h2a1 1 0 100-2h-2V8z" clipRule="evenodd" />
                    </svg>
                    Generuj raport
                  </button>
                </div>
                
                {showResults && (
                  <>
                    {/* Wyniki raportu */}
                    <div className="bg-gray-50 p-4 rounded-lg mb-6">
                      <h3 className="text-lg font-medium text-gray-800 mb-2">Podsumowanie</h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        <div className="bg-white p-4 rounded shadow">
                          <p className="text-sm text-gray-500">Liczba posiłków</p>
                          <p className="text-2xl font-bold">{filteredData.length}</p>
                        </div>
                        <div className="bg-white p-4 rounded shadow">
                          <p className="text-sm text-gray-500">Łączna wartość</p>
                          <p className="text-2xl font-bold">
                            {formatCurrency(filteredData.reduce((sum, item) => sum + item.price, 0))}
                          </p>
                        </div>
                        <div className="bg-white p-4 rounded shadow">
                          <p className="text-sm text-gray-500">Najczęściej wybierany posiłek</p>
                          <p className="text-lg font-bold">
                            {filteredData.length > 0 ? 
                              (() => {
                                const productCounts: Record<string, number> = {};
                                filteredData.forEach(item => {
                                  productCounts[item.product] = (productCounts[item.product] || 0) + 1;
                                });
                                let mostPopularProduct = '';
                                let maxCount = 0;
                                for (const product in productCounts) {
                                  if (productCounts[product] > maxCount) {
                                    mostPopularProduct = product;
                                    maxCount = productCounts[product];
                                  }
                                }
                                return mostPopularProduct;
                              })() : 'Brak danych'
                            }
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    {/* Tabela wyników */}
                    <div className="overflow-x-auto shadow rounded-lg">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              ID
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Pracownik
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Produkt
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Data
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Cena
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {filteredData.length > 0 ? (
                            filteredData.map(reservation => (
                              <tr key={reservation.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {reservation.id}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {reservation.employee}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {reservation.product}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {reservation.date}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {formatCurrency(reservation.price)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  <span className={
                                    reservation.status === 'Zrealizowana' 
                                      ? 'px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800'
                                      : reservation.status === 'Aktywna'
                                      ? 'px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800'
                                      : 'px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800'
                                  }>
                                    {reservation.status}
                                  </span>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan={6} className="px-6 py-4 text-center text-sm text-gray-500">
                                Brak wyników dla wybranych kryteriów
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                    
                    {filteredData.length > 0 && (
                      <div className="mt-6 flex justify-end">
                        <button 
                          className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                          onClick={() => exportToCSV(filteredData, `Raport_Posilkow_Pracowniczych_${new Date().toISOString().slice(0, 10)}`)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                          </svg>
                          Eksportuj CSV
                        </button>
                      </div>
                    )}
                  </>
                )}
                

              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};