import React, { useState, useCallback, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { MealReservation, Employee, Chamber } from '@shared/schema';
import { format, parseISO } from 'date-fns';
import { pl } from 'date-fns/locale';
import { Calendar as CalendarIcon, RefreshCcw, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

export const MealReservationsView: React.FC = () => {
  console.log("Rendering MealReservationsView component");
  const today = new Date();
  const [selectedDate, setSelectedDate] = useState<Date>(today);
  const formattedDate = selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '';
  const { toast } = useToast();
  
  // Dodajemy dodatkową zmienną stanu do force-reload komponentu przy zmianie daty
  const [versionKey, setVersionKey] = useState(0);

  // Stan dla sprawdzania, czy pracownicy pracują w danym dniu
  const [employeeWorkingStatus, setEmployeeWorkingStatus] = useState<Record<number, boolean>>({});
  const [isLoadingWorkDays, setIsLoadingWorkDays] = useState(false);
  const [dataReloadKey, setDataReloadKey] = useState(0);
  const reloadIdRef = React.useRef(0);

  // Pobieranie rezerwacji
  const { 
    data: reservationData, 
    isLoading: isLoadingReservations, 
    refetch: refetchReservations 
  } = useQuery<{
    success: boolean;
    reservations: MealReservation[];
  }>({
    queryKey: ['/api/meal-reservations', formattedDate],
    queryFn: async () => {
      try {
        console.log(`Pobieranie rezerwacji dla daty: ${formattedDate}`);
        const response = await fetch(`/api/meal-reservations?date=${formattedDate}`, {
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' }
        });
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        console.log('Pobrano dane rezerwacji:', data);
        return data;
      } catch (err) {
        console.error('Błąd pobierania rezerwacji:', err);
        throw err;
      }
    },
    enabled: !!formattedDate
  });

  // Pobieranie pracowników
  const { 
    data: employees,
    isLoading: isLoadingEmployees 
  } = useQuery<Employee[]>({
    queryKey: ['/api/employees'],
  });

  // Pobieranie szuflad
  const { 
    data: chambersData,
    isLoading: isLoadingChambers 
  } = useQuery<{ chambers: Chamber[] }>({
    queryKey: ['/api/chambers'],
  });

  // Debugowanie - śledzenie stanu komponentu
  useEffect(() => {
    console.log("MealReservationsView: Stan komponentu:", {
      isLoadingReservations,
      isLoadingEmployees,
      isLoadingChambers,
      isLoadingWorkDays,
      employeesCount: employees?.length || 0,
      reservationsCount: reservationData?.reservations?.length || 0,
      chambersCount: chambersData?.chambers?.length || 0,
      formattedDate,
      selectedDate: selectedDate?.toISOString(),
      dataReloadKey
    });
  }, [
    isLoadingReservations, 
    isLoadingEmployees, 
    isLoadingChambers, 
    isLoadingWorkDays, 
    employees, 
    reservationData, 
    chambersData, 
    formattedDate, 
    selectedDate,
    dataReloadKey
  ]);

  // Ręczne odświeżenie danych
  const handleRefresh = useCallback(() => {
    console.log("Ręczne odświeżenie danych");
    refetchReservations();
    setDataReloadKey(prev => prev + 1);
  }, [refetchReservations]);

  // Pobieranie danych o dniach pracy pracowników
  useEffect(() => {
    // Warunek do uruchomienia efektu - potrzebujemy mieć datę i listę pracowników
    if (!formattedDate || !employees || employees.length === 0) {
      console.log("Warunki nie spełnione dla sprawdzania statusu pracy - brak daty lub pracowników");
      return;
    }
    
    // Zapisujemy aktualny ID odświeżenia w referencji
    const currentReloadId = ++reloadIdRef.current;
    
    // Funkcja, która faktycznie ładuje dane o pracy pracowników
    let isActive = true; // Flaga aby uniknąć aktualizacji stanu po odmontowaniu
    
    // Ustawiamy loading na true
    setIsLoadingWorkDays(true);
    console.log(`[MealReservationsView] Pobieranie statusu pracy dla ${employees.length} pracowników na datę ${formattedDate} (ID: ${currentReloadId})`);
    
    // Bardziej zaawansowana metoda ładowania: zamiast ładować dane dla każdego pracownika osobno,
    // tworzymy tablicę obietnic i używamy Promise.all aby uzyskać wszystkie wyniki naraz
    const loadWorkStatus = async () => {
      try {
        // Tworzenie tablicy obietnic
        const workStatusPromises = employees.map(employee => 
          fetch(`/api/employee-work-days/${employee.id}/check/${formattedDate}`, {
            headers: { 'Accept': 'application/json' }
          })
          .then(response => {
            if (!response.ok) {
              throw new Error(`Błąd HTTP: ${response.status}`);
            }
            return response.json();
          })
          .then(data => ({ employeeId: employee.id, isWorking: data.isWorking }))
          .catch(error => {
            console.error(`[MealReservationsView] Błąd sprawdzania statusu dla pracownika ${employee.id}:`, error);
            return { employeeId: employee.id, isWorking: false }; // W razie błędu domyślnie nie pracuje
          })
        );
        
        // Wykonanie wszystkich zapytań równolegle
        const results = await Promise.all(workStatusPromises);
        
        // Jeśli komponent został odmontowany lub jest inne żądanie w toku, przerywamy
        if (!isActive || reloadIdRef.current !== currentReloadId) {
          console.log(`[MealReservationsView] Przerwano przetwarzanie wyników, nowsze żądanie jest w toku (ID: ${reloadIdRef.current})`);
          return;
        }
        
        // Zapisujemy wyniki do stanu
        const newStatus: Record<number, boolean> = {};
        results.forEach(result => {
          newStatus[result.employeeId] = result.isWorking;
        });
        
        // Aktualizujemy stan
        setEmployeeWorkingStatus(newStatus);
        console.log(`[MealReservationsView] Zakończono ładowanie statusu pracowników (ID: ${currentReloadId})`, newStatus);
      } catch (error) {
        console.error('[MealReservationsView] Błąd podczas zbierania statusu pracy pracowników:', error);
      } finally {
        // Kończymy ładowanie niezależnie od wyniku
        if (isActive && reloadIdRef.current === currentReloadId) {
          setIsLoadingWorkDays(false);
        }
      }
    };
    
    // Uruchamiamy ładowanie danych
    loadWorkStatus();
    
    // Funkcja czyszcząca - ustawiamy flagę isActive na false, aby uniknąć aktualizacji stanu po odmontowaniu
    return () => {
      isActive = false;
    };
    
  }, [formattedDate, employees, dataReloadKey]); // Usunięto employeeWorkingStatus z zależności, aby uniknąć pętli

  // Pobieranie informacji o rezerwacji dla danego pracownika
  const getReservationForEmployee = (employeeId: number) => {
    if (!reservationData?.reservations) {
      console.log('[MealReservationsView] Brak danych o rezerwacjach', reservationData);
      return null;
    }
    
    // Dodajemy dodatkowe logowanie dla debugowania
    console.log(`[MealReservationsView] Szukam rezerwacji dla pracownika ${employeeId} na datę ${formattedDate}`, {
      total: reservationData.reservations.length,
      reservations: reservationData.reservations
        .filter(r => r.employeeId === employeeId)
        .map(r => ({ id: r.id, date: r.reservedForDate, employeeId: r.employeeId }))
    });
    
    const result = reservationData.reservations.find(r => 
      r.employeeId === employeeId && r.reservedForDate === formattedDate
    );
    
    return result;
  };

  // Pobieranie informacji o szufladzie przypisanej do pracownika
  const getChamberInfoForEmployee = (employeeId: number) => {
    if (!chambersData?.chambers) return 'Brak przydziału';
    
    // Najpierw sprawdź przypisane szuflady z ogólnych przypisań
    const assignedChamber = chambersData.chambers.find(c => c.employeeId === employeeId);
    if (assignedChamber) {
      return `${assignedChamber.id}`;
    }
    
    // Jeśli nie ma ogólnego przypisania, sprawdź przypisania z rezerwacji
    const reservation = getReservationForEmployee(employeeId);
    if (reservation && reservation.chamberId) {
      const chamber = chambersData.chambers.find(c => c.id === reservation.chamberId);
      return chamber ? `${chamber.id}` : 'Brak przydziału';
    }
    
    return 'Brak przydziału';
  };

  // Formatowanie metody przypisania
  const formatAssignmentType = (type: string | null | undefined) => {
    if (!type) return 'Samodzielny wybór'; // Domyślnie wszystkie rezerwacje są wybrane przez pracownika
    switch (type) {
      case 'manual': return 'Samodzielny wybór';
      case 'preference': return 'Wg preferencji';
      case 'random': return 'Losowo';
      default: return 'Samodzielny wybór'; // Domyślnie wszystkie rezerwacje są wybrane przez pracownika
    }
  };

  // Funkcja obsługująca wybór daty
  const handleDateSelect = (date: Date | undefined) => {
    if (date) {
      console.log(`Wybrano nową datę: ${format(date, 'yyyy-MM-dd')}`);
      
      // Reset stanu - wyczyść status pracowników
      setEmployeeWorkingStatus({});
      
      // Ustaw flagę ładowania na true, aby pokazać ekran ładowania
      setIsLoadingWorkDays(true);
      
      // Ustaw nową datę (to spowoduje odświeżenie danych)
      setSelectedDate(date);
      
      // Inkrementuj klucz wersji aby wymusić ponowne renderowanie całego komponentu
      setVersionKey(prev => prev + 1);
      
      // Ręcznie wywołaj odświeżenie danych o rezerwacjach
      setTimeout(() => {
        refetchReservations();
        setDataReloadKey(prev => prev + 1);
      }, 100);
    }
  };
  
  // Funkcja obsługująca eksport danych
  const handleExportData = () => {
    if (!employees || employees.length === 0) {
      toast({
        title: "Brak danych do eksportu",
        description: "Nie ma dostępnych danych do wyeksportowania.",
        variant: "destructive"
      });
      return;
    }
    
    // Create data for export
    const exportData = employees.map(employee => {
      const reservation = getReservationForEmployee(employee.id);
      const isWorking = employeeWorkingStatus[employee.id];
      const chamberInfo = getChamberInfoForEmployee(employee.id);
      
      let mealStatus = 'Nie pracuje w tym dniu';
      if (isWorking === true) {
        mealStatus = reservation 
          ? (reservation.productName || 'Brak informacji o produkcie')
          : 'Brak wyboru posiłku';
      }
      
      return {
        'Pracownik': `${employee.firstName} ${employee.lastName}`,
        'Nr szuflady': chamberInfo === 'Brak przydziału' ? '-' : chamberInfo,
        'Posiłek': mealStatus,
        'Metoda przypisania': reservation ? formatAssignmentType(reservation.assignmentType) : '-'
      };
    });
    
    // Convert to CSV
    const headers = ['Pracownik', 'Nr szuflady', 'Posiłek', 'Metoda przypisania'];
    const csvContent = [
      headers.join(','),
      ...exportData.map(row => 
        headers.map(header => 
          // Escape commas and quotes in the cell value
          `"${String(row[header]).replace(/"/g, '""')}"`
        ).join(',')
      )
    ].join('\n');
    
    // Create file and trigger download
    const date = selectedDate ? format(selectedDate, 'yyyy-MM-dd', { locale: pl }) : 'wszystkie';
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    link.setAttribute('href', url);
    link.setAttribute('download', `rezerwacje-posilkow-${date}.csv`);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Eksport zakończony",
      description: "Plik CSV z danymi został pobrany.",
      variant: "default"
    });
  };

  // Sprawdzanie czy dane są w trakcie ładowania
  const isLoading = isLoadingReservations || isLoadingWorkDays || isLoadingEmployees || isLoadingChambers;

  // Dodajemy więcej logów diagnostycznych przed renderowaniem
  console.log('[MealReservationsView] Status przed renderowaniem:', {
    isLoading,
    isLoadingReservations,
    isLoadingWorkDays,
    isLoadingEmployees,
    isLoadingChambers,
    reservationDataExists: !!reservationData?.reservations,
    reservationCount: reservationData?.reservations?.length || 0,
    employeesCount: employees?.length || 0,
    workingStatusKeys: Object.keys(employeeWorkingStatus).length,
    chambersDataExists: !!chambersData?.chambers
  });

  // Sprawdzamy czy dane faktycznie się załadowały
  if (employees && employees.length > 0 && !isLoading) {
    const sampleEmployee = employees[0];
    const reservation = getReservationForEmployee(sampleEmployee.id);
    
    // Bezpieczne sprawdzenie isWorking
    const workingStatus = employeeWorkingStatus && typeof employeeWorkingStatus === 'object' 
      ? (sampleEmployee.id in employeeWorkingStatus ? employeeWorkingStatus[sampleEmployee.id] : 'nie określono')
      : 'brak obiektu statusu';
    
    console.log(`[MealReservationsView] Przykładowe dane dla ${sampleEmployee.firstName} ${sampleEmployee.lastName}:`, {
      employeeId: sampleEmployee.id,
      reservation,
      isWorking: workingStatus,
      chamberInfo: getChamberInfoForEmployee(sampleEmployee.id)
    });
  }

  // Użyj klucza wersji do wymuszenia pełnego ponownego renderowania przy zmianie daty
  return (
    <div className="space-y-6" key={`reservation-view-${versionKey}`}>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-medium text-gray-800">Rezerwacje posiłków</h3>
          <p className="text-gray-600 mt-1">
            Przeglądaj i monitoruj rezerwacje posiłków pracowników na poszczególne dni
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-[240px] justify-start text-left font-normal",
                  !selectedDate && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {selectedDate ? (
                  format(selectedDate, "PPP", { locale: pl })
                ) : (
                  <span>Wybierz datę</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateSelect}
                initialFocus
                locale={pl}
              />
            </PopoverContent>
          </Popover>
          
          <Button 
            className="bg-green-500 hover:bg-green-600 flex items-center gap-2"
            onClick={handleExportData}
          >
            <FileText className="h-4 w-4" />
            Eksportuj
          </Button>
        </div>
      </div>

      {/* Wyświetlamy jasny spinner ładowania */}
      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-8 bg-white rounded-lg border">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
          <div className="text-base font-medium text-gray-700">Ładowanie danych...</div>
          <div className="text-xs text-gray-500 mt-2">
            {isLoadingEmployees && <span>Pobieranie pracowników... </span>}
            {isLoadingReservations && <span>Pobieranie rezerwacji... </span>}
            {isLoadingWorkDays && <span>Sprawdzanie dni pracy... </span>}
            {isLoadingChambers && <span>Pobieranie szuflad... </span>}
          </div>
        </div>
      ) : !employees || employees.length === 0 ? (
        <div className="border rounded-md p-8 text-center text-gray-500">
          Brak danych o pracownikach do wyświetlenia
        </div>
      ) : (
        <div className="rounded-md border overflow-hidden">
          <Table className="bg-white">
            <TableHeader className="bg-gray-50">
              <TableRow>
                <TableHead className="py-3 font-medium">Pracownik</TableHead>
                <TableHead className="py-3 font-medium">Nr szuflady</TableHead>
                <TableHead className="py-3 font-medium">Posiłek</TableHead>
                <TableHead className="py-3 font-medium">Metoda przypisania</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {employees?.map((employee) => {
                const reservation = getReservationForEmployee(employee.id);
                // W stanie przechowujemy informację czy pracownik pracuje
                const isWorking = employeeWorkingStatus[employee.id];
                
                return (
                  <TableRow key={employee.id}>
                    <TableCell className="font-medium py-4">
                      {employee.firstName} {employee.lastName}
                    </TableCell>
                    <TableCell className="py-4">
                      {getChamberInfoForEmployee(employee.id) === 'Brak przydziału' ? (
                        <span className="text-gray-500">Brak przydziału</span>
                      ) : (
                        <div className="bg-green-100 text-green-800 rounded-full px-3 py-1 text-sm inline-flex items-center justify-center w-fit">
                          {getChamberInfoForEmployee(employee.id)}
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="py-4">
                      {isWorking === true ? (
                        reservation ? (
                          <span>{reservation.productName || 'Brak informacji o produkcie'}</span>
                        ) : (
                          <span className="text-orange-500">Brak wyboru posiłku</span>
                        )
                      ) : isWorking === false ? (
                        <span className="text-gray-500 italic">Nie pracuje w tym dniu</span>
                      ) : (
                        <span className="text-gray-400">Ładowanie statusu...</span>
                      )}
                    </TableCell>
                    <TableCell className="py-4">
                      {reservation ? (
                        <Badge variant="secondary">
                          {formatAssignmentType(reservation.assignmentType)}
                        </Badge>
                      ) : (
                        <span className="text-gray-500">-</span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
};