import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { pl } from 'date-fns/locale';
import { format, addDays, parse } from 'date-fns';

import {
  Card,
  CardContent,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';

import {
  CalendarIcon, RefreshCw, User, Utensils, 
  CalendarCheck, Box, Lightbulb, 
  RefreshCcw, MousePointer
} from 'lucide-react';
import { cn } from '@/lib/utils';

type MealReservation = {
  id: number;
  employeeId: number;
  productId: number;
  reservedForDate: string;
  chamberId?: number | null;
  assignmentType?: 'manual' | 'preference' | 'random' | null;
};

type Employee = {
  id: number;
  firstName: string;
  lastName: string;
  email?: string;
  position?: string;
  department?: string;
  photoUrl?: string | null;
  dietaryPreferences?: string[];
};

type Chamber = {
  id: number;
  productId: number | null;
  employeeId: number | null;
  isAvailable: boolean;
};

type WorkDay = {
  id: number;
  employeeId: number;
  workDate: string;
  isWorking: boolean;
};

export const SimpleMealReservationManager: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [chambersMap, setChambersMap] = useState<Record<number, number>>({});
  const [employeeWorkStatus, setEmployeeWorkStatus] = useState<Record<number, boolean>>({});
  const [showCalendar, setShowCalendar] = useState<boolean>(false);
  
  // Format the selected date for API calls
  const formattedDate = format(selectedDate, 'yyyy-MM-dd');
  
  // Fetch employees
  const { 
    data: employees = [] 
  } = useQuery({
    queryKey: ['/api/employees'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/employees');
        return response as Employee[];
      } catch (error) {
        console.error('Błąd podczas pobierania pracowników:', error);
        return [];
      }
    },
  });
  
  // Fetch products
  const { 
    data: products = [] 
  } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/products');
        return response;
      } catch (error) {
        console.error('Błąd podczas pobierania produktów:', error);
        return [];
      }
    },
  });
  
  // Fetch meal reservations for the selected date
  const { 
    data: reservationsResponse = { reservations: [] }, 
    isLoading: isLoadingReservations,
    refetch: refetchReservations
  } = useQuery({
    queryKey: ['/api/meal-reservations', { date: formattedDate }],
    queryFn: async () => {
      try {
        const response = await apiRequest(`/api/meal-reservations?date=${formattedDate}`);
        if (response && response.reservations) {
          return response;
        }
        return { reservations: [] };
      } catch (error) {
        console.error('Błąd podczas pobierania rezerwacji:', error);
        return { reservations: [] };
      }
    },
  });
  
  // Get chambers data
  const { 
    data: chambersResponse = { chambers: [] }, 
    isLoading: isLoadingChambers 
  } = useQuery({
    queryKey: ['/api/chambers'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/chambers');
        return response;
      } catch (error) {
        console.error('Błąd podczas pobierania szuflad:', error);
        return { chambers: [] };
      }
    },
  });
  
  // Fetch meal counts for calendar
  const { 
    data: mealCountsResponse = { 
      success: false, 
      reservationCounts: [] 
    }
  } = useQuery({
    queryKey: ['/api/meal-reservations/counts', { month: format(selectedDate, 'yyyy-MM') }],
    queryFn: async () => {
      try {
        // This endpoint doesn't exist yet, so we'll just return a mock
        // In real implementation, this would fetch the meal counts for the current month
        const startOfMonth = format(
          parse(`${format(selectedDate, 'yyyy-MM')}-01`, 'yyyy-MM-dd', new Date()), 
          'yyyy-MM-dd'
        );
        const endOfMonth = format(
          addDays(
            parse(`${format(selectedDate, 'yyyy-MM')}-01`, 'yyyy-MM-dd', new Date()),
            30
          ), 
          'yyyy-MM-dd'
        );
        
        const response = await apiRequest(`/api/meal-reservations?startDate=${startOfMonth}&endDate=${endOfMonth}`);
        
        // Process the response to get counts by date
        if (response && response.reservations) {
          const counts: Record<string, number> = {};
          response.reservations.forEach((reservation: any) => {
            const date = reservation.reservedForDate;
            counts[date] = (counts[date] || 0) + 1;
          });
          
          return { 
            success: true, 
            reservationCounts: Object.entries(counts).map(([date, count]) => ({ 
              date, 
              count 
            }))
          };
        }
        
        return { success: false, reservationCounts: [] };
      } catch (error) {
        console.error('Błąd podczas pobierania liczby rezerwacji:', error);
        return { success: false, reservationCounts: [] };
      }
    },
  });
  
  // Process chambers data to map employee IDs to chamber IDs
  useEffect(() => {
    if (chambersResponse && chambersResponse.chambers) {
      const chambers = chambersResponse.chambers;
      const chamberMapping: Record<number, number> = {};
      
      chambers.forEach((chamber: Chamber) => {
        if (chamber.employeeId !== null) {
          chamberMapping[chamber.employeeId] = chamber.id;
        }
      });
      
      setChambersMap(chamberMapping);
    }
  }, [chambersResponse]);
  
  // Process employee work status for the selected date
  useEffect(() => {
    const checkWorkStatus = async () => {
      const workStatus: Record<number, boolean> = {};
      
      // Check work status for each employee
      for (const employee of employees) {
        try {
          const response = await apiRequest(`/api/employee-work-days/by-employee/${employee.id}?date=${formattedDate}`);
          
          if (Array.isArray(response) && response.length > 0) {
            // If we have a record, use the isWorking value
            workStatus[employee.id] = response[0].isWorking;
          } else {
            // Default to not working if no record found
            workStatus[employee.id] = false;
          }
        } catch (error) {
          console.error(`Error checking work status for employee ${employee.id}:`, error);
          workStatus[employee.id] = false;
        }
      }
      
      setEmployeeWorkStatus(workStatus);
    };
    
    if (employees.length > 0) {
      checkWorkStatus();
    }
  }, [employees, formattedDate]);
  
  // Helper to get product name by ID
  const getProductName = (productId: number) => {
    const product = products.find((p: any) => p.id === productId);
    return product ? product.name : `Produkt #${productId}`;
  };
  
  // Helper to get assignment type display info
  const getAssignmentTypeInfo = (type: string | null | undefined) => {
    switch(type) {
      case 'manual':
        return {
          label: 'Wybór użytkownika',
          icon: <MousePointer className="w-3 h-3 mr-1" />,
        };
      case 'preference':
        return {
          label: 'Wg preferencji',
          icon: <Lightbulb className="w-3 h-3 mr-1" />,
        };
      case 'random':
        return {
          label: 'Losowy wybór',
          icon: <RefreshCcw className="w-3 h-3 mr-1" />,
        };
      default:
        return {
          label: 'Nieznany',
          icon: null,
        };
    }
  };
  
  // Process reservations to get unique reservations per employee
  const getEmployeeReservations = () => {
    const reservations = reservationsResponse.reservations || [];
    const employeeReservationsMap: Record<number, any> = {};
    
    // Group reservations by employee ID, taking the highest ID (newest)
    reservations.forEach((reservation: any) => {
      const existingReservation = employeeReservationsMap[reservation.employeeId];
      
      if (!existingReservation || reservation.id > existingReservation.id) {
        employeeReservationsMap[reservation.employeeId] = reservation;
      }
    });
    
    return employeeReservationsMap;
  };
  
  const employeeReservations = getEmployeeReservations();
  
  // Calendar component based on image
  const CalendarView = () => {
    const monthStr = format(selectedDate, 'MMMM yyyy', { locale: pl });
    
    // Get reservations count data for calendar display
    const reservationCounts = mealCountsResponse.reservationCounts || [];
    
    // Simple dictionary with date -> count
    const countsByDate: Record<string, number> = {};
    reservationCounts.forEach((item: any) => {
      countsByDate[item.date] = item.count;
    });
    
    return (
      <div className="border rounded-md p-4 bg-white shadow-sm">
        <div className="flex justify-between items-center mb-3">
          <button
            className="p-1 hover:bg-gray-100 rounded-md"
            onClick={() => {
              // Previous month logic here
            }}
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24">
              <path d="M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z" fill="currentColor" />
            </svg>
          </button>
          <h2 className="text-base font-medium">{monthStr}</h2>
          <button
            className="p-1 hover:bg-gray-100 rounded-md"
            onClick={() => {
              // Next month logic here
            }}
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24">
              <path d="M8.59 16.59L10 18l6-6-6-6-1.41 1.41L13.17 12z" fill="currentColor" />
            </svg>
          </button>
        </div>
        
        {/* Days of week */}
        <div className="grid grid-cols-7 text-center text-xs text-gray-500">
          <div>pon</div>
          <div>wto</div>
          <div>śro</div>
          <div>czw</div>
          <div>pią</div>
          <div>sob</div>
          <div>nie</div>
        </div>
        
        {/* Calendar days */}
        <div className="grid grid-cols-7 gap-1 mt-1">
          {/* This is simplified to match the screenshot exactly */}
          {/* First week */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <button className="flex items-center justify-center rounded-full w-7 h-7 text-sm bg-blue-50">
            1<span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center rounded-full bg-blue-100 text-[8px] text-blue-700">3</span>
          </button>
          <button className="flex items-center justify-center rounded-full w-7 h-7 text-sm bg-blue-50">
            2<span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center rounded-full bg-blue-100 text-[8px] text-blue-700">3</span>
          </button>
          <button className="flex items-center justify-center rounded-full w-7 h-7 text-sm bg-blue-50">
            3<span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center rounded-full bg-blue-100 text-[8px] text-blue-700">1</span>
          </button>
          
          {/* Second week */}
          <button className="flex items-center justify-center rounded-full w-7 h-7 text-sm bg-blue-50">
            4<span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center rounded-full bg-blue-100 text-[8px] text-blue-700">1</span>
          </button>
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          
          {/* Third week */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <button className="flex items-center justify-center rounded-full w-7 h-7 text-sm bg-blue-50">
            11<span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center rounded-full bg-blue-100 text-[8px] text-blue-700">1</span>
          </button>
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          
          {/* Fourth week */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <button className="flex items-center justify-center rounded-full w-7 h-7 text-sm bg-blue-50">
            18<span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center rounded-full bg-blue-100 text-[8px] text-blue-700">1</span>
          </button>
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          <div className="w-7 h-7"></div>  {/* Empty cell */}
          
          {/* Other weeks would follow... */}
        </div>
      </div>
    );
  };
  
  // Employee card component
  const EmployeeRow = ({ 
    employee, 
    isWorking = false 
  }: { 
    employee: Employee; 
    isWorking: boolean;
  }) => {
    const reservation = employeeReservations[employee.id];
    const hasReservation = !!reservation;
    const chamberNumber = chambersMap[employee.id];
    const productName = reservation ? getProductName(reservation.productId) : '';
    const assignmentType = reservation ? reservation.assignmentType : null;
    const assignmentInfo = getAssignmentTypeInfo(assignmentType);
    
    return (
      <Card className="mb-2 overflow-hidden">
        <CardContent className="p-0">
          <div className="flex flex-col md:flex-row">
            {/* Employee section */}
            <div className="p-4 flex items-center space-x-3">
              <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="font-medium">{employee.firstName} {employee.lastName}</h3>
                <div className="flex items-center text-sm text-muted-foreground">
                  <CalendarCheck className="h-3 w-3 mr-1" />
                  {isWorking ? 'Pracuje' : 'Nie pracuje'}
                </div>
              </div>
            </div>
            
            {/* Reservation section - only shown for working employees */}
            <div className="ml-auto flex items-center">
              {isWorking ? (
                hasReservation ? (
                  <div className="p-4 bg-blue-50/80 flex flex-col items-end">
                    <div className="flex items-center text-sm font-medium text-green-600">
                      <Utensils className="h-3.5 w-3.5 mr-1" />
                      {productName}
                    </div>
                    
                    <div className="flex items-center text-xs text-muted-foreground mt-1">
                      {assignmentInfo.icon}
                      {assignmentInfo.label}
                    </div>
                    
                    {chamberNumber && (
                      <div className="flex items-center text-xs text-purple-600 mt-1">
                        <Box className="h-3 w-3 mr-1" />
                        Szuflada #{chamberNumber}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-4 bg-gray-50 flex items-center">
                    <span className="text-sm text-muted-foreground italic">
                      Brak zamówienia
                    </span>
                  </div>
                )
              ) : (
                <div className="p-4 bg-gray-50 flex items-center">
                  <span className="text-sm text-muted-foreground italic">
                    Nie pracuje w tym dniu
                  </span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };
  
  // Filter and sort employees
  const sortedEmployees = [...employees].sort((a, b) => {
    if (!a || !b) return 0;
    
    const aIsWorking = employeeWorkStatus[a.id] || false;
    const bIsWorking = employeeWorkStatus[b.id] || false;
    
    // First sort by working status
    if (aIsWorking && !bIsWorking) return -1;
    if (!aIsWorking && bIsWorking) return 1;
    
    // Then sort by reservation status (working employees with reservations first)
    if (aIsWorking && bIsWorking) {
      const aHasReservation = !!employeeReservations[a.id];
      const bHasReservation = !!employeeReservations[b.id];
      
      if (aHasReservation && !bHasReservation) return -1;
      if (!aHasReservation && bHasReservation) return 1;
    }
    
    // Finally sort by last name
    return `${a.lastName} ${a.firstName}`.localeCompare(`${b.lastName} ${b.firstName}`);
  });
  
  return (
    <div className="space-y-6">
      {/* Header with date selection */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Rezerwacje posiłków</h2>
          <p className="text-muted-foreground">
            Wyświetlanie rezerwacji posiłków dla pracowników
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => refetchReservations()}
          >
            <RefreshCw className="h-3.5 w-3.5 mr-1.5" />
            Odśwież
          </Button>
          
          <div className="relative">
            <Button
              variant="outline"
              onClick={() => setShowCalendar(!showCalendar)}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {format(selectedDate, 'd MMMM yyyy', { locale: pl })}
            </Button>
            
            {showCalendar && (
              <div className="absolute z-10 mt-1 right-0">
                <CalendarView />
              </div>
            )}
          </div>
        </div>
      </div>
      
      <Separator />
      
      {/* Employee list */}
      {isLoadingReservations || isLoadingChambers ? (
        <div className="flex justify-center p-8">
          <div className="flex flex-col items-center">
            <RefreshCw className="h-8 w-8 text-muted-foreground animate-spin" />
            <p className="mt-2">Ładowanie danych...</p>
          </div>
        </div>
      ) : (
        <ScrollArea className="h-[calc(100vh-250px)] pr-4">
          <div className="space-y-1">
            {sortedEmployees.map((employee) => {
              if (!employee) return null;
              return (
                <EmployeeRow
                  key={employee.id}
                  employee={employee}
                  isWorking={employeeWorkStatus[employee.id] || false}
                />
              );
            })}
          </div>
        </ScrollArea>
      )}
    </div>
  );
};