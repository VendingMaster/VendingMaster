import React from 'react';
import UsageButton from './UsageButton';

interface ActionButtonsProps {
  item: any;
  onUse: (item: any) => void;
  onDispose: (item: any) => void;
  showDispose?: boolean;
}

/**
 * Komponent przycisków akcji dla magazynu
 */
const ActionButtons: React.FC<ActionButtonsProps> = ({ 
  item, 
  onUse, 
  onDispose, 
  showDispose = true 
}) => {
  return (
    <div className="flex space-x-2">
      <UsageButton 
        type="usage" 
        onClick={() => onUse(item)} 
      />
      {showDispose && (
        <UsageButton 
          type="dispose" 
          onClick={() => onDispose(item)} 
        />
      )}
    </div>
  );
};

export default ActionButtons;