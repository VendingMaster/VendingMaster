import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import { Employee } from "@shared/schema";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  UtensilsCrossed, 
  Calendar, 
  Clock, 
  AlertCircle, 
  XCircle
} from "lucide-react";
import { format } from "date-fns";
import { pl } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
// Usunięto niepotrzebne importy

interface OrdersProps {
  employee: Employee;
}

interface MealRecord {
  id: number;
  chamberId: number | null;
  productId: number;
  productName: string;
  productImage?: string;
  shortDescription?: string;
  weight?: number;
  calories?: number;
  reservedForDate: string;
  status: "active" | "fulfilled" | "cancelled";
  reservedAt: string;
}

export const Orders: React.FC<OrdersProps> = ({ employee }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMeal, setSelectedMeal] = useState<MealRecord | null>(null);
  // Już nie potrzebujemy funkcji edycji
  
  // Funkcja pomocnicza do przewijania strony do góry - bardziej zdecydowane podejście
  const scrollToTop = () => {
    // Natychmiastowe przewinięcie
    document.documentElement.scrollTop = 0; // Dla Firefox
    document.body.scrollTop = 0; // Dla Safari
    window.scrollTo(0, 0); // Dla innych przeglądarek
    
    // Dodatkowe przewinięcie po małym opóźnieniu dla większej pewności
    setTimeout(() => {
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      window.scrollTo({
        top: 0,
        behavior: 'auto' // Natychmiastowe przewinięcie
      });
      
      // Jeszcze jedno przewinięcie dla pewności
      setTimeout(() => {
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        window.scrollTo(0, 0);
      }, 50);
    }, 10);
  };
  
  // Przewiń stronę do góry przy inicjalizacji komponentu
  useEffect(() => {
    scrollToTop();
  }, []);
  
  // Pobieranie ustawień portalu pracownika (w tym informacji o pierwszym możliwym dniu rezerwacji)
  const { data: settingsData } = useQuery<{ success: boolean, settings: { id: number, firstReservationDay: number } }>({
    queryKey: ['/api/settings'],
    queryFn: async () => {
      const response = await fetch('/api/settings');
      if (!response.ok) {
        throw new Error('Problem z pobieraniem ustawień');
      }
      return response.json();
    }
  });

  // Pobierz rezerwacje posiłków pracownika
  const { data, isLoading, error } = useQuery<{success: boolean, reservations: MealRecord[]}>({
    queryKey: ['/api/meal-reservations', employee.id],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/meal-reservations?employeeId=${employee.id}`);
        if (!response.ok) {
          throw new Error('Problem z pobieraniem rezerwacji');
        }
        const result = await response.json();
        return result;
      } catch (err) {
        console.error("Error fetching reservations:", err);
        throw err;
      }
    },
    staleTime: 1000 * 60 * 5 // 5 minut
  });

  // Mutacja do anulowania rezerwacji
  const cancelReservationMutation = useMutation({
    mutationFn: async (reservationId: number) => {
      return apiRequest(`/api/meal-reservations/${reservationId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations', employee.id] });
      toast({
        title: "Rezerwacja anulowana",
        description: "Rezerwacja została pomyślnie anulowana.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error?.message || "Nie udało się anulować rezerwacji. Spróbuj ponownie później.",
        variant: "destructive",
      });
      console.error("Error cancelling reservation:", error);
    }
  });

  // Obsługa anulowania rezerwacji
  const handleCancelReservation = (reservationId: number) => {
    if (confirm('Czy na pewno chcesz anulować tę rezerwację?')) {
      cancelReservationMutation.mutate(reservationId);
    }
  };

  // Usunięto funkcje związane z edycją zamówień

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <p>Ładowanie zamówień...</p>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>
          Wystąpił problem z pobieraniem zamówień. Spróbuj ponownie później.
        </AlertDescription>
      </Alert>
    );
  }

  const reservations = data?.reservations || [];

  // Grupowanie posiłków według daty rezerwacji
  const groupedReservations: Record<string, MealRecord[]> = {};
  
  reservations.forEach(reservation => {
    if (!groupedReservations[reservation.reservedForDate]) {
      groupedReservations[reservation.reservedForDate] = [];
    }
    groupedReservations[reservation.reservedForDate].push(reservation);
  });

  // Sortowanie dat od najnowszej do najstarszej
  const sortedDates = Object.keys(groupedReservations).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  
  // Filtruj tylko nadchodzące zamówienia z aktywnym statusem
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const upcomingDates = sortedDates.filter(date => {
    const dateObj = new Date(date);
    dateObj.setHours(0, 0, 0, 0);
    
    // Filtruj tylko przyszłe lub dzisiejsze daty z aktywnymi rezerwacjami
    return dateObj >= today && groupedReservations[date].some(reservation => 
      reservation.status === 'active'
    );
  });

  if (upcomingDates.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="bg-muted w-16 h-16 rounded-full flex items-center justify-center mb-4">
          <UtensilsCrossed className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium mb-2">Brak nadchodzących zamówień</h3>
        <p className="text-muted-foreground max-w-md">
          Nie masz jeszcze żadnych nadchodzących zamówień. Zarezerwuj posiłek z zakładki "Wybór posiłków".
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 mx-2.5">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold">Nadchodzące zamówienia</h2>
        <p className="text-muted-foreground">
          Lista Twoich nadchodzących zamówień. Pamiętaj, że możliwość edycji zależy od ustawień portalu i terminu dostawy posiłku.
        </p>
      </div>

      {upcomingDates.map(date => (
        <div key={date} className="space-y-4">
          <div className="p-2 mb-2 text-black font-medium">{formatDate(date)}</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {groupedReservations[date]
              .filter(reservation => reservation.status === 'active')
              .map(reservation => (
                <Card key={reservation.id} className="border border-gray-200">
                  <CardHeader className="p-0">
                    {reservation.productImage && (
                      <div className="relative w-full h-[200px] px-2.5 pt-2.5">
                        <Dialog>
                          <DialogTrigger asChild>
                            <img 
                              src={reservation.productImage} 
                              alt={reservation.productName} 
                              className="object-cover w-full h-full rounded-md cursor-pointer hover:opacity-90 transition-opacity"
                            />
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-xl p-0">
                            <img 
                              src={reservation.productImage} 
                              alt={reservation.productName}
                              className="w-full h-auto"
                            />
                          </DialogContent>
                        </Dialog>
                      </div>
                    )}
                  </CardHeader>
                  <CardContent className="p-2">
                    <div className="flex justify-between items-start">
                      <h3 className="font-semibold truncate flex-1">{reservation.productName}</h3>
                      <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700 border-blue-300">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Aktywna
                      </Badge>
                    </div>
                    
                    <div className="flex items-center mt-1 text-sm text-muted-foreground">
                      <Calendar className="w-3 h-3 mr-1" />
                      Na dzień: {format(new Date(reservation.reservedForDate), "dd MMMM yyyy", { locale: pl })}
                    </div>
                    
                    <div className="text-xs text-muted-foreground mt-1 flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      Zarezerwowano: {formatDateTime(reservation.reservedAt)}
                    </div>
                  </CardContent>
                  <CardFooter className="p-2 pt-0">
                    <Button 
                      variant="destructive" 
                      size="sm"
                      className="w-full"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCancelReservation(reservation.id);
                      }}
                      disabled={cancelReservationMutation.isPending}
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Anuluj zamówienie
                    </Button>
                  </CardFooter>
                </Card>
            ))}
          </div>
        </div>
      ))}

      {/* Dialog ze szczegółami posiłku */}
      <Dialog open={!!selectedMeal} onOpenChange={(open) => !open && setSelectedMeal(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Szczegóły zamówienia</DialogTitle>
            <DialogDescription>
              Informacje o zarezerwowanym posiłku
            </DialogDescription>
          </DialogHeader>
          
          {selectedMeal && (
            <div className="space-y-4">
              <div className="w-full overflow-hidden rounded-md mb-4" style={{ maxHeight: '200px' }}>
                {selectedMeal.productImage ? (
                  <img 
                    src={selectedMeal.productImage} 
                    alt={selectedMeal.productName} 
                    className="object-cover w-full h-auto"
                    style={{ maxHeight: '200px' }}
                  />
                ) : (
                  <div className="w-full h-48 flex items-center justify-center bg-muted">
                    <UtensilsCrossed className="h-12 w-12 text-muted-foreground" />
                  </div>
                )}
              </div>
              
              <div>
                <h3 className="text-lg font-semibold">{selectedMeal.productName}</h3>
                
                {selectedMeal.shortDescription && (
                  <p className="text-sm text-muted-foreground mt-2">{selectedMeal.shortDescription}</p>
                )}
                
                <div className="mt-4 grid grid-cols-2 gap-2">
                  {selectedMeal.weight && (
                    <div className="bg-blue-50 rounded p-2 text-center">
                      <div className="text-xs text-muted-foreground">Waga</div>
                      <div className="font-semibold">{selectedMeal.weight} g</div>
                    </div>
                  )}
                  
                  {selectedMeal.calories && (
                    <div className="bg-orange-50 rounded p-2 text-center">
                      <div className="text-xs text-muted-foreground">Kalorie</div>
                      <div className="font-semibold">{selectedMeal.calories} kcal</div>
                    </div>
                  )}
                </div>
                
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">Status:</span>
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
                      Aktywna
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">Data posiłku:</span>
                    <span>{format(new Date(selectedMeal.reservedForDate), "dd MMMM yyyy", { locale: pl })}</span>
                  </div>
                  
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">Data rezerwacji:</span>
                    <span>{formatDateTime(selectedMeal.reservedAt)}</span>
                  </div>
                  
                  {selectedMeal.chamberId && (
                    <div className="flex justify-between text-sm border-b border-muted py-2">
                      <span className="font-medium">Numer szuflady:</span>
                      <span>{selectedMeal.chamberId}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">ID rezerwacji:</span>
                    <span>#{selectedMeal.id}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex justify-between">
            <DialogClose asChild>
              <Button variant="outline">
                Zamknij
              </Button>
            </DialogClose>
            
            {selectedMeal && (
              <Button 
                variant="destructive"
                onClick={() => {
                  if (selectedMeal) {
                    handleCancelReservation(selectedMeal.id);
                    setSelectedMeal(null);
                  }
                }}
                disabled={cancelReservationMutation.isPending}
              >
                {cancelReservationMutation.isPending ? 'Anulowanie...' : 'Anuluj zamówienie'}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Funkcja pomocnicza do formatowania daty
function formatDate(dateString: string): string {
  const date = new Date(dateString);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  if (date.getTime() === today.getTime()) {
    return "Dzisiaj";
  } else if (date.getTime() === tomorrow.getTime()) {
    return "Jutro";
  } else if (date.getTime() === yesterday.getTime()) {
    return "Wczoraj";
  } else {
    return date.toLocaleDateString('pl-PL', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    });
  }
}

// Formatowanie daty i czasu
function formatDateTime(dateString: string): string {
  const date = new Date(dateString);
  return format(date, "dd.MM.yyyy HH:mm", { locale: pl });
}