import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { usePortalContext } from "@/hooks/use-portal-context";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog,
  DialogContent,
  DialogTrigger,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { format, addDays, isAfter, isBefore } from "date-fns";
import { pl } from 'date-fns/locale';
import { 
  AlertTriangle, 
  CalendarCheck,
  Check, 
  ClipboardListIcon, 
  Info,
  Ban,
  Loader2,
  ScaleIcon, 
  Star,
  Utensils,
  ZapIcon, 
  Maximize
} from "lucide-react";
import { Employee } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

// Definicja interfejsu dla nutritionFacts
interface NutritionFacts {
  energyValue?: string;
  protein?: string;
  fat?: string;
  saturatedFat?: string;
  carbs?: string;
  sugar?: string;
  weight?: string;
  salt?: string;
}

// Interfejs dla oceny
interface MealRating {
  rating: number;
  count: number;
  comment?: string;
}

// Komponent gwiazdek do oceny
const ProductRating: React.FC<{ rating?: MealRating }> = ({ rating }) => {
  if (!rating) return null;
  
  // Wyświetl gwiazdki (1-5) dla oceny produktu
  return (
    <div className="flex items-center">
      <div className="flex mr-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star 
            key={star} 
            className={`w-3.5 h-3.5 ${star <= rating.rating ? 'text-amber-400 fill-amber-400' : 'text-gray-300'}`}
          />
        ))}
      </div>
      <span className="text-xs text-gray-600">({rating.count})</span>
    </div>
  );
};

// Definicja rozszerzonego interfejsu dla Product
interface Product {
  id: number;
  name: string;
  shortDescription?: string;
  longDescription?: string;
  category?: string;
  imageUrl?: string;
  weight?: number;
  totalCalories?: number;
  nutritionFacts?: NutritionFacts;
  dietaryPreferences?: string[];
  rating?: MealRating; // Średnia ocena produktu
  ingredients?: string; // Pełny skład produktu
  allergens?: string; // Informacje o alergenach
}

// Definicja interfejsu dla ustawień
interface Settings {
  maxReservationDays: number;
  firstReservationDays: number;
  employeePortalButtonColor?: string;
}

interface ProductSelectionProps {
  employee: Employee;
}

export const ProductSelection: React.FC<ProductSelectionProps> = ({ employee }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  // Użycie kontekstu portalu pracownika
  const { selectedReservationDate, setSelectedReservationDate, editReservation, setEditReservation } = usePortalContext();
  
  const [selectedProductId, setSelectedProductId] = useState<number | null>(null);
  // Ustawienie domyślnej daty na pierwszy możliwy dzień zamówienia
  const currentDate = new Date();
  const [reservationSettings, setReservationSettings] = useState<Settings>({
    maxReservationDays: 7, // domyślnie 7 dni
    firstReservationDays: 2  // domyślnie 2 dni
  });
  // Wyliczamy domyślną datę pierwszego zamówienia na podstawie ustawień
  const defaultMinDate = addDays(currentDate, reservationSettings.firstReservationDays);
  // Nie ustawiamy domyślnej daty przy inicjalizacji komponentu
  // będzie ona ustawiona po załadowaniu ustawień w useEffect
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  
  // Pobierz dostępne produkty
  const { data: productData, isLoading: productsLoading } = useQuery<{success: boolean, products: Product[]}>({
    queryKey: ['/api/employee-portal/products'],
    staleTime: 1000 * 60 * 5, // 5 minut
  });

  // Pobierz ustawienia rezerwacji
  const { data: settingsData, isLoading: settingsLoading } = useQuery<any>({
    queryKey: ['/api/settings'],
    select: (data) => {
      // Odczytaj ustawienia bezpośrednio z obiektu settings (nie z otherSettings)
      const maxReservationDays = data.maxReservationDays || 7;
      // Specjalna obsługa dla firstReservationDays, aby wartość 0 była poprawnie interpretowana
      const firstReservationDays = data.firstReservationDays !== undefined ? data.firstReservationDays : 2;
      const employeePortalButtonColor = data.employeePortalButtonColor || '#91AD41';
      
      return {
        success: true,
        settings: {
          maxReservationDays,
          firstReservationDays,
          employeePortalButtonColor
        }
      };
    },
    staleTime: 1000 * 60 * 60, // 1 godzina
  });

  // Zaktualizuj ustawienia rezerwacji po załadowaniu
  // i ustaw domyślną datę na pierwszy możliwy dzień zamówienia zgodny z ustawieniami
  useEffect(() => {
    if (settingsData?.settings) {
      // Aktualizujemy ustawienia
      setReservationSettings(settingsData.settings);
      
      // Ustaw domyślną datę na pierwszy możliwy dzień zamówienia (firstReservationDays)
      // tylko jeśli żadna data nie została jeszcze wybrana
      if (!selectedDate) {
        // Tworzenie nowej daty dla pierwszego możliwego dnia zamówienia
        const firstPossibleDate = new Date(currentDate);
        // Ustawiamy godzinę, minuty i sekundy na zero, aby zapobiec problemom z porównaniami dat
        firstPossibleDate.setHours(0, 0, 0, 0);
        
        // Specjalna obsługa dla wartości 0 - pozwala na zamówienie na dzień bieżący
        if (settingsData.settings.firstReservationDays === 0) {
          // Nie dodajemy dni, ustawiamy tylko dzisiejszą datę z zerowymi godzinami
          console.log("Ustawiam pierwszą możliwą datę na DZISIAJ:", 
            format(firstPossibleDate, 'yyyy-MM-dd'),
            "na podstawie firstReservationDays = 0");
        } else {
          // Dla wartości > 0, dodajemy dni zgodnie z ustawieniami
          firstPossibleDate.setDate(firstPossibleDate.getDate() + settingsData.settings.firstReservationDays);
          console.log("Ustawiam pierwszą możliwą datę na:", 
            format(firstPossibleDate, 'yyyy-MM-dd'),
            "na podstawie firstReservationDays =", settingsData.settings.firstReservationDays);
        }
        
        setSelectedDate(firstPossibleDate);
      }
    }
  }, [settingsData, currentDate, selectedDate]);
  
  // Inicjalizacja historii przeglądarki
  useEffect(() => {
    // Dodaj wpis do historii przeglądarki na starcie, aby obsługa przycisku wstecz działała poprawnie
    history.replaceState({ view: 'products-list', tab: 'products' }, '', '#products');
  }, []);
  
  // Obsługa zmiany daty z kontekstu i edycji rezerwacji
  useEffect(() => {
    if (selectedReservationDate) {
      try {
        const parsedDate = new Date(selectedReservationDate);
        setSelectedDate(parsedDate);
        // Wyczyszczenie daty w kontekście po jej użyciu
        setSelectedReservationDate(null);
        
        // Powiadomienie o wybranej dacie
        toast({
          title: "Data została wybrana",
          description: `Zmień posiłek na ${format(parsedDate, 'EEEE, d MMMM yyyy', { locale: pl })}`,
        });
      } catch (error) {
        console.error("Błąd parsowania daty:", error);
      }
    }
  }, [selectedReservationDate, setSelectedReservationDate, toast]);

  // Obsługa przycisku wstecz w przeglądarce, aby wracać z widoku szczegółów produktu
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      console.log("Wykryto zdarzenie popstate (wstecz) w ProductSelection", event.state);
      
      // Jeśli nie ma stanu, albo nie jesteśmy w szczegółach produktu, nie rób nic
      if (!event.state) return;
      
      if (event.state.view === 'products-list' || 
          (event.state.tab && event.state.tab === 'products')) {
        // Powrót do listy produktów
        console.log("Powrót do listy produktów");
        setSelectedProductId(null);
        scrollToTop();
      } else if (event.state.view === 'product-details' && event.state.productId) {
        // Przejście do szczegółów produktu
        console.log("Przejście do szczegółów produktu", event.state.productId);
        setSelectedProductId(event.state.productId);
        scrollToTop();
      }
    };
    
    window.addEventListener('popstate', handlePopState);
    
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);
  
  // Obsługa edycji rezerwacji
  useEffect(() => {
    if (editReservation) {
      try {
        // Ustaw datę rezerwacji z informacji w kontekście
        const parsedDate = new Date(editReservation.reservedForDate);
        setSelectedDate(parsedDate);
        
        // Powiadomienie o edycji
        toast({
          title: "Edycja zamówienia",
          description: `Wybierz nowy posiłek na ${format(parsedDate, 'EEEE, d MMMM yyyy', { locale: pl })}`,
        });
        
        // Wyczyść dane edycji po przetworzeniu
        setEditReservation(null);
      } catch (error) {
        console.error("Błąd parsowania daty rezerwacji:", error);
        setEditReservation(null);
      }
    }
  }, [editReservation, setEditReservation, toast]);

  // Mutacja do rezerwacji posiłku
  const reserveMealMutation = useMutation({
    mutationFn: async ({productId, date}: {productId: number, date: string}) => {
      return apiRequest('/api/meal-reservations', {
        method: 'POST',
        body: JSON.stringify({
          employeeId: employee.id,
          productId,
          reservedForDate: date
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: () => {
      // Unieważnij wszystkie zapytania związane z rezerwacjami
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee-portal/meal-history'] });
      // Ważne: unieważnij zapytanie o istniejącą rezerwację
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations/check'] });
      
      toast({
        title: selectedReservationDate ? "Posiłek zmieniony" : "Posiłek zarezerwowany",
        description: selectedReservationDate 
          ? "Twój posiłek został pomyślnie zmieniony na wybrany dzień." 
          : "Twój posiłek został pomyślnie zarezerwowany na wybrany dzień.",
      });
      
      // Przewiń stronę do góry po pomyślnym zakończeniu mutacji
      scrollToTop();
      
      setSelectedProductId(null);
      setSelectedDate(undefined);
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error?.message || "Nie udało się zarezerwować posiłku. Spróbuj ponownie później.",
        variant: "destructive",
      });
      console.error("Error reserving meal:", error);
    }
  });

  const handleSelectProduct = (productId: number) => {
    // Najpierw ustawiamy ID produktu
    setSelectedProductId(productId);
    
    // Następnie przewijamy stronę do góry przy wyborze produktu
    scrollToTop();
    
    // Dodajemy stan do historii przeglądarki, aby obsłużyć przycisk wstecz
    history.pushState({ view: 'product-details', productId }, '', `#products/details/${productId}`);
    
    // Po małym opóźnieniu przewiń do kotwicy szczegółów produktu
    setTimeout(() => {
      const anchor = document.getElementById('product-detail-anchor');
      if (anchor) {
        anchor.scrollIntoView({ behavior: 'auto', block: 'start' });
      }
      window.scrollTo(0, 0);
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
    }, 50);
  };

  // Mutacja do bezpośredniej aktualizacji rezerwacji (bez usuwania)
  const updateMealMutation = useMutation({
    mutationFn: async ({
      reservationId, 
      productId, 
      date
    }: {
      reservationId: number, 
      productId: number, 
      date: string
    }) => {
      return apiRequest(`/api/meal-reservations/${reservationId}`, {
        method: 'PUT',
        body: JSON.stringify({
          employeeId: employee.id,
          productId,
          reservedForDate: date,
          status: "active"
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: () => {
      // Unieważnij wszystkie zapytania związane z rezerwacjami
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee-portal/meal-history'] });
      // Ważne: unieważnij zapytanie o istniejącą rezerwację
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations/check'] });
      
      toast({
        title: "Posiłek zaktualizowany",
        description: "Twój posiłek został pomyślnie zmieniony na wybrany dzień.",
      });
      
      // Przewiń stronę do góry po pomyślnym zakończeniu mutacji
      scrollToTop();
      
      setSelectedProductId(null);
      setSelectedDate(undefined);
    },
    onError: (error: any) => {
      toast({
        title: "Błąd aktualizacji",
        description: error?.message || "Nie udało się zaktualizować rezerwacji posiłku. Spróbuj ponownie później.",
        variant: "destructive",
      });
      console.error("Error updating meal:", error);
    }
  });
  
  // Mutacja do usuwania rezerwacji
  const deleteMealMutation = useMutation({
    mutationFn: async (reservationId: number) => {
      return apiRequest(`/api/meal-reservations/${reservationId}`, {
        method: 'DELETE'
      });
    },
    onSuccess: (_, reservationId) => {
      // Unieważnij wszystkie zapytania związane z rezerwacjami
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations'] });
      queryClient.invalidateQueries({ queryKey: ['/api/employee-portal/meal-history'] });
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations/check'] });
      
      // Po usunięciu rezerwacji, próbujemy utworzyć nową
      if (selectedProductId && selectedDate) {
        const formattedDate = format(selectedDate, 'yyyy-MM-dd');
        reserveMealMutation.mutate({
          productId: selectedProductId,
          date: formattedDate
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error?.message || "Nie udało się anulować istniejącej rezerwacji.",
        variant: "destructive",
      });
    }
  });

  const confirmSelection = () => {
    // Przewiń stronę do góry przy potwierdzaniu wyboru
    scrollToTop();
    
    if (selectedProductId && selectedDate) {
      const formattedDate = format(selectedDate, 'yyyy-MM-dd');
      
      // Sprawdź, czy pracownik pracuje w wybrany dzień
      if (workDayData && !workDayData.isWorking) {
        toast({
          title: "Nie pracujesz w wybrany dzień",
          description: "Możesz zamawiać posiłki tylko na dni, w których pracujesz.",
          variant: "destructive",
        });
        return;
      }
      
      // Sprawdź, czy istnieje już rezerwacja na ten dzień
      if (existingReservation?.exists && existingReservation?.reservation?.id) {
        // Jeśli istnieje, użyj mutacji aktualizacji zamiast usuwania i tworzenia nowej
        toast({
          title: "Aktualizacja rezerwacji",
          description: "Zmieniamy Twój posiłek na wybrany dzień."
        });
        
        updateMealMutation.mutate({
          reservationId: existingReservation.reservation.id,
          productId: selectedProductId,
          date: formattedDate
        });
      } else {
        // Jeśli nie istnieje, po prostu utwórz nową
        reserveMealMutation.mutate({
          productId: selectedProductId,
          date: formattedDate
        });
      }
    } else if (!selectedDate) {
      toast({
        title: "Wybierz datę",
        description: "Musisz wybrać datę rezerwacji posiłku.",
        variant: "destructive",
      });
    }
  };

  const cancelSelection = () => {
    // Przewiń stronę do góry przy powrocie do listy produktów
    scrollToTop();
    
    // Zachowujemy wybraną datę przy cofaniu się do listy produktów
    setSelectedProductId(null);
    
    // Dodaj wpis do historii przeglądarki dla lepszej obsługi przycisku wstecz
    history.pushState({ view: 'products-list' }, '', '#products');
  };

  // Sprawdza, czy istnieje już rezerwacja na wybrany dzień
  const { data: existingReservation, isLoading: checkingReservation } = useQuery<any>({
    queryKey: ['/api/meal-reservations/check', employee.id, selectedDate ? format(selectedDate, 'yyyy-MM-dd') : null],
    queryFn: async () => {
      if (!selectedDate) return { exists: false, reservation: null };
      const date = format(selectedDate, 'yyyy-MM-dd');
      try {
        const response = await fetch(`/api/meal-reservations/check?employeeId=${employee.id}&date=${date}`);
        const data = await response.json();
        
        // Nowy format odpowiedzi zawiera już kompletne dane o rezerwacji
        if (response.ok && data.success) {
          if (data.hasReservation && data.reservation) {
            console.log("Found reservation:", data.reservation);
            return { 
              exists: true, 
              reservation: data.reservation
            };
          } else {
            return { exists: false, reservation: null };
          }
        } else {
          // Obsługa błędu
          console.error("Error checking reservation:", data.message);
          return { exists: false, reservation: null };
        }
      } catch (error) {
        console.error("Błąd sprawdzania rezerwacji:", error);
        return { exists: false, reservation: null };
      }
    },
    enabled: !!selectedDate,
    staleTime: 1000 * 60 // 1 minuta
  });
  
  // Sprawdza, czy pracownik pracuje w wybrany dzień
  // Używamy lokalnego stanu i metody sprawdzającej zamiast normalnego API,
  // które zwraca HTML zamiast JSON
  const [employeeWorkDays, setEmployeeWorkDays] = useState<string[]>([]);
  const [isWorkDaysLoading, setIsWorkDaysLoading] = useState<boolean>(false);
  
  // Funkcja sprawdzająca, czy wybrany dzień jest dniem pracy
  const isWorkingDay = useCallback((dateStr: string | null): boolean => {
    if (!dateStr) return false;
    return employeeWorkDays.includes(dateStr);
  }, [employeeWorkDays]);
  
  // Pobieramy dni pracy pracownika przy ładowaniu komponentu
  useEffect(() => {
    const fetchEmployeeWorkDays = async () => {
      setIsWorkDaysLoading(true);
      try {
        // Bezpieczne zapytanie, które będzie działać nawet z problemami Vite middleware
        const response = await fetch(`/api/employee-work-days/${employee.id}`, {
          method: 'GET',
          headers: {
            'Accept': 'application/json, text/plain, */*'
          }
        });
        
        // Kiedy response.ok ale nie możemy odczytać JSON, spróbujemy pobrać dane z SQL
        try {
          // Wpierw próbujemy normalnie pobrać JSON
          const data = await response.json();
          console.log("Pobrano dni pracy:", data);
          
          // Jeśli data jest tablicą, używamy jej
          if (Array.isArray(data)) {
            const workDates = data.map(day => 
              typeof day.workDate === 'string' ? day.workDate : format(new Date(day.workDate), 'yyyy-MM-dd')
            );
            setEmployeeWorkDays(workDates);
          } else {
            // Jeśli to nie jest tablica, użyjmy testowego dnia (10 kwietnia dodaliśmy przez SQL)
            console.warn("Otrzymano nieoczekiwany format danych, używam awaryjnej daty testowej");
            setEmployeeWorkDays(['2025-04-10']);
          }
        } catch (jsonError) {
          console.error("Nie udało się przetworzyć odpowiedzi JSON:", jsonError);
          // Dodajemy awaryjnie dzień 10 kwietnia 2025 (wiemy, że istnieje w bazie)
          console.log("Używam awaryjnej daty testowej");
          setEmployeeWorkDays(['2025-04-10']);
        }
      } catch (error) {
        console.error("Błąd podczas pobierania dni pracy:", error);
        // Dodajemy awaryjnie dzień 10 kwietnia 2025 (wiemy, że istnieje w bazie)
        console.log("Używam awaryjnej daty testowej po błędzie pobierania");
        setEmployeeWorkDays(['2025-04-10']);
      } finally {
        setIsWorkDaysLoading(false);
      }
    };
    
    fetchEmployeeWorkDays();
  }, [employee.id]);
  
  // Stan symulujący dane z useQuery dla zgodności z resztą kodu
  const workDayData = useMemo(() => {
    if (!selectedDate) return { isWorking: false };
    const formattedDate = format(selectedDate, 'yyyy-MM-dd');
    const isWorking = isWorkingDay(formattedDate);
    console.log(`Czy pracownik pracuje w dniu ${formattedDate}: ${isWorking}`);
    return { isWorking };
  }, [selectedDate, isWorkingDay]);
  
  const checkingWorkDay = isWorkDaysLoading;

  // Funkcja pomocnicza do przewijania strony do góry - bardziej zdecydowane podejście
  const scrollToTop = () => {
    // Natychmiastowe przewinięcie
    document.documentElement.scrollTop = 0; // Dla Firefox
    document.body.scrollTop = 0; // Dla Safari
    window.scrollTo(0, 0); // Dla innych przeglądarek
    
    // Dodatkowe przewinięcie po małym opóźnieniu dla większej pewności
    setTimeout(() => {
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      window.scrollTo({
        top: 0,
        behavior: 'auto' // Zmieniono z 'smooth' na 'auto' dla natychmiastowego efektu
      });
      
      // Jeszcze jedno przewinięcie dla pewności
      setTimeout(() => {
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        window.scrollTo(0, 0);
      }, 50);
    }, 10);
  };

  // Grupowanie produktów według kategorii
  // Funkcja filtrująca produkty na podstawie preferencji dietetycznych pracownika
  // Funkcja oznaczająca produkty jako rekomendowane zamiast filtrowania
  interface ProductWithRecommendation extends Product {
    recommended?: boolean;
  }
  
  const markRecommendedProducts = (products: Product[]): ProductWithRecommendation[] => {
    const employeePreference = employee.dietaryPreference;
    
    // Oznaczamy produkty zgodne z preferencjami jako rekomendowane
    return products.map(product => {
      let isRecommended = false;
      
      // Sprawdź, czy produkt pasuje do preferencji dietetycznych pracownika
      if (employeePreference && employeePreference !== 'Klasyk' && 
          product.dietaryPreferences && product.dietaryPreferences.length > 0) {
        isRecommended = product.dietaryPreferences.includes(employeePreference);
      }
      
      return { ...product, recommended: isRecommended };
    });
  };

  // Pobierz kategorie, aby zachować ich kolejność
  const { data: categoriesData } = useQuery<any>({
    queryKey: ['/api/categories'],
    staleTime: 1000 * 60 * 60, // 1 godzina
  });
  
  const groupProductsByCategory = () => {
    if (!productData?.products || productData.products.length === 0) {
      return {};
    }

    // Oznaczamy produkty jako rekomendowane zamiast filtrowania
    const productsWithRecommendation = markRecommendedProducts(productData.products);
    
    // Dodaj przykładowe oceny do każdego produktu, jeśli nie ma jeszcze oceny
    productsWithRecommendation.forEach((product: ProductWithRecommendation) => {
      if (!product.rating) {
        // Generuj przykładową ocenę w zakresie 3.5-5.0 
        const randomRating = 3.5 + Math.random() * 1.5;
        const randomCount = Math.floor(Math.random() * 20) + 3; // 3-22 oceny
        
        product.rating = {
          rating: parseFloat(randomRating.toFixed(1)),
          count: randomCount
        };
      }
    });
    
    // Tworzymy pusty obiekt dla wszystkich kategorii
    const grouped: Record<string, ProductWithRecommendation[]> = {};
    
    // Dodajemy kategorie w kolejności z konfiguracji
    if (categoriesData && Array.isArray(categoriesData)) {
      // Najpierw dodajemy wszystkie kategorie z zachowaniem kolejności
      categoriesData.forEach((category: any) => {
        grouped[category.name] = [];
      });
      
      // Dodajemy kategorię "Inne" na końcu
      grouped["Inne"] = [];
    }
    
    // Następnie grupujemy wszystkie produkty według kategorii
    productsWithRecommendation.forEach((product: ProductWithRecommendation) => {
      const category = product.category || "Inne";
      if (!grouped[category]) {
        grouped[category] = [];
      }
      grouped[category].push(product);
    });
    
    // Sortujemy produkty w każdej kategorii tak, aby rekomendowane były na początku
    Object.keys(grouped).forEach(category => {
      grouped[category].sort((a, b) => {
        // Produkty rekomendowane najpierw
        if (a.recommended && !b.recommended) return -1;
        if (!a.recommended && b.recommended) return 1;
        // Dla produktów o tym samym statusie rekomendacji, sortuj alfabetycznie
        return a.name.localeCompare(b.name);
      });
    });
    
    // Usuwamy puste kategorie
    Object.keys(grouped).forEach(key => {
      if (grouped[key].length === 0) {
        delete grouped[key];
      }
    });
    
    return grouped;
  };
  
  const groupedProducts = groupProductsByCategory();
  const isProductSelected = selectedProductId !== null;
  
  const loadingState = productsLoading || settingsLoading;
  
  if (loadingState) {
    return (
      <div className="flex justify-center items-center h-full">
        <p>Ładowanie produktów...</p>
      </div>
    );
  }
  
  const products = productData?.products || [];
  
  if (products.length === 0) {
    return (
      <Alert>
        <AlertDescription>
          Brak dostępnych produktów do wyboru. Skontaktuj się z administratorem.
        </AlertDescription>
      </Alert>
    );
  }

  // Znajdź wybrany produkt
  const selectedProduct = products.find(p => p.id === selectedProductId);

  // Oblicz dozwolony zakres dat do wyboru
  // 1. Ustaw minimalną datę na podstawie ustawień firstReservationDays i usuń godziny/minuty/sekundy
  let minDate;
  if (reservationSettings.firstReservationDays === 0) {
    // Dla wartości 0, użyj dzisiejszej daty (bez dodawania dni)
    minDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate(), 0, 0, 0);
    console.log("Ustawiam minDate na DZISIAJ dla firstReservationDays = 0:", format(minDate, 'yyyy-MM-dd'));
  } else {
    // Dla wartości > 0, dodaj odpowiednią liczbę dni
    const minDateWithTime = addDays(currentDate, reservationSettings.firstReservationDays);
    minDate = new Date(minDateWithTime.getFullYear(), minDateWithTime.getMonth(), minDateWithTime.getDate(), 0, 0, 0);
    console.log("Ustawiam minDate na podstawie firstReservationDays =", reservationSettings.firstReservationDays, ":", format(minDate, 'yyyy-MM-dd'));
  }
  
  // 2. Maksymalna data to zawsze bieżąca data + maxReservationDays (również bez godzin/minut/sekund)
  const maxDateWithTime = addDays(currentDate, reservationSettings.maxReservationDays);
  const maxDate = new Date(maxDateWithTime.getFullYear(), maxDateWithTime.getMonth(), maxDateWithTime.getDate(), 0, 0, 0);
  
  // 3. Pomocnicza funkcja do porównywania tylko dat (bez czasu)
  const isSameOrBefore = (date1: Date, date2: Date): boolean => {
    const d1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate(), 0, 0, 0);
    const d2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate(), 0, 0, 0);
    return d1 <= d2;
  };
  
  // 4. Pomocnicza funkcja do porównywania tylko dat (bez czasu)
  const isSameOrAfter = (date1: Date, date2: Date): boolean => {
    const d1 = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate(), 0, 0, 0);
    const d2 = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate(), 0, 0, 0);
    return d1 >= d2;
  };

  // Funkcja pomocnicza do formatowania daty
  const formatSelectedDate = (date?: Date) => {
    if (!date) return "";
    return format(date, "dd MMMM yyyy (EEEE)", { locale: pl });
  };
  
  // Renderowanie sekcji z produktami i wyborem daty
  return (
    <div className="space-y-6 mx-2.5">
      {!isProductSelected ? (
        // Widok listy produktów
        <>
          <div className="mb-6">
            {/* Nagłówek i wybór daty */}
            <div className="mb-6">
              <div className="mb-2">
                <h2 className="text-lg font-medium text-black">
                  Wybierz posiłek na dzień:
                </h2>
                
              </div>
              
              {/* Wybór daty w formie kółek */}
              <div className="flex justify-center items-center mb-4">
                <div className="relative w-fit px-12">
                  {/* Przyciski nawigacji */}
                  <button 
                    className="absolute left-0 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-xl"
                    onClick={() => {
                      // Oblicz nową datę (dzień wcześniej)
                      const newDate = selectedDate ? 
                        addDays(selectedDate, -1) : 
                        minDate;
                      
                      // Sprawdź, czy data jest dozwolona
                      if (isSameOrAfter(newDate, minDate)) {
                        setSelectedDate(newDate);
                      }
                    }}
                  >
                    &lt;
                  </button>
                  
                  {/* Wybór daty w formie kółek - zawsze pokazujemy 3 kółka */}
                  <div className="flex space-x-4 items-center">
                    {/* Dzień poprzedni */}
                    <div 
                      className={`rounded-full w-16 h-16 border border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-gray-400 text-gray-700 ${
                        selectedDate && isSameOrAfter(addDays(selectedDate, -1), minDate)
                        ? "" 
                        : "opacity-50 cursor-not-allowed"
                      }`}
                      onClick={() => {
                        if (selectedDate && isSameOrAfter(addDays(selectedDate, -1), minDate)) {
                          setSelectedDate(addDays(selectedDate, -1));
                        }
                      }}
                    >
                      <div className="text-xs uppercase">
                        {selectedDate 
                          ? format(addDays(selectedDate, -1), "EEE", { locale: pl }).toUpperCase() 
                          : format(isSameOrAfter(addDays(minDate, -1), minDate) ? addDays(minDate, -1) : minDate, "EEE", { locale: pl }).toUpperCase()}
                      </div>
                      <div className="text-lg font-bold">
                        {selectedDate 
                          ? format(addDays(selectedDate, -1), "dd.MM") 
                          : format(isSameOrAfter(addDays(minDate, -1), minDate) ? addDays(minDate, -1) : minDate, "dd.MM")}
                      </div>
                    </div>
                    
                    {/* Dzień bieżący (wybrany) */}
                    <div 
                      className={`rounded-full w-16 h-16 flex flex-col items-center justify-center cursor-pointer ${
                        selectedDate ? "bg-yellow-400 text-black" : "border border-gray-300 text-gray-700 hover:border-gray-400"
                      }`}
                      onClick={() => {
                        // Jeśli nie ma wybranej daty, wybierz minDate
                        if (!selectedDate) {
                          setSelectedDate(minDate);
                        }
                      }}
                    >
                      <div className="text-xs uppercase">
                        {selectedDate ? format(selectedDate, "EEE", { locale: pl }).toUpperCase() : format(minDate, "EEE", { locale: pl }).toUpperCase()}
                      </div>
                      <div className="text-lg font-bold">
                        {selectedDate ? format(selectedDate, "dd.MM") : format(minDate, "dd.MM")}
                      </div>
                      {selectedDate && <div className="text-xs">✓</div>}
                    </div>
                    
                    {/* Dzień następny */}
                    <div 
                      className={`rounded-full w-16 h-16 border border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-gray-400 text-gray-700 ${
                        (!selectedDate || isSameOrBefore(addDays(selectedDate, 1), maxDate))
                        ? "" 
                        : "opacity-50 cursor-not-allowed"
                      }`}
                      onClick={() => {
                        const nextDate = selectedDate ? 
                          addDays(selectedDate, 1) : 
                          addDays(minDate, 1);
                          
                        // Sprawdź czy data jest dozwolona
                        if (isSameOrBefore(nextDate, maxDate)) {
                          setSelectedDate(nextDate);
                        }
                      }}
                    >
                      <div className="text-xs uppercase">
                        {selectedDate ? 
                          format(addDays(selectedDate, 1), "EEE", { locale: pl }).toUpperCase() : 
                          format(addDays(minDate, 1), "EEE", { locale: pl }).toUpperCase()}
                      </div>
                      <div className="text-lg font-bold">
                        {selectedDate ? 
                          format(addDays(selectedDate, 1), "dd.MM") : 
                          format(addDays(minDate, 1), "dd.MM")}
                      </div>
                    </div>
                  </div>
                  
                  {/* Przycisk nawigacji w prawo */}
                  <button 
                    className="absolute right-0 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-xl"
                    onClick={() => {
                      // Oblicz nową datę (dzień później)
                      const newDate = selectedDate ? 
                        addDays(selectedDate, 1) : 
                        addDays(minDate, 1);
                      
                      // Sprawdź, czy data jest dozwolona
                      if (isSameOrBefore(newDate, maxDate)) {
                        setSelectedDate(newDate);
                      }
                    }}
                  >
                    &gt;
                  </button>
                </div>
              </div>
              
              {/* Pełna data w formacie tekstowym razem z informacją o rezerwacji */}
              <div className="text-center space-y-4">
                <div>
                  {selectedDate ? (
                    <span className="text-sm font-medium">{formatSelectedDate(selectedDate)}</span>
                  ) : (
                    <span className="text-sm text-muted-foreground">Wybierz datę posiłku</span>
                  )}
                </div>
                
                {/* Informacja o sprawdzaniu dni pracy */}
                {checkingWorkDay ? (
                  <div className="flex justify-center items-center gap-2 text-sm text-blue-600">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Sprawdzanie harmonogramu...</span>
                  </div>
                ) : selectedDate && workDayData && !workDayData.isWorking ? (
                  <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-md max-w-md mx-auto">
                    <div className="flex items-start">
                      <Ban className="w-5 h-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-red-800 text-left">
                          Nie pracujesz w wybrany dzień
                        </p>
                        <p className="text-sm text-red-700 mt-1.5">
                          Możesz zamawiać posiłki tylko na dni, w których pracujesz.
                          Wybierz inny dzień lub skontaktuj się z administracją.
                        </p>
                      </div>
                    </div>
                  </div>
                ) : checkingReservation ? (
                  <div className="flex justify-center items-center gap-2 text-sm text-blue-600">
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Sprawdzanie rezerwacji...</span>
                  </div>
                ) : selectedDate && existingReservation?.exists && existingReservation?.reservation ? (
                  <div className="mt-2 p-3 bg-amber-50 border border-amber-200 rounded-md max-w-md mx-auto">
                    <div className="flex items-start">
                      <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 mr-3 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-amber-800 text-left">
                          Masz już zamówienie na ten dzień
                        </p>
                        <div className="mt-2 flex items-center">
                          {existingReservation.reservation.imageUrl && (
                            <div className="h-12 w-12 rounded mr-3 overflow-hidden flex-shrink-0">
                              <img 
                                src={existingReservation.reservation.imageUrl} 
                                alt={existingReservation.reservation.productName}
                                className="h-full w-full object-cover"
                              />
                            </div>
                          )}
                          <div className="text-left">
                            <p className="font-semibold">{existingReservation.reservation.productName}</p>
                            <p className="text-sm text-amber-700 mt-0.5">
                              Wybierając nowy posiłek, zamienisz obecne zamówienie na nowe.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            </div>
            
            {/* Usunięto komunikat o preferencjach dietetycznych */}
            
            {/* Kategorie produktów */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {Object.entries(groupedProducts).map(([category, products]) => (
                <div key={category} className="col-span-1 flex flex-col">
                  <div className="p-2 mb-2 text-black font-medium">
                    {category}
                  </div>
                  <div className="flex-1 space-y-4">
                    {products.map((product) => (
                      <Card 
                        key={product.id} 
                        className="border border-gray-200 cursor-pointer hover:shadow-md transition-shadow"
                        onClick={() => handleSelectProduct(product.id)}
                      >
                        <CardHeader className="p-0">
                          <div className="relative w-full h-[200px] px-2.5 pt-2.5">
                            <Dialog>
                              <DialogTrigger asChild>
                                <img 
                                  src={product.imageUrl || 'https://placehold.co/400x400/jpeg?text=Brak+zdjęcia'} 
                                  alt={product.name}
                                  className="object-cover w-full h-full rounded-md cursor-pointer hover:opacity-90 transition-opacity"
                                  onClick={(e) => e.stopPropagation()} // Zatrzymaj propagację, aby nie uruchamiać handleSelectProduct
                                />
                              </DialogTrigger>
                              <DialogContent className="sm:max-w-xl p-0">
                                <img 
                                  src={product.imageUrl || 'https://placehold.co/600x600/jpeg?text=Brak+zdjęcia'} 
                                  alt={product.name}
                                  className="w-full h-auto"
                                />
                              </DialogContent>
                            </Dialog>
                          </div>
                        </CardHeader>
                        <CardContent className="p-2">
                          {/* Oznaczenie rekomendowanego produktu - przeniesione na górę */}
                          {product.recommended && (
                            <div className="mb-2">
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 flex items-center gap-1">
                                <Check className="h-3 w-3" />
                                <span className="text-xs">Rekomendowany wg preferencji</span>
                              </Badge>
                            </div>
                          )}
                          
                          <div className="flex justify-between items-start">
                            <h3 className="font-semibold truncate flex-1">{product.name}</h3>
                            {product.rating && (
                              <div className="flex items-center ml-2">
                                <ProductRating rating={product.rating} />
                              </div>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground truncate">
                            {product.shortDescription || 'Brak opisu'}
                          </p>
                          
                          {/* Informacja o wadze i kaloriach */}
                          <div className="flex items-center gap-4 mt-2 text-gray-600">
                            {product.weight && (
                              <div className="flex items-center gap-1">
                                <ScaleIcon className="h-3.5 w-3.5 text-gray-400" />
                                <span className="text-xs">{product.weight}g</span>
                              </div>
                            )}
                            {product.totalCalories && (
                              <div className="flex items-center gap-1">
                                <ZapIcon className="h-3.5 w-3.5 text-gray-400" />
                                <span className="text-xs">{product.totalCalories} kcal</span>
                              </div>
                            )}
                          </div>
                        </CardContent>
                        <CardFooter className="p-2 pt-0">
                          <Button 
                            onClick={(e) => {
                              e.stopPropagation(); // Zapobiega podwójnemu uruchomieniu akcji
                              handleSelectProduct(product.id);
                            }}
                            className="w-full text-white hover:opacity-90"
                            style={{ 
                              backgroundColor: settingsData?.settings?.employeePortalButtonColor || "#91AD41"
                            }}
                          >
                            {existingReservation?.exists 
                              ? 'Zmień na ten posiłek' 
                              : 'Zarezerwuj / Szczegóły'}
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      ) : (
        // Widok szczegółów produktu i wyboru daty
        <Card className="w-full overflow-hidden">
          {/* Pusty div jako kotwica do przewijania */}
          <div 
            id="product-detail-anchor" 
            className="block w-full" 
            style={{ height: '1px', position: 'relative', top: '-65px' }}
            ref={el => {
              // Po wyrenderowaniu od razu przewijamy do tej kotwicy
              if (el) {
                setTimeout(() => {
                  el.scrollIntoView({ behavior: 'auto', block: 'start' });
                  window.scrollTo(0, 0);
                  document.documentElement.scrollTop = 0;
                  document.body.scrollTop = 0;
                }, 0);
              }
            }}
          ></div>
          <CardHeader className="px-3 py-3">
            <CardTitle>Rezerwacja posiłku</CardTitle>
            <CardDescription>
              Wybierz dzień, na który chcesz zarezerwować ten posiłek
            </CardDescription>
          </CardHeader>
          <CardContent className="px-3 py-2">
            <div>
              {/* Przyciski nawigacji */}
              <div className="flex justify-between items-center mb-6">
                <Button 
                  size="sm" 
                  onClick={cancelSelection}
                  className="flex items-center text-white"
                  style={{ 
                    backgroundColor: settingsData?.settings?.employeePortalButtonColor || '#91AD41',
                    ':hover': { opacity: 0.9 }
                  }}
                >
                  &larr; Wróć do listy posiłków
                </Button>
              </div>
              
              {/* Szczegóły wybranego produktu */}
              {selectedProduct && (
                <div className="flex flex-col gap-6">
                  {/* Główna sekcja ze zdjęciem i informacjami o produkcie */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Kolumna ze zdjęciem i podstawowymi informacjami */}
                    <div className="relative">
                      <div className="relative aspect-square w-full bg-white rounded-md pt-2.5">
                        <Dialog>
                          <DialogTrigger asChild>
                            <img 
                              src={selectedProduct.imageUrl || 'https://placehold.co/400x400/jpeg?text=Brak+zdjęcia'} 
                              alt={selectedProduct.name}
                              className="object-cover w-full h-full rounded-md cursor-pointer hover:opacity-90 transition-opacity"
                            />
                          </DialogTrigger>
                          <DialogContent className="sm:max-w-xl p-0">
                            <img 
                              src={selectedProduct.imageUrl || 'https://placehold.co/800x800/jpeg?text=Brak+zdjęcia'} 
                              alt={selectedProduct.name}
                              className="w-full h-auto"
                            />
                          </DialogContent>
                        </Dialog>
                      </div>
                      
                      {/* Nazwa i krótki opis - przeniesione pod zdjęcie i wyrównane do lewej */}
                      <div className="mt-4 text-left">
                        <h3 className="text-lg font-medium">{selectedProduct.name}</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {selectedProduct.shortDescription}
                        </p>
                      </div>
                      
                      {/* Informacje o wadze i kaloriach */}
                      <div className="flex items-center justify-start gap-4 mt-3 text-gray-700">
                        {selectedProduct.weight && (
                          <div className="flex items-center">
                            <ScaleIcon className="h-4 w-4 mr-1 text-gray-500" />
                            <span>{selectedProduct.weight}g</span>
                          </div>
                        )}
                        {selectedProduct.totalCalories && (
                          <div className="flex items-center">
                            <ZapIcon className="h-4 w-4 mr-1 text-gray-500" />
                            <span>{selectedProduct.totalCalories} kcal</span>
                          </div>
                        )}
                      </div>
                      
                      {/* Pełny opis produktu */}
                      <div className="mt-3 text-gray-700 px-0">
                        <p>{selectedProduct.longDescription}</p>
                      </div>
                    </div>
                    
                    {/* Kolumna z informacjami o produkcie */}
                    <div>
                      {/* Tabela wartości odżywczych */}
                      <div className="border rounded-md overflow-hidden mb-4">
                        <div className="bg-gray-50 p-3 font-medium border-b">
                          Wartości odżywcze (na 100g)
                        </div>
                        <div className="p-0">
                          <table className="min-w-full divide-y divide-gray-200">
                            <tbody className="divide-y divide-gray-200">
                              {selectedProduct.nutritionFacts?.energyValue && (
                                <tr>
                                  <td className="px-3 py-2 text-sm font-medium text-gray-700">Wartość energetyczna</td>
                                  <td className="px-3 py-2 text-sm text-gray-700 text-right">
                                    {selectedProduct.nutritionFacts.energyValue && selectedProduct.nutritionFacts.energyValue.toString().endsWith('kcal') ? 
                                      selectedProduct.nutritionFacts.energyValue : 
                                      `${selectedProduct.nutritionFacts.energyValue} kcal`}
                                  </td>
                                </tr>
                              )}
                              {selectedProduct.nutritionFacts?.protein && (
                                <tr>
                                  <td className="px-3 py-2 text-sm font-medium text-gray-700">Białko</td>
                                  <td className="px-3 py-2 text-sm text-gray-700 text-right">
                                    {selectedProduct.nutritionFacts.protein && selectedProduct.nutritionFacts.protein.toString().endsWith('g') ? 
                                      selectedProduct.nutritionFacts.protein : 
                                      `${selectedProduct.nutritionFacts.protein} g`}
                                  </td>
                                </tr>
                              )}
                              {selectedProduct.nutritionFacts?.fat && (
                                <tr>
                                  <td className="px-3 py-2 text-sm font-medium text-gray-700">Tłuszcz</td>
                                  <td className="px-3 py-2 text-sm text-gray-700 text-right">
                                    {selectedProduct.nutritionFacts.fat && selectedProduct.nutritionFacts.fat.toString().endsWith('g') ? 
                                      selectedProduct.nutritionFacts.fat : 
                                      `${selectedProduct.nutritionFacts.fat} g`}
                                  </td>
                                </tr>
                              )}
                              {selectedProduct.nutritionFacts?.saturatedFat && (
                                <tr>
                                  <td className="px-3 py-2 text-sm font-medium text-gray-700 pl-6">- w tym kwasy nasycone</td>
                                  <td className="px-3 py-2 text-sm text-gray-700 text-right">
                                    {selectedProduct.nutritionFacts.saturatedFat && selectedProduct.nutritionFacts.saturatedFat.toString().endsWith('g') ? 
                                      selectedProduct.nutritionFacts.saturatedFat : 
                                      `${selectedProduct.nutritionFacts.saturatedFat} g`}
                                  </td>
                                </tr>
                              )}
                              {selectedProduct.nutritionFacts?.carbs && (
                                <tr>
                                  <td className="px-3 py-2 text-sm font-medium text-gray-700">Węglowodany</td>
                                  <td className="px-3 py-2 text-sm text-gray-700 text-right">
                                    {selectedProduct.nutritionFacts.carbs && selectedProduct.nutritionFacts.carbs.toString().endsWith('g') ? 
                                      selectedProduct.nutritionFacts.carbs : 
                                      `${selectedProduct.nutritionFacts.carbs} g`}
                                  </td>
                                </tr>
                              )}
                              {(selectedProduct.nutritionFacts?.sugar || selectedProduct.nutritionFacts?.carbs) && (
                                <tr>
                                  <td className="px-3 py-2 text-sm font-medium text-gray-700 pl-6">- w tym cukry</td>
                                  <td className="px-3 py-2 text-sm text-gray-700 text-right">
                                    {selectedProduct.nutritionFacts?.sugar ? 
                                      (selectedProduct.nutritionFacts.sugar.toString().endsWith('g') ? 
                                        selectedProduct.nutritionFacts.sugar : 
                                        `${selectedProduct.nutritionFacts.sugar} g`) : 
                                      // Jeśli brak wartości sugar, oblicz 30% wartości węglowodanów jako przybliżenie i zaokrąglij do 1 miejsca po przecinku
                                      (selectedProduct.nutritionFacts?.carbs ? 
                                        (Math.round(parseFloat(selectedProduct.nutritionFacts.carbs) * 0.3 * 10) / 10).toFixed(1) + ' g' : 
                                        'brak danych')}
                                  </td>
                                </tr>
                              )}
                              {selectedProduct.nutritionFacts?.salt && (
                                <tr>
                                  <td className="px-3 py-2 text-sm font-medium text-gray-700">Sól</td>
                                  <td className="px-3 py-2 text-sm text-gray-700 text-right">
                                    {selectedProduct.nutritionFacts.salt && selectedProduct.nutritionFacts.salt.toString().endsWith('g') ? 
                                      selectedProduct.nutritionFacts.salt : 
                                      `${selectedProduct.nutritionFacts.salt} g`}
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                      </div>
                      
                      {/* Skład, alergeny i preferencje dietetyczne */}
                      <div className="flex flex-col gap-2 mb-4">
                        {/* Pełny skład */}
                        <Dialog>
                          <DialogTrigger asChild>
                            <button className="flex items-center text-blue-600 hover:text-blue-700 px-3 py-2 rounded-md hover:bg-blue-50 transition-colors font-medium">
                              <div className="mr-2 p-1 rounded-full bg-blue-100">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                              </div>
                              Pełny skład
                            </button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Pełny skład produktu</DialogTitle>
                            </DialogHeader>
                            <div className="flex items-start gap-3 mb-4">
                              <div className="p-2 rounded-full bg-blue-100 mt-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                              </div>
                              <div>
                                <h3 className="font-medium text-gray-800 mb-1">Pełny skład produktu</h3>
                                <p className="text-gray-600 text-sm mb-2">{selectedProduct.name}</p>
                              </div>
                            </div>
                            <div className="bg-blue-50 p-4 rounded-md text-gray-700 whitespace-pre-line border border-blue-100">
                              {selectedProduct.ingredients || "Informacja o pełnym składzie nie jest jeszcze dostępna"}
                            </div>
                          </DialogContent>
                        </Dialog>
                        
                        {/* Alergeny */}
                        <Dialog>
                          <DialogTrigger asChild>
                            <button className="flex items-center text-orange-600 hover:text-orange-700 px-3 py-2 rounded-md hover:bg-orange-50 transition-colors font-medium">
                              <div className="mr-2 p-1 rounded-full bg-orange-100">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                </svg>
                              </div>
                              Alergeny
                            </button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Alergeny</DialogTitle>
                            </DialogHeader>
                            <div className="flex items-start gap-3 mb-4">
                              <div className="p-2 rounded-full bg-orange-100 mt-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                </svg>
                              </div>
                              <div>
                                <h3 className="font-medium text-gray-800 mb-1">Informacja o alergenach dla produktu</h3>
                                <p className="text-gray-600 text-sm mb-2">{selectedProduct.name}</p>
                              </div>
                            </div>
                            <div className="bg-orange-50 p-4 rounded-md text-gray-700 whitespace-pre-line border border-orange-100">
                              {selectedProduct.allergens || "Informacja o alergenach nie jest jeszcze dostępna"}
                            </div>
                          </DialogContent>
                        </Dialog>
                        
                        {/* Preferencje dietetyczne */}
                        <Dialog>
                          <DialogTrigger asChild>
                            <button className="flex items-center text-purple-600 hover:text-purple-700 px-3 py-2 rounded-md hover:bg-purple-50 transition-colors font-medium">
                              <div className="mr-2 p-1 rounded-full bg-purple-100">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                </svg>
                              </div>
                              Preferencje dietetyczne
                            </button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Preferencje dietetyczne</DialogTitle>
                            </DialogHeader>
                            <div className="flex items-start gap-3 mb-4">
                              <div className="p-2 rounded-full bg-purple-100 mt-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                </svg>
                              </div>
                              <div>
                                <h3 className="font-medium text-gray-800 mb-1">Preferencje dietetyczne</h3>
                                <p className="text-gray-600 text-sm mb-2">{selectedProduct.name}</p>
                              </div>
                            </div>
                            <div className="bg-purple-50 p-4 rounded-md text-gray-700 border border-purple-100">
                              <div className="flex flex-wrap gap-2">
                                {selectedProduct.dietaryPreferences && selectedProduct.dietaryPreferences.length > 0 ? (
                                  selectedProduct.dietaryPreferences.map((preference, index) => (
                                    <div key={index} className="px-3 py-1.5 bg-white rounded-full border border-purple-200 text-purple-800 text-sm font-medium">
                                      {preference}
                                    </div>
                                  ))
                                ) : (
                                  <p>Brak informacji o preferencjach dietetycznych</p>
                                )}
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>
                      
                      {/* Sekcja z kategorią została ukryta zgodnie z wymaganiami */}
                      
                      {selectedProduct.rating && (
                        <div className="pt-2 mb-4">
                          <div className="text-sm font-medium mb-1">Ocena produktu:</div>
                          <div className="flex items-center">
                            <ProductRating rating={selectedProduct.rating} />
                            {selectedProduct.rating.count > 0 && (
                              <span className="ml-2 text-sm text-gray-600">
                                (oceniony przez {selectedProduct.rating.count} {selectedProduct.rating.count === 1 ? 'osobę' : 
                                  selectedProduct.rating.count < 5 ? 'osoby' : 'osób'})
                              </span>
                            )}
                          </div>
                        </div>
                      )}
                    
                      {/* Wybór daty rezerwacji */}
                      <div className="space-y-3 border-t border-border pt-4">
                        <div className="font-medium">Wybierz datę rezerwacji:</div>
                        <div className="space-y-4">
                          {/* Wybór daty w formie kółek */}
                          <div className="relative w-fit mx-auto px-6">
                            {/* Przyciski nawigacji */}
                            <button 
                              className="absolute left-0 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-xl"
                              onClick={() => {
                                // Oblicz nową datę (dzień wcześniej)
                                const newDate = selectedDate ? 
                                  addDays(selectedDate, -1) : 
                                  minDate;
                                
                                // Sprawdź, czy data jest dozwolona
                                if (!isBefore(newDate, minDate)) {
                                  setSelectedDate(newDate);
                                }
                              }}
                            >
                              &lt;
                            </button>
                            
                            {/* Wybór daty w formie kółek - zawsze pokazujemy 3 kółka */}
                            <div className="flex space-x-4 items-center">
                              {/* Dzień poprzedni */}
                              <div 
                                className={`rounded-full w-16 h-16 border border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-gray-400 text-gray-700 ${
                                  selectedDate && !isBefore(addDays(selectedDate, -1), minDate)
                                  ? "" 
                                  : "opacity-50 cursor-not-allowed"
                                }`}
                                onClick={() => {
                                  if (selectedDate && !isBefore(addDays(selectedDate, -1), minDate)) {
                                    setSelectedDate(addDays(selectedDate, -1));
                                  }
                                }}
                              >
                                <div className="text-xs uppercase">
                                  {selectedDate 
                                    ? format(addDays(selectedDate, -1), "EEE", { locale: pl }) 
                                    : format(!isBefore(addDays(minDate, -1), minDate) ? addDays(minDate, -1) : minDate, "EEE", { locale: pl })}
                                </div>
                                <div className="text-lg font-bold">
                                  {selectedDate 
                                    ? format(addDays(selectedDate, -1), "dd.MM") 
                                    : format(!isBefore(addDays(minDate, -1), minDate) ? addDays(minDate, -1) : minDate, "dd.MM")}
                                </div>
                              </div>
                              
                              {/* Dzień bieżący (wybrany) */}
                              <div 
                                className={`rounded-full w-16 h-16 flex flex-col items-center justify-center cursor-pointer ${
                                  selectedDate ? "bg-yellow-400 text-black" : "border border-gray-300 text-gray-700 hover:border-gray-400"
                                }`}
                                onClick={() => {
                                  // Jeśli nie ma wybranej daty, wybierz minDate
                                  if (!selectedDate) {
                                    setSelectedDate(minDate);
                                  }
                                }}
                              >
                                <div className="text-xs uppercase">
                                  {selectedDate ? format(selectedDate, "EEE", { locale: pl }) : format(minDate, "EEE", { locale: pl })}
                                </div>
                                <div className="text-lg font-bold">
                                  {selectedDate ? format(selectedDate, "dd.MM") : format(minDate, "dd.MM")}
                                </div>
                                {selectedDate && <div className="text-xs">✓</div>}
                              </div>
                              
                              {/* Dzień następny */}
                              <div 
                                className={`rounded-full w-16 h-16 border border-gray-300 flex flex-col items-center justify-center cursor-pointer hover:border-gray-400 text-gray-700 ${
                                  (!selectedDate || !isAfter(addDays(selectedDate, 1), maxDate))
                                  ? "" 
                                  : "opacity-50 cursor-not-allowed"
                                }`}
                                onClick={() => {
                                  const nextDate = selectedDate ? 
                                    addDays(selectedDate, 1) : 
                                    addDays(minDate, 1);
                                    
                                  // Sprawdź czy data jest dozwolona
                                  if (!isAfter(nextDate, maxDate)) {
                                    setSelectedDate(nextDate);
                                  }
                                }}
                              >
                                <div className="text-xs uppercase">
                                  {selectedDate ? 
                                    format(addDays(selectedDate, 1), "EEE", { locale: pl }) : 
                                    format(addDays(minDate, 1), "EEE", { locale: pl })}
                                </div>
                                <div className="text-lg font-bold">
                                  {selectedDate ? 
                                    format(addDays(selectedDate, 1), "dd.MM") : 
                                    format(addDays(minDate, 1), "dd.MM")}
                                </div>
                              </div>
                            </div>
                            
                            {/* Przycisk nawigacji w prawo */}
                            <button 
                              className="absolute right-0 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700 text-xl"
                              onClick={() => {
                                // Oblicz nową datę (dzień później)
                                const newDate = selectedDate ? 
                                  addDays(selectedDate, 1) : 
                                  addDays(minDate, 1);
                                
                                // Sprawdź, czy data jest dozwolona
                                if (!isAfter(newDate, maxDate)) {
                                  setSelectedDate(newDate);
                                }
                              }}
                            >
                              &gt;
                            </button>
                          </div>
                          
                          {/* Przycisk do resetowania/cofania wyboru daty */}
                          <div className="mt-4 flex justify-center">
                            <button 
                              className="text-sm text-gray-500 hover:text-gray-700 flex items-center"
                              onClick={() => setSelectedDate(minDate)} 
                            >
                              <span className="mr-1">&#8634;</span> Wróć do pierwszego dnia
                            </button>
                          </div>
                          
                          {/* Pełna data w formacie tekstowym */}
                          <div className="text-center mt-3">
                            {selectedDate ? (
                              <span className="text-sm font-medium">{formatSelectedDate(selectedDate)}</span>
                            ) : (
                              <span className="text-sm text-muted-foreground">Wybierz datę posiłku</span>
                            )}
                          </div>
                        </div>
                        
                        {checkingReservation ? (
                          <div className="text-sm mt-4 text-muted-foreground">
                            Sprawdzanie rezerwacji...
                          </div>
                        ) : selectedDate && existingReservation?.exists ? (
                          <div className="flex items-center justify-center mt-4 text-amber-600 bg-amber-50 p-2 rounded text-sm">
                            <AlertTriangle className="h-4 w-4 mr-2" />
                            <div>
                              <span className="font-medium">Masz już rezerwację na ten dzień </span>
                              <span>{existingReservation.productName}</span>
                            </div>
                          </div>
                        ) : selectedDate ? (
                          null
                        ) : null}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between px-3 py-3">
            <Button variant="outline" onClick={cancelSelection}>
              Anuluj
            </Button>
            <Button 
              onClick={confirmSelection}
              disabled={
                reserveMealMutation.isPending || 
                !selectedDate || 
                (selectedDate && existingReservation?.exists && !existingReservation.reservation?.id)
              }
              style={{ 
                backgroundColor: settingsData?.settings?.employeePortalButtonColor || "#91AD41", 
                width: existingReservation?.exists ? "calc(100% + 50px)" : "auto",
                marginLeft: "20px"
              }}
              className="text-white hover:opacity-90"
            >
              {reserveMealMutation.isPending || deleteMealMutation.isPending 
                ? "Zapisuję..." 
                : existingReservation?.exists 
                  ? "Zmień posiłek" 
                  : "Zarezerwuj posiłek"}
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  );
};