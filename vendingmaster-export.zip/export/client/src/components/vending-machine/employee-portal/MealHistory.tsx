import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle, 
  CardFooter
} from "@/components/ui/card";
import { Employee } from "@shared/schema";

// Komponent gwiazdek oceny
function StarRating({ 
  value, 
  onChange, 
  readOnly = false 
}: { 
  value: number; 
  onChange?: (value: number) => void; 
  readOnly?: boolean 
}) {
  return (
    <div className="flex items-center space-x-1">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          className={`p-0.5 focus:outline-none transition-colors ${readOnly ? 'cursor-default' : 'cursor-pointer hover:text-amber-500'}`}
          onClick={() => !readOnly && onChange && onChange(star)}
          disabled={readOnly}
        >
          {star <= value ? (
            <Star className="w-5 h-5 fill-amber-400 text-amber-400" />
          ) : (
            <Star className="w-5 h-5 text-muted-foreground" />
          )}
        </button>
      ))}
    </div>
  );
};
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  UtensilsCrossed, 
  Calendar, 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  XCircle, 
  X,
  Star,
  MessageSquare
} from "lucide-react";
import { format } from "date-fns";
import { pl } from "date-fns/locale";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
  DialogTrigger
} from "@/components/ui/dialog";

interface MealHistoryProps {
  employee: Employee;
}

interface MealRating {
  id: number;
  reservationId: number;
  employeeId: number;
  productId: number;
  rating: number; // 1-5
  comment?: string;
  createdAt: string;
}

interface MealRecord {
  id: number;
  chamberId: number | null;
  productId: number;
  productName: string;
  productImage?: string;
  shortDescription?: string;
  weight?: number;
  calories?: number;
  reservedForDate: string;
  status: "active" | "fulfilled" | "cancelled";
  reservedAt: string; // zmienione z createdAt na reservedAt zgodnie z API
  hasRating?: boolean; // czy posiłek został już oceniony
}

export const MealHistory: React.FC<MealHistoryProps> = ({ employee }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMeal, setSelectedMeal] = useState<MealRecord | null>(null);
  const [isRatingDialogOpen, setIsRatingDialogOpen] = useState(false);
  const [ratingValue, setRatingValue] = useState(0);
  const [ratingComment, setRatingComment] = useState("");
  const [existingRating, setExistingRating] = useState<MealRating | null>(null);
  
  // Funkcja pomocnicza do przewijania strony do góry - bardziej zdecydowane podejście
  const scrollToTop = () => {
    // Natychmiastowe przewinięcie
    document.documentElement.scrollTop = 0; // Dla Firefox
    document.body.scrollTop = 0; // Dla Safari
    window.scrollTo(0, 0); // Dla innych przeglądarek
    
    // Dodatkowe przewinięcie po małym opóźnieniu dla większej pewności
    setTimeout(() => {
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      window.scrollTo({
        top: 0,
        behavior: 'auto' // Natychmiastowe przewinięcie
      });
      
      // Jeszcze jedno przewinięcie dla pewności
      setTimeout(() => {
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        window.scrollTo(0, 0);
      }, 50);
    }, 10);
  };
  
  // Przewiń stronę do góry przy inicjalizacji komponentu
  useEffect(() => {
    scrollToTop();
  }, []);

  // Pobierz historię rezerwacji posiłków pracownika
  const { data, isLoading, error } = useQuery<{success: boolean, reservations: MealRecord[]}>({
    queryKey: ['/api/meal-reservations', employee.id],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/meal-reservations?employeeId=${employee.id}`);
        if (!response.ok) {
          throw new Error('Problem z pobieraniem historii rezerwacji');
        }
        const result = await response.json();
        return result;
      } catch (err) {
        console.error("Error fetching reservations:", err);
        throw err;
      }
    },
    staleTime: 1000 * 60 * 5 // 5 minut
  });
  
  // Pobierz oceny posiłków pracownika
  const { data: ratingsData } = useQuery<MealRating[]>({
    queryKey: ['/api/meal-ratings', employee.id],
    queryFn: async () => {
      try {
        const response = await fetch(`/api/meal-ratings?employeeId=${employee.id}`);
        if (!response.ok) {
          throw new Error('Problem z pobieraniem ocen');
        }
        return await response.json();
      } catch (err) {
        console.error("Error fetching ratings:", err);
        return [];
      }
    },
    enabled: !!employee.id,
    staleTime: 1000 * 60 * 5 // 5 minut
  });
  
  // Mutacja do dodawania oceny posiłku
  const addRatingMutation = useMutation({
    mutationFn: async (ratingData: { 
      reservationId: number; 
      employeeId: number; 
      productId: number; 
      rating: number; 
      comment?: string 
    }) => {
      return apiRequest('/api/meal-ratings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(ratingData)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/meal-ratings', employee.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations', employee.id] });
      setIsRatingDialogOpen(false);
      setRatingValue(0);
      setRatingComment("");
      toast({
        title: "Ocena dodana",
        description: "Twoja ocena została zapisana. Dziękujemy za opinię!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error?.message || "Nie udało się dodać oceny. Spróbuj ponownie później.",
        variant: "destructive",
      });
    }
  });
  
  // Mutacja do aktualizacji oceny posiłku
  const updateRatingMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: { rating: number; comment?: string } }) => {
      return apiRequest(`/api/meal-ratings/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/meal-ratings', employee.id] });
      setIsRatingDialogOpen(false);
      setRatingValue(0);
      setRatingComment("");
      toast({
        title: "Ocena zaktualizowana",
        description: "Twoja ocena została zaktualizowana. Dziękujemy za opinię!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error?.message || "Nie udało się zaktualizować oceny. Spróbuj ponownie później.",
        variant: "destructive",
      });
    }
  });

  // Mutacja do anulowania rezerwacji
  const cancelReservationMutation = useMutation({
    mutationFn: async (reservationId: number) => {
      return apiRequest(`/api/meal-reservations/${reservationId}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/meal-reservations', employee.id] });
      toast({
        title: "Rezerwacja anulowana",
        description: "Rezerwacja została pomyślnie anulowana.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Błąd",
        description: error?.message || "Nie udało się anulować rezerwacji. Spróbuj ponownie później.",
        variant: "destructive",
      });
      console.error("Error cancelling reservation:", error);
    }
  });

  // Sprawdzanie, czy rezerwacja ma już ocenę
  const checkIfReservationHasRating = (reservationId: number): MealRating | undefined => {
    if (!ratingsData) return undefined;
    return ratingsData.find(rating => rating.reservationId === reservationId);
  };

  // Zmienna do przechowywania posiłku do oceny (oddzielna od selectedMeal dla dialogu)
  const [mealToRate, setMealToRate] = useState<MealRecord | null>(null);
  
  // Obsługa otwarcia okna dialogowego oceny
  const handleOpenRatingDialog = (reservation: MealRecord) => {
    // Zapisz posiłek do oceny
    setMealToRate(reservation);
    setSelectedMeal(null); // Zamknij dialog szczegółów
    
    // Sprawdź, czy istnieje już ocena dla tej rezerwacji
    const rating = checkIfReservationHasRating(reservation.id);
    
    if (rating) {
      // Jeśli ocena istnieje, ustaw ją do edycji
      setExistingRating(rating);
      setRatingValue(rating.rating);
      setRatingComment(rating.comment || "");
    } else {
      // Nowa ocena
      setExistingRating(null);
      setRatingValue(0);
      setRatingComment("");
    }
    
    setIsRatingDialogOpen(true);
  };

  // Obsługa zapisywania oceny
  const handleSaveRating = () => {
    if (!mealToRate) return;
    
    if (ratingValue === 0) {
      toast({
        title: "Wybierz ocenę",
        description: "Proszę wybrać ocenę od 1 do 5 gwiazdek.",
        variant: "destructive"
      });
      return;
    }
    
    console.log("Zapisywanie oceny dla posiłku:", mealToRate);
    
    if (existingRating) {
      // Aktualizacja istniejącej oceny
      updateRatingMutation.mutate({
        id: existingRating.id,
        data: {
          rating: ratingValue,
          comment: ratingComment || undefined
        }
      });
    } else {
      // Dodanie nowej oceny
      addRatingMutation.mutate({
        reservationId: mealToRate.id,
        employeeId: employee.id,
        productId: mealToRate.productId,
        rating: ratingValue,
        comment: ratingComment || undefined
      });
    }
  };

  const handleCancelReservation = (reservationId: number) => {
    if (confirm('Czy na pewno chcesz anulować tę rezerwację?')) {
      cancelReservationMutation.mutate(reservationId);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-full">
        <p>Ładowanie historii rezerwacji...</p>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertDescription>
          Wystąpił problem z pobieraniem historii rezerwacji. Spróbuj ponownie później.
        </AlertDescription>
      </Alert>
    );
  }

  const reservations = data?.reservations || [];

  // Grupowanie posiłków według daty rezerwacji
  const groupedReservations: Record<string, MealRecord[]> = {};
  
  reservations.forEach(reservation => {
    if (!groupedReservations[reservation.reservedForDate]) {
      groupedReservations[reservation.reservedForDate] = [];
    }
    groupedReservations[reservation.reservedForDate].push(reservation);
  });

  // Sortowanie dat od najnowszej do najstarszej
  const sortedDates = Object.keys(groupedReservations).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
  
  // Filtruj tylko historyczne zamówienia (przeszłe daty lub zrealizowane/anulowane)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Zatrzymaj tylko przeszłe daty oraz zamówienia o statusie fulfilled lub cancelled
  const historicalDates = sortedDates.filter(date => {
    const dateObj = new Date(date);
    dateObj.setHours(0, 0, 0, 0);
    
    // Jeśli data jest wcześniejsza niż dzisiaj, to na pewno jest historyczna
    if (dateObj < today) return true;
    
    // Jeśli data jest dzisiejsza lub przyszła, sprawdź czy wszystkie zamówienia są zrealizowane lub anulowane
    return groupedReservations[date].every(reservation => 
      reservation.status === 'fulfilled' || reservation.status === 'cancelled'
    );
  });
  
  if (reservations.length === 0 || historicalDates.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <div className="bg-muted w-16 h-16 rounded-full flex items-center justify-center mb-4">
          <UtensilsCrossed className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-medium mb-2">Brak historii rezerwacji</h3>
        <p className="text-muted-foreground max-w-md">
          Nie masz jeszcze żadnych zrealizowanych lub anulowanych rezerwacji. Po zrealizowaniu zamówień, pojawią się one tutaj.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 mx-2.5">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold">Historia rezerwacji posiłków</h2>
        <p className="text-muted-foreground">
          Lista wszystkich zarezerwowanych przez Ciebie posiłków
        </p>
      </div>

      {historicalDates.map(date => (
        <div key={date} className="space-y-4">
          <div className="p-2 mb-2 text-black font-medium">{formatDate(date)}</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {groupedReservations[date].map(reservation => (
              <Card key={reservation.id} className="border border-gray-200">
                <CardHeader className="p-0">
                  {reservation.productImage && (
                    <div className="relative w-full h-[200px] px-2.5 pt-2.5">
                      <Dialog>
                        <DialogTrigger asChild>
                          <img 
                            src={reservation.productImage} 
                            alt={reservation.productName} 
                            className="object-cover w-full h-full rounded-md cursor-pointer hover:opacity-90 transition-opacity"
                          />
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-xl p-0">
                          <img 
                            src={reservation.productImage} 
                            alt={reservation.productName}
                            className="w-full h-auto"
                          />
                        </DialogContent>
                      </Dialog>
                    </div>
                  )}
                </CardHeader>
                <CardContent className="p-2">
                  <div className="flex justify-between items-start">
                    <h3 className="font-semibold truncate flex-1">{reservation.productName}</h3>
                    {getStatusBadge(reservation.status)}
                  </div>
                  
                  <div className="flex items-center mt-1 text-sm text-muted-foreground">
                    <Calendar className="w-3 h-3 mr-1" />
                    Na dzień: {format(new Date(reservation.reservedForDate), "dd MMMM yyyy", { locale: pl })}
                  </div>
                  
                  <div className="text-xs text-muted-foreground mt-1 flex items-center">
                    <Clock className="w-3 h-3 mr-1" />
                    Zarezerwowano: {formatDateTime(reservation.reservedAt)}
                  </div>
                  
                  {reservation.chamberId && (
                    <div className="text-xs text-muted-foreground mt-1">
                      Szuflada nr {reservation.chamberId}
                    </div>
                  )}
                </CardContent>
                
                <CardFooter className="p-2 pt-0">
                  {/* Pokaż opcję oceny dla zrealizowanych zamówień lub tych, których data już minęła */}
                  {(reservation.status === 'fulfilled' || 
                    (reservation.status === 'active' && new Date(reservation.reservedForDate) < new Date())) && (
                    <Button
                      variant="default"
                      size="sm"
                      className="w-full bg-amber-500 hover:bg-amber-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleOpenRatingDialog(reservation);
                      }}
                    >
                      <Star className="w-4 h-4 mr-1" />
                      {reservation.hasRating ? 'Edytuj ocenę' : 'Oceń posiłek'}
                    </Button>
                  )}
                  
                  {/* Pokaż opcję anulowania tylko dla aktywnych rezerwacji, których data jeszcze nie minęła */}
                  {reservation.status === 'active' && new Date(reservation.reservedForDate) >= new Date() && (
                    <Button 
                      variant="destructive" 
                      size="sm"
                      className="w-full"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCancelReservation(reservation.id);
                      }}
                      disabled={cancelReservationMutation.isPending}
                    >
                      <XCircle className="w-4 h-4 mr-1" />
                      Anuluj rezerwację
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      ))}

      {/* Dialog ze szczegółami posiłku */}
      <Dialog open={!!selectedMeal} onOpenChange={(open) => !open && setSelectedMeal(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Szczegóły rezerwacji</DialogTitle>
            <DialogDescription>
              Informacje o zarezerwowanym posiłku
            </DialogDescription>
          </DialogHeader>
          
          {selectedMeal && (
            <div className="space-y-4">
              <div className="w-full overflow-hidden rounded-md mb-4" style={{ maxHeight: '200px' }}>
                {selectedMeal.productImage ? (
                  <img 
                    src={selectedMeal.productImage} 
                    alt={selectedMeal.productName} 
                    className="object-cover w-full h-auto"
                    style={{ maxHeight: '200px' }}
                  />
                ) : (
                  <div className="w-full h-48 flex items-center justify-center bg-muted">
                    <UtensilsCrossed className="h-12 w-12 text-muted-foreground" />
                  </div>
                )}
              </div>
              
              <div>
                <h3 className="text-lg font-semibold flex items-center justify-between">
                  {selectedMeal.productName}
                  {getStatusBadge(selectedMeal.status)}
                </h3>
                
                {selectedMeal.shortDescription && (
                  <p className="text-sm text-muted-foreground mt-2">{selectedMeal.shortDescription}</p>
                )}
                
                <div className="mt-4 grid grid-cols-2 gap-2">
                  {selectedMeal.weight && (
                    <div className="bg-blue-50 rounded p-2 text-center">
                      <div className="text-xs text-muted-foreground">Waga</div>
                      <div className="font-semibold">{selectedMeal.weight} g</div>
                    </div>
                  )}
                  
                  {selectedMeal.calories && (
                    <div className="bg-orange-50 rounded p-2 text-center">
                      <div className="text-xs text-muted-foreground">Kalorie</div>
                      <div className="font-semibold">{selectedMeal.calories} kcal</div>
                    </div>
                  )}
                </div>
                
                <div className="mt-4 space-y-2">
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">Status:</span>
                    <span>
                      {selectedMeal.status === 'active' && 'Aktywna'}
                      {selectedMeal.status === 'fulfilled' && 'Zrealizowana'}
                      {selectedMeal.status === 'cancelled' && 'Anulowana'}
                    </span>
                  </div>
                  
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">Data posiłku:</span>
                    <span>{format(new Date(selectedMeal.reservedForDate), "dd MMMM yyyy", { locale: pl })}</span>
                  </div>
                  
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">Data rezerwacji:</span>
                    <span>{formatDateTime(selectedMeal.reservedAt)}</span>
                  </div>
                  
                  {selectedMeal.chamberId && (
                    <div className="flex justify-between text-sm border-b border-muted py-2">
                      <span className="font-medium">Numer szuflady:</span>
                      <span>{selectedMeal.chamberId}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between text-sm border-b border-muted py-2">
                    <span className="font-medium">ID rezerwacji:</span>
                    <span>#{selectedMeal.id}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter className="flex justify-between sm:justify-between">
            <DialogClose asChild>
              <Button variant="outline">
                Zamknij
              </Button>
            </DialogClose>
            
            {/* Pokaż opcję anulowania tylko dla aktywnych rezerwacji, których data jeszcze nie minęła */}
            {selectedMeal && 
              selectedMeal.status === 'active' && 
              new Date(selectedMeal.reservedForDate) >= new Date() && (
              <Button 
                variant="destructive"
                onClick={() => {
                  if (selectedMeal) {
                    handleCancelReservation(selectedMeal.id);
                    setSelectedMeal(null);
                  }
                }}
                disabled={cancelReservationMutation.isPending}
              >
                {cancelReservationMutation.isPending ? 'Anulowanie...' : 'Anuluj rezerwację'}
              </Button>
            )}
            
            {/* Pokaż opcję oceny dla zrealizowanych zamówień lub tych, których data już minęła */}
            {selectedMeal && 
              (selectedMeal.status === 'fulfilled' || 
               (selectedMeal.status === 'active' && new Date(selectedMeal.reservedForDate) < new Date())) && (
              <Button
                variant="default"
                onClick={() => {
                  if (selectedMeal) {
                    setSelectedMeal(selectedMeal);
                    handleOpenRatingDialog(selectedMeal);
                  }
                }}
                className="bg-amber-500 hover:bg-amber-600"
              >
                <Star className="w-4 h-4 mr-1" />
                {selectedMeal.hasRating ? 'Edytuj ocenę' : 'Oceń posiłek'}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Dialog z ocenianiem posiłku */}
      <Dialog open={isRatingDialogOpen} onOpenChange={setIsRatingDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Oceń posiłek</DialogTitle>
            <DialogDescription>
              Twoja opinia pomoże nam dostarczać lepsze posiłki w przyszłości.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-5 py-3">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Jak oceniasz ten posiłek?</h3>
              <div className="flex justify-center py-2">
                <div className="flex flex-col items-center space-y-2">
                  <StarRating value={ratingValue} onChange={setRatingValue} />
                  <span className="text-sm text-muted-foreground pt-1">
                    {ratingValue === 0 && 'Wybierz ocenę'}
                    {ratingValue === 1 && 'Bardzo słabo'}
                    {ratingValue === 2 && 'Słabo'}
                    {ratingValue === 3 && 'Przeciętnie'}
                    {ratingValue === 4 && 'Dobrze'}
                    {ratingValue === 5 && 'Znakomicie'}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="comment" className="text-sm font-medium">
                Komentarz (opcjonalnie)
              </label>
              <Textarea
                id="comment"
                placeholder="Podziel się swoją opinią o tym posiłku..."
                value={ratingComment}
                onChange={(e) => setRatingComment(e.target.value)}
                className="resize-none"
                rows={4}
              />
            </div>
          </div>
          
          <DialogFooter className="flex justify-between sm:justify-between">
            <DialogClose asChild>
              <Button variant="outline">
                Anuluj
              </Button>
            </DialogClose>
            
            <Button 
              variant="default"
              onClick={handleSaveRating}
              disabled={addRatingMutation.isPending || updateRatingMutation.isPending}
              className="bg-amber-500 hover:bg-amber-600"
            >
              {addRatingMutation.isPending || updateRatingMutation.isPending ? 
                'Zapisywanie...' : 
                (existingRating ? 'Aktualizuj ocenę' : 'Dodaj ocenę')
              }
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

// Funkcja pomocnicza do formatowania daty
function formatDate(dateString: string): string {
  const date = new Date(dateString);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  
  if (date.getTime() === today.getTime()) {
    return "Dzisiaj";
  } else if (date.getTime() === tomorrow.getTime()) {
    return "Jutro";
  } else if (date.getTime() === yesterday.getTime()) {
    return "Wczoraj";
  } else {
    return date.toLocaleDateString('pl-PL', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    });
  }
}

// Formatowanie daty i czasu
function formatDateTime(dateString: string): string {
  const date = new Date(dateString);
  return format(date, "dd.MM.yyyy HH:mm", { locale: pl });
}

// Funkcja zwracająca klasę dla obramowania karty na podstawie statusu
function getCardBorderClass(status: string): string {
  switch (status) {
    case 'fulfilled':
      return 'border-green-300';
    case 'active':
      return 'border-blue-300';
    case 'cancelled':
      return 'border-red-300';
    default:
      return '';
  }
}

// Funkcja zwracająca badge statusu
function getStatusBadge(status: string): React.ReactNode {
  switch (status) {
    case 'fulfilled':
      return (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
          <CheckCircle className="w-3 h-3 mr-1" />
          Zrealizowana
        </Badge>
      );
    case 'active':
      return (
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
          <AlertCircle className="w-3 h-3 mr-1" />
          Aktywna
        </Badge>
      );
    case 'cancelled':
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-300">
          <XCircle className="w-3 h-3 mr-1" />
          Anulowana
        </Badge>
      );
    default:
      return null;
  }
}