import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { X, Settings } from 'lucide-react';

export const DebugTools: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { toast } = useToast();

  const toggleDevTools = () => {
    setIsOpen(!isOpen);
  };

  const refreshPage = () => {
    window.location.reload();
    toast({
      title: 'Odświeżanie strony',
      description: 'Strona zostanie odświeżona za chwilę...',
    });
  };

  const clearLocalStorage = () => {
    localStorage.clear();
    toast({
      title: 'Wyczyszczono localStorage',
      description: 'Wszystkie dane z localStorage zostały usunięte.',
    });
  };

  const clearSessionStorage = () => {
    sessionStorage.clear();
    toast({
      title: 'Wyczyszczono sessionStorage',
      description: 'Wszystkie dane z sessionStorage zostały usunięte.',
    });
  };

  const logLocalStorageContents = () => {
    console.log('LocalStorage zawartość:', { ...localStorage });
    toast({
      title: 'Zapisano zawartość localStorage',
      description: 'Sprawdź konsolę przeglądarki.',
    });
  };

  return (
    <>
      {/* Przycisk aktywujący narzędzia deweloperskie */}
      <div 
        className="fixed bottom-4 right-4 z-50 bg-gray-800 rounded-full p-2 shadow-lg cursor-pointer"
        onClick={toggleDevTools}
      >
        <Settings className="h-6 w-6 text-white" />
      </div>

      {/* Panel narzędzi deweloperskich */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
          <Card className="w-[90%] max-w-md">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle>Narzędzia deweloperskie</CardTitle>
              <Button variant="ghost" size="icon" onClick={toggleDevTools}>
                <X className="h-5 w-5" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 gap-3">
                <Button onClick={refreshPage} variant="outline">
                  Odśwież stronę
                </Button>
                <Button onClick={clearLocalStorage} variant="outline">
                  Wyczyść localStorage
                </Button>
                <Button onClick={clearSessionStorage} variant="outline">
                  Wyczyść sessionStorage
                </Button>
                <Button onClick={logLocalStorageContents} variant="outline">
                  Pokaż localStorage w konsoli
                </Button>
                <Button 
                  onClick={() => {
                    console.log('Aktualny stan aplikacji:', {
                      url: window.location.href,
                      viewportWidth: window.innerWidth,
                      viewportHeight: window.innerHeight,
                      userAgent: navigator.userAgent
                    });
                    toast({
                      title: 'Zapisano stan aplikacji',
                      description: 'Sprawdź konsolę przeglądarki.',
                    });
                  }} 
                  variant="outline"
                >
                  Pokaż stan aplikacji
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </>
  );
};

export default DebugTools;