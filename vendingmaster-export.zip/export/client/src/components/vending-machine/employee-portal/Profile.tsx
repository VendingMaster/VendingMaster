import React, { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Employee, DIETARY_PREFERENCES, Chamber } from "@shared/schema";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { User, Smartphone, AtSign, CreditCard, Activity, Download, Maximize, Minimize, Box, LogOut } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ProfileProps {
  employee: Employee;
  onLogout?: () => void;
}

export const Profile: React.FC<ProfileProps> = ({ employee, onLogout }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Pobieranie informacji o szufladach przypisanych do pracownika
  const { data: chambers } = useQuery({
    queryKey: ['/api/chambers'],
    select: (data: any) => {
      // Obsługa nowej struktury odpowiedzi z API (zawierającej timestamp)
      const chambersArray = data.chambers || data;
      return chambersArray.filter((chamber: Chamber) => chamber.employeeId === employee.id);
    }
  });
  
  // Funkcja obsługująca otwieranie szuflady
  const handleOpenChamber = async (chamberId: number) => {
    try {
      toast({
        title: "Otwieranie szuflady",
        description: "Trwa wysyłanie polecenia otwarcia szuflady...",
      });
      
      // Wysłanie żądania do API
      const response = await fetch(`/api/mqtt/drawer/open/${chamberId}`, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        }
      });
      
      const data = await response.json();
      
      if (data.success) {
        toast({
          title: "Szuflada otwarta",
          description: `Szuflada #${chamberId} została otwarta.`,
        });
      } else {
        throw new Error(data.message || 'Nie udało się otworzyć szuflady');
      }
    } catch (error) {
      console.error('Błąd podczas otwierania szuflady:', error);
      toast({
        title: "Błąd",
        description: `Nie udało się otworzyć szuflady: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  };
  
  // Stan dla PWA
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstallable, setIsInstallable] = useState<boolean>(false);
  
  // Stan pełnego ekranu
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  
  // Funkcja pomocnicza do przewijania strony do góry - bardziej zdecydowane podejście
  const scrollToTop = () => {
    // Natychmiastowe przewinięcie
    document.documentElement.scrollTop = 0; // Dla Firefox
    document.body.scrollTop = 0; // Dla Safari
    window.scrollTo(0, 0); // Dla innych przeglądarek
    
    // Dodatkowe przewinięcie po małym opóźnieniu dla większej pewności
    setTimeout(() => {
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      window.scrollTo({
        top: 0,
        behavior: 'auto' // Natychmiastowe przewinięcie
      });
      
      // Jeszcze jedno przewinięcie dla pewności
      setTimeout(() => {
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        window.scrollTo(0, 0);
      }, 50);
    }, 10);
  };
  
  // Przewiń stronę do góry przy inicjalizacji komponentu
  useEffect(() => {
    scrollToTop();
  }, []);
  
  // Obsługa instalacji PWA
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      // Zapobieganie automatycznemu pokazaniu komunikatu o instalacji
      e.preventDefault();
      // Przechowanie zdarzenia, aby pokazać je później
      setDeferredPrompt(e);
      // Ustawienie flagi, że aplikacja może być zainstalowana
      setIsInstallable(true);
    };
    
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);
  
  // Śledzenie stanu pełnego ekranu
  useEffect(() => {
    const checkFullscreen = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    // Nasłuchiwanie na zmiany trybu pełnoekranowego
    document.addEventListener('fullscreenchange', checkFullscreen);
    
    // Sprawdzenie początkowego stanu
    checkFullscreen();
    
    return () => {
      document.removeEventListener('fullscreenchange', checkFullscreen);
    };
  }, []);
  
  // Funkcja obsługująca instalację PWA
  const handleInstallClick = () => {
    if (!deferredPrompt) {
      return;
    }
    
    // Pokazanie komunikatu o instalacji
    deferredPrompt.prompt();
    
    // Czekaj na wybór użytkownika
    deferredPrompt.userChoice.then((choiceResult: { outcome: string }) => {
      if (choiceResult.outcome === 'accepted') {
        toast({
          title: "Instalacja rozpoczęta",
          description: "Dziękujemy za zainstalowanie naszej aplikacji!",
        });
      }
      // Reset stanu promptu
      setDeferredPrompt(null);
      setIsInstallable(false);
    });
  };
  
  // Funkcja przełączająca tryb pełnoekranowy
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(err => {
        toast({
          title: "Błąd",
          description: "Nie udało się aktywować trybu pełnoekranowego",
          variant: "destructive"
        });
        console.error(`Błąd przejścia do trybu pełnoekranowego: ${err.message}`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().then(() => {
          setIsFullscreen(false);
        });
      }
    }
  };
  
  const getProfileImage = () => {
    const initials = `${employee.firstName.charAt(0)}${employee.lastName.charAt(0)}`;
    return (
      <div className="w-24 h-24 bg-primary rounded-full flex items-center justify-center text-primary-foreground text-3xl font-bold">
        {initials}
      </div>
    );
  };

  // Stany dla formularza zmiany hasła
  const [showPasswordForm, setShowPasswordForm] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordLoading, setPasswordLoading] = useState(false);
  
  // Funkcja obsługująca zmianę hasła
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Walidacja
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast({
        title: "Błąd walidacji",
        description: "Wszystkie pola są wymagane",
        variant: "destructive"
      });
      return;
    }
    
    if (newPassword !== confirmPassword) {
      toast({
        title: "Błąd walidacji",
        description: "Nowe hasło i jego potwierdzenie nie są zgodne",
        variant: "destructive"
      });
      return;
    }
    
    try {
      setPasswordLoading(true);
      
      // Wysyłamy żądanie zmiany hasła
      const response = await apiRequest(`/api/employees/${employee.id}/change-password`, {
        method: 'POST',
        data: {
          currentPassword,
          password: newPassword,
          confirmPassword: confirmPassword
        }
      });
      
      // Czyszczenie formularza
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      setShowPasswordForm(false);
      
      toast({
        title: "Sukces",
        description: "Twoje hasło zostało zmienione",
      });
    } catch (error) {
      console.error('Błąd podczas zmiany hasła:', error);
      toast({
        title: "Błąd",
        description: "Nie udało się zmienić hasła. Sprawdź, czy obecne hasło jest poprawne.",
        variant: "destructive"
      });
    } finally {
      setPasswordLoading(false);
    }
  };
  
  // Usunięto funkcję handleResetPassword, gdyż przycisk został usunięty

  // Funkcja aktualizująca preferencje żywieniowe
  const updateDietaryPreferencesMutation = useMutation({
    mutationFn: async (dietaryPreference: string) => {
      // Używamy apiRequest do wysłania żądania PATCH
      return apiRequest(`/api/employees/${employee.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          dietaryPreference
        })
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees/current'] });
      toast({
        title: "Preferencje zaktualizowane",
        description: "Twoje preferencje żywieniowe zostały zaktualizowane.",
      });
    },
    onError: () => {
      toast({
        title: "Błąd aktualizacji",
        description: "Nie udało się zaktualizować preferencji. Spróbuj ponownie później.",
        variant: "destructive",
      });
    }
  });

  return (
    <div className="space-y-6 mx-2.5">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold">Mój profil</h2>
        <p className="text-muted-foreground">
          Informacje o Twoim koncie i preferencjach
        </p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Dane osobowe</CardTitle>
          <CardDescription>
            Twoje podstawowe informacje
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col md:flex-row md:items-center gap-6">
            <div className="flex justify-center">
              {getProfileImage()}
            </div>
            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center text-muted-foreground">
                    <User className="mr-2 h-4 w-4" />
                    <Label>Imię i nazwisko</Label>
                  </div>
                  <div>{employee.firstName} {employee.lastName}</div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center text-muted-foreground">
                    <CreditCard className="mr-2 h-4 w-4" />
                    <Label>Numer karty RFID</Label>
                  </div>
                  <div>{employee.rfidCardNumber}</div>
                </div>

                {employee.email && (
                  <div className="space-y-2">
                    <div className="flex items-center text-muted-foreground">
                      <AtSign className="mr-2 h-4 w-4" />
                      <Label>Email</Label>
                    </div>
                    <div>{employee.email}</div>
                  </div>
                )}
                
                {/* Informacja o przypisanej szufladzie */}
                {chambers && chambers.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center text-muted-foreground">
                      <Box className="mr-2 h-4 w-4" />
                      <Label>Przypisana szuflada</Label>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {chambers && chambers.map((chamber: { id: number }) => (
                        <div key={chamber.id} className="flex flex-col gap-2">
                          <Badge variant="outline" className="p-1.5">
                            Szuflada #{chamber.id}
                          </Badge>
                          <Button 
                            size="sm" 
                            className="mt-1 flex items-center justify-center"
                            onClick={() => handleOpenChamber(chamber.id)}
                          >
                            <span className="flex items-center gap-1">
                              <Box className="h-3 w-3 mr-1" />
                              Otwórz szufladę
                            </span>
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col md:flex-row gap-4 md:justify-end">
          {/* Usunięto przycisk resetowania hasła, ponieważ funkcjonalność zmiany hasła jest dostępna w sekcji bezpieczeństwa */}
        </CardFooter>
      </Card>
      
      {/* Karta aplikacji mobilnej */}
      <Card>
        <CardHeader>
          <CardTitle>Aplikacja mobilna</CardTitle>
          <CardDescription>
            Zainstaluj aplikację na swoim urządzeniu
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-sm space-y-4">
            <p>
              Zainstaluj tę aplikację na swoim urządzeniu i korzystaj z niej w trybie offline.
              Będziesz mieć dostęp do rezerwacji posiłków i historii nawet bez połączenia z internetem.
            </p>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Smartphone className="h-4 w-4" />
              <span>Działa na telefonach i tabletach</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-3">
          {isInstallable ? (
            <Button 
              className="w-full flex items-center justify-center gap-2"
              onClick={handleInstallClick}
            >
              <Download className="h-4 w-4" />
              Zainstaluj aplikację
            </Button>
          ) : (
            <div className="text-center text-sm text-muted-foreground w-full mb-2">
              Aplikacja jest już zainstalowana lub nie może być zainstalowana na tym urządzeniu.
            </div>
          )}
          
          <Button 
            className="w-full flex items-center justify-center gap-2"
            variant="outline"
            onClick={toggleFullscreen}
          >
            {isFullscreen ? (
              <>
                <Minimize className="h-4 w-4" />
                Zamknij tryb pełnoekranowy
              </>
            ) : (
              <>
                <Maximize className="h-4 w-4" />
                Włącz tryb pełnoekranowy
              </>
            )}
          </Button>
        </CardFooter>
      </Card>
      
      {/* Karta bezpieczeństwa i wylogowania */}
      <Card>
        <CardHeader>
          <CardTitle>Bezpieczeństwo</CardTitle>
          <CardDescription>
            Opcje bezpieczeństwa i wylogowanie
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-sm space-y-4">
            <p>
              Pamiętaj, aby wylogować się z aplikacji po zakończeniu korzystania z niej, 
              szczególnie jeśli korzystasz z publicznego urządzenia.
            </p>
            
            {/* Przycisk zmiany hasła */}
            {!showPasswordForm && (
              <Button 
                variant="outline" 
                className="w-full md:w-auto mt-2"
                onClick={() => setShowPasswordForm(true)}
              >
                Zmień hasło
              </Button>
            )}
            
            {/* Formularz zmiany hasła */}
            {showPasswordForm && (
              <form onSubmit={handleChangePassword} className="mt-4 space-y-3 pt-2 border-t border-gray-100">
                <h4 className="font-medium">Zmiana hasła</h4>
                
                <div className="space-y-2">
                  <label className="block text-sm">
                    Aktualne hasło
                    <input
                      type="password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md text-sm"
                      required
                    />
                  </label>
                </div>
                
                <div className="space-y-2">
                  <label className="block text-sm">
                    Nowe hasło
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md text-sm"
                      required
                    />
                  </label>
                </div>
                
                <div className="space-y-2">
                  <label className="block text-sm">
                    Potwierdź nowe hasło
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md text-sm"
                      required
                    />
                  </label>
                </div>
                
                <div className="flex gap-2 mt-3">
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setShowPasswordForm(false);
                      setCurrentPassword('');
                      setNewPassword('');
                      setConfirmPassword('');
                    }}
                  >
                    Anuluj
                  </Button>
                  <Button 
                    type="submit" 
                    size="sm"
                    disabled={passwordLoading}
                  >
                    {passwordLoading ? 'Zapisywanie...' : 'Zmień hasło'}
                  </Button>
                </div>
              </form>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex flex-col md:flex-row gap-4">
          <Button 
            variant="destructive" 
            onClick={onLogout}
            className="flex items-center justify-center gap-2 w-full md:w-auto"
          >
            <LogOut className="h-4 w-4" />
            Wyloguj się
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};