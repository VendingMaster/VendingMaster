import React, { useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Employee, DIETARY_PREFERENCES } from "@shared/schema";
import { Activity, Apple, Beef, Fish, EggFried, Milk, Wheat, AlertTriangle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Badge } from "@/components/ui/badge";

interface DietaryPreferencesProps {
  employee: Employee;
}

export const DietaryPreferences: React.FC<DietaryPreferencesProps> = ({ employee }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Funkcja pomocnicza do przewijania strony do góry - bardziej zdecydowane podejście
  const scrollToTop = () => {
    // Natychmiastowe przewinięcie
    document.documentElement.scrollTop = 0; // Dla Firefox
    document.body.scrollTop = 0; // Dla Safari
    window.scrollTo(0, 0); // Dla innych przeglądarek
    
    // Dodatkowe przewinięcie po małym opóźnieniu dla większej pewności
    setTimeout(() => {
      document.documentElement.scrollTop = 0;
      document.body.scrollTop = 0;
      window.scrollTo({
        top: 0,
        behavior: 'auto' // Natychmiastowe przewinięcie
      });
      
      // Jeszcze jedno przewinięcie dla pewności
      setTimeout(() => {
        document.documentElement.scrollTop = 0;
        document.body.scrollTop = 0;
        window.scrollTo(0, 0);
      }, 50);
    }, 10);
  };
  
  // Przewiń stronę do góry przy inicjalizacji komponentu
  useEffect(() => {
    scrollToTop();
  }, []);
  
  // Funkcja aktualizująca preferencje żywieniowe
  const updateDietaryPreferencesMutation = useMutation({
    mutationFn: async (newPreference: string) => {
      console.log(`Żądanie zmiany preferencji: ${newPreference}`);
      
      // Pobieramy aktualne dane pracownika, aby zaktualizować tylko preferencje
      const employeeData = {
        firstName: employee.firstName,
        lastName: employee.lastName,
        rfidCardNumber: employee.rfidCardNumber,
        rfidCardFormat: employee.rfidCardFormat,
        email: employee.email,
        dietaryPreference: newPreference  // Ustawiamy nową preferencję
      };
      
      // Używamy fetch bezpośrednio zamiast apiRequest
      const response = await fetch(`/api/employees/${employee.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(employeeData)
      });
      
      if (!response.ok) {
        throw new Error(`Błąd HTTP: ${response.status}`);
      }
      
      return newPreference; // Zwracamy nową preferencję zamiast odpowiedzi API
    },
    onSuccess: (newPreference) => {
      console.log(`Zapisano nową preferencję: ${newPreference}`);
      
      // Tworzymy zaktualizowany obiekt pracownika z nową preferencją
      const updatedEmployee = {
        ...employee,
        dietaryPreference: newPreference
      };
      
      // Zapisujemy zaktualizowane dane w localStorage
      try {
        localStorage.setItem('currentEmployee', JSON.stringify(updatedEmployee));
        console.log('Zaktualizowano dane pracownika w localStorage:', updatedEmployee);
      } catch (error) {
        console.error('Błąd podczas zapisywania do localStorage:', error);
      }
      
      // Wyświetl powiadomienie
      toast({
        title: "Preferencje zaktualizowane",
        description: "Twoje preferencje żywieniowe zostały zaktualizowane.",
      });
      
      // Odśwież stronę po krótkiej chwili, aby toast był widoczny
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    },
    onError: () => {
      toast({
        title: "Błąd aktualizacji",
        description: "Nie udało się zaktualizować preferencji. Spróbuj ponownie później.",
        variant: "destructive",
      });
    }
  });

  const getPreferenceIcon = (preference: string) => {
    switch(preference) {
      case "Wegetariańska":
        return <Apple className="h-4 w-4 mr-2" />;
      case "Wegańska":
        return <Apple className="h-4 w-4 mr-2" />;
      case "Bezglutenowa":
        return <Wheat className="h-4 w-4 mr-2" />;
      case "Bezlaktozowa":
        return <Milk className="h-4 w-4 mr-2" />;
      case "Bez jajek":
        return <EggFried className="h-4 w-4 mr-2" />;
      case "Bez ryb":
        return <Fish className="h-4 w-4 mr-2" />;
      case "Bez wieprzowiny":
        return <Beef className="h-4 w-4 mr-2" />;
      default:
        return <Activity className="h-4 w-4 mr-2" />;
    }
  };

  return (
    <div className="space-y-6 mx-2.5">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold">Preferencje żywieniowe</h2>
        <p className="text-muted-foreground">
          Określ swoje preferencje, które pomogą w doborze posiłków
        </p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Activity className="h-5 w-5 mr-2" />
            Twoja aktualna preferencja
          </CardTitle>
          <CardDescription>
            Twoja preferencja będzie uwzględniana przy rekomendowaniu posiłków
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-6">
            {employee.dietaryPreference ? (
              <Badge className="text-lg py-2 px-4">
                {getPreferenceIcon(employee.dietaryPreference)}
                {employee.dietaryPreference}
              </Badge>
            ) : (
              <div className="text-center text-muted-foreground flex flex-col items-center">
                <AlertTriangle className="h-10 w-10 mb-2 text-yellow-500" />
                <span>Nie wybrano preferencji żywieniowych</span>
                <span className="text-sm mt-1">Wybierz jedną z opcji poniżej</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Apple className="h-5 w-5 mr-2" />
            Wybierz preferencję
          </CardTitle>
          <CardDescription>
            Kliknij jedną z opcji, aby wybrać swoją preferencję żywieniową
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {DIETARY_PREFERENCES.map(preference => (
              <Button
                key={preference}
                variant={employee.dietaryPreference === preference ? "default" : "outline"}
                className="justify-start"
                onClick={() => updateDietaryPreferencesMutation.mutate(preference)}
              >
                {getPreferenceIcon(preference)}
                {preference}
              </Button>
            ))}
          </div>
        </CardContent>
        <CardFooter className="flex justify-between items-center">
          <Button 
            variant="ghost" 
            className="text-muted-foreground"
            onClick={() => updateDietaryPreferencesMutation.mutate("")}
          >
            Resetuj preferencje
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            Ważne informacje
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm space-y-4">
          <p>
            Określenie preferencji żywieniowych pomaga systemowi w lepszym dopasowaniu posiłków do Twoich potrzeb. 
            Twoje preferencje będą uwzględniane przy wyświetlaniu zaleceń na stronie wyboru posiłków.
          </p>
          <p>
            Pamiętaj, że wybór preferencji nie oznacza automatycznego filtrowania posiłków - nadal będziesz widzieć wszystkie 
            dostępne opcje, ale system będzie podkreślał te, które najbardziej odpowiadają Twoim preferencjom.
          </p>
          <p className="font-medium text-primary">
            Jeśli nie wybierzesz posiłku na dany dzień, wybierzemy go dla Ciebie automatycznie według Twoich preferencji.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};