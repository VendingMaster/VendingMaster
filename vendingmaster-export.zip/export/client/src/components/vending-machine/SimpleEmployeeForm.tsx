import React, { useState, useEffect } from 'react';
import { 
  Employee, 
  InsertEmployee, 
  RFID_CARD_FORMATS, 
  DIETARY_PREFERENCES 
} from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface SimpleEmployeeFormProps {
  employee: Employee | null;
  isOpen: boolean;
  onClose: () => void;
}

export const SimpleEmployeeForm: React.FC<SimpleEmployeeFormProps> = ({ employee, isOpen, onClose }) => {
  const { toast } = useToast();
  
  // Zdefiniuj stan dla wszystkich pól formularza
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [rfidCardNumber, setRfidCardNumber] = useState('');
  const [rfidCardFormat, setRfidCardFormat] = useState<'decimal' | 'hex'>('decimal');
  const [email, setEmail] = useState('');
  // Używamy dokładnego typu z DIETARY_PREFERENCES lub null
  const [dietaryPreference, setDietaryPreference] = useState<typeof DIETARY_PREFERENCES[number] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  // Dodajemy stan, czy formularz został zainicjowany
  const [isInitialized, setIsInitialized] = useState(false);

  console.log('SimpleEmployeeForm - renderowanie, isOpen:', isOpen, 'zainicjalizowany:', isInitialized);
  console.log('SimpleEmployeeForm - employee:', employee);

  // Aktualizuj formularz, gdy zmieni się pracownik
  useEffect(() => {
    console.log('SimpleEmployeeForm - useEffect [employee, isOpen, isInitialized]');
    console.log('employee:', employee);
    console.log('isOpen:', isOpen);
    console.log('isInitialized:', isInitialized);
    
    // Jeśli formularz jest zamknięty i ponownie otwarty, zresetujmy stan inicjalizacji
    if (!isOpen) {
      if (isInitialized) {
        setIsInitialized(false);
        console.log('Zresetowano stan inicjalizacji formularza');
      }
      return;
    }
    
    // Unikaj powtórnej inicjalizacji
    if (isInitialized) {
      console.log('Formularz już zainicjalizowany, pomijam');
      return;
    }
    
    if (employee && isOpen) {
      try {
        console.log('Inicjalizacja formularza dla pracownika:', employee.id);
        setFirstName(employee.firstName || '');
        setLastName(employee.lastName || '');
        setRfidCardNumber(employee.rfidCardNumber || '');
        setRfidCardFormat(employee.rfidCardFormat as 'decimal' | 'hex' || 'decimal');
        setEmail(employee.email || '');
        
        // Bezpieczne ustawienie preferencji dietetycznej z typem
        if (employee.dietaryPreference && 
            DIETARY_PREFERENCES.includes(employee.dietaryPreference as any)) {
          // Używamy jawnego rzutowania, aby uspokoić TypeScript
          const typedPreference = employee.dietaryPreference as typeof DIETARY_PREFERENCES[number];
          setDietaryPreference(typedPreference);
        } else {
          setDietaryPreference(null);
        }
        
        setIsInitialized(true);
        console.log('Formularz zainicjalizowany danymi pracownika');
      } catch (error) {
        console.error('Błąd podczas inicjalizacji formularza:', error);
      }
    } else if (!employee && isOpen) {
      // Resetowanie formularza dla nowego pracownika
      try {
        console.log('Inicjalizacja formularza dla nowego pracownika');
        setFirstName('');
        setLastName('');
        setRfidCardNumber('');
        setRfidCardFormat('decimal');
        setEmail('');
        setDietaryPreference(null);
        setIsInitialized(true);
        console.log('Formularz zresetowany dla nowego pracownika');
      } catch (error) {
        console.error('Błąd podczas resetowania formularza:', error);
      }
    }
  }, [employee, isOpen, isInitialized]);

  // Funkcja do zapisywania danych pracownika
  const handleSave = async () => {
    try {
      console.log('Zapisywanie danych pracownika...');
      setIsLoading(true);
      
      // Walidacja podstawowa
      if (!firstName || !lastName || !rfidCardNumber) {
        toast({
          title: 'Błąd',
          description: 'Proszę wypełnić wszystkie wymagane pola (imię, nazwisko, numer RFID)',
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }
      
      // Dodatkowa walidacja numeru RFID
      if (rfidCardFormat === 'hex' && !/^[0-9A-Fa-f]+$/.test(rfidCardNumber)) {
        toast({
          title: 'Błąd',
          description: 'Numer karty RFID w formacie HEX powinien zawierać tylko znaki 0-9 i A-F',
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }
      
      if (rfidCardFormat === 'decimal' && !/^\d+$/.test(rfidCardNumber)) {
        toast({
          title: 'Błąd',
          description: 'Numer karty RFID w formacie dziesiętnym powinien zawierać tylko cyfry',
          variant: 'destructive',
        });
        setIsLoading(false);
        return;
      }
      
      // Obiekt z danymi pracownika
      const employeeData: InsertEmployee = {
        firstName,
        lastName,
        rfidCardNumber,
        rfidCardFormat,
        email: email || '',
        dietaryPreference,
      };
      
      console.log('Dane do zapisania:', employeeData);
      
      if (employee) {
        // Aktualizacja istniejącego pracownika
        await apiRequest(`/api/employees/${employee.id}`, {
          method: 'PUT',
          data: employeeData,
        });
        
        toast({
          title: 'Sukces',
          description: 'Dane pracownika zostały zaktualizowane',
        });
      } else {
        // Dodanie nowego pracownika
        await apiRequest('/api/employees', {
          method: 'POST',
          data: employeeData,
        });
        
        toast({
          title: 'Sukces',
          description: 'Nowy pracownik został dodany',
        });
      }
      
      // Odśwież cache zapytań
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      
      // Zamknij formularz
      onClose();
    } catch (error) {
      console.error('Błąd podczas zapisywania pracownika:', error);
      toast({
        title: 'Błąd',
        description: 'Wystąpił błąd podczas zapisywania danych pracownika',
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{employee ? 'Edytuj pracownika' : 'Dodaj nowego pracownika'}</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="firstName">Imię</Label>
            <Input
              id="firstName"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder="Jan"
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="lastName">Nazwisko</Label>
            <Input
              id="lastName"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              placeholder="Kowalski"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="rfidCardNumber">Numer karty RFID</Label>
              <Input
                id="rfidCardNumber"
                value={rfidCardNumber}
                onChange={(e) => setRfidCardNumber(e.target.value)}
                placeholder="1234567890"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="rfidCardFormat">Format karty</Label>
              <Select
                value={rfidCardFormat}
                onValueChange={(value: 'decimal' | 'hex') => setRfidCardFormat(value)}
              >
                <SelectTrigger id="rfidCardFormat">
                  <SelectValue placeholder="Wybierz format" />
                </SelectTrigger>
                <SelectContent>
                  {RFID_CARD_FORMATS.map((format) => (
                    <SelectItem key={format} value={format}>
                      {format === 'decimal' ? 'Decimal (123456)' : 'HEX (1A2B3C)'}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="email">Email (opcjonalnie)</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jan.kowalski@przykład.pl"
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="dietaryPreference">Preferencja dietetyczna</Label>
            <Select
              value={dietaryPreference || ''}
              onValueChange={(value) => {
                if (value === '') {
                  setDietaryPreference(null);
                } else {
                  // Sprawdzamy, czy wartość jest jedną z dozwolonych preferencji dietetycznych
                  if (DIETARY_PREFERENCES.includes(value as any)) {
                    setDietaryPreference(value as typeof DIETARY_PREFERENCES[number]);
                  }
                }
              }}
            >
              <SelectTrigger id="dietaryPreference">
                <SelectValue placeholder="Wybierz preferencję dietetyczną" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">Brak preferencji</SelectItem>
                {DIETARY_PREFERENCES.map((preference) => (
                  <SelectItem key={preference} value={preference}>
                    {preference}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Anuluj
          </Button>
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? 'Zapisywanie...' : employee ? 'Zapisz zmiany' : 'Dodaj pracownika'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};