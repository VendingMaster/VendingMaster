import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Chamber, Employee, Product } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, Info } from 'lucide-react';

interface EmployeeChamberAssignmentProps {
  employee: Employee;
  isOpen: boolean;
  onClose: () => void;
}

export const EmployeeChamberAssignment: React.FC<EmployeeChamberAssignmentProps> = ({
  employee,
  isOpen,
  onClose
}) => {
  // Flaga wskazująca, czy dokonano zmian w przypisaniu
  const [changesApplied, setChangesApplied] = useState(false);
  const { toast } = useToast();
  const [selectedChamberId, setSelectedChamberId] = useState<string>("");
  const [selectedProductId, setSelectedProductId] = useState<string>("");
  
  // Pobieranie produktów
  const { data: products = [], isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await apiRequest<Product[]>('/api/products');
      return response;
    }
  });
  
  // Pobieranie szuflad, które można przypisać (nieprzypisane do innych pracowników)
  const { data: chambersData = { chambers: [], timestamp: 0 }, isLoading: isLoadingChambers, refetch: refetchChambers } = useQuery({
    queryKey: ['/api/chambers'],
    queryFn: async () => {
      const response = await apiRequest<{chambers: Chamber[], timestamp: number}>('/api/chambers');
      return response;
    },
    staleTime: 0, // Zawsze pobieraj świeże dane
    refetchInterval: 2000 // Odświeżaj co 2 sekundy
  });
  
  // Filtrowanie szuflad, które są dostępne dla pracownika
  const chambers = (chambersData.chambers || []).filter(chamber => 
    !chamber.employeeId || chamber.employeeId === employee.id
  );
  
  // Pobieranie szuflad przypisanych do pracownika
  const { data: assignedChambersData = { chambers: [], timestamp: 0 }, refetch: refetchAssignedChambers } = useQuery({
    queryKey: ['/api/chambers', 'employee', employee.id],
    queryFn: async () => {
      const response = await apiRequest<{chambers: Chamber[], timestamp: number}>('/api/chambers');
      return response;
    },
    staleTime: 0, // Zawsze pobieraj świeże dane
    refetchInterval: 2000 // Odświeżaj co 2 sekundy
  });
  
  // Filtrowanie szuflad przypisanych do pracownika
  const assignedChambers = (assignedChambersData.chambers || []).filter(chamber => 
    chamber.employeeId === employee.id
  );
  
  const handleAssignChamber = async () => {
    if (!selectedChamberId) {
      toast({
        title: "Błąd",
        description: "Wybierz szufladę do przypisania.",
        variant: "destructive",
      });
      return;
    }
    
    try {
      console.log("[UI] Przypisywanie szuflady poprzez dedykowany endpoint...");
      
      // Pobierz aktualne przypisane szuflady, aby porównać po operacji
      const currentAssignedChambers = [...assignedChambers];
      
      // Dodajemy losowy parametr timestamp, aby obejść cache
      const randomParam = new Date().getTime();
      
      const response = await apiRequest(`/api/chambers/assign-employee?t=${randomParam}`, {
        method: 'POST',
        data: {
          chamberId: parseInt(selectedChamberId),
          employeeId: employee.id
        }
      });
      
      // Oznacz, że dokonano zmian w przypisaniu
      setChangesApplied(true);
      
      // Odśwież dane w całej aplikacji, wymuszone pobieranie świeżych danych
      await queryClient.invalidateQueries({ queryKey: ['/api/chambers'], refetchType: 'all' });
      await queryClient.invalidateQueries({ queryKey: ['/api/chambers', 'employee', employee.id], refetchType: 'all' });
      
      // Wykonaj bezpośrednie ponowne żądania, aby uniknąć cache
      await refetchChambers();
      await refetchAssignedChambers();
      
      // Sprawdź, czy usunięto jakieś poprzednie przypisania
      if (response.previousAssignmentsRemoved) {
        toast({
          title: "Sukces",
          description: "Szuflada została przypisana do pracownika. Poprzednie przypisanie zostało usunięte.",
        });
      } else {
        toast({
          title: "Sukces",
          description: "Szuflada została przypisana do pracownika.",
        });
      }
      
      setSelectedChamberId("");
      setSelectedProductId("");
      
      // Upewnij się, że tylko jedna szuflada jest przypisana
      setTimeout(async () => {
        const response = await apiRequest<{chambers: Chamber[], timestamp: number}>('/api/chambers');
        const stillAssigned = response.chambers.filter(c => c.employeeId === employee.id);
        
        if (stillAssigned.length > 1) {
          console.log("[UI] Wykryto wiele przypisanych szuflad, czyszczenie...");
          
          // Zachowaj tylko najnowszą szufladę, usuń resztę
          const targetChamber = stillAssigned.find(c => c.id === parseInt(selectedChamberId));
          const chambersToClean = stillAssigned.filter(c => c.id !== parseInt(selectedChamberId));
          
          for (const chamber of chambersToClean) {
            await apiRequest(`/api/chambers/${chamber.id}`, {
              method: 'PUT',
              data: {
                employeeId: null,
                productId: null,
                isAvailable: false
              }
            });
            console.log(`[UI] Usunięto dodatkową szufladę ${chamber.id}`);
          }
          
          // Odśwież dane po czyszczeniu
          queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
          queryClient.invalidateQueries({ queryKey: ['/api/chambers', 'employee', employee.id] });
        }
      }, 500);
    } catch (error) {
      console.error("[UI] Błąd podczas przypisywania szuflady:", error);
      toast({
        title: "Błąd",
        description: "Nie udało się przypisać szuflady do pracownika.",
        variant: "destructive",
      });
    }
  };
  
  const handleRemoveChamberAssignment = async (chamberId: number) => {
    try {
      console.log(`[UI] Usuwanie przypisania szuflady ${chamberId}...`);
      
      await apiRequest(`/api/chambers/${chamberId}`, {
        method: 'PUT',
        data: {
          employeeId: null,
          productId: null,
          isAvailable: false
        }
      });
      
      // Oznacz, że dokonano zmian w przypisaniu
      setChangesApplied(true);
      
      // Odśwież dane tylko w bieżącym komponencie
      await queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      await queryClient.invalidateQueries({ queryKey: ['/api/chambers', 'employee', employee.id] });
      
      toast({
        title: "Sukces",
        description: "Przypisanie szuflady zostało usunięte.",
      });
      
      // Dodatkowe sprawdzenie, czy wszystkie przypisania zostały usunięte
      setTimeout(async () => {
        const response = await apiRequest<{chambers: Chamber[], timestamp: number}>('/api/chambers');
        const stillAssigned = response.chambers.filter(c => c.employeeId === employee.id);
        
        if (stillAssigned.length > 0) {
          console.log(`[UI] Wykryto ${stillAssigned.length} szuflad nadal przypisanych po usunięciu, czyszczenie...`);
          
          for (const chamber of stillAssigned) {
            await apiRequest(`/api/chambers/${chamber.id}`, {
              method: 'PUT',
              data: {
                employeeId: null,
                productId: chamber.productId, // Zachowaj produkt
                isAvailable: chamber.isAvailable
              }
            });
            console.log(`[UI] Oczyszczono dodatkową szufladę ${chamber.id}`);
          }
          
          // Odśwież dane po czyszczeniu
          queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
          queryClient.invalidateQueries({ queryKey: ['/api/chambers', 'employee', employee.id] });
        }
      }, 500);
    } catch (error) {
      console.error("[UI] Błąd podczas usuwania przypisania szuflady:", error);
      toast({
        title: "Błąd",
        description: "Nie udało się usunąć przypisania szuflady.",
        variant: "destructive",
      });
    }
  };
  
  const hasAssignedChamber = assignedChambers.length > 0;
  
  // Efekt do śledzenia zmian - gdy komponent się zamyka, sprawdzamy czy były zmiany
  React.useEffect(() => {
    if (!isOpen && changesApplied) {
      // Odśwież dane o szufladach w całej aplikacji
      console.log("[UI] Zamykanie komponentu przypisania szuflady - odświeżanie danych...");
      queryClient.refetchQueries({ queryKey: ['/api/chambers'] });
      
      // Po zakończeniu wszystkich operacji resetuj flagę zmian
      setChangesApplied(false);
    }
  }, [isOpen, changesApplied]);
  
  // Aktualizuj dane przy każdym otwarciu dialogu
  React.useEffect(() => {
    if (isOpen) {
      console.log("[UI] Otwarto dialog przypisania szuflady - odświeżanie danych...");
      refetchChambers();
      refetchAssignedChambers();
    }
  }, [isOpen, refetchChambers, refetchAssignedChambers]);
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Przypisanie szuflady dla pracownika</DialogTitle>
          <DialogDescription>
            Przypisz szufladę z posiłkami abonamentowymi dla pracownika: {`${employee.firstName} ${employee.lastName}`}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Alert o limicie szuflad */}
          <Alert className="bg-blue-50">
            <Info className="h-4 w-4" />
            <AlertTitle>Informacja</AlertTitle>
            <AlertDescription>
              Pracownik może mieć przypisaną tylko jedną szufladę. Przypisanie nowej szuflady spowoduje usunięcie poprzedniego przypisania.
            </AlertDescription>
          </Alert>
          
          {/* Aktualnie przypisane szuflady */}
          <div>
            <h3 className="text-lg font-medium mb-2">Aktualnie przypisana szuflada</h3>
            {assignedChambers.length === 0 ? (
              <p className="text-sm text-muted-foreground">Brak przypisanej szuflady</p>
            ) : (
              <div className="space-y-2">
                {assignedChambers.map(chamber => {
                  const product = products.find(p => p.id === chamber.productId);
                  return (
                    <Card key={chamber.id} className="relative overflow-hidden">
                      <CardContent className="p-4 flex justify-between items-center">
                        <div>
                          <p className="font-medium">Szuflada {chamber.id}</p>
                          {product ? (
                            <p className="text-sm">{product.name}</p>
                          ) : (
                            <p className="text-sm text-muted-foreground">Brak przypisanego produktu</p>
                          )}
                        </div>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => handleRemoveChamberAssignment(chamber.id)}
                        >
                          Usuń
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
          
          {/* Formularz przypisania nowej szuflady */}
          <div className="space-y-4 border-t pt-4">
            <h3 className="text-lg font-medium">
              {hasAssignedChamber ? "Zmień przypisaną szufladę" : "Przypisz nową szufladę"}
            </h3>
            
            <div className="space-y-2">
              <Label htmlFor="chamber-select">Wybierz szufladę</Label>
              <Select
                value={selectedChamberId}
                onValueChange={setSelectedChamberId}
              >
                <SelectTrigger id="chamber-select">
                  <SelectValue placeholder="Wybierz szufladę" />
                </SelectTrigger>
                <SelectContent>
                  {isLoadingChambers ? (
                    <SelectItem value="loading" disabled>Ładowanie szuflad...</SelectItem>
                  ) : chambers.length === 0 ? (
                    <SelectItem value="empty" disabled>Brak dostępnych szuflad</SelectItem>
                  ) : (
                    chambers
                      .filter(chamber => !chamber.employeeId)
                      .map(chamber => (
                        <SelectItem key={chamber.id} value={chamber.id.toString()}>
                          Szuflada {chamber.id}
                        </SelectItem>
                      ))
                  )}
                </SelectContent>
              </Select>
            </div>
            
            {selectedChamberId && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Wybierz produkt (opcjonalnie)</Label>
                </div>
                <RadioGroup 
                  value={selectedProductId} 
                  onValueChange={setSelectedProductId}
                  className="space-y-2 max-h-[200px] overflow-y-auto"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="" id="product-none" />
                    <Label htmlFor="product-none">Bez produktu</Label>
                  </div>
                  
                  {isLoadingProducts ? (
                    <div>Ładowanie produktów...</div>
                  ) : (
                    products.slice(0, 10).map(product => (
                      <div key={product.id} className="flex items-center space-x-2">
                        <RadioGroupItem value={product.id.toString()} id={`product-${product.id}`} />
                        <Label htmlFor={`product-${product.id}`}>
                          {product.name}
                        </Label>
                      </div>
                    ))
                  )}
                  
                  {products.length > 10 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      Wyświetlam 10 pierwszych produktów. Łącznie produktów: {products.length}
                    </p>
                  )}
                </RadioGroup>
              </div>
            )}
          </div>
        </div>
        
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={onClose}>
            Anuluj
          </Button>
          <Button 
            onClick={handleAssignChamber}
            disabled={!selectedChamberId}
          >
            {hasAssignedChamber ? "Zmień szufladę" : "Przypisz szufladę"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};