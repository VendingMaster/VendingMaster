import React from 'react';
import { Button } from "@/components/ui/button";
import { ShoppingBag, Trash } from "lucide-react";

interface UsageButtonProps {
  onClick: () => void;
  type: 'usage' | 'dispose';
}

/**
 * Przycisk akcji Rozchód/Utylizacja
 */
const UsageButton: React.FC<UsageButtonProps> = ({ onClick, type }) => {
  if (type === 'usage') {
    return (
      <Button 
        variant="outline" 
        size="sm"
        onClick={onClick}
        className="flex items-center gap-1 bg-gradient-to-r from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 text-blue-600 border-blue-200"
      >
        <ShoppingBag className="h-4 w-4" />
        <span>Rozchód</span>
      </Button>
    );
  } else {
    return (
      <Button 
        variant="destructive" 
        size="sm"
        onClick={onClick}
        className="flex items-center bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700"
      >
        <Trash className="h-4 w-4" />
      </Button>
    );
  }
};

export default UsageButton;