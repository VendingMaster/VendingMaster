import React, { useState } from 'react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Product } from '@shared/schema';
import { X } from 'lucide-react';
import { useQueryClient, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface ProductDetailProps {
  product: Product;
  chamberId: number | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({ 
  product, 
  chamberId,
  isOpen, 
  onClose 
}) => {
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [isPurchased, setIsPurchased] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const resetChamberMutation = useMutation({
    mutationFn: async () => {
      if (!chamberId) return null;
      await apiRequest(`/api/chambers/${chamberId}/product`, { method: 'DELETE' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      setIsPurchasing(false);
      setIsPurchased(true);
      
      toast({
        title: "Produkt zakupiony",
        description: `Twój ${product.name} został wydany z automatu. Smacznego!`,
      });
      
      // Zamknij okno po 3 sekundach od zakupu
      setTimeout(() => {
        onClose();
        setIsPurchased(false);
      }, 3000);
    },
    onError: (error) => {
      setIsPurchasing(false);
      toast({
        title: "Błąd",
        description: `Nie udało się zakupić produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  const handlePurchase = () => {
    setIsPurchasing(true);
    
    // Symulacja procesu zakupu (opóźnienie 1.5s)
    setTimeout(() => {
      resetChamberMutation.mutate();
    }, 1500);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden rounded-lg">
        <DialogTitle className="sr-only">Szczegóły produktu</DialogTitle>
        <DialogDescription className="sr-only">Informacje o produkcie, wartości odżywcze i opcja zakupu</DialogDescription>
        
        <button 
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-500 hover:text-gray-700 z-10"
          disabled={isPurchasing}
        >
          <X className="h-6 w-6" />
        </button>
        
        <div className="md:flex">
          <div className="md:w-1/2 overflow-hidden md:rounded-l-lg">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-full object-cover min-h-[350px]" 
            />
          </div>
          <div className="p-6 md:w-1/2">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-gray-800">{product.name}</h2>
              <p className="text-primary text-xl font-medium mt-1">{product.price.toFixed(2)} zł</p>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-gray-700 mb-2">Opis</h3>
              <p className="text-gray-600">{product.longDescription}</p>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-gray-700 mb-2">Wartości odżywcze (na 100g)</h3>
              <div className="bg-gray-50 p-3 rounded-md">
                <table className="w-full text-sm nutrition-table">
                  <tbody>
                    {(() => {
                      // Konwersja na poprawny typ
                      const nutritionFacts = product.nutritionFacts as {
                        energyValue: number;
                        fat: number;
                        saturatedFat: number;
                        carbs: number;
                        sugars: number;
                        protein: number;
                        salt: number;
                      };
                      
                      return (
                        <>
                          <tr className="border-b border-gray-200">
                            <td className="py-1.5">Wartość energetyczna</td>
                            <td className="py-1.5 text-right">{nutritionFacts.energyValue} kcal</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="py-1.5">Tłuszcz</td>
                            <td className="py-1.5 text-right">{nutritionFacts.fat} g</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="py-1.5 pl-4 text-gray-600">w tym kwasy nasycone</td>
                            <td className="py-1.5 text-right">{nutritionFacts.saturatedFat} g</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="py-1.5">Węglowodany</td>
                            <td className="py-1.5 text-right">{nutritionFacts.carbs} g</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="py-1.5 pl-4 text-gray-600">w tym cukry</td>
                            <td className="py-1.5 text-right">{nutritionFacts.sugars} g</td>
                          </tr>
                          <tr className="border-b border-gray-200">
                            <td className="py-1.5">Białko</td>
                            <td className="py-1.5 text-right">{nutritionFacts.protein} g</td>
                          </tr>
                          <tr>
                            <td className="py-1.5">Sól</td>
                            <td className="py-1.5 text-right">{nutritionFacts.salt} g</td>
                          </tr>
                        </>
                      )
                    })()}
                  </tbody>
                </table>
              </div>
            </div>
            
            <div className="flex justify-between items-center">
              <div className="text-sm text-gray-600">
                Komora: #{chamberId?.toString().padStart(2, '0')}
              </div>
              {isPurchased ? (
                <div className="bg-green-100 text-green-700 px-4 py-2 rounded-md font-medium">
                  Produkt zakupiony!
                </div>
              ) : (
                <Button 
                  onClick={handlePurchase} 
                  disabled={isPurchasing}
                  className={isPurchasing ? "cursor-not-allowed" : ""}
                >
                  {isPurchasing ? 'Realizacja...' : 'Kup teraz'}
                </Button>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
