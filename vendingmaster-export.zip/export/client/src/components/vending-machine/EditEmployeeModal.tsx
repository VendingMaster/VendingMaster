import * as React from 'react';
import { useState, useEffect } from 'react';
import { useMutation } from '@tanstack/react-query';
import { 
  Employee, 
  InsertEmployee, 
  RFID_CARD_FORMATS, 
  DIETARY_PREFERENCES 
} from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface EditEmployeeModalProps {
  employee: Employee | null;
  isOpen: boolean;
  onClose: () => void;
}

// Ta funkcja jest bezpieczna do wywołania w komponencie
const safeLog = (message: string, data?: any) => {
  try {
    if (data) {
      console.log(`[EditEmployeeModal] ${message}`, data);
    } else {
      console.log(`[EditEmployeeModal] ${message}`);
    }
  } catch (e) {
    console.log(`[EditEmployeeModal] Błąd podczas logowania:`, e);
  }
};

const EditEmployeeModal: React.FC<EditEmployeeModalProps> = ({ employee, isOpen, onClose }) => {
  safeLog(`Rendering komponenetu, isOpen=${isOpen}, employee=`, employee);
  const { toast } = useToast();
  
  // Zdefiniuj stan dla wszystkich pól formularza
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [rfidCardNumber, setRfidCardNumber] = useState('');
  const [rfidCardFormat, setRfidCardFormat] = useState<'decimal' | 'hex'>('decimal');
  const [email, setEmail] = useState('');
  // Używamy 'as any' żeby uniknąć problemów z typami w DIETARY_PREFERENCES
  const [dietaryPreference, setDietaryPreference] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Aktualizuj formularz, gdy zmieni się pracownik
  useEffect(() => {
    try {
      safeLog(`useEffect triggered, employee=`, employee);
      safeLog(`useEffect triggered, isOpen=`, isOpen);
      
      if (employee && isOpen) {
        safeLog('Inicjalizacja formularza z danymi pracownika:', employee);
        setFirstName(employee.firstName || '');
        setLastName(employee.lastName || '');
        setRfidCardNumber(employee.rfidCardNumber || '');
        setRfidCardFormat(employee.rfidCardFormat as 'decimal' | 'hex' || 'decimal');
        setEmail(employee.email || '');
        setDietaryPreference(employee.dietaryPreference || null);
        safeLog('Formularz zainicjalizowany pomyślnie');
      }
    } catch (error) {
      safeLog('Błąd podczas inicjalizacji formularza:', error);
    }
  }, [employee, isOpen]);

  // Mutacja do aktualizacji pracownika
  const updateMutation = useMutation({
    mutationFn: async (data: { id: number; employee: InsertEmployee }) => {
      return await apiRequest(`/api/employees/${data.id}`, {
        method: 'PUT',
        data: data.employee,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      toast({
        title: "Sukces",
        description: "Dane pracownika zostały zaktualizowane.",
      });
      handleClose();
    },
    onError: () => {
      toast({
        title: "Błąd",
        description: "Nie udało się zaktualizować danych pracownika. Spróbuj ponownie.",
        variant: "destructive",
      });
      setIsLoading(false);
    },
  });

  // Funkcja do obsługi zapisu
  const handleSave = () => {
    if (!employee) return;
    
    // Walidacja
    if (!firstName.trim()) {
      toast({ title: "Błąd", description: "Imię jest wymagane", variant: "destructive" });
      return;
    }
    
    if (!lastName.trim()) {
      toast({ title: "Błąd", description: "Nazwisko jest wymagane", variant: "destructive" });
      return;
    }
    
    if (!rfidCardNumber.trim()) {
      toast({ title: "Błąd", description: "Numer karty RFID jest wymagany", variant: "destructive" });
      return;
    }
    
    setIsLoading(true);
    
    const employeeData: InsertEmployee = {
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      rfidCardNumber: rfidCardNumber.trim(),
      rfidCardFormat: rfidCardFormat,
      email: email.trim() || "",
      dietaryPreference: dietaryPreference as any,
    };
    
    updateMutation.mutate({ 
      id: employee.id, 
      employee: employeeData 
    });
  };

  // Resetuj formularz i zamknij modal
  const handleClose = () => {
    setFirstName('');
    setLastName('');
    setRfidCardNumber('');
    setRfidCardFormat('decimal');
    setEmail('');
    setDietaryPreference(null);
    setIsLoading(false);
    onClose();
  };

  // Użyjmy prostego widoku aby zdiagnozować problem
  try {
    safeLog('Rendering tryb debug, isOpen=', isOpen);
    
    if (!isOpen) {
      return null;
    }
    
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
        <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
          <h2 className="text-xl font-bold mb-4">Edytuj pracownika</h2>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium">Imię</label>
              <input 
                type="text" 
                value={firstName} 
                onChange={(e) => setFirstName(e.target.value)}
                className="w-full border rounded p-2" 
              />
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium">Nazwisko</label>
              <input 
                type="text" 
                value={lastName} 
                onChange={(e) => setLastName(e.target.value)}
                className="w-full border rounded p-2" 
              />
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium">Nr karty RFID</label>
              <input 
                type="text" 
                value={rfidCardNumber} 
                onChange={(e) => setRfidCardNumber(e.target.value)}
                className="w-full border rounded p-2" 
              />
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium">Format karty</label>
              <select 
                value={rfidCardFormat} 
                onChange={(e) => setRfidCardFormat(e.target.value as 'decimal' | 'hex')}
                className="w-full border rounded p-2"
              >
                <option value="decimal">Decimal (123456)</option>
                <option value="hex">HEX (1A2B3C)</option>
              </select>
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium">Email</label>
              <input 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)}
                className="w-full border rounded p-2" 
              />
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium">Preferencja dietetyczna</label>
              <select 
                value={dietaryPreference || ""} 
                onChange={(e) => setDietaryPreference(e.target.value || null)}
                className="w-full border rounded p-2"
              >
                <option value="">Brak preferencji</option>
                {DIETARY_PREFERENCES.map((preference) => (
                  <option key={preference} value={preference}>{preference}</option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="flex justify-end space-x-2 mt-6">
            <button 
              onClick={handleClose} 
              disabled={isLoading}
              className="px-4 py-2 border rounded bg-gray-100 hover:bg-gray-200"
            >
              Anuluj
            </button>
            <button 
              onClick={handleSave} 
              disabled={isLoading}
              className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700"
            >
              {isLoading ? 'Zapisywanie...' : 'Zapisz zmiany'}
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    safeLog('Błąd podczas renderowania komponentu:', error);
    
    // Awaryjny widok w przypadku błędu
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
        <div className="bg-white p-6 rounded-lg shadow-lg">
          <h2 className="text-xl font-bold mb-4 text-red-600">Wystąpił błąd</h2>
          <p>Nie można wyświetlić formularza edycji pracownika.</p>
          <button 
            onClick={handleClose}
            className="mt-4 px-4 py-2 bg-gray-100 rounded hover:bg-gray-200"
          >
            Zamknij
          </button>
        </div>
      </div>
    );
  }
};

export default EditEmployeeModal;