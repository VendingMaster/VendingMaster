import React, { useState, useEffect, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Product, Chamber, Settings } from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';

interface ChamberAssignmentProps {
  chamberId: number;
  isOpen: boolean;
  onClose: () => void;
}

export const ChamberAssignment: React.FC<ChamberAssignmentProps> = ({ 
  chamberId, 
  isOpen, 
  onClose 
}) => {
  const [productId, setProductId] = useState<string>('');
  const [isAvailable, setIsAvailable] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: chamber, isLoading: chamberLoading } = useQuery<Chamber>({
    queryKey: [`/api/chambers/${chamberId}`],
    enabled: isOpen && chamberId !== null,
  });

  // Pobierz ustawienia systemu
  const { data: settings, isLoading: settingsLoading } = useQuery<Settings>({
    queryKey: ['/api/settings'],
    enabled: isOpen,
  });

  // Sprawdź, czy aktywny jest tryb przypisywania bazujący na magazynie
  const inventoryBasedMode = settings?.inventoryBasedAssignment || false;

  // Pobierz wszystkie produkty lub tylko te dostępne w magazynie
  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
    enabled: isOpen && !inventoryBasedMode,
  });

  // Pobierz produkty dostępne w magazynie (tylko kiedy aktywny jest tryb bazujący na magazynie)
  const { data: inventoryProducts, isLoading: inventoryProductsLoading, refetch: refetchInventory } = useQuery<{productId: number, productName: string, items: any[], totalQuantity: number, availableQuantity: number}[]>({
    queryKey: ['/api/inventory/grouped'],
    enabled: isOpen && inventoryBasedMode,
  });

  // Pobierz listę przeterminowanych produktów
  const { data: expiredItems } = useQuery<{id: number, productId: number}[]>({
    queryKey: ['/api/inventory/expired'],
    enabled: isOpen && inventoryBasedMode,
  });
  
  // Lista produktów do wyświetlenia w zależności od trybu
  const productsList = React.useMemo(() => {
    if (inventoryBasedMode && inventoryProducts) {
      // Przygotuj zbiór ID przeterminowanych produktów do wykluczenia
      const expiredProductIds = new Set(expiredItems?.map(item => item.productId) || []);
      
      // Konwertuj elementy magazynowe na format zgodny z Product[] wykluczając przeterminowane
      const uniqueProducts = inventoryProducts
        // Odfiltruj produkty przeterminowane
        .filter(item => !expiredProductIds.has(item.productId))
        .map(item => ({
          id: item.productId,
          name: item.productName,
          category: '',
          price: 0,
          imageUrl: '',
          shortDescription: '',
          longDescription: '',
          purchasePrice: 0,
          vatRate: '',
          weight: 0,
          calories: 0,
          proteins: 0,
          carbs: 0,
          fats: 0,
          allergens: '',
          ingredients: '',
          dietaryPreferences: ''
        })) as Product[];
      
      return uniqueProducts;
    }
    return products || [];
  }, [products, inventoryProducts, expiredItems, inventoryBasedMode]);

  // Set initial form state based on chamber data
  useEffect(() => {
    if (chamber) {
      setProductId(chamber.productId ? chamber.productId.toString() : 'null');
      setIsAvailable(chamber.isAvailable);
    }
  }, [chamber]);

  const updateMutation = useMutation({
    mutationFn: async (data: { productId: number | null; isAvailable: boolean }) => {
      return await apiRequest(`/api/chambers/${chamberId}`, { method: 'PUT', data });
    },
    onSuccess: () => {
      // Odśwież wszystkie potrzebne dane
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      queryClient.invalidateQueries({ queryKey: [`/api/chambers/${chamberId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/grouped'] });
      queryClient.invalidateQueries({ queryKey: ['/api/diagnostics/inventory'] });
      
      // Ręcznie odśwież dane po operacji
      refetchInventory();
      refetchDiagnostics();
      
      onClose();
      toast({
        title: "Sukces",
        description: "Szuflada została zaktualizowana pomyślnie",
      });
    },
    onError: (error) => {
      // Sprawdzamy czy to błąd braku wystarczającej ilości produktu
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      const isInventoryError = errorMessage.includes("Niewystarczająca ilość produktu");
      
      toast({
        title: isInventoryError ? "Brak wystarczającej ilości w magazynie" : "Nie można przypisać produktu",
        description: errorMessage,
        variant: "destructive",
      });
    }
  });

  const resetMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest(`/api/chambers/${chamberId}/product`, { method: 'DELETE' });
    },
    onSuccess: () => {
      // Odśwież wszystkie potrzebne dane
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      queryClient.invalidateQueries({ queryKey: [`/api/chambers/${chamberId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/grouped'] });
      queryClient.invalidateQueries({ queryKey: ['/api/diagnostics/inventory'] });
      
      // Ręcznie odśwież dane po operacji
      refetchInventory();
      refetchDiagnostics();
      
      onClose();
      toast({
        title: "Sukces",
        description: "Szuflada została zresetowana pomyślnie",
      });
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się zresetować szuflady: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  // Interfejs dla danych diagnostycznych magazynu
  interface InventoryDiagnostics {
    inventoryBasedAssignment: boolean;
    productAssignments: Array<{
      productId: number;
      productName: string;
      chambersCount: number;
      totalAvailable: number;
      sufficient: boolean;
    }>;
  }

  // Nowe zapytanie do diagnostyki magazynu - zawsze włączone gdy formularz jest otwarty
  const { data: inventoryDiagnostics, isLoading: diagnosticsLoading, refetch: refetchDiagnostics } = useQuery<InventoryDiagnostics>({
    queryKey: [`/api/diagnostics/inventory`],
    enabled: isOpen && inventoryBasedMode,
  });

  // Sprawdź dane o dostępności bezpośrednio z magazynu
  const selectedInventoryData = useMemo(() => {
    if (!productId || productId === "null" || !inventoryProducts) return null;
    
    const productId_num = parseInt(productId);
    return inventoryProducts.find(p => p.productId === productId_num);
  }, [productId, inventoryProducts]);
  
  // Sprawdź dane o przypisaniu z diagnostyki
  const selectedDiagnosticData = useMemo(() => {
    if (!productId || productId === "null" || !inventoryDiagnostics) return null;
    
    const productId_num = parseInt(productId);
    return inventoryDiagnostics.productAssignments?.find(
      p => p.productId === productId_num
    );
  }, [productId, inventoryDiagnostics]);
  
  // Czy produkt ma wystarczającą ilość w magazynie
  const hasAvailableStock = useMemo(() => {
    if (!inventoryBasedMode) return true;
    
    // Pobierz dane z obu źródeł
    const availableCount = selectedInventoryData ? selectedInventoryData.availableQuantity : 0;
    const assignedCount = selectedDiagnosticData ? selectedDiagnosticData.chambersCount : 0;
    
    return (availableCount - assignedCount) > 0;
  }, [selectedInventoryData, selectedDiagnosticData, inventoryBasedMode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Dodatkowa walidacja przed wysłaniem (zabezpieczenie)
    if (inventoryBasedMode && productId && productId !== "null" && !hasAvailableStock) {
      toast({
        title: "Brak wystarczającej ilości w magazynie",
        description: "Nie można przypisać produktu, ponieważ nie ma wystarczającej ilości w magazynie.",
        variant: "destructive",
      });
      return;
    }
    
    updateMutation.mutate({
      productId: productId && productId !== "null" ? parseInt(productId) : null,
      isAvailable: isAvailable
    });
  };

  const handleReset = () => {
    if (window.confirm('Czy na pewno chcesz zresetować tę szufladę?')) {
      resetMutation.mutate();
    }
  };

  // Funkcja sprawdzająca stan magazynu dla wybranego produktu
  const handleCheckInventory = () => {
    if (!productId || productId === 'null') {
      toast({
        title: "Brak produktu",
        description: "Wybierz produkt, aby sprawdzić stan magazynu",
        variant: "destructive",
      });
      return;
    }
    
    const productId_num = parseInt(productId);
    
    // Odśwież dane diagnostyczne
    refetchDiagnostics();
    
    // Znajdź dane dla wybranego produktu z obu źródeł
    const inventoryData = inventoryProducts?.find(p => p.productId === productId_num);
    const diagnosticData = inventoryDiagnostics?.productAssignments?.find(p => p.productId === productId_num);
    
    // Znajdź nazwę produktu
    const foundProduct = productsList.find(p => p.id === productId_num);
    
    if (inventoryData) {
      // Oblicz wartości
      const availableCount = inventoryData.availableQuantity || 0;
      const assignedCount = diagnosticData ? diagnosticData.chambersCount : 0;
      const availableForNewAssignments = Math.max(0, availableCount - assignedCount);
      const isSufficient = availableForNewAssignments > 0;
      
      toast({
        title: "Stan magazynu",
        description: `Produkt: ${foundProduct?.name}
          Dostępne w magazynie: ${availableCount} szt.
          Przypisane szuflady: ${assignedCount} szt.
          Dostępne dla nowych przypisań: ${availableForNewAssignments} szt.
          Stan: ${isSufficient ? 'Wystarczający ✅' : 'Niewystarczający ❌'}`,
      });
    } else {
      // Brak danych magazynowych
      if (foundProduct) {
        toast({
          title: "Brak danych magazynowych",
          description: `Produkt: ${foundProduct.name}
            Nie znaleziono danych magazynowych dla tego produktu.`,
        });
      }
    }
  };
  
  const isLoading = chamberLoading || productsLoading || settingsLoading || (inventoryBasedMode && inventoryProductsLoading);
  const isPending = updateMutation.isPending || resetMutation.isPending;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isLoading ? (
              <Skeleton className="h-6 w-48" />
            ) : (
              `Przypisz Produkt do Szuflady #${chamberId.toString().padStart(2, '0')}`
            )}
          </DialogTitle>
          <DialogDescription>
            Wybierz produkt, który chcesz umieścić w tej szufladzie i określ czy ma być on dostępny dla klientów.
          </DialogDescription>
        </DialogHeader>
        
        {isLoading ? (
          <div className="space-y-4 py-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-48" />
          </div>
        ) : (
          <form onSubmit={handleSubmit}>
            <div className="py-4 space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <Label htmlFor="product-select">Wybierz Produkt</Label>
                  {inventoryBasedMode && (
                    <Button 
                      type="button" 
                      size="sm" 
                      variant="outline" 
                      className="text-xs h-6 px-2 bg-blue-50 text-blue-600 hover:bg-blue-100"
                      onClick={handleCheckInventory}
                      disabled={!productId || productId === "null" || diagnosticsLoading}
                    >
                      {diagnosticsLoading ? "Sprawdzanie..." : "Sprawdź stan magazynu"}
                    </Button>
                  )}
                </div>
                
                <Select
                  value={productId}
                  onValueChange={setProductId}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="-- Wybierz produkt --" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="null">-- Brak produktu (pusta) --</SelectItem>
                    {productsList.map(product => {
                      // Pobierz dane o dostępności z drugiego endpointu (inventory/grouped)
                      const inventoryData = inventoryBasedMode && inventoryProducts
                        ? inventoryProducts.find(p => p.productId === product.id)
                        : null;
                      
                      // Pobierz dane o przypisaniu z diagnostyki
                      const diagnosticData = inventoryBasedMode && inventoryDiagnostics 
                        ? inventoryDiagnostics.productAssignments?.find(p => p.productId === product.id)
                        : null;
                      
                      // Pobierz wartości z obu źródeł z fallbackiem
                      const availableCount = inventoryData ? inventoryData.availableQuantity : 0;
                      const assignedCount = diagnosticData ? diagnosticData.chambersCount : 0;
                      const availableForNewAssignments = Math.max(0, availableCount - assignedCount);
                      
                      // Kolorowanie tekstu w zależności od dostępności
                      let itemClass = "";
                      if (inventoryBasedMode) {
                        itemClass = availableForNewAssignments > 0 
                          ? "text-green-700" 
                          : "text-red-600";
                      }
                      
                      return (
                        <SelectItem 
                          key={product.id} 
                          value={product.id.toString()}
                          className={itemClass}
                        >
                          {product.name}
                          {inventoryBasedMode && ` (${availableForNewAssignments} dostępne)`}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Switch 
                  id="isAvailable"
                  checked={isAvailable}
                  onCheckedChange={setIsAvailable}
                  disabled={!productId || productId === "null"}
                />
                <Label htmlFor="isAvailable">Dostępna dla klientów</Label>
              </div>
              
              {/* Informacja o trybie przypisywania szuflad */}
              {inventoryBasedMode && (
                <div className="text-sm text-amber-600 bg-amber-50 p-3 rounded-md border border-amber-200">
                  <strong>Uwaga:</strong> Aktywny jest tryb przypisywania bazujący na magazynie. 
                  Przypisanie produktu do szuflady jest możliwe tylko wtedy, gdy w magazynie jest 
                  wystarczająca ilość produktów. System wymaga jednej sztuki produktu na każdą szufladę.
                </div>
              )}
            </div>
            
            <DialogFooter className="flex justify-between">
              <Button 
                type="button" 
                variant="outline" 
                onClick={handleReset}
                disabled={isPending || !chamber?.productId}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                Resetuj
              </Button>
              <div className="space-x-2">
                <Button type="button" variant="outline" onClick={onClose} disabled={isPending}>
                  Anuluj
                </Button>
                <Button type="submit" disabled={isPending}>
                  {isPending ? 'Zapisywanie...' : 'Przypisz'}
                </Button>
              </div>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};
