import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Employee, EmployeeWorkDay } from '@shared/schema';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Calendar as CalendarIcon, Plus, Minus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { addDays, format, isAfter, isBefore, isSameDay, isToday, startOfMonth, endOfMonth, getDay, addMonths, addYears, parse } from 'date-fns';
import { pl } from 'date-fns/locale';

interface EmployeeWorkDayCalendarProps {
  employee: Employee;
  isOpen: boolean;
  onClose: () => void;
}

// NOWA WERSJA - całkowicie przebudowany kalendarz pracowniczy
export const EmployeeWorkDayCalendar: React.FC<EmployeeWorkDayCalendarProps> = ({
  employee,
  isOpen,
  onClose
}) => {
  // Unikalny ID dla tego konkretnego pracownika i otwarcia
  const instanceId = useMemo(() => `employee-${employee.id}-${Date.now()}`, [employee.id]);
  
  const { toast } = useToast();
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [workDays, setWorkDays] = useState<string[]>([]);
  // Ref do przechowywania dni, które zostały jawnie oznaczone jako wolne (przez usunięcie z bazy)
  const removedWorkDays = useRef<string[]>([]);
  
  // Pobieranie dni pracy pracownika
  const startDate = format(startOfMonth(currentMonth), 'yyyy-MM-dd');
  const endDate = format(endOfMonth(addMonths(currentMonth, 1)), 'yyyy-MM-dd');
  
  // Pobieranie dni pracy pracownika
  const fetchEmployeeWorkDays = async () => {
    console.log(`[${instanceId}] Pobieranie dni pracy dla pracownika ${employee.id}`);
    
    try {
      // Dodajemy timestamp jako cache buster
      const timestamp = new Date().getTime();
      const url = `/api/employee-work-days/${employee.id}?fromDate=${startDate}&toDate=${endDate}&_t=${timestamp}`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Błąd HTTP: ${response.status}`);
      }
      
      const data = await response.json();
      console.log(`[${instanceId}] Pobrano ${data.length} dni pracy dla pracownika ${employee.id}`);
      
      // Filtrujemy tylko dla tego pracownika i wyciągamy daty
      const filteredDates = data
        .filter((day: any) => day.employeeId === employee.id)
        .map((day: any) => {
          // Upewniamy się, że format daty jest yyyy-MM-dd
          return typeof day.workDate === 'string' 
            ? day.workDate 
            : format(new Date(day.workDate), 'yyyy-MM-dd');
        });
      
      console.log(`[${instanceId}] Przefiltrowano ${filteredDates.length} dni dla pracownika ${employee.id}`);
      return filteredDates;
    } catch (error) {
      console.error(`[${instanceId}] Błąd podczas pobierania dni pracy:`, error);
      return [];
    }
  };
  
  // Sprawdzanie, które dni są domyślnymi dniami pracy - dla WSZYSTKICH przyszłych dni
  const getDefaultWorkDaysForRange = useCallback(() => {
    const result: string[] = [];
    
    // Zaczynamy od dzisiaj (nie patrzymy na miesiąc)
    const start = new Date();
    
    // Kończymy na odległym dniu w przyszłości (np. rok do przodu)
    // aby mieć pewność, że mamy wszystkie potencjalne dni
    const end = addYears(new Date(), 1);
    
    // Generujemy wszystkie dni w tym zakresie
    let current = start;
    while (current <= end) {
      // Wszystkie przyszłe dni (włącznie z dzisiaj) są domyślnie dniami pracy
      result.push(format(current, 'yyyy-MM-dd'));
      
      // Przejście do następnego dnia
      current = addDays(current, 1);
    }
    
    return result;
  }, []);
  
  // Przy każdej zmianie miesiąca lub pracownika, odświeżamy dane
  useEffect(() => {
    if (isOpen) {
      // Pobieramy dni pracy z bazy danych
      fetchEmployeeWorkDays().then(days => {
        setWorkDays(days);
        
        // Teraz określamy dni, które zostały jawnie wyłączone (powinny być zapamiętane)
        // 1. Pobieramy wszystkie dni, które domyślnie są dniami pracy
        const defaultWorkDays = getDefaultWorkDaysForRange();
        
        // 2. Usuwamy te, które są zapisane w bazie jako dni pracy
        const potentiallyRemovedDays = defaultWorkDays.filter(day => !days.includes(day));
        
        // 3. Pozostałe dni są tymi, które zostały jawnie usunięte
        // Ale sprawdzamy tylko przyszłe dni, bo przeszłe nie są domyślnie dniami pracy
        const removed = potentiallyRemovedDays.filter(dateStr => {
          const date = new Date(dateStr);
          return !isBefore(date, new Date()) || isToday(date);
        });
        
        // 4. Aktualizujemy listę usuniętych dni
        removedWorkDays.current = removed;
        
        console.log(`[${instanceId}] Wykryto jawnie usunięte dni:`, removed);
      });
    }
  }, [isOpen, employee.id, currentMonth, startDate, endDate, getDefaultWorkDaysForRange]);
  
  // Dodawanie dnia pracy
  const addWorkDay = async (dateStr: string) => {
    try {
      console.log(`[${instanceId}] Dodawanie dnia pracy ${dateStr} dla pracownika ${employee.id}`);
      
      // Aktualizacja lokalna przed zapytaniem do serwera
      setWorkDays(prev => [...prev, dateStr]);
      
      // Usuwamy dzień z listy usuniętych (jawnie oznaczonych jako wolne)
      removedWorkDays.current = removedWorkDays.current.filter(d => d !== dateStr);
      
      // Wysyłamy zapytanie do API
      const response = await fetch('/api/employee-work-days', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          employeeId: employee.id,
          workDate: dateStr
        })
      });
      
      if (!response.ok) {
        throw new Error(`Błąd HTTP: ${response.status}`);
      }
      
      toast({
        title: "Sukces",
        description: "Dzień pracy został dodany."
      });
      
      // Ponownie pobieramy dane, aby upewnić się, że mamy aktualny stan
      fetchEmployeeWorkDays().then(days => {
        setWorkDays(days);
      });
      
    } catch (error) {
      console.error(`[${instanceId}] Błąd podczas dodawania dnia pracy:`, error);
      toast({
        title: "Błąd",
        description: "Wystąpił problem podczas dodawania dnia pracy.",
        variant: "destructive"
      });
      
      // Cofamy zmianę lokalną w przypadku błędu
      fetchEmployeeWorkDays().then(days => {
        setWorkDays(days);
      });
    }
  };
  
  // Usuwanie dnia pracy
  const removeWorkDay = async (dateStr: string) => {
    try {
      console.log(`[${instanceId}] Usuwanie dnia pracy ${dateStr} dla pracownika ${employee.id}`);
      
      // Aktualizacja lokalna przed zapytaniem do serwera
      setWorkDays(prev => prev.filter(d => d !== dateStr));
      
      // Dodajemy do listy usuniętych dni (jawnie oznaczone jako dni wolne)
      removedWorkDays.current = [...removedWorkDays.current, dateStr];
      
      // Wysyłamy zapytanie do API
      const response = await fetch(`/api/employee-work-days/${employee.id}/${dateStr}`, {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`Błąd HTTP: ${response.status}`);
      }
      
      toast({
        title: "Sukces",
        description: "Dzień pracy został usunięty."
      });
      
      // Ponownie pobieramy dane, aby upewnić się, że mamy aktualny stan
      fetchEmployeeWorkDays().then(days => {
        setWorkDays(days);
      });
      
    } catch (error) {
      console.error(`[${instanceId}] Błąd podczas usuwania dnia pracy:`, error);
      toast({
        title: "Błąd",
        description: "Wystąpił problem podczas usuwania dnia pracy.",
        variant: "destructive"
      });
      
      // Cofamy zmianę lokalną w przypadku błędu
      fetchEmployeeWorkDays().then(days => {
        setWorkDays(days);
      });
      
      // Usuwamy z listy usuniętych dni w przypadku błędu
      removedWorkDays.current = removedWorkDays.current.filter(d => d !== dateStr);
    }
  };
  
  // Sprawdzenie, czy data jest dniem pracy
  const isWorkDay = useCallback((date: Date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    
    // Sprawdzamy, czy to jest przyszły dzień (lub dzisiaj)
    const isFutureOrToday = !isBefore(date, new Date()) || isToday(date);
    
    // Dla przeszłości - tylko jeśli są jawnie oznaczone
    if (!isFutureOrToday) {
      return workDays.includes(dateStr);
    }
    
    // Dla przyszłości i dzisiaj - zakładamy, że to dni pracy, chyba że jawnie oznaczono dni wolne
    // przez brak w tablicy workDays
    return isFutureOrToday && !isWorkDayExplicitlyDisabled(dateStr);
  }, [workDays]);
  
  // Pomocnicza funkcja do sprawdzania czy dzień został jawnie oznaczony jako wolny
  // (przez brak w bazie danych)
  const isWorkDayExplicitlyDisabled = useCallback((dateStr: string) => {
    // Sprawdzamy historię akcji dla tego dnia
    // Jeśli ostatnią akcją było usunięcie dnia pracy, to oznacza że dzień jest wolny
    const wasExplicitlyDeleted = removedWorkDays.current.includes(dateStr);
    
    // Jeśli dzień został jawnie usunięty, to jest to dzień wolny
    return wasExplicitlyDeleted;
  }, []);
  
  // Obsługa kliknięcia na dzień
  const handleDayClick = (date: Date) => {
    // Konwertujemy datę na string w formacie YYYY-MM-DD
    const dateStr = format(date, 'yyyy-MM-dd');
    console.log(`[${instanceId}] Kliknięto dzień ${dateStr}`);
    
    // Sprawdzamy czy to przyszły dzień (lub dzisiaj)
    const isFutureOrToday = !isBefore(date, new Date()) || isToday(date);
    
    // Ignorujemy kliknięcia na dni z przeszłości
    if (!isFutureOrToday) {
      console.log(`[${instanceId}] Zignorowano kliknięcie na przeszły dzień`);
      return;
    }
    
    // Sprawdzamy, czy dzień jest już oznaczony jako dzień pracy
    // W przyszłości dni są domyślnie dniami pracy, więc musimy sprawdzić czy:
    // 1. Dzień jest jawnie oznaczony w bazie danych (workDays) LUB
    // 2. Dzień nie został jawnie usunięty (removedWorkDays)
    
    const isExplicitlyMarked = workDays.includes(dateStr);
    const isExplicitlyDisabled = removedWorkDays.current.includes(dateStr);
    
    // Sprawdzamy czy to dzień pracy w oparciu o logikę aplikacji
    const isWorkingDay = isWorkDay(date);
    
    if (isWorkingDay) {
      // Jeśli to dzień pracy (jawnie dodany lub domyślny przyszły), oznacz jako wolny
      console.log(`[${instanceId}] Oznaczanie jako dzień wolny: ${dateStr}`);
      removeWorkDay(dateStr);
    } else {
      // Jeśli to dzień wolny (jawnie usunięty lub przeszły), oznacz jako pracujący
      console.log(`[${instanceId}] Oznaczanie jako dzień pracy: ${dateStr}`);
      addWorkDay(dateStr);
    }
  };
  
  // Generowanie dni miesiąca do wyświetlenia
  const generateDays = useCallback(() => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    const startDay = getDay(monthStart);
    
    const days = [];
    const daysInMonth = [];
    
    // Dodajemy dni poprzedniego miesiąca
    for (let i = 0; i < startDay; i++) {
      const d = addDays(monthStart, i - startDay);
      daysInMonth.push({ date: d, isCurrentMonth: false });
    }
    
    // Dodajemy dni obecnego miesiąca
    let day = monthStart;
    while (day <= monthEnd) {
      daysInMonth.push({ date: day, isCurrentMonth: true });
      day = addDays(day, 1);
    }
    
    // Dzielimy na tygodnie
    let week = [];
    for (let i = 0; i < daysInMonth.length; i++) {
      week.push(daysInMonth[i]);
      if (week.length === 7) {
        days.push(week);
        week = [];
      }
    }
    
    // Dodajemy dni następnego miesiąca aby uzupełnić ostatni tydzień
    if (week.length > 0) {
      const daysToAdd = 7 - week.length;
      for (let i = 1; i <= daysToAdd; i++) {
        const d = addDays(monthEnd, i);
        week.push({ date: d, isCurrentMonth: false });
      }
      days.push(week);
    }
    
    return days;
  }, [currentMonth]);
  
  // Przejście do poprzedniego miesiąca
  const previousMonth = () => {
    const newMonth = addMonths(currentMonth, -1);
    setCurrentMonth(newMonth);
  };
  
  // Przejście do następnego miesiąca
  const nextMonth = () => {
    const newMonth = addMonths(currentMonth, 1);
    setCurrentMonth(newMonth);
  };
  
  // Reset wszystkiego przy zamknięciu
  const handleClose = () => {
    console.log(`[${instanceId}] Zamykanie kalendarza dla pracownika ${employee.id}`);
    // Odświeżamy wszystkie zapytania dotyczące dni pracy, aby upewnić się,
    // że przy następnym otwarciu będziemy mieli aktualne dane
    queryClient.invalidateQueries({ queryKey: ['/api/employee-work-days'] });
    onClose();
  };
  
  const days = useMemo(() => generateDays(), [generateDays]);
  const dayNames = ['Pon', 'Wto', 'Śro', 'Czw', 'Pią', 'Sob', 'Nie'];
  const monthYear = format(currentMonth, 'LLLL yyyy', { locale: pl });
  
  // Debug info - wyświetlamy dane dla tego konkretnego pracownika
  console.log(`[${instanceId}] Renderuję kalendarz pracownika ${employee.id} (${employee.firstName} ${employee.lastName})`);
  console.log(`[${instanceId}] Dni pracy: `, workDays);
  console.log(`[${instanceId}] Dni jawnie oznaczone jako wolne: `, removedWorkDays.current);
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && handleClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Harmonogram pracy: {employee.firstName} {employee.lastName}</DialogTitle>
          <DialogDescription>
            Kliknij na dzień, aby zaznaczyć go jako dzień pracy (zielony) lub wolny.
            W dniach pracy pracownik będzie mógł zarezerwować posiłek.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-2 mt-4">
          <div className="flex items-center justify-between mb-4">
            <Button variant="outline" size="sm" onClick={previousMonth}>&lt;</Button>
            <div className="text-lg font-semibold">{monthYear}</div>
            <Button variant="outline" size="sm" onClick={nextMonth}>&gt;</Button>
          </div>
          
          <div className="grid grid-cols-7 gap-1 mb-2">
            {dayNames.map((day: string) => (
              <div key={day} className="text-center text-sm font-medium">
                {day}
              </div>
            ))}
          </div>
          
          {days.map((week, weekIndex) => (
            <div key={`${weekIndex}-${instanceId}`} className="grid grid-cols-7 gap-1">
              {week.map(({ date, isCurrentMonth }, dayIndex) => {
                const dateStr = format(date, 'yyyy-MM-dd');
                const isPast = isBefore(date, new Date()) && !isToday(date);
                
                // Sprawdzamy czy to jest dzień pracy używając naszej funkcji
                const isWorkingDay = isWorkDay(date);
                
                return (
                  <div 
                    key={`${dayIndex}-${dateStr}-${instanceId}`}
                    onClick={() => !isPast && handleDayClick(date)}
                    className={`
                      h-10 flex items-center justify-center rounded-md text-sm cursor-pointer
                      ${!isCurrentMonth ? 'text-gray-400' : ''}
                      ${isWorkingDay ? 'bg-green-100 text-green-900 font-semibold' : ''}
                      ${isToday(date) ? 'font-bold' : ''}
                      ${isPast ? 'text-gray-400 cursor-not-allowed' : 'hover:bg-gray-100'}
                    `}
                  >
                    {format(date, 'd')}
                  </div>
                );
              })}
            </div>
          ))}
          
          <div className="text-sm text-gray-600 mt-4">
            <div className="flex items-center">
              <div className="w-4 h-4 bg-green-100 border rounded-sm border-green-300 mr-2"></div>
              <span>Dni pracy</span>
            </div>
            <p className="mt-2">
              Pracownik może zamawiać posiłki tylko na dni, w których pracuje (zaznaczone na zielono).
              Kliknij na dzień, aby przełączyć między dniem pracy (zielony) a dniem wolnym.
            </p>
          </div>
        </div>
        
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={handleClose}>
            Zamknij
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};