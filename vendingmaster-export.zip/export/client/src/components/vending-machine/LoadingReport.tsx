import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Printer, Download, ArrowLeft } from 'lucide-react';

// Typy dla danych raportu
interface ChamberReportItem {
  chamberId: number;
  type: 'employee' | 'product' | 'empty';
  orderNumber?: string;
  employeeId?: number;
  productName?: string;
  productId?: number | null;
  isAvailable?: boolean;
  imageUrl?: string | null;
}

interface LoadingReportData {
  success: boolean;
  date: string;
  chambers: ChamberReportItem[];
}

export const LoadingReport: React.FC = () => {
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  // Pobieranie danych raportu
  const { data: reportData, isLoading, error } = useQuery<LoadingReportData>({
    queryKey: ['/api/chambers/loading-report'],
  });
  
  // Nasłuchiwanie na zmiany rozmiaru okna
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  // Obsługa wydruku raportu
  const handlePrint = () => {
    window.print();
  };
  
  // Funkcja pomocnicza do formatowania daty
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('pl-PL', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };
  
  // Funkcja pomocnicza do pobierania raportu jako CSV
  const downloadCSV = () => {
    if (!reportData) return;
    
    const headers = ['ID Szuflady', 'Typ', 'Zamówienie', 'Produkt'];
    
    const rows = reportData.chambers.map(chamber => {
      const chamberType = 
        chamber.type === 'employee' ? 'Pracownik' : 
        chamber.type === 'product' ? 'Produkt' : 
        'Pusta';
      
      return [
        chamber.chamberId,
        chamberType,
        chamber.orderNumber || '',
        chamber.productName || ''
      ];
    });
    
    // Dodajemy nagłówek BOM dla prawidłowej obsługi polskich znaków
    let csvContent = '\uFEFF' + headers.join(',') + '\n';
    
    rows.forEach(row => {
      // Owijamy wszystkie pola w cudzysłowy i zamieniamy cudzysłowy w danych na podwójne
      const escapedRow = row.map(field => {
        const stringField = String(field).replace(/"/g, '""');
        return `"${stringField}"`;
      });
      csvContent += escapedRow.join(',') + '\n';
    });
    
    // Tworzenie i pobieranie pliku
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    
    link.setAttribute('href', url);
    link.setAttribute('download', `raport-zaladunku-${reportData.date}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  // Funkcja do obsługi powrotu - kieruje do listy szuflad zamiast historii przeglądarki
  const handleGoBack = () => {
    // Nawigacja do strony głównej zarządzania szufladami
    window.location.hash = '#chambers';
  };
  
  // Renderujemy różne stany komponentu
  if (isLoading) {
    return (
      <div className="p-4 min-h-screen">
        <div className="mb-6">
          <Skeleton className="h-12 w-60 mb-4" />
          <Skeleton className="h-6 w-80 mb-6" />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(12)].map((_, i) => (
            <div key={i} className="flex items-center p-4 border rounded-lg">
              <Skeleton className="h-16 w-16 rounded-full mr-4" />
              <div className="flex-1">
                <Skeleton className="h-4 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="p-4 min-h-screen flex flex-col items-center justify-center">
        <div className="text-red-500 text-xl mb-4">
          Wystąpił błąd podczas pobierania raportu
        </div>
        <Button onClick={handleGoBack} className="flex items-center">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Powrót
        </Button>
      </div>
    );
  }
  
  if (!reportData) {
    return (
      <div className="p-4 min-h-screen flex flex-col items-center justify-center">
        <div className="text-gray-500 text-xl mb-4">
          Brak danych do wyświetlenia
        </div>
        <Button onClick={handleGoBack} className="flex items-center">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Powrót
        </Button>
      </div>
    );
  }
  
  // Podzielamy szuflady na kolumny
  const getChambersForColumn = (startId: number, endId: number) => {
    return reportData.chambers
      .filter(chamber => chamber.chamberId >= startId && chamber.chamberId <= endId)
      .sort((a, b) => a.chamberId - b.chamberId);
  };
  
  // Organizujemy dane dla układu urządzenia
  const column1Chambers = getChambersForColumn(1, 15);
  const column2Chambers = getChambersForColumn(16, 24);
  const column3Chambers = getChambersForColumn(25, 33);
  const column4Chambers = getChambersForColumn(34, 48);
  
  // Generujemy klasy kolorów dla różnych typów
  const getChamberColor = (chamber: ChamberReportItem) => {
    if (chamber.type === 'employee') return 'bg-blue-50 border-blue-200';
    if (chamber.type === 'product') {
      return chamber.isAvailable 
        ? 'bg-green-50 border-green-200' 
        : 'bg-red-50 border-red-200';
    }
    return 'bg-gray-50 border-gray-200';
  };
  
  return (
    <div className="p-4 container mx-auto">
      {/* Nagłówek strony */}
      <div className="mb-6 print:mb-3 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold mb-2 print:text-xl">
            Raport załadunku szuflad
          </h1>
          <p className="text-gray-600 print:text-sm">
            Data: {formatDate(reportData.date)}
          </p>
        </div>
        
        <div className="flex gap-2 print:hidden">
          <Button 
            variant="outline" 
            onClick={downloadCSV}
            className="flex items-center"
          >
            <Download className="w-4 h-4 mr-2" />
            CSV
          </Button>
          <Button 
            variant="outline" 
            onClick={handlePrint}
            className="flex items-center"
          >
            <Printer className="w-4 h-4 mr-2" />
            Drukuj
          </Button>
        </div>
      </div>
      
      {/* Legenda */}
      <div className="mb-5 print:mb-3 flex flex-wrap gap-3 print:text-sm">
        <div className="flex items-center">
          <div className="w-4 h-4 bg-blue-100 border border-blue-200 rounded mr-2"></div>
          <span>Szuflada pracownika</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 bg-green-100 border border-green-200 rounded mr-2"></div>
          <span>Szuflada produktowa (dostępna)</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 bg-red-100 border border-red-200 rounded mr-2"></div>
          <span>Szuflada produktowa (niedostępna)</span>
        </div>
        <div className="flex items-center">
          <div className="w-4 h-4 bg-gray-100 border border-gray-200 rounded mr-2"></div>
          <span>Pusta szuflada</span>
        </div>
      </div>
      
      {/* Zawartość raportu */}
      {isMobile ? (
        // Widok mobilny - lista liniowa
        <div className="flex flex-col gap-3">
          {reportData.chambers.sort((a, b) => a.chamberId - b.chamberId).map(chamber => (
            <div 
              key={chamber.chamberId}
              className={`p-3 border rounded-lg flex items-center ${getChamberColor(chamber)}`}
            >
              <div className="text-lg font-bold bg-white text-gray-700 w-8 h-8 rounded-full flex items-center justify-center mr-3 border">
                {chamber.chamberId}
              </div>
              <div className="flex-1">
                {chamber.type === 'employee' && (
                  <>
                    <div className="font-medium">{chamber.orderNumber}</div>
                    <div className="text-sm text-gray-600">
                      {chamber.productName || 'Brak rezerwacji na dzisiaj'}
                    </div>
                  </>
                )}
                {chamber.type === 'product' && (
                  <>
                    <div className="font-medium">{chamber.productName}</div>
                    <div className="text-sm text-gray-600">
                      {chamber.isAvailable ? 'Dostępna' : 'Niedostępna'}
                    </div>
                  </>
                )}
                {chamber.type === 'empty' && (
                  <div className="text-gray-500">Pusta szuflada</div>
                )}
              </div>
            </div>
          ))}
        </div>
      ) : (
        // Widok desktopowy - układ kolumnowy
        <div className="grid grid-cols-4 gap-4 print:gap-2 print:text-xs">
          {/* Kolumna 1 - szuflady 1-15 */}
          <div className="flex flex-col gap-2 print:gap-1">
            <h3 className="text-sm font-bold mb-1 text-center print:text-xs">Kolumna 1 (1-15)</h3>
            {column1Chambers.map(chamber => (
              <div 
                key={chamber.chamberId}
                className={`p-2 print:p-1 border rounded-lg flex items-center ${getChamberColor(chamber)}`}
              >
                <div className="text-sm font-bold bg-white text-gray-700 w-6 h-6 rounded-full flex items-center justify-center mr-2 border print:w-4 print:h-4 print:text-xs">
                  {chamber.chamberId}
                </div>
                <div className="flex-1 truncate">
                  {chamber.type === 'employee' ? (
                    <>
                      <div className="font-medium truncate">{chamber.orderNumber}</div>
                      <div className="text-xs text-gray-600 truncate">
                        {chamber.productName || 'Brak rezerwacji'}
                      </div>
                    </>
                  ) : chamber.type === 'product' ? (
                    <div className="truncate">{chamber.productName}</div>
                  ) : (
                    <div className="text-gray-500">Pusta</div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {/* Kolumna 2 - szuflady 16-24 */}
          <div className="flex flex-col gap-2 print:gap-1">
            <h3 className="text-sm font-bold mb-1 text-center print:text-xs">Kolumna 2 (16-24)</h3>
            {column2Chambers.map(chamber => (
              <div 
                key={chamber.chamberId}
                className={`p-2 print:p-1 border rounded-lg flex items-center ${getChamberColor(chamber)}`}
              >
                <div className="text-sm font-bold bg-white text-gray-700 w-6 h-6 rounded-full flex items-center justify-center mr-2 border print:w-4 print:h-4 print:text-xs">
                  {chamber.chamberId}
                </div>
                <div className="flex-1 truncate">
                  {chamber.type === 'employee' ? (
                    <>
                      <div className="font-medium truncate">{chamber.orderNumber}</div>
                      <div className="text-xs text-gray-600 truncate">
                        {chamber.productName || 'Brak rezerwacji'}
                      </div>
                    </>
                  ) : chamber.type === 'product' ? (
                    <div className="truncate">{chamber.productName}</div>
                  ) : (
                    <div className="text-gray-500">Pusta</div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {/* Kolumna 3 - szuflady 25-33 */}
          <div className="flex flex-col gap-2 print:gap-1">
            <h3 className="text-sm font-bold mb-1 text-center print:text-xs">Kolumna 3 (25-33)</h3>
            {column3Chambers.map(chamber => (
              <div 
                key={chamber.chamberId}
                className={`p-2 print:p-1 border rounded-lg flex items-center ${getChamberColor(chamber)}`}
              >
                <div className="text-sm font-bold bg-white text-gray-700 w-6 h-6 rounded-full flex items-center justify-center mr-2 border print:w-4 print:h-4 print:text-xs">
                  {chamber.chamberId}
                </div>
                <div className="flex-1 truncate">
                  {chamber.type === 'employee' ? (
                    <>
                      <div className="font-medium truncate">{chamber.orderNumber}</div>
                      <div className="text-xs text-gray-600 truncate">
                        {chamber.productName || 'Brak rezerwacji'}
                      </div>
                    </>
                  ) : chamber.type === 'product' ? (
                    <div className="truncate">{chamber.productName}</div>
                  ) : (
                    <div className="text-gray-500">Pusta</div>
                  )}
                </div>
              </div>
            ))}
          </div>
          
          {/* Kolumna 4 - szuflady 34-48 */}
          <div className="flex flex-col gap-2 print:gap-1">
            <h3 className="text-sm font-bold mb-1 text-center print:text-xs">Kolumna 4 (34-48)</h3>
            {column4Chambers.map(chamber => (
              <div 
                key={chamber.chamberId}
                className={`p-2 print:p-1 border rounded-lg flex items-center ${getChamberColor(chamber)}`}
              >
                <div className="text-sm font-bold bg-white text-gray-700 w-6 h-6 rounded-full flex items-center justify-center mr-2 border print:w-4 print:h-4 print:text-xs">
                  {chamber.chamberId}
                </div>
                <div className="flex-1 truncate">
                  {chamber.type === 'employee' ? (
                    <>
                      <div className="font-medium truncate">{chamber.orderNumber}</div>
                      <div className="text-xs text-gray-600 truncate">
                        {chamber.productName || 'Brak rezerwacji'}
                      </div>
                    </>
                  ) : chamber.type === 'product' ? (
                    <div className="truncate">{chamber.productName}</div>
                  ) : (
                    <div className="text-gray-500">Pusta</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {/* Stopka dla wydruku */}
      <div className="mt-6 print:mt-4 text-center text-gray-500 text-sm hidden print:block">
        Wygenerowano z systemu IQSTORE w dniu {formatDate(reportData.date)}
      </div>
      
      {/* Style do wydruku */}
      <style dangerouslySetInnerHTML={{
        __html: `
          @media print {
            body {
              font-size: 11px;
            }
            @page {
              margin: 1cm;
            }
          }
        `
      }} />
    </div>
  );
};
