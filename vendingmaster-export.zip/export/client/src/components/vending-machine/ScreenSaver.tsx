import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';

// Typ dla ustawień wygaszacza
interface ScreensaverSettings {
  screensaverEnabled: boolean;
  screensaverTimeoutSeconds: number;
  screensaverImageUrl: string | null;
}

export const ScreenSaver: React.FC = () => {
  // Stan aktywności wygaszacza
  const [isActive, setIsActive] = useState(false);
  
  // Pobierz ustawienia wygaszacza z API
  const { data: settings } = useQuery<any>({
    queryKey: ['/api/settings'],
    refetchInterval: 30000, // Odświeżaj co 30 sekund
  });

  // Uproszczone ustawienia wygaszacza
  const screensaverEnabled = settings?.screensaverEnabled || false;
  const screensaverTimeoutSeconds = settings?.screensaverTimeoutSeconds || 60;
  const screensaverImageUrl = settings?.screensaverImageUrl || null;

  // Funkcja do wyłączania wygaszacza po kliknięciu
  const hideScreensaver = () => {
    setIsActive(false);
    
    // Pokaż przyciski nawigacyjne
    const navButtons = document.querySelectorAll('.fixed-nav-btn');
    navButtons.forEach(button => {
      (button as HTMLElement).style.display = 'flex';
    });
  };

  // Aktywacja timera wygaszacza ekranu
  useEffect(() => {
    if (!screensaverEnabled) {
      return;
    }
    
    let timeoutId: number;
    
    // Funkcja resetująca timer
    const resetTimer = () => {
      // Wyczyść istniejący timer
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      
      // Ustaw nowy timer
      timeoutId = window.setTimeout(() => {
        // Ukryj przyciski nawigacyjne
        const navButtons = document.querySelectorAll('.fixed-nav-btn');
        navButtons.forEach(button => {
          (button as HTMLElement).style.display = 'none';
        });
        
        // Pokaż wygaszacz
        setIsActive(true);
      }, screensaverTimeoutSeconds * 1000);
    };
    
    // Zresetuj timer na starcie
    resetTimer();
    
    // Nasłuchuj ruchu myszą i klików, aby resetować timer
    const handleActivity = () => {
      // Wyłącz wygaszacz jeśli jest aktywny
      if (isActive) {
        hideScreensaver();
      }
      
      // Resetuj timer
      resetTimer();
    };
    
    // Dodaj nasłuchiwanie na zdarzenia
    window.addEventListener('mousemove', handleActivity);
    window.addEventListener('mousedown', handleActivity);
    window.addEventListener('keypress', handleActivity);
    window.addEventListener('touchstart', handleActivity);
    window.addEventListener('touchmove', handleActivity);
    
    // Sprzątanie przy odmontowywaniu
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('mousemove', handleActivity);
      window.removeEventListener('mousedown', handleActivity);
      window.removeEventListener('keypress', handleActivity);
      window.removeEventListener('touchstart', handleActivity);
      window.removeEventListener('touchmove', handleActivity);
      
      // Przywróć przyciski nawigacyjne
      const navButtons = document.querySelectorAll('.fixed-nav-btn');
      navButtons.forEach(button => {
        (button as HTMLElement).style.display = 'flex';
      });
    };
  }, [isActive, screensaverEnabled, screensaverTimeoutSeconds]);

  // Jeśli wygaszacz nie jest aktywny, nie renderuj nic
  if (!isActive || !screensaverEnabled) {
    return null;
  }

  // Renderuj wygaszacz ekranu
  return (
    <div 
      className="fixed inset-0 z-[99999] bg-black flex items-center justify-center"
      onClick={hideScreensaver}
      style={{ cursor: 'none' }}
    >
      {screensaverImageUrl ? (
        <img
          src={`${screensaverImageUrl}?t=${Date.now()}`}
          alt="Wygaszacz ekranu"
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="text-white flex flex-col items-center p-8">
          <h2 className="text-4xl font-bold mb-4">Automat Vendingowy</h2>
          <p className="text-xl">Dotknij ekranu aby kontynuować</p>
        </div>
      )}
    </div>
  );
};