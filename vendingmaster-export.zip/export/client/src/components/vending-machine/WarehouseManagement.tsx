import React, { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Calendar,
  CalendarIcon,
  ArrowDownIcon,
  ArrowUpIcon,
  Loader2,
  AlertCircle,
  CheckCircle,
  XCircle,
  FileText,
  Package,
  PackageOpen,
  PackageCheck,
  Trash2,
  Clock,
  Calendar as CalendarIcon2,
  Plus,
  FileWarning,
  ShoppingCart,
  Search,
  RefreshCw,
} from "lucide-react";
import { format, addDays, isAfter, isBefore, parseISO, isSameDay } from "date-fns";
import { pl } from "date-fns/locale";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

// Aliasy typów dla lepszej czytelności
type InventoryItem = {
  id: number;
  productId: number;
  quantity: number;
  expiryDate: string;
  batchNumber?: string;
  notes?: string;
  deliveryId?: number;
  disposed: boolean;
  disposedAt?: string;
  disposedQuantity?: number;
  isUsed: boolean;
  usedAt?: string;
  usedQuantity?: number;
  usageReason?: string;
  // Dodatkowe pola z danych produktu
  productName?: string;
  productImage?: string;
};

type GroupedInventoryItem = {
  productId: number;
  productName: string;
  items: InventoryItem[];
  totalQuantity: number;
  availableQuantity: number;
};

type Product = {
  id: number;
  name: string;
  category: string;
  price: number;
  imageUrl: string;
};

type Delivery = {
  id: number;
  deliveryNumber: string;
  deliveryDate: string;
  notes?: string;
  items?: DeliveryItem[];
};

type DeliveryItem = {
  productId: number;
  quantity: number;
  expiryDate: string;
  batchNumber?: string;
};

// Schemat dla formularza dostawy
const deliveryFormSchema = z.object({
  deliveryNumber: z.string().min(1, { message: "Numer dostawy jest wymagany" }),
  deliveryDate: z.date({
    required_error: "Data dostawy jest wymagana",
  }),
  notes: z.string().optional(),
  items: z.array(
    z.object({
      productId: z.number({ required_error: "Produkt jest wymagany" }),
      quantity: z.number()
        .min(1, { message: "Ilość musi być większa od 0" }),
      expiryDate: z.union([
        z.date({
          required_error: "Data ważności jest wymagana",
        }),
        z.string().min(1, { message: "Data ważności jest wymagana" })
      ]),
      batchNumber: z.string().optional(),
    })
  ).min(1, { message: "Przynajmniej jeden produkt musi być wybrany" }),
});

type DeliveryFormValues = z.infer<typeof deliveryFormSchema>;

// Schemat dla formularza utylizacji lub rozchodu
const usageFormSchema = z.object({
  quantity: z.number()
    .min(1, { message: "Ilość musi być większa od 0" }),
  reason: z.string().min(1, { message: "Powód jest wymagany" }),
  notes: z.string().optional(),
});

type UsageFormValues = z.infer<typeof usageFormSchema>;

// Główny komponent zarządzania magazynem
export const WarehouseManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState("overview");
  // Dodajemy znacznik czasu, aby wymusić odświeżenie zapytań przy zmianie zakładki
  const [refreshTimestamp, setRefreshTimestamp] = useState(Date.now());
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);
  const [isDeliveryDialogOpen, setIsDeliveryDialogOpen] = useState(false);
  const [isUsageDialogOpen, setIsUsageDialogOpen] = useState(false);
  const [isDisposalDialogOpen, setIsDisposalDialogOpen] = useState(false);
  const [isDeliveryDetailsDialogOpen, setIsDeliveryDetailsDialogOpen] = useState(false);
  const [selectedInventoryItem, setSelectedInventoryItem] = useState<InventoryItem | null>(null);
  const [selectedDelivery, setSelectedDelivery] = useState<Delivery | null>(null);
  
  // Stan dla paginacji dostaw
  const [deliveriesPage, setDeliveriesPage] = useState(1);
  const [deliveriesPerPage] = useState(10);

  const [expiringThreshold, setExpiringThreshold] = useState(7);
  const [expiredThreshold, setExpiredThreshold] = useState(-1);

  const { toast } = useToast();

  // Pobieranie danych produktów
  const { data: products, isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/products'],
    select: (data) => data as Product[],
  });

  // Pobieranie danych magazynowych pogrupowanych według produktów
  const { 
    data: groupedInventory, 
    isLoading: isLoadingInventory,
    refetch: refetchInventory 
  } = useQuery({
    queryKey: ['/api/inventory/grouped', refreshTimestamp],
    select: (data) => data as GroupedInventoryItem[],
    staleTime: 0, // Zawsze uznajemy dane za nieaktualne
    gcTime: 0,    // Nie cachujemy wyników
  });

  // Pobieranie elementów magazynowych w terminie
  const { 
    data: inDateItems, 
    isLoading: isLoadingInDateItems,
    refetch: refetchInDateItems 
  } = useQuery({
    queryKey: ['/api/inventory/indate', refreshTimestamp],
    select: (data) => data as InventoryItem[],
    staleTime: 0,
    gcTime: 0,
  });

  // Pobieranie elementów magazynowych przeterminowanych
  const { 
    data: expiredItems, 
    isLoading: isLoadingExpiredItems,
    refetch: refetchExpiredItems 
  } = useQuery({
    queryKey: ['/api/inventory/expired', refreshTimestamp],
    select: (data) => data as InventoryItem[],
    staleTime: 0,
    gcTime: 0,
  });

  // Pobieranie elementów z kończącym się terminem
  const { 
    data: expiringItems, 
    isLoading: isLoadingExpiringItems,
    refetch: refetchExpiringItems 
  } = useQuery({
    queryKey: ['/api/inventory/expiring', refreshTimestamp],
    select: (data) => data as InventoryItem[],
    staleTime: 0,
    gcTime: 0,
  });

  // Stan paginacji dla historii rozchodów
  const [usageLimit, setUsageLimit] = useState<number>(10);
  const [usageOffset, setUsageOffset] = useState<number>(0);
  const [hasMoreUsageHistory, setHasMoreUsageHistory] = useState<boolean>(true);

  // Stan paginacji dla historii utylizacji
  const [disposedLimit, setDisposedLimit] = useState<number>(10);
  const [disposedOffset, setDisposedOffset] = useState<number>(0);
  const [hasMoreDisposedItems, setHasMoreDisposedItems] = useState<boolean>(true);

  // Stan dla przechowywania wszystkich załadowanych danych historii
  const [allUsageHistory, setAllUsageHistory] = useState<any[]>([]);
  const [allDisposedItems, setAllDisposedItems] = useState<InventoryItem[]>([]);

  // Pobieranie historii rozchodów z paginacją
  const { 
    data: usageHistoryPage, 
    isLoading: isLoadingUsageHistory,
    refetch: refetchUsageHistory,
    isFetching: isFetchingUsageHistory
  } = useQuery({
    queryKey: ['/api/inventory/usage', usageLimit, usageOffset, refreshTimestamp],
    queryFn: async () => {
      const response = await apiRequest(`/api/inventory/usage?limit=${usageLimit}&offset=${usageOffset}`);
      // Jeśli otrzymano mniej wyników niż limit, oznacza to, że nie ma więcej danych
      setHasMoreUsageHistory(response.length === usageLimit);
      return response as any[];
    },
    refetchOnWindowFocus: true,
    staleTime: 0, // Zawsze uznajemy dane za nieaktualne
    gcTime: 0, // Nie cachujemy wyników (zamiennik cacheTime w nowszej wersji React Query)
  });

  // Pobieranie historii utylizacji z paginacją
  const { 
    data: disposedItemsPage, 
    isLoading: isLoadingDisposedItems,
    refetch: refetchDisposedItems,
    isFetching: isFetchingDisposedItems
  } = useQuery({
    queryKey: ['/api/inventory/disposed', disposedLimit, disposedOffset, refreshTimestamp],
    queryFn: async () => {
      const response = await apiRequest(`/api/inventory/disposed?limit=${disposedLimit}&offset=${disposedOffset}`);
      // Jeśli otrzymano mniej wyników niż limit, oznacza to, że nie ma więcej danych
      setHasMoreDisposedItems(response.length === disposedLimit);
      return response as InventoryItem[];
    },
    staleTime: 0,
    gcTime: 0,
  });
  
  // Aktualizacja zbiorczych danych po załadowaniu nowej strony
  useEffect(() => {
    if (usageHistoryPage) {
      setAllUsageHistory(prevItems => {
        // Sprawdzamy, czy to pierwsza strona (offset 0)
        if (usageOffset === 0) {
          return [...usageHistoryPage];
        }
        // Łączymy aktualnie załadowane dane z nowymi
        const newItems = [...prevItems];
        // Dodajemy tylko nowe elementy (unikamy duplikatów)
        usageHistoryPage.forEach(item => {
          if (!newItems.some(existingItem => existingItem.id === item.id)) {
            newItems.push(item);
          }
        });
        return newItems;
      });
    }
  }, [usageHistoryPage, usageOffset]);

  // Aktualizacja zbiorczych danych po załadowaniu nowej strony utylizacji
  useEffect(() => {
    if (disposedItemsPage) {
      setAllDisposedItems(prevItems => {
        // Sprawdzamy, czy to pierwsza strona (offset 0)
        if (disposedOffset === 0) {
          return [...disposedItemsPage];
        }
        // Łączymy aktualnie załadowane dane z nowymi
        const newItems = [...prevItems];
        // Dodajemy tylko nowe elementy (unikamy duplikatów)
        disposedItemsPage.forEach(item => {
          if (!newItems.some(existingItem => existingItem.id === item.id)) {
            newItems.push(item);
          }
        });
        return newItems;
      });
    }
  }, [disposedItemsPage, disposedOffset]);
  
  // Funkcje obsługujące paginację
  const loadMoreUsageHistory = () => {
    if (hasMoreUsageHistory && !isFetchingUsageHistory) {
      setUsageOffset(prev => prev + usageLimit);
    }
  };
  
  const loadMoreDisposedItems = () => {
    if (hasMoreDisposedItems && !isFetchingDisposedItems) {
      setDisposedOffset(prev => prev + disposedLimit);
    }
  };

  // Pobieranie historii dostaw
  const { 
    data: deliveries, 
    isLoading: isLoadingDeliveries,
    refetch: refetchDeliveries,
    isFetching: isFetchingDeliveries
  } = useQuery({
    queryKey: ['/api/deliveries', refreshTimestamp],
    select: (data) => data as Delivery[],
    refetchOnWindowFocus: true,
    staleTime: 0, // Zawsze uznajemy dane za nieaktualne
    gcTime: 0, // Nie cachujemy wyników (zamiennik cacheTime w najnowszej wersji React Query)
  });

  // Pobieranie ustawień systemowych
  const { data: settings } = useQuery({
    queryKey: ['/api/settings'],
    select: (data) => data as any,
  });
  
  // Aktualizacja progów na podstawie ustawień
  useEffect(() => {
    if (settings) {
      setExpiringThreshold(settings.expiringDaysThreshold || 7);
      setExpiredThreshold(settings.expiredDaysThreshold || -1);
    }
  }, [settings]);
  
  // WebSocket do odbierania powiadomień o zmianach stanu magazynu
  useEffect(() => {
    // Funkcja obsługująca wiadomości WebSocket
    const handleWebSocketMessage = (event: MessageEvent) => {
      try {
        const message = JSON.parse(event.data);
        console.log('[WebSocket Magazyn] Odebrano wiadomość:', message);
        
        // Obsługa powiadomienia o zmianie stanu magazynu
        if (message.type === 'inventory_changed') {
          console.log('[WebSocket Magazyn] Odebrano powiadomienie o zmianie stanu magazynu. Odświeżam dane...');
          
          // Informujemy użytkownika o aktualizacji
          toast({
            title: "Stan magazynowy zaktualizowany",
            description: "Odświeżam dane magazynu...",
            variant: "default"
          });
          
          // Unieważniamy wszystkie zapytania związane z magazynem w cache
          queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
          queryClient.invalidateQueries({ queryKey: ['/api/inventory/grouped'] });
          queryClient.invalidateQueries({ queryKey: ['/api/inventory/indate'] });
          queryClient.invalidateQueries({ queryKey: ['/api/inventory/expired'] });
          queryClient.invalidateQueries({ queryKey: ['/api/inventory/expiring'] });
          queryClient.invalidateQueries({ queryKey: ['/api/inventory/usage'] });
          queryClient.invalidateQueries({ queryKey: ['/api/inventory/disposed'] });
          queryClient.invalidateQueries({ queryKey: ['/api/diagnostics/inventory-status'] });
          queryClient.invalidateQueries({ queryKey: ['/api/deliveries'] });
          
          // Odświeżamy wszystkie zapytania związane z magazynem
          refetchInventory();
          refetchInDateItems();
          refetchExpiredItems();
          refetchExpiringItems();
          refetchUsageHistory();
          refetchDisposedItems();
          if (deliveries) {
            refetchDeliveries();
          }
          
          // Aktualizujemy znacznik czasu, aby wymusić odświeżenie wszystkich zapytań
          setRefreshTimestamp(Date.now());
        }
      } catch (error) {
        console.error('[WebSocket Magazyn] Błąd przetwarzania wiadomości:', error);
      }
    };

    // Funkcja do nasłuchiwania na wiadomości WebSocket
    const setupWebSocketListener = () => {
      // Określamy adres URL WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      console.log(`[WebSocket Magazyn] Łączenie z ${wsUrl} dla nasłuchiwania zmian magazynu...`);
      
      // Tworzymy nowe połączenie WebSocket do nasłuchiwania
      const ws = new WebSocket(wsUrl);
      
      // Ustawiamy obsługę wiadomości
      ws.addEventListener('message', handleWebSocketMessage);
      
      // Ustawiamy obsługę połączenia
      ws.addEventListener('open', () => {
        console.log('[WebSocket Magazyn] Połączono z serwerem dla nasłuchiwania zmian magazynu');
      });
      
      // Ustawiamy obsługę błędów
      ws.addEventListener('error', (error) => {
        console.error('[WebSocket Magazyn] Błąd połączenia dla nasłuchiwania zmian magazynu:', error);
      });
      
      // Ustawiamy obsługę zamknięcia połączenia
      ws.addEventListener('close', () => {
        console.log('[WebSocket Magazyn] Rozłączono z serwerem dla nasłuchiwania zmian magazynu');
      });
      
      // Zwracamy funkcję czyszczącą
      return () => {
        ws.removeEventListener('message', handleWebSocketMessage);
        ws.close();
      };
    };
    
    // Uruchamiamy nasłuchiwanie
    const cleanup = setupWebSocketListener();
    
    // Zwracamy funkcję czyszczącą
    return cleanup;
  }, [
    toast, 
    refetchInventory, 
    refetchInDateItems, 
    refetchExpiredItems, 
    refetchExpiringItems, 
    refetchUsageHistory, 
    refetchDisposedItems, 
    refetchDeliveries, 
    deliveries
  ]); // Zależności dla useEffect

  // Formularz dla dodawania nowej dostawy
  const deliveryForm = useForm<DeliveryFormValues>({
    resolver: zodResolver(deliveryFormSchema),
    defaultValues: {
      deliveryNumber: `D-${format(new Date(), 'yyyyMMdd')}-001`,
      deliveryDate: new Date(),
      notes: "",
      items: [
        {
          productId: 0,
          quantity: 1,
          expiryDate: addDays(new Date(), 7),
          batchNumber: "",
        }
      ]
    }
  });

  // Formularz dla rozchodu/utylizacji
  const usageForm = useForm<UsageFormValues>({
    resolver: zodResolver(usageFormSchema),
    defaultValues: {
      quantity: 1,
      reason: "",
      notes: "",
    }
  });

  // Mutacja do dodawania nowej dostawy
  const addDeliveryMutation = useMutation({
    mutationFn: async (data: DeliveryFormValues) => {
      console.log("Formularz dostawy przed formatowaniem:", data);
      
      // Konwersja dat na format ISO string i upewnienie się, że items istnieje
      const formattedData = {
        ...data,
        deliveryDate: format(data.deliveryDate, 'yyyy-MM-dd'),
        items: Array.isArray(data.items) ? data.items.map(item => ({
          ...item,
          expiryDate: format(item.expiryDate, 'yyyy-MM-dd')
        })) : []
      };
      
      console.log("Wysyłanie danych dostawy:", formattedData);

      // Sprawdź, czy mamy elementy przed wysłaniem
      if (!formattedData.items || formattedData.items.length === 0) {
        throw new Error('Brak produktów w dostawie');
      }

      return await apiRequest('/api/deliveries', {
        method: 'POST',
        data: formattedData, // Używamy parametru 'data' zamiast 'body'
      });
    },
    onSuccess: () => {
      toast({
        title: "Dostawa dodana",
        description: "Dostawa została pomyślnie dodana do magazynu.",
        variant: "default",
      });
      setIsDeliveryDialogOpen(false);
      deliveryForm.reset();
      // Odświeżenie danych magazynowych
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/grouped'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/indate'] });
      queryClient.invalidateQueries({ queryKey: ['/api/deliveries'] });
      
      // Natychmiastowe odświeżenie danych
      refetchInventory();
      refetchInDateItems();
      refetchDeliveries();
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się dodać dostawy: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  // Mutacja do utylizacji produktu
  const disposeItemMutation = useMutation({
    mutationFn: async (data: { id: number, quantity: number, reason: string }) => {
      return await apiRequest(`/api/inventory/${data.id}/dispose`, {
        method: 'POST',
        data: {
          quantity: data.quantity,
          reason: data.reason,
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Utylizacja zakończona",
        description: "Produkt został pomyślnie zutylizowany.",
        variant: "default",
      });
      setIsDisposalDialogOpen(false);
      usageForm.reset();
      // Odświeżenie danych magazynowych
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/grouped'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/indate'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/expired'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/expiring'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/disposed'] });
      
      // Natychmiastowe odświeżenie danych
      refetchInventory();
      refetchInDateItems();
      refetchExpiredItems();
      refetchExpiringItems();
      refetchDisposedItems();
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się zutylizować produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  // Mutacja do użycia produktu (rozchód)
  const useItemMutation = useMutation({
    mutationFn: async (data: { id: number, quantity: number, reason: string, notes?: string }) => {
      return await apiRequest(`/api/inventory/${data.id}/use`, {
        method: 'POST',
        data: {
          quantity: data.quantity,
          reason: data.reason,
          notes: data.notes
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Rozchód zakończony",
        description: "Produkt został pomyślnie rozchodowany.",
        variant: "default",
      });
      setIsUsageDialogOpen(false);
      usageForm.reset();
      // Odświeżenie danych magazynowych
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/grouped'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/indate'] });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory/usage'] });
      
      // Natychmiastowe odświeżenie danych
      refetchInventory();
      refetchInDateItems();
      refetchUsageHistory();
    },
    onError: (error) => {
      toast({
        title: "Błąd",
        description: `Nie udało się rozchodować produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  // Dodawanie nowego produktu do formularza dostawy
  const addProductToDelivery = () => {
    const items = deliveryForm.getValues().items || [];
    deliveryForm.setValue('items', [
      ...items,
      {
        productId: 0,
        quantity: 1,
        expiryDate: addDays(new Date(), 7),
        batchNumber: "",
      }
    ]);
  };

  // Usuwanie produktu z formularza dostawy
  const removeProductFromDelivery = (index: number) => {
    const items = deliveryForm.getValues().items;
    if (items && items.length > 1) {
      deliveryForm.setValue('items', items.filter((_, i) => i !== index));
    } else {
      toast({
        title: "Uwaga",
        description: "Dostawa musi zawierać przynajmniej jeden produkt.",
        variant: "destructive",
      });
    }
  };

  // Obsługa dodawania nowej dostawy
  const onSubmitDelivery = (data: DeliveryFormValues) => {
    addDeliveryMutation.mutate(data);
  };

  // Obsługa utylizacji produktu
  const onSubmitDisposal = (data: UsageFormValues) => {
    if (selectedInventoryItem) {
      disposeItemMutation.mutate({
        id: selectedInventoryItem.id,
        quantity: data.quantity,
        reason: data.reason,
      });
    }
  };

  // Obsługa użycia produktu (rozchód)
  const onSubmitUsage = (data: UsageFormValues) => {
    if (selectedInventoryItem) {
      useItemMutation.mutate({
        id: selectedInventoryItem.id,
        quantity: data.quantity,
        reason: data.reason,
        notes: data.notes,
      });
    }
  };

  // Otwieranie dialogu utylizacji
  const openDisposalDialog = (item: InventoryItem) => {
    setSelectedInventoryItem(item);
    usageForm.setValue('quantity', Math.min(item.quantity, 1));
    usageForm.setValue('reason', 'disposal');
    usageForm.setValue('notes', 'Utylizacja przedawnionego produktu');
    setIsDisposalDialogOpen(true);
  };

  // Otwieranie dialogu rozchodu
  const openUsageDialog = (item: InventoryItem) => {
    setSelectedInventoryItem(item);
    usageForm.setValue('quantity', Math.min(item.quantity, 1));
    usageForm.setValue('reason', 'manual_usage');
    usageForm.setValue('notes', 'Rozchód produktu');
    setIsUsageDialogOpen(true);
  };

  // Używamy wszystkich danych z magazynu
  const filteredInventory = groupedInventory;
  
  // Obliczanie całkowitej ilości produktów w magazynie
  const calculateTotalInventoryQuantity = () => {
    if (!groupedInventory) return 0;
    return groupedInventory.reduce((total, group) => total + group.availableQuantity, 0);
  };

  // Formatowanie daty
  const formatDate = (dateString: string) => {
    try {
      return format(parseISO(dateString), 'dd.MM.yyyy', { locale: pl });
    } catch (e) {
      return dateString;
    }
  };

  // Sprawdzanie, czy produkt jest przeterminowany (zgodnie z ustawieniami)
  const isExpired = (dateString: string) => {
    if (!dateString) return false;
    
    try {
      const expiryDate = parseISO(dateString);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Produkt jest przeterminowany, jeśli jego data ważności minęła (jest przed dzisiejszą datą)
      return isBefore(expiryDate, today);
    } catch (error) {
      console.error("Błąd w funkcji isExpired:", error);
      return false;
    }
  };

  // Sprawdzanie, czy produkt kończy się termin (zgodnie z ustawieniami)
  const isExpiring = (dateString: string) => {
    // Ochrona przed undefined/null
    if (!dateString) return false;
    
    try {
      // Konwertujemy do daty
      const expiryDate = parseISO(dateString);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Przeterminowany produkt nigdy nie jest "kończący się"
      if (isBefore(expiryDate, today)) {
        return false;
      }
      
      // WAŻNE: Tutaj korzystamy z danych bezpośrednio z API, a nie z lokalnej logiki
      // Sprawdzamy czy produkt znajduje się w liście kończących się produktów
      if (expiringItems && expiryDate) {
        const expiryDateStr = format(expiryDate, 'yyyy-MM-dd');
        const found = expiringItems.some(item => {
          const itemDate = item.expiryDate ? item.expiryDate.split('T')[0] : '';
          return itemDate === expiryDateStr;
        });
        return found;
      }
      
      // Jeśli nie mamy danych z API, używamy lokalnej logiki
      
      // Dla progu = 0, "Kończące się" to te z dzisiejszą datą ważności
      if (expiringThreshold === 0) {
        const isToday = isSameDay(expiryDate, today);
        return isToday;
      }
      
      // Dla progu = 1, "Kończące się" to te z dzisiejszą i jutrzejszą datą ważności
      if (expiringThreshold === 1) {
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const isToday = isSameDay(expiryDate, today);
        const isTomorrow = isSameDay(expiryDate, tomorrow);
        return isToday || isTomorrow;
      }
      
      // Dla progu > 1
      const thresholdDate = new Date(today);
      thresholdDate.setDate(thresholdDate.getDate() + expiringThreshold);
      
      // Produkt jest "kończący się" jeśli ma datę ważności nie późniejszą niż próg (thresholdDate)
      return isBefore(expiryDate, thresholdDate) || isSameDay(expiryDate, thresholdDate);
    } catch (error) {
      console.error("Błąd w funkcji isExpiring:", error);
      return false;
    }
  };
  
  // Sprawdzanie, czy produkt jest "w terminie" (zgodnie z ustawieniami)
  const isInDate = (dateString: string) => {
    // Ochrona przed undefined/null
    if (!dateString) return false;
    
    try {
      // Konwertujemy datę
      const expiryDate = parseISO(dateString);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      // Produkt przeterminowany nigdy nie jest "w terminie"
      if (isBefore(expiryDate, today)) {
        return false;
      }
      
      // WAŻNE: Używamy danych z API, tak samo jak w isExpiring dla spójności
      // Sprawdzamy czy ten produkt jest kończący się wg. API
      if (expiringItems && expiryDate) {
        const expiryDateStr = format(expiryDate, 'yyyy-MM-dd');
        const isExpiringFromAPI = expiringItems.some(item => {
          const itemDate = item.expiryDate ? item.expiryDate.split('T')[0] : '';
          return itemDate === expiryDateStr;
        });
        
        // Jeśli produkt jest w liście kończących się, to nie jest "w terminie"
        if (isExpiringFromAPI) {
          return false;
        }
      } else {
        // Jeśli nie mamy dostępu do danych API, używamy lokalnej logiki
        if (isExpiring(dateString)) {
          return false;
        }
      }
      
      // Wszystkie pozostałe produkty są "w terminie"
      return true;
    } catch (error) {
      console.error("Błąd w funkcji isInDate:", error);
      return false;
    }
  };

  // Render głównego komponentu
  return (
    <div className="container mx-auto pb-8">
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-800">Zarządzanie Magazynem</h3>
        <p className="text-gray-600 mt-1">
          Zarządzaj dostawami, stanem magazynowym i monitoruj terminy ważności produktów
        </p>
      </div>

      <div className="mb-6 flex justify-between items-center">
        <Tabs 
          value={activeTab} 
          onValueChange={(value) => {
            setActiveTab(value);
            // Odświeżamy znacznik czasu przy zmianie zakładki
            setRefreshTimestamp(Date.now());
            
            // Odświeżenie danych przy przejściu na zakładkę dostaw
            if (value === "deliveries") {
              console.log("Przejście na zakładkę dostaw - odświeżam dane...");
              // Unieważniamy cache dla dostawy
              queryClient.invalidateQueries({ queryKey: ['/api/deliveries'] });
              // Wymuszamy natychmiastowe odświeżenie
              setTimeout(() => {
                refetchDeliveries();
              }, 100);
            }
            
            // Odświeżenie danych przy przejściu na zakładkę historii
            if (value === "history") {
              console.log("Przejście na zakładkę historii - odświeżam dane rozchodów...");
              // Unieważniamy cache dla historii rozchodów
              queryClient.invalidateQueries({ queryKey: ['/api/inventory/usage'] });
              // Wymuszamy natychmiastowe odświeżenie
              setTimeout(() => {
                refetchUsageHistory();
              }, 100);
            }
          }} 
          className="flex-grow">
          <TabsList>
            <TabsTrigger value="overview">
              <Package className="h-4 w-4 mr-2" />
              Przegląd
            </TabsTrigger>
            <TabsTrigger value="inventory">
              <PackageOpen className="h-4 w-4 mr-2" />
              Stan magazynu
            </TabsTrigger>
            <TabsTrigger value="expiring">
              <Clock className="h-4 w-4 mr-2" />
              Kończące się
            </TabsTrigger>
            <TabsTrigger value="history">
              <CalendarIcon2 className="h-4 w-4 mr-2" />
              Historia
            </TabsTrigger>
            <TabsTrigger value="deliveries">
              <ShoppingCart className="h-4 w-4 mr-2" />
              Dostawy
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <Button 
          onClick={() => setIsDeliveryDialogOpen(true)}
          className="flex items-center gap-1 bg-green-500 hover:bg-green-600 text-white"
        >
          <Plus className="h-4 w-4" />
          Nowa dostawa
        </Button>
      </div>
      
      <Tabs 
        value={activeTab} 
        onValueChange={(value) => {
          setActiveTab(value);
          // Odświeżamy znacznik czasu przy zmianie zakładki
          setRefreshTimestamp(Date.now());
          
          // Odświeżenie danych przy przejściu na zakładkę dostaw
          if (value === "deliveries") {
            console.log("Przejście na zakładkę dostaw (tabs) - odświeżam dane...");
            // Unieważniamy cache dla dostawy
            queryClient.invalidateQueries({ queryKey: ['/api/deliveries'] });
            // Wymuszamy natychmiastowe odświeżenie
            setTimeout(() => {
              refetchDeliveries();
            }, 100);
          }
          
          // Odświeżenie danych przy przejściu na zakładkę historii
          if (value === "history") {
            console.log("Przejście na zakładkę historii (tabs) - odświeżam dane rozchodów...");
            // Unieważniamy cache dla historii rozchodów
            queryClient.invalidateQueries({ queryKey: ['/api/inventory/usage'] });
            // Wymuszamy natychmiastowe odświeżenie
            setTimeout(() => {
              refetchUsageHistory();
            }, 100);
          }
        }}>

        {/* Zakładka przeglądu */}
        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center">
                  <PackageCheck className="h-5 w-5 mr-2 text-blue-500" />
                  Całkowity stan
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingInventory ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    calculateTotalInventoryQuantity()
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  Suma wszystkich produktów
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center">
                  <PackageOpen className="h-5 w-5 mr-2 text-primary" />
                  Produkty w magazynie
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingInventory ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    groupedInventory?.length || 0
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  Unikalne produkty
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center">
                  <FileWarning className="h-5 w-5 mr-2 text-amber-500" />
                  Kończące się terminy
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingExpiringItems ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    // Sumujemy dostępną liczbę sztuk produktów zamiast liczby unikalnych produktów
                    expiringItems?.reduce((total, item) => {
                      // Obliczamy dostępną ilość (ilość - zużyte - zutylizowane)
                      const available = item.quantity - (item.usedQuantity || 0) - (item.disposedQuantity || 0);
                      return total + (available > 0 ? available : 0);
                    }, 0) || 0
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  Sztuk z kończącym się terminem
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-medium flex items-center">
                  <Trash2 className="h-5 w-5 mr-2 text-red-500" />
                  Przeterminowane
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {isLoadingExpiredItems ? (
                    <Loader2 className="h-6 w-6 animate-spin" />
                  ) : (
                    // Sumujemy dostępną liczbę sztuk przeterminowanych produktów
                    expiredItems?.reduce((total, item) => {
                      // Obliczamy dostępną ilość (ilość - zużyte - zutylizowane)
                      const available = item.quantity - (item.usedQuantity || 0) - (item.disposedQuantity || 0);
                      return total + (available > 0 ? available : 0);
                    }, 0) || 0
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  Sztuk do utylizacji
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Stan magazynu</CardTitle>
              <CardDescription>
                Aktualny stan magazynowy produktów
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingInventory ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredInventory && filteredInventory.length > 0 ? (
                <div className="space-y-4">
                  {filteredInventory.map((group) => {
                    // Znajdź produkt, aby uzyskać URL obrazu
                    const product = products?.find(p => p.id === group.productId);
                    return (
                    <div key={group.productId} className="flex items-center p-4 bg-white rounded-lg border border-gray-200 hover:bg-gray-50">
                      <div className="flex-shrink-0 h-16 w-16 bg-gray-100 rounded-md overflow-hidden mr-4">
                        {product?.imageUrl ? (
                          <img 
                            src={product.imageUrl} 
                            alt={group.productName} 
                            className="h-full w-full object-cover"
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full w-full text-gray-400">
                            <Package className="h-8 w-8" />
                          </div>
                        )}
                      </div>
                      <div className="flex-grow">
                        <h4 className="text-base font-medium text-gray-900">{group.productName}</h4>
                        <div className="flex justify-between mt-1">
                          <div className="text-sm text-gray-500">
                            Dostępne: <span className="font-medium text-gray-900">{group.availableQuantity} szt.</span>
                          </div>
                          <div className="text-sm text-gray-500">
                            Najbliższy termin: <span className={
                              isExpired(group.items[0]?.expiryDate || '') 
                                ? 'text-red-500 font-medium' 
                                : isExpiring(group.items[0]?.expiryDate || '')
                                ? 'text-amber-500 font-medium'
                                : isInDate(group.items[0]?.expiryDate || '')
                                ? 'font-medium text-green-700'
                                : 'font-medium text-gray-900'
                            }>
                              {formatDate(group.items[0]?.expiryDate || '')}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )})}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Package className="h-12 w-12 text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">Brak produktów w magazynie</h3>
                  <p className="text-gray-500 max-w-md mb-6">
                    Aktualnie nie ma żadnych produktów w magazynie. Dodaj nową dostawę, aby uzupełnić stan.
                  </p>
                  <Button onClick={() => setIsDeliveryDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj nową dostawę
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
          
          {expiringItems && expiringItems.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-amber-500" />
                  Produkty z kończącym się terminem
                </CardTitle>
                <CardDescription>
                  Te produkty wkrótce się przeterminują i wymagają uwagi
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Produkt</TableHead>
                      <TableHead>Partia</TableHead>
                      <TableHead>Ilość</TableHead>
                      <TableHead>Data ważności</TableHead>
                      <TableHead>Akcje</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {expiringItems.slice(0, 5).map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.productName || `Produkt ID: ${item.productId}`}</TableCell>
                        <TableCell>{item.batchNumber || "—"}</TableCell>
                        <TableCell>{item.quantity} szt.</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-amber-50 text-amber-700 hover:bg-amber-50">
                            {formatDate(item.expiryDate)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-2 justify-end">
                            <Button 
                              variant="outline" 
                              size="icon"
                              onClick={() => openUsageDialog(item)}
                              title="Rozchód"
                            >
                              <ArrowDownIcon className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {expiringItems.length > 5 && (
                  <div className="flex justify-center mt-4">
                    <Button 
                      variant="link" 
                      onClick={() => setActiveTab("expiring")}
                    >
                      Zobacz wszystkie ({expiringItems.length})
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
          
          {expiredItems && expiredItems.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <AlertCircle className="h-5 w-5 mr-2 text-red-500" />
                  Przeterminowane produkty
                </CardTitle>
                <CardDescription>
                  Te produkty są przeterminowane i powinny zostać zutylizowane
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Produkt</TableHead>
                      <TableHead>Partia</TableHead>
                      <TableHead>Ilość</TableHead>
                      <TableHead>Data ważności</TableHead>
                      <TableHead>Akcje</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {expiredItems.slice(0, 5).map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.productName || `Produkt ID: ${item.productId}`}</TableCell>
                        <TableCell>{item.batchNumber || "—"}</TableCell>
                        <TableCell>{item.quantity} szt.</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-50">
                            {formatDate(item.expiryDate)}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button 
                            variant="destructive" 
                            size="icon"
                            onClick={() => openDisposalDialog(item)}
                            title="Utylizuj"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {expiredItems.length > 5 && (
                  <div className="flex justify-center mt-4">
                    <Button 
                      variant="link" 
                      onClick={() => setActiveTab("expiring")}
                    >
                      Zobacz wszystkie ({expiredItems.length})
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Zakładka stanu magazynu */}
        <TabsContent value="inventory">
          <Card>
            <CardHeader>
              <CardTitle>Stan magazynu</CardTitle>
              <CardDescription>
                Szczegółowy stan magazynowy z podziałem na partie
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingInventory ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : filteredInventory && filteredInventory.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Produkt</TableHead>
                      <TableHead>Partia</TableHead>
                      <TableHead>Data ważności</TableHead>
                      <TableHead>Ilość</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Akcje</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredInventory.flatMap(group => 
                      group.items
                        // Filtruj tylko elementy, które mają dostępną ilość większą niż 0
                        .filter(item => (item.quantity - (item.usedQuantity || 0) - (item.disposedQuantity || 0)) > 0)
                        .map(item => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{group.productName}</TableCell>
                          <TableCell>{item.batchNumber || "—"}</TableCell>
                          <TableCell>
                            {isExpired(item.expiryDate) ? (
                              <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-50">
                                {formatDate(item.expiryDate)}
                              </Badge>
                            ) : isExpiring(item.expiryDate) ? (
                              <Badge variant="outline" className="bg-amber-50 text-amber-700 hover:bg-amber-50">
                                {formatDate(item.expiryDate)}
                              </Badge>
                            ) : isInDate(item.expiryDate) ? (
                              <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                                {formatDate(item.expiryDate)}
                              </Badge>
                            ) : (
                              <Badge variant="outline" className="bg-gray-50 text-gray-700 hover:bg-gray-50">
                                {formatDate(item.expiryDate)}
                              </Badge>
                            )}
                          </TableCell>
                          <TableCell>{item.quantity - (item.usedQuantity || 0) - (item.disposedQuantity || 0)} szt.</TableCell>
                          <TableCell>
                            {isExpired(item.expiryDate) ? (
                              <Badge variant="destructive">Przeterminowany</Badge>
                            ) : isExpiring(item.expiryDate) ? (
                              <Badge variant="outline" className="border-amber-500 text-amber-700">Kończy się termin</Badge>
                            ) : isInDate(item.expiryDate) ? (
                              <Badge variant="outline" className="border-green-500 text-green-700">W terminie</Badge>
                            ) : (
                              <Badge variant="outline" className="border-gray-500 text-gray-700">Nieznany status</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex gap-2 justify-end">
                              <Button 
                                variant="outline" 
                                size="icon"
                                onClick={() => openUsageDialog(item)}
                                title="Rozchód"
                              >
                                <ArrowDownIcon className="h-4 w-4" />
                              </Button>
                              {isExpired(item.expiryDate) && (
                                <Button 
                                  variant="destructive" 
                                  size="icon"
                                  onClick={() => openDisposalDialog(item)}
                                  title="Utylizuj"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Package className="h-12 w-12 text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">Brak produktów w magazynie</h3>
                  <p className="text-gray-500 max-w-md mb-6">
                    Aktualnie nie ma żadnych produktów w magazynie. Dodaj nową dostawę, aby uzupełnić stan.
                  </p>
                  <Button onClick={() => setIsDeliveryDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj nową dostawę
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Zakładka produktów z kończącym się terminem */}
        <TabsContent value="expiring">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-amber-500" />
                  Produkty z kończącym się terminem
                </CardTitle>
                <CardDescription>
                  Te produkty wkrótce się przeterminują i wymagają uwagi
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingExpiringItems ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : expiringItems && expiringItems.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produkt</TableHead>
                        <TableHead>Partia</TableHead>
                        <TableHead>Data ważności</TableHead>
                        <TableHead>Ilość</TableHead>
                        <TableHead>Akcje</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {expiringItems
                        // Filtruj tylko elementy, które mają dostępną ilość większą niż 0
                        .filter(item => (item.quantity - (item.usedQuantity || 0) - (item.disposedQuantity || 0)) > 0)
                        .map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.productName || `Produkt ID: ${item.productId}`}</TableCell>
                          <TableCell>{item.batchNumber || "—"}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-amber-50 text-amber-700 hover:bg-amber-50">
                              {formatDate(item.expiryDate)}
                            </Badge>
                          </TableCell>
                          <TableCell>{item.quantity - (item.usedQuantity || 0) - (item.disposedQuantity || 0)} szt.</TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="outline" 
                              size="icon"
                              onClick={() => openUsageDialog(item)}
                              title="Rozchód"
                            >
                              <ArrowDownIcon className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <CheckCircle className="h-12 w-12 text-green-300 mb-3" />
                    <h3 className="text-lg font-medium text-gray-900 mb-1">Brak produktów kończących się</h3>
                    <p className="text-gray-500 max-w-md">
                      Wszystkie produkty w magazynie mają jeszcze długi termin ważności.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <XCircle className="h-5 w-5 mr-2 text-red-500" />
                  Przeterminowane produkty
                </CardTitle>
                <CardDescription>
                  Te produkty są przeterminowane i powinny zostać zutylizowane
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingExpiredItems ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : expiredItems && expiredItems.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produkt</TableHead>
                        <TableHead>Partia</TableHead>
                        <TableHead>Data ważności</TableHead>
                        <TableHead>Ilość</TableHead>
                        <TableHead>Akcje</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {expiredItems
                        // Filtruj tylko elementy, które mają dostępną ilość większą niż 0
                        .filter(item => (item.quantity - (item.usedQuantity || 0) - (item.disposedQuantity || 0)) > 0)
                        .map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.productName || `Produkt ID: ${item.productId}`}</TableCell>
                          <TableCell>{item.batchNumber || "—"}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="bg-red-50 text-red-700 hover:bg-red-50">
                              {formatDate(item.expiryDate)}
                            </Badge>
                          </TableCell>
                          <TableCell>{item.quantity} szt.</TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="destructive" 
                              size="icon"
                              onClick={() => openDisposalDialog(item)}
                              title="Utylizuj"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <CheckCircle className="h-12 w-12 text-green-300 mb-3" />
                    <h3 className="text-lg font-medium text-gray-900 mb-1">Brak przeterminowanych produktów</h3>
                    <p className="text-gray-500 max-w-md">
                      W magazynie nie ma przeterminowanych produktów.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Zakładka historii */}
        <TabsContent value="history">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Historia rozchodów</CardTitle>
                <CardDescription>
                  Operacje rozchodu produktów z magazynu
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingUsageHistory ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : allUsageHistory && allUsageHistory.length > 0 ? (
                  <div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data</TableHead>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Powód</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {allUsageHistory.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              {item.timestamp ? (
                                <>
                                  {formatDate(item.timestamp)}
                                  <div className="text-xs text-gray-500">
                                    {item.timestamp ? format(parseISO(item.timestamp), 'HH:mm:ss', { locale: pl }) : ''}
                                  </div>
                                </>
                              ) : '—'}
                            </TableCell>
                            <TableCell className="font-medium">
                              {item.productName || products?.find(p => p.id === item.productId)?.name || `Produkt ID: ${item.productId}`}
                            </TableCell>
                            <TableCell>{item.quantity} szt.</TableCell>
                            <TableCell>
                              {item.reason === 'drawer_assignment' ? 'Przypisanie do szuflady' :
                               item.reason === 'manual_usage' ? 'Ręczny rozchód' :
                               item.reason === 'disposal' ? 'Utylizacja' :
                               item.reason === 'sale' ? 'Sprzedaż' :
                               item.reason === 'employee_purchase' ? 'Zakup pracowniczy' : 
                               item.reason === 'Wydanie z automatu' ? 'Wydanie z automatu' : 
                               item.reason}
                              {item.employeeData && (
                                <div className="text-xs text-gray-500">
                                  {`${item.employeeData.firstName} ${item.employeeData.lastName}`}
                                </div>
                              )}
                              {item.chamberNumber && (
                                <div className="text-xs text-gray-500">
                                  {`Szuflada: ${item.chamberNumber}`}
                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    
                    {hasMoreUsageHistory && (
                      <div className="mt-4 flex justify-center">
                        <Button 
                          variant="outline" 
                          onClick={loadMoreUsageHistory}
                          disabled={isFetchingUsageHistory}
                        >
                          {isFetchingUsageHistory ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Ładowanie...
                            </>
                          ) : (
                            "Załaduj więcej"
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <FileText className="h-12 w-12 text-gray-300 mb-3" />
                    <h3 className="text-lg font-medium text-gray-900 mb-1">Brak historii rozchodów</h3>
                    <p className="text-gray-500 max-w-md">
                      Jeszcze nie zarejestrowano żadnych operacji rozchodu.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Historia utylizacji</CardTitle>
                <CardDescription>
                  Zutylizowane produkty
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoadingDisposedItems ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : allDisposedItems && allDisposedItems.length > 0 ? (
                  <div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Data</TableHead>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Przyczyna</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {allDisposedItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              {item.disposedAt ? (
                                <>
                                  {formatDate(item.disposedAt)}
                                  <div className="text-xs text-gray-500">
                                    {item.disposedAt ? format(parseISO(item.disposedAt), 'HH:mm:ss', { locale: pl }) : ''}
                                  </div>
                                </>
                              ) : '—'}
                            </TableCell>
                            <TableCell className="font-medium">
                              {item.productName || products?.find(p => p.id === item.productId)?.name || `Produkt ID: ${item.productId}`}
                            </TableCell>
                            <TableCell>{item.disposedQuantity || item.quantity} szt.</TableCell>
                            <TableCell>
                              {item.disposalReason === 'expired' ? 'Przeterminowanie' : 
                               item.disposalReason === 'damaged' ? 'Uszkodzenie' : 
                               item.disposalReason === 'quality_issue' ? 'Problem jakościowy' : 
                               item.disposalReason || 'Przeterminowanie'
                              }
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    
                    {hasMoreDisposedItems && (
                      <div className="mt-4 flex justify-center">
                        <Button 
                          variant="outline" 
                          onClick={loadMoreDisposedItems}
                          disabled={isFetchingDisposedItems}
                        >
                          {isFetchingDisposedItems ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Ładowanie...
                            </>
                          ) : (
                            "Załaduj więcej"
                          )}
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <FileText className="h-12 w-12 text-gray-300 mb-3" />
                    <h3 className="text-lg font-medium text-gray-900 mb-1">Brak historii utylizacji</h3>
                    <p className="text-gray-500 max-w-md">
                      Jeszcze nie zarejestrowano żadnych utylizacji produktów.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Zakładka dostaw */}
        <TabsContent value="deliveries">
          <Card>
            <CardHeader>
              <CardTitle>Historia dostaw</CardTitle>
              <CardDescription>
                Lista dostaw do magazynu
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingDeliveries ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : deliveries && deliveries.length > 0 ? (
                <div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Nr dostawy</TableHead>
                        <TableHead>Data dostawy</TableHead>
                        <TableHead>Liczba produktów</TableHead>
                        <TableHead>Uwagi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {deliveries
                        .slice((deliveriesPage - 1) * deliveriesPerPage, deliveriesPage * deliveriesPerPage)
                        .map((delivery) => (
                          <TableRow key={delivery.id}>
                            <TableCell className="font-medium">{delivery.deliveryNumber}</TableCell>
                            <TableCell>{formatDate(delivery.deliveryDate)}</TableCell>
                            <TableCell>
                              {delivery.items?.length || 0} pozycji 
                              ({delivery.items?.reduce((sum, item) => sum + item.quantity, 0) || 0} szt.)
                            </TableCell>
                            <TableCell className="flex justify-between items-center">
                              <span>{delivery.notes || "—"}</span>
                              <Button 
                                variant="ghost" 
                                size="sm"
                                onClick={() => {
                                  setSelectedDelivery(delivery);
                                  setIsDeliveryDetailsDialogOpen(true);
                                }}
                                className="ml-2"
                              >
                                <FileText className="h-4 w-4" />
                                <span className="ml-1">Szczegóły</span>
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                
                  <div className="flex items-center justify-between space-x-2 py-4">
                    <div className="text-sm text-muted-foreground">
                      Strona {deliveriesPage} z {Math.ceil(deliveries.length / deliveriesPerPage)}
                    </div>
                    <div className="space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeliveriesPage((prev) => Math.max(prev - 1, 1))}
                        disabled={deliveriesPage === 1}
                      >
                        Poprzednia
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeliveriesPage((prev) => Math.min(prev + 1, Math.ceil(deliveries.length / deliveriesPerPage)))}
                        disabled={deliveriesPage === Math.ceil(deliveries.length / deliveriesPerPage)}
                      >
                        Następna
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <ShoppingCart className="h-12 w-12 text-gray-300 mb-3" />
                  <h3 className="text-lg font-medium text-gray-900 mb-1">Brak dostaw</h3>
                  <p className="text-gray-500 max-w-md mb-6">
                    Nie znaleziono żadnych zarejestrowanych dostaw. Dodaj nową dostawę, aby uzupełnić magazyn.
                  </p>
                  <Button onClick={() => setIsDeliveryDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj nową dostawę
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Dialog dodawania nowej dostawy */}
      <Dialog open={isDeliveryDialogOpen} onOpenChange={setIsDeliveryDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Dodaj nową dostawę</DialogTitle>
            <DialogDescription>
              Zarejestruj nową dostawę produktów do magazynu
            </DialogDescription>
          </DialogHeader>
          <Form {...deliveryForm}>
            <form onSubmit={deliveryForm.handleSubmit(onSubmitDelivery)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={deliveryForm.control}
                  name="deliveryNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Numer dostawy</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="D-20250401-001" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={deliveryForm.control}
                  name="deliveryDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Data dostawy</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={
                                "pl-3 text-left font-normal flex justify-between items-center " +
                                (!field.value && "text-muted-foreground")
                              }
                            >
                              {field.value ? (
                                format(field.value, "PP", { locale: pl })
                              ) : (
                                <span>Wybierz datę</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            locale={pl}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
                
              <FormField
                control={deliveryForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Uwagi (opcjonalnie)</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Dodatkowe informacje o dostawie..." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-medium">Produkty w dostawie</h4>
                  <Button type="button" variant="outline" size="sm" onClick={addProductToDelivery}>
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj produkt
                  </Button>
                </div>

                <Separator />

                {deliveryForm.watch("items")?.map((_, index) => (
                  <div key={index} className="p-4 border rounded-md bg-gray-50">
                    <div className="flex justify-between items-center mb-3">
                      <h5 className="text-sm font-medium">Produkt {index + 1}</h5>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm"
                        onClick={() => removeProductFromDelivery(index)}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <FormField
                        control={deliveryForm.control}
                        name={`items.${index}.productId`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Produkt</FormLabel>
                            <Select
                              onValueChange={(value) => field.onChange(parseInt(value))}
                              defaultValue={field.value.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Wybierz produkt" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {products?.map((product) => (
                                  <SelectItem key={product.id} value={product.id.toString()}>
                                    {product.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={deliveryForm.control}
                        name={`items.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Ilość</FormLabel>
                            <FormControl>
                              <Input
                                type="number"
                                min="1"
                                {...field}
                                onChange={(e) => field.onChange(parseInt(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={deliveryForm.control}
                        name={`items.${index}.expiryDate`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Data ważności</FormLabel>
                            <FormControl>
                              <div className="relative">
                                <Input
                                  type="date"
                                  className="w-full"
                                  value={field.value instanceof Date ? field.value.toISOString().split('T')[0] : field.value || ''}
                                  onChange={(e) => {
                                    // Jeśli schema oczekuje Date, konwertujemy na Date, w przeciwnym razie zostawiamy jako string
                                    const value = e.target.value;
                                    field.onChange(value);
                                  }}
                                />
                              </div>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={deliveryForm.control}
                      name={`items.${index}.batchNumber`}
                      render={({ field }) => (
                        <FormItem className="mt-3">
                          <FormLabel>Numer partii (opcjonalnie)</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Numer partii produktu..." />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                ))}
              </div>

              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDeliveryDialogOpen(false)}
                >
                  Anuluj
                </Button>
                <Button 
                  type="submit" 
                  disabled={addDeliveryMutation.isPending}
                >
                  {addDeliveryMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Dodaj dostawę
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Dialog utylizacji produktu */}
      <Dialog open={isDisposalDialogOpen} onOpenChange={setIsDisposalDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Utylizacja produktu</DialogTitle>
            <DialogDescription>
              Wprowadź ilość produktu do utylizacji
            </DialogDescription>
          </DialogHeader>
          <Form {...usageForm}>
            <form onSubmit={usageForm.handleSubmit(onSubmitDisposal)} className="space-y-4">
              {selectedInventoryItem && (
                <div className="p-4 border rounded bg-muted mb-4">
                  <p className="text-sm font-medium">{selectedInventoryItem.productName || `Produkt ID: ${selectedInventoryItem.productId}`}</p>
                  <p className="text-sm text-muted-foreground">
                    Data ważności: {formatDate(selectedInventoryItem.expiryDate)}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Dostępna ilość: {selectedInventoryItem.quantity} szt.
                  </p>
                  {selectedInventoryItem.batchNumber && (
                    <p className="text-sm text-muted-foreground">
                      Partia: {selectedInventoryItem.batchNumber}
                    </p>
                  )}
                </div>
              )}

              <FormField
                control={usageForm.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ilość do utylizacji</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        max={selectedInventoryItem?.quantity || 1}
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormDescription>
                      Maksymalna ilość: {selectedInventoryItem?.quantity || 0} szt.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={usageForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Uwagi (opcjonalnie)</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Dodatkowe informacje o utylizacji..." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDisposalDialogOpen(false)}
                >
                  Anuluj
                </Button>
                <Button 
                  type="submit" 
                  variant="destructive" 
                  disabled={disposeItemMutation.isPending}
                >
                  {disposeItemMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Utylizuj
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Dialog rozchodu produktu */}
      <Dialog open={isUsageDialogOpen} onOpenChange={setIsUsageDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rozchód produktu</DialogTitle>
            <DialogDescription>
              Wprowadź ilość i powód rozchodu produktu
            </DialogDescription>
          </DialogHeader>
          <Form {...usageForm}>
            <form onSubmit={usageForm.handleSubmit(onSubmitUsage)} className="space-y-4">
              {selectedInventoryItem && (
                <div className="p-4 border rounded bg-muted mb-4">
                  <p className="text-sm font-medium">{selectedInventoryItem.productName || `Produkt ID: ${selectedInventoryItem.productId}`}</p>
                  <p className="text-sm text-muted-foreground">
                    Data ważności: {formatDate(selectedInventoryItem.expiryDate)}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Dostępna ilość: {selectedInventoryItem.quantity} szt.
                  </p>
                  {selectedInventoryItem.batchNumber && (
                    <p className="text-sm text-muted-foreground">
                      Partia: {selectedInventoryItem.batchNumber}
                    </p>
                  )}
                </div>
              )}

              <FormField
                control={usageForm.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Ilość do rozchodu</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        max={selectedInventoryItem?.quantity || 1}
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormDescription>
                      Maksymalna ilość: {selectedInventoryItem?.quantity || 0} szt.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={usageForm.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Powód rozchodu</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Wybierz powód" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="manual_usage">Ręczny rozchód</SelectItem>
                        <SelectItem value="drawer_assignment">Przypisanie do szuflady</SelectItem>
                        <SelectItem value="other">Inny powód</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={usageForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Uwagi (opcjonalnie)</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Dodatkowe informacje o rozchodzie..." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsUsageDialogOpen(false)}
                >
                  Anuluj
                </Button>
                <Button 
                  type="submit" 
                  disabled={useItemMutation.isPending}
                >
                  {useItemMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Zapisz rozchód
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Dialog szczegółów dostawy */}
      <Dialog open={isDeliveryDetailsDialogOpen} onOpenChange={setIsDeliveryDetailsDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Szczegóły dostawy</DialogTitle>
            <DialogDescription>
              {selectedDelivery && (
                <>
                  <span className="font-medium">{selectedDelivery.deliveryNumber}</span>
                  <span className="mx-2">•</span>
                  <span>{formatDate(selectedDelivery.deliveryDate)}</span>
                </>
              )}
            </DialogDescription>
          </DialogHeader>
          
          {selectedDelivery && (
            <div className="space-y-6">
              {selectedDelivery.notes && (
                <div className="bg-muted p-4 rounded-md">
                  <h4 className="text-sm font-medium mb-2">Uwagi:</h4>
                  <p className="text-sm">{selectedDelivery.notes}</p>
                </div>
              )}
              
              <div>
                <h4 className="text-sm font-medium mb-3">Produkty w dostawie:</h4>
                {selectedDelivery.items && selectedDelivery.items.length > 0 ? (
                  <div className="border rounded-md overflow-hidden">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Produkt</TableHead>
                          <TableHead>Ilość</TableHead>
                          <TableHead>Data ważności</TableHead>
                          <TableHead>Partia</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {selectedDelivery.items.map((item, index) => {
                          // Znajdź nazwę produktu
                          const product = products?.find(p => p.id === item.productId);
                          
                          // Określ kolor statusu
                          let statusColor = "text-green-600";
                          if (item.status === "Zutylizowany" || item.status === "Częściowo zutylizowany") {
                            statusColor = "text-red-600";
                          } else if (item.status === "Użyty" || item.status === "Częściowo użyty") {
                            statusColor = "text-blue-600";
                          }
                          
                          return (
                            <TableRow key={index}>
                              <TableCell className="font-medium">{item.productName || product?.name || `Produkt ID: ${item.productId}`}</TableCell>
                              <TableCell>{item.quantity} szt.</TableCell>
                              <TableCell>{formatDate(item.expiryDate)}</TableCell>
                              <TableCell>{item.batchNumber || "—"}</TableCell>
                              <TableCell className={statusColor}>{item.status || "Dostępny"}</TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>Brak produktów w tej dostawie</p>
                  </div>
                )}
              </div>
              
              <DialogFooter>
                <Button 
                  type="button" 
                  onClick={() => setIsDeliveryDetailsDialogOpen(false)}
                >
                  Zamknij
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};