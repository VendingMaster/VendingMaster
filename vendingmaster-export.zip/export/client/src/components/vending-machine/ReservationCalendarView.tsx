import React, { useState, useEffect } from 'react';
import { format, addDays, subDays, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay } from 'date-fns';
import { pl } from 'date-fns/locale';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Calendar as CalendarIcon, 
  Utensils, 
  User, 
  Package, 
  Info,
  ChevronLeft,
  ChevronRight,
  MousePointer,
  Lightbulb,
  RefreshCcw,
  Clock
} from 'lucide-react';
import { cn } from '@/lib/utils';

// Typy danych
type Employee = {
  id: number;
  firstName: string;
  lastName: string;
  email?: string;
  position?: string;
  department?: string;
  photoUrl?: string | null;
  dietaryPreferences?: string[];
};

type MealReservation = {
  id: number;
  employeeId: number;
  productId: number;
  reservedForDate: string;
  chamberId?: number | null;
  assignmentType?: 'manual' | 'preference' | 'random' | null;
};

type WorkDay = {
  id: number;
  employeeId: number;
  workDate: string;
  isWorking: boolean;
};

type DailyReservationProps = {
  selectedDate: Date;
  onSelectDate: (date: Date) => void;
};

export const ReservationCalendarView: React.FC<DailyReservationProps> = ({ 
  selectedDate,
  onSelectDate
}) => {
  const [currentMonth, setCurrentMonth] = useState<Date>(selectedDate);
  
  // Format dates for API
  const formattedSelectedDate = format(selectedDate, 'yyyy-MM-dd');
  
  // Get days for current month view
  const getDaysInMonth = () => {
    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    
    return eachDayOfInterval({ start: monthStart, end: monthEnd });
  };
  
  // Fetch meal reservations for the month
  const { data: monthlyReservations = [] } = useQuery({
    queryKey: ['/api/meal-reservations', { 
      startDate: format(startOfMonth(currentMonth), 'yyyy-MM-dd'),
      endDate: format(endOfMonth(currentMonth), 'yyyy-MM-dd')
    }],
    queryFn: async () => {
      try {
        const startDate = format(startOfMonth(currentMonth), 'yyyy-MM-dd');
        const endDate = format(endOfMonth(currentMonth), 'yyyy-MM-dd');
        
        const response = await apiRequest(`/api/meal-reservations?startDate=${startDate}&endDate=${endDate}`);
        if (response && response.reservations) {
          return response.reservations;
        }
        return [];
      } catch (error) {
        console.error('Błąd podczas pobierania rezerwacji na miesiąc:', error);
        return [];
      }
    }
  });
  
  // Group reservations by date
  const reservationCountsByDate = monthlyReservations.reduce((acc: Record<string, number>, reservation: any) => {
    const date = reservation.reservedForDate;
    acc[date] = (acc[date] || 0) + 1;
    return acc;
  }, {});
  
  const renderCalendarDay = (day: Date) => {
    const dateStr = format(day, 'yyyy-MM-dd');
    const isToday = isSameDay(day, new Date());
    const isSelected = isSameDay(day, selectedDate);
    const reservationCount = reservationCountsByDate[dateStr] || 0;
    
    return (
      <button
        key={dateStr}
        className={cn(
          "h-9 w-9 p-0 font-normal relative rounded-full",
          !isSameMonth(day, currentMonth) && "text-gray-400",
          isToday && "bg-blue-50 text-blue-900 font-medium",
          isSelected && "bg-primary text-primary-foreground font-medium",
          !isSelected && !isToday && isSameMonth(day, currentMonth) && "hover:bg-gray-100"
        )}
        onClick={() => onSelectDate(day)}
      >
        <time dateTime={dateStr}>{format(day, 'd')}</time>
        {reservationCount > 0 && (
          <span className="absolute bottom-0 right-0 flex h-3 w-3 items-center justify-center rounded-full bg-blue-100 text-[8px] text-blue-700">
            {reservationCount}
          </span>
        )}
      </button>
    );
  };
  
  // Navigation functions
  const nextMonth = () => {
    setCurrentMonth(month => addDays(month, 32)); // Ensure we move to next month
  };
  
  const prevMonth = () => {
    setCurrentMonth(month => subDays(month, 1)); // Ensure we move to previous month
  };
  
  return (
    <div className="p-3 border rounded-lg shadow-sm bg-white">
      <div className="space-y-4">
        {/* Month navigation */}
        <div className="flex items-center justify-between">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={prevMonth}
          >
            <ChevronLeft className="h-4 w-4" />
            <span className="sr-only">Poprzedni miesiąc</span>
          </Button>
          
          <h2 className="font-medium text-lg capitalize">
            {format(currentMonth, 'LLLL yyyy', { locale: pl })}
          </h2>
          
          <Button 
            variant="ghost" 
            size="icon"
            onClick={nextMonth}
          >
            <ChevronRight className="h-4 w-4" />
            <span className="sr-only">Następny miesiąc</span>
          </Button>
        </div>
        
        {/* Days of week */}
        <div className="grid grid-cols-7 text-center text-xs text-gray-500">
          <div>pon</div>
          <div>wto</div>
          <div>śro</div>
          <div>czw</div>
          <div>pią</div>
          <div>sob</div>
          <div>nie</div>
        </div>
        
        {/* Days grid */}
        <div className="grid grid-cols-7 text-sm gap-1">
          {getDaysInMonth().map(day => renderCalendarDay(day))}
        </div>
      </div>
    </div>
  );
};

// Komponent do wyświetlania pracowników i ich rezerwacji na wybrany dzień
export const DailyEmployeeReservations: React.FC<DailyReservationProps> = ({
  selectedDate
}) => {
  const formattedDate = format(selectedDate, 'yyyy-MM-dd');
  
  // Pracownicy
  const { data: employees = [] } = useQuery({
    queryKey: ['/api/employees'],
    queryFn: async () => {
      const response = await apiRequest('/api/employees');
      return response as Employee[];
    }
  });
  
  // Produkty
  const { data: products = [] } = useQuery({
    queryKey: ['/api/products'],
    queryFn: async () => {
      const response = await apiRequest('/api/products');
      return response;
    }
  });
  
  // Rezerwacje na wybrany dzień
  const { data: reservationsData = { reservations: [] } } = useQuery({
    queryKey: ['/api/meal-reservations', { date: formattedDate }],
    queryFn: async () => {
      const response = await apiRequest(`/api/meal-reservations?date=${formattedDate}`);
      return response;
    }
  });
  
  // Szuflady
  const { data: chambersData = { chambers: [] } } = useQuery({
    queryKey: ['/api/chambers'],
    queryFn: async () => {
      const response = await apiRequest('/api/chambers');
      return response;
    }
  });
  
  // Status pracy pracowników na wybrany dzień
  const [employeeWorkStatus, setEmployeeWorkStatus] = useState<Record<number, boolean>>({});
  
  // Pobranie statusu pracy dla każdego pracownika
  useEffect(() => {
    const fetchWorkStatuses = async () => {
      const statuses: Record<number, boolean> = {};
      
      for (const employee of employees) {
        try {
          const response = await apiRequest(`/api/employee-work-days/by-employee/${employee.id}?date=${formattedDate}`);
          
          if (Array.isArray(response) && response.length > 0) {
            // Jeśli mamy zapis, używamy jego wartości isWorking
            statuses[employee.id] = response[0].isWorking !== false;
          } else {
            // Domyślnie pracownik nie pracuje jeśli nie ma zapisu
            statuses[employee.id] = false;
          }
        } catch (error) {
          console.error(`Błąd pobierania statusu pracy dla pracownika ${employee.id}:`, error);
          statuses[employee.id] = false;
        }
      }
      
      setEmployeeWorkStatus(statuses);
    };
    
    if (employees.length > 0) {
      fetchWorkStatuses();
    }
  }, [employees, formattedDate]);
  
  // Rezerwacje dla pracowników
  const employeeReservations: Record<number, any> = {};
  if (reservationsData && reservationsData.reservations) {
    // Grupujemy po pracowniku, biorąc najnowszą rezerwację (największe ID)
    reservationsData.reservations.forEach((reservation: any) => {
      const existingReservation = employeeReservations[reservation.employeeId];
      
      if (!existingReservation || reservation.id > existingReservation.id) {
        employeeReservations[reservation.employeeId] = reservation;
      }
    });
  }
  
  // Mapowanie szuflad do pracowników
  const chambersByEmployee: Record<number, number> = {};
  (chambersData.chambers || []).forEach((chamber: any) => {
    if (chamber.employeeId) {
      chambersByEmployee[chamber.employeeId] = chamber.id;
    }
  });
  
  // Pomocnicza funkcja do znalezienia nazwy produktu
  const getProductName = (productId: number) => {
    const product = products.find((p: any) => p.id === productId);
    return product ? product.name : `Produkt #${productId}`;
  };
  
  // Helper do wyświetlania typu przypisania
  const getAssignmentTypeInfo = (type: string | null | undefined) => {
    switch(type) {
      case 'manual':
        return {
          label: 'Wybór użytkownika',
          icon: <MousePointer className="h-3 w-3 mr-1" />,
          bgColor: 'bg-green-50',
          textColor: 'text-green-700'
        };
      case 'preference':
        return {
          label: 'Wg preferencji',
          icon: <Lightbulb className="h-3 w-3 mr-1" />,
          bgColor: 'bg-yellow-50',
          textColor: 'text-yellow-700'
        };
      case 'random':
        return {
          label: 'Losowy wybór',
          icon: <RefreshCcw className="h-3 w-3 mr-1" />,
          bgColor: 'bg-blue-50',
          textColor: 'text-blue-700'
        };
      default:
        return {
          label: 'Bez przypisania',
          icon: <Clock className="h-3 w-3 mr-1" />,
          bgColor: 'bg-gray-50',
          textColor: 'text-gray-500'
        };
    }
  };
  
  // Sortujemy pracowników: najpierw pracujący z rezerwacjami, potem pracujący bez rezerwacji, potem niepracujący
  const sortedEmployees = [...employees].sort((a, b) => {
    const aIsWorking = employeeWorkStatus[a.id] === true;
    const bIsWorking = employeeWorkStatus[b.id] === true;
    
    // Najpierw według statusu pracy
    if (aIsWorking && !bIsWorking) return -1;
    if (!aIsWorking && bIsWorking) return 1;
    
    // Dla pracujących, sortowanie według posiadania rezerwacji
    if (aIsWorking && bIsWorking) {
      const aHasReservation = !!employeeReservations[a.id];
      const bHasReservation = !!employeeReservations[b.id];
      
      if (aHasReservation && !bHasReservation) return -1;
      if (!aHasReservation && bHasReservation) return 1;
    }
    
    // Na końcu alfabetycznie według nazwiska
    return (a.lastName + ' ' + a.firstName).localeCompare(b.lastName + ' ' + b.firstName);
  });
  
  return (
    <Card>
      <CardContent className="p-0">
        <ScrollArea className="h-[calc(100vh-420px)] pr-2">
          <div className="p-4">
            <h3 className="font-medium text-lg mb-3">
              Rezerwacje na {format(selectedDate, 'd MMMM yyyy', { locale: pl })}
            </h3>
            
            {sortedEmployees.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-muted-foreground py-8">
                <Info className="h-8 w-8 mb-2 opacity-50" />
                <p>Brak danych o pracownikach.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {sortedEmployees.map(employee => {
                  const isWorking = employeeWorkStatus[employee.id] === true;
                  const reservation = employeeReservations[employee.id];
                  const chamberNumber = chambersByEmployee[employee.id];
                  
                  return (
                    <div 
                      key={employee.id}
                      className={cn(
                        "border rounded-md overflow-hidden",
                        isWorking ? "border-l-4 border-l-green-400" : "border-l-4 border-l-gray-300 opacity-75"
                      )}
                    >
                      <div className="flex flex-col md:flex-row items-stretch">
                        {/* Informacje o pracowniku */}
                        <div className="p-3 flex items-center space-x-3 flex-1">
                          <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                            <User className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h4 className="font-medium">{employee.firstName} {employee.lastName}</h4>
                            <p className="text-sm text-muted-foreground">
                              {isWorking ? "Pracuje" : "Nie pracuje w tym dniu"}
                            </p>
                          </div>
                        </div>
                        
                        {/* Informacje o rezerwacji */}
                        <div className={cn(
                          "p-3 md:min-w-[240px]",
                          isWorking && reservation ? "bg-blue-50" : "bg-gray-50"
                        )}>
                          {isWorking ? (
                            reservation ? (
                              <div className="space-y-1.5">
                                <div className="flex items-center text-sm font-medium text-green-700">
                                  <Utensils className="h-4 w-4 mr-1.5" />
                                  {getProductName(reservation.productId)}
                                </div>
                                
                                {/* Informacja o przypisaniu */}
                                <div className={cn(
                                  "text-xs flex items-center px-2 py-1 rounded-md",
                                  getAssignmentTypeInfo(reservation.assignmentType).bgColor,
                                  getAssignmentTypeInfo(reservation.assignmentType).textColor
                                )}>
                                  {getAssignmentTypeInfo(reservation.assignmentType).icon}
                                  {getAssignmentTypeInfo(reservation.assignmentType).label}
                                </div>
                                
                                {/* Informacja o szufladzie */}
                                {chamberNumber && (
                                  <div className="text-xs flex items-center text-purple-700">
                                    <Package className="h-3.5 w-3.5 mr-1.5" />
                                    Szuflada #{chamberNumber}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <div className="flex items-center h-full">
                                <p className="text-sm text-muted-foreground italic">
                                  Brak zamówienia
                                </p>
                              </div>
                            )
                          ) : (
                            <div className="flex items-center h-full">
                              <p className="text-sm text-muted-foreground italic">
                                Nie pracuje w tym dniu
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};