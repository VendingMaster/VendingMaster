import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Product, Chamber, ProductCategory, Category, PRODUCT_CATEGORIES, Settings as AppSettings, DietaryPreference } from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { calculateGrossPrice, formatPrice } from '@/lib/utils';
import { ScreenSaver } from './ScreenSaver';

// Rozszerzenie typu Window o websocket
declare global {
  interface Window {
    websocket?: WebSocket;
  }
}
import { 
  AdminModal, 
  AllergensModal, 
  IngredientsModal, 
  DietaryPreferencesModal 
} from './modals/index';
import { 
  ShoppingCart, 
  Coffee, 
  Soup, 
  Salad, 
  Beer, 
  Cookie,
  UtensilsCrossed
} from 'lucide-react';

export const KioskView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("wszystkie");
  const [activeIndex, setActiveIndex] = useState(0);
  const [selectedChamber, setSelectedChamber] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: products, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Pobieranie szuflad z automatycznym odświeżaniem co 60 sekund w trybie kiosk
  const { data: chambersData, isLoading: chambersLoading } = useQuery<{chambers: Chamber[], timestamp: number}>({
    queryKey: ['/api/chambers'],
    // Dodajemy automatyczne odświeżanie co 60 sekund
    refetchInterval: 60000, // co 60 sekund
    refetchIntervalInBackground: true,
  });
  
  const { data: settings, isLoading: settingsLoading } = useQuery<AppSettings>({
    queryKey: ['/api/settings'],
  });
  
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Ekstrahuj chambers z odpowiedzi API
  const chambers = chambersData?.chambers || [];
  
  const availableChambers = chambers.filter(chamber => chamber.isAvailable) || [];

  // Nasłuchiwanie na wiadomości WebSocket dla aktualizacji w czasie rzeczywistym
  useEffect(() => {
    // Referencja do queryClient, abyśmy mogli odświeżyć dane
    const refreshData = () => {
      console.log('[Kiosk] Odświeżanie danych szuflad po otrzymaniu powiadomienia WebSocket');
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
    };

    // Funkcja obsługująca wiadomości WebSocket
    const handleWebSocketMessage = (event: MessageEvent) => {
      try {
        const message = JSON.parse(event.data);
        console.log('[WebSocket Kiosk] Odebrano wiadomość:', message);
        
        // Obsługa różnych typów wiadomości
        if (message.type === 'inventory_changed' || message.type === 'drawer_status') {
          console.log('[WebSocket Kiosk] Wykryto zmianę stanu szuflad. Odświeżam dane...');
          refreshData();
        }
      } catch (error) {
        console.error('[WebSocket Kiosk] Błąd przetwarzania wiadomości:', error);
      }
    };

    // Sprawdź, czy już istnieje globalne połączenie WebSocket
    if (window.websocket) {
      console.log('[WebSocket Kiosk] Używam istniejącego połączenia WebSocket');
      window.websocket.addEventListener('message', handleWebSocketMessage);
    } else {
      console.log('[WebSocket Kiosk] Tworzenie nowego połączenia WebSocket');
      // Określamy adres URL WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      try {
        const ws = new WebSocket(wsUrl);
        
        ws.addEventListener('open', () => {
          console.log('[WebSocket Kiosk] Połączono z serwerem');
        });
        
        ws.addEventListener('message', handleWebSocketMessage);
        
        ws.addEventListener('error', (error) => {
          console.error('[WebSocket Kiosk] Błąd połączenia:', error);
        });
        
        // Zachowaj referencję do WebSocket globalnie
        window.websocket = ws;
      } catch (error) {
        console.error('[WebSocket Kiosk] Błąd podczas tworzenia połączenia:', error);
      }
    }
    
    // Sprzątanie przy demontażu komponentu
    return () => {
      if (window.websocket) {
        window.websocket.removeEventListener('message', handleWebSocketMessage);
      }
    };
  }, [queryClient]);

  const getProductById = (id: number | null) => {
    if (!id || !products) return null;
    return products.find(product => product.id === id);
  };

  // Grupujemy komory według produktów
  const groupedProducts = useMemo(() => {
    if (!products || !availableChambers.length) return [];
    
    const productMap = new Map<number, Chamber[]>();
    
    // Grupujemy komory według ID produktów
    availableChambers.forEach(chamber => {
      if (chamber.productId) {
        if (!productMap.has(chamber.productId)) {
          productMap.set(chamber.productId, []);
        }
        productMap.get(chamber.productId)?.push(chamber);
      }
    });
    
    // Tworzymy tablicę unikalnych produktów z przypisanymi im komorami
    const result: { product: Product; chambers: Chamber[] }[] = [];
    
    productMap.forEach((chambers, productId) => {
      const product = getProductById(productId);
      if (product) {
        // Sortujemy komory według ID (od najmniejszego do największego)
        const sortedChambers = chambers.sort((a, b) => a.id - b.id);
        result.push({ product, chambers: sortedChambers });
      }
    });
    
    return result;
  }, [products, availableChambers]);
  
  // Filtrujemy produkty według wybranej kategorii
  const filteredProducts = useMemo(() => {
    if (selectedCategory === "wszystkie") {
      return groupedProducts;
    }
    
    return groupedProducts.filter(
      ({ product }) => product.category === selectedCategory
    );
  }, [groupedProducts, selectedCategory]);

  // Resetowanie indeksu aktywnego produktu, gdy zmienia się kategoria lub liczba produktów
  useEffect(() => {
    if (filteredProducts.length > 0 && activeIndex >= filteredProducts.length) {
      setActiveIndex(0);
    }
  }, [filteredProducts, activeIndex]);

  // Funkcja do zakupu produktu
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [adminPin, setAdminPin] = useState('');
  
  // Modalne okna dla składu, alergenów i preferencji dietetycznych
  const [ingredientsModalOpen, setIngredientsModalOpen] = useState(false);
  const [allergensModalOpen, setAllergensModalOpen] = useState(false);
  const [dietaryPreferencesModalOpen, setDietaryPreferencesModalOpen] = useState(false);
  
  // Dodamy tutaj więcej funkcjonalności w przyszłości
  
  const resetChamberMutation = useMutation({
    mutationFn: async (chamberId: number) => {
      await apiRequest(`/api/chambers/${chamberId}/product`, { method: 'DELETE' });
    },
    onSuccess: (_, chamberId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/chambers'] });
      setIsPurchasing(false);
      
      // Znajdź produkt, który został zakupiony
      const chamber = chambers?.find(c => c.id === chamberId);
      const product = chamber?.productId ? getProductById(chamber.productId) : null;
      
      if (product) {
        toast({
          title: "Produkt zakupiony",
          description: `Twój ${product.name} został wydany z automatu. Smacznego!`,
        });
      }
    },
    onError: (error) => {
      setIsPurchasing(false);
      toast({
        title: "Błąd",
        description: `Nie udało się zakupić produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`,
        variant: "destructive",
      });
    }
  });

  const handlePurchase = () => {
    if (filteredProducts.length === 0 || isPurchasing) return;
    
    const activeProduct = filteredProducts[activeIndex];
    if (!activeProduct || activeProduct.chambers.length === 0) return;
    
    const chamberId = activeProduct.chambers[0].id;
    setSelectedChamber(chamberId);
    setIsPurchasing(true);
    
    console.log(`Wysyłanie komendy otwarcia szuflady ${chamberId} w trybie zakupu...`);
    
    // Używamy metody POST zamiast GET do otwarcia szuflady z flagą purchaseMode=true
    // Ta flaga oznacza, że zmniejszamy stan magazynowy - to jest faktyczny zakup produktu
    fetch(`/api/mqtt/drawer/open`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Cache-Control': 'no-cache'
      },
      body: JSON.stringify({
        drawerNumber: chamberId,
        purchaseMode: true // Kluczowa zmiana - flaga purchaseMode wskazuje, że to faktyczny zakup
      })
    })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        toast({
          title: "Szuflada otwarta",
          description: `Komora ${chamberId} z produktem ${activeProduct.product.name} została otwarta.`,
        });
        
        // Zaktualizuj stan w bazie danych, gdy szuflada została otwarta
        resetChamberMutation.mutate(chamberId);
      } else {
        throw new Error(data.message || 'Nie udało się otworzyć szuflady');
      }
    })
    .catch(error => {
      setIsPurchasing(false);
      toast({
        title: "Błąd",
        description: `Nie udało się otworzyć szuflady: ${error.message || 'Nieznany błąd'}`,
        variant: "destructive",
      });
    });
  };

  // UWAGA: Te funkcje są teraz zduplikowane w handlePrevious i handleNext w useEffect

  // Aktualnie wyświetlany produkt
  const currentProduct = filteredProducts.length > 0 ? filteredProducts[activeIndex] : null;
  const nutritionFacts = currentProduct?.product.nutritionFacts as {
    energyValue: number;
    fat: number;
    saturatedFat: number;
    carbs: number;
    sugars: number;
    protein: number;
    salt: number;
  } | undefined;
  
  // Upewniamy się, że preferencje dietetyczne są zawsze tablicą
  const dietaryPreferences = Array.isArray(currentProduct?.product.dietaryPreferences) 
    ? currentProduct?.product.dietaryPreferences as DietaryPreference[]
    : [] as DietaryPreference[];

  // Funkcja do renderowania ikony kategorii (emoji lub Lucide icon)
  const renderCategoryIcon = (category: Category | string) => {
    // Jeśli to obiekt kategorii z bazy danych
    if (typeof category !== 'string' && category.icon) {
      // Sprawdź czy ikona to emoji (nie zaczyna się od "data:")
      if (!category.icon.startsWith('data:')) {
        return (
          <div className="text-2xl flex items-center justify-center w-6 h-6">
            {category.icon}
          </div>
        );
      } else {
        // Jeśli to obraz w base64
        return (
          <img 
            src={category.icon} 
            alt={category.name} 
            className="w-6 h-6 object-contain" 
          />
        );
      }
    } 
    
    // Dla standardowej kategorii jako string lub gdy kategoria nie ma ikony
    const categoryName = typeof category === 'string' ? category : category.name;
    
    switch (categoryName) {
      case "Obiady": 
        return <UtensilsCrossed className="h-6 w-6" />;
      case "Śniadania": 
        return <Coffee className="h-6 w-6" />;
      case "Zupy": 
        return <Soup className="h-6 w-6" />;
      case "Sałatki": 
        return <Salad className="h-6 w-6" />;
      case "Napoje":
        return <Beer className="h-6 w-6" />;
      case "Przekąski":
        return <Cookie className="h-6 w-6" />;
      default:
        return <ShoppingCart className="h-6 w-6" />;
    }
  };

  // Funkcja weryfikująca PIN - zachowujemy na potrzeby potencjalnej przyszłej funkcjonalności
  const verifyPin = () => {
    if (adminPin === '1308') {
      // Prawidłowy PIN - przekierowanie do panelu administratora
      window.location.href = '/admin';
    } else {
      toast({
        title: "Błędny PIN",
        description: "Wprowadzony PIN jest nieprawidłowy.",
        variant: "destructive"
      });
      setAdminPin('');
    }
  };
  
  // Użyjemy useEffect, aby dodać przyciski nawigacyjne bezpośrednio do body
  // Kluczowa zmiana: dodajemy filteredProducts do tablicy zależności useEffect, 
  // aby zapewnić świeże referencje do funkcji nawigacyjnych
  useEffect(() => {
    // Referencje do funkcji nawigacyjnych
    const handlePrevious = () => {
      console.log("Przycisk POPRZEDNI kliknięty");
      if (filteredProducts.length === 0) return;
      
      // Aktywuj overlay by podświetlić cały ekran
      const overlay = document.querySelector('.nav-overlay');
      if (overlay) {
        overlay.classList.add('active');
        setTimeout(() => {
          overlay.classList.remove('active');
        }, 300); // Przyciemnienie znika po 300ms
      }
      
      setActiveIndex((current) => 
        current === 0 ? filteredProducts.length - 1 : current - 1
      );
    };
    
    const handleNext = () => {
      console.log("Przycisk NASTĘPNY kliknięty");
      if (filteredProducts.length === 0) return;
      
      // Aktywuj overlay by podświetlić cały ekran
      const overlay = document.querySelector('.nav-overlay');
      if (overlay) {
        overlay.classList.add('active');
        setTimeout(() => {
          overlay.classList.remove('active');
        }, 300); // Przyciemnienie znika po 300ms
      }
      
      setActiveIndex((current) => 
        current === filteredProducts.length - 1 ? 0 : current + 1
      );
    };
    
    // Stwórz przyciski nawigacyjne
    const leftBtn = document.createElement('button');
    leftBtn.className = 'fixed-nav-btn left-btn';
    leftBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M15 19l-7-7 7-7" /></svg>';
    leftBtn.onclick = handlePrevious;
    
    const rightBtn = document.createElement('button');
    rightBtn.className = 'fixed-nav-btn right-btn';
    rightBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M9 5l7 7-7 7" /></svg>';
    rightBtn.onclick = handleNext;
    
    // Usunięto przyciemnienie tła dla nawigacji
    
    // Dodaj style do head dokumentu
    const style = document.createElement('style');
    style.innerHTML = `
      
      .fixed-nav-btn {
        position: fixed;
        top: 50%;
        transform: translateY(-50%);
        z-index: 9990; /* Zmniejszony z-index, żeby wygaszacz mógł być nad nimi */
        width: 110px;
        height: 240px;
        background: linear-gradient(to right, #16a34a, #10b981);
        color: white;
        border: none;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.2);
        cursor: pointer;
        transition: all 0.2s ease;
      }
      .fixed-nav-btn:active {
        transform: translateY(-50%) scale(0.95);
      }
      .left-btn {
        left: 0;
        border-radius: 0 24px 24px 0;
        background: linear-gradient(to right, #16a34a, #10b981);
      }
      .right-btn {
        right: 0;
        border-radius: 24px 0 0 24px;
        background: linear-gradient(to left, #16a34a, #10b981);
      }
    `;
    
    // Dodaj elementy do body
    document.head.appendChild(style);
    document.body.appendChild(leftBtn);
    document.body.appendChild(rightBtn);
    
    // Usuń elementy przy demontażu komponentu
    return () => {
      document.head.removeChild(style);
      document.body.removeChild(leftBtn);
      document.body.removeChild(rightBtn);
    };
  }, [filteredProducts]);

  return (
    <>
      <ScreenSaver />
      <div className="max-w-7xl mx-auto h-screen flex flex-col transform scale-120 origin-top relative">
        <div className="flex-grow flex flex-col">
          {/* Sekcja kategorii produktów - zawsze na stałej wysokości */}
          <div className="categories-container flex items-center justify-center py-5 bg-white shadow-md border-b border-gray-100">
            <div className="container mx-auto">
              <div className="flex overflow-x-auto py-3 no-scrollbar justify-center">
                <div className="flex gap-4 items-center">
                  <button
                    key="wszystkie"
                    className={`min-w-[144px] h-24 rounded-xl flex flex-col items-center justify-center transition-all duration-300 px-4 ${
                      selectedCategory === "wszystkie"
                        ? "bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-lg category-button-glow category-button-active scale-105 transform"
                        : "bg-white text-slate-700 hover:bg-gray-50 hover:shadow-lg shadow-md"
                    }`}
                    onClick={() => setSelectedCategory("wszystkie")}
                  >
                    <div className={`p-3 rounded-full mb-1 ${
                      selectedCategory === "wszystkie" 
                        ? "bg-white/20" 
                        : "bg-emerald-100"
                    }`}>
                      <ShoppingCart className={`h-6 w-6 ${
                        selectedCategory === "wszystkie" ? "text-white" : "text-emerald-600"
                      }`} />
                    </div>
                    <span className="text-base font-medium">Wszystkie</span>
                  </button>
                  
                  {/* Wyświetlanie kategorii z bazy danych */}
                  {categoriesLoading ? (
                    // Podczas ładowania pokazujemy 4 placeholders
                    Array.from({length: 4}).map((_, index) => (
                      <div key={`skeleton-${index}`} className="min-w-[144px] h-24 rounded-xl shadow-md bg-white p-4">
                        <Skeleton className="h-10 w-10 rounded-full mx-auto mb-2" />
                        <Skeleton className="h-4 w-16 mx-auto" />
                      </div>
                    ))
                  ) : categories && categories.length > 0 ? (
                    // Gdy mamy kategorie z bazy
                    categories.map(category => {
                      return (
                        <button
                          key={category.id}
                          className={`min-w-[144px] h-24 rounded-xl flex flex-col items-center justify-center transition-all duration-300 px-4 ${
                            selectedCategory === category.name
                              ? "bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-lg category-button-glow category-button-active scale-105 transform"
                              : "bg-white text-slate-700 hover:bg-gray-50 hover:shadow-lg shadow-md"
                          }`}
                          onClick={() => setSelectedCategory(category.name)}
                        >
                          <div className={`p-3 rounded-full mb-1 ${
                            selectedCategory === category.name 
                              ? "bg-white/20" 
                              : "bg-emerald-100"
                          }`}>
                            <div className={`${
                              selectedCategory === category.name ? "text-white" : "text-emerald-600"
                            }`}>
                              {renderCategoryIcon(category)}
                            </div>
                          </div>
                          <span className="text-base font-medium">{category.name}</span>
                        </button>
                      );
                    })
                  ) : (
                    // Fallback na standardowe kategorie, gdy nie ma z bazy
                    PRODUCT_CATEGORIES.map(category => {
                      return (
                        <button
                          key={category}
                          className={`min-w-[144px] h-24 rounded-xl flex flex-col items-center justify-center transition-all duration-300 px-4 ${
                            selectedCategory === category
                              ? "bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-lg category-button-glow category-button-active scale-105 transform"
                              : "bg-white text-slate-700 hover:bg-gray-50 hover:shadow-lg shadow-md"
                          }`}
                          onClick={() => setSelectedCategory(category)}
                        >
                          <div className={`p-3 rounded-full mb-1 ${
                            selectedCategory === category 
                              ? "bg-white/20" 
                              : "bg-emerald-100"
                          }`}>
                            <div className={`${
                              selectedCategory === category ? "text-white" : "text-emerald-600"
                            }`}>
                              {renderCategoryIcon(category)}
                            </div>
                          </div>
                          <span className="text-base font-medium">{category}</span>
                        </button>
                      );
                    })
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Główna zawartość - kontener produktu */}
          <div className="flex-grow flex justify-center items-center">
            {(productsLoading || chambersLoading) ? (
              <div className="w-full max-w-6xl flex justify-center items-center">
                <Skeleton className="h-96 w-full max-w-6xl rounded-lg" />
              </div>
            ) : filteredProducts.length > 0 && currentProduct ? (
              <div className="w-full flex flex-col justify-center relative">
                {/* Usunięto duplikaty przycisków */}
                
                {/* Karuzela - jeden produkt na ekranie */}
                <div className="flex justify-center px-4 sm:px-8 py-4">
                  {/* Kontener produktu - biały na szarym tle - powiększony o 100px */}
                  <div className="w-full max-w-[1300px] bg-gray-100 rounded-xl shadow-lg">
                    <div className="flex flex-col md:flex-row">
                      {/* Lewa strona - zdjęcie produktu */}
                      <div className="md:w-1/2 overflow-hidden md:rounded-l-xl">
                          <img 
                            src={currentProduct.product.imageUrl} 
                            alt={currentProduct.product.name} 
                            className="w-full h-full object-cover min-h-[400px]" 
                          />
                      </div>
                      
                      {/* Prawa strona - szczegóły produktu */}
                      <div className="md:w-1/2 p-8 flex flex-col bg-white md:rounded-r-xl mt-4 md:mt-0">
                        <div className="mb-3">
                          <div className="flex justify-between items-start">
                            <div>
                              <h2 className="text-4xl font-bold text-gray-800">{currentProduct.product.name}</h2>
                              <p className="text-gray-500 mt-1 text-lg">{currentProduct.product.shortDescription}</p>
                              {/* Informacje o wadze i kaloryczności - umieszczone bezpośrednio pod opisem */}
                              {(currentProduct.product.weight || currentProduct.product.totalCalories) && (
                                <div className="flex gap-4 mt-2">
                                  {currentProduct.product.weight && (
                                    <div className="flex items-center text-sm text-gray-600">
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3" />
                                      </svg>
                                      Waga: {currentProduct.product.weight} g
                                    </div>
                                  )}
                                  {currentProduct.product.totalCalories && (
                                    <div className="flex items-center text-sm text-gray-600">
                                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                                      </svg>
                                      Kaloryczność: {currentProduct.product.totalCalories} kcal
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                            <div className="bg-primary/90 text-base font-semibold px-4 py-1.5 rounded-full shadow-sm text-white">
                              Dostępne: {currentProduct.chambers.length}
                            </div>
                          </div>
                          <p className="text-primary text-2xl font-bold mt-3">
                            {formatPrice(calculateGrossPrice(currentProduct.product.price, currentProduct.product.vatRate))} zł
                            <span className="text-sm text-gray-500 font-normal ml-2">
                              brutto (VAT {currentProduct.product.vatRate || "8%"})
                            </span>
                          </p>
                        </div>
                        
                        <div className="mb-5">
                          <p className="text-gray-600 text-base">{currentProduct.product.longDescription}</p>
                          
                        {/* Przyciski wyświetlania składu i alergenów */}
                          <div className="flex gap-4 mt-3">
                            {currentProduct.product.ingredients && (
                              <button
                                onClick={() => setIngredientsModalOpen(true)}
                                className="text-lg text-primary font-medium flex items-center hover:underline"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                                Pełny skład
                              </button>
                            )}
                            
                            {currentProduct.product.allergens && (
                              <button
                                onClick={() => setAllergensModalOpen(true)}
                                className="text-lg text-orange-600 font-medium flex items-center hover:underline"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                                </svg>
                                Alergeny
                              </button>
                            )}
                            
                            {dietaryPreferences.length > 0 && (
                              <button
                                onClick={() => setDietaryPreferencesModalOpen(true)}
                                className="text-lg text-purple-600 font-medium flex items-center hover:underline"
                              >
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                </svg>
                                Preferencje dietetyczne
                              </button>
                            )}
                          </div>
                        </div>
                        
                        {nutritionFacts && (
                          <div className="mb-4">
                            <h3 className="font-medium text-gray-600 mb-2 text-sm">Wartości odżywcze (na 100g)</h3>
                            <div className="bg-gray-50 p-4 rounded-md">
                              <table className="w-full text-sm nutrition-table">
                                <tbody>
                                  <tr className="border-b border-gray-200">
                                    <td className="py-1">Wartość energetyczna</td>
                                    <td className="py-1 text-right">{nutritionFacts.energyValue} kcal</td>
                                  </tr>
                                  <tr className="border-b border-gray-200">
                                    <td className="py-1">Tłuszcz</td>
                                    <td className="py-1 text-right">{nutritionFacts.fat} g</td>
                                  </tr>
                                  <tr className="border-b border-gray-200">
                                    <td className="py-1 pl-4 text-gray-600">w tym kwasy nasycone</td>
                                    <td className="py-1 text-right">{nutritionFacts.saturatedFat} g</td>
                                  </tr>
                                  <tr className="border-b border-gray-200">
                                    <td className="py-1">Węglowodany</td>
                                    <td className="py-1 text-right">{nutritionFacts.carbs} g</td>
                                  </tr>
                                  <tr className="border-b border-gray-200">
                                    <td className="py-1 pl-4 text-gray-600">w tym cukry</td>
                                    <td className="py-1 text-right">{nutritionFacts.sugars} g</td>
                                  </tr>
                                  <tr className="border-b border-gray-200">
                                    <td className="py-1">Białko</td>
                                    <td className="py-1 text-right">{nutritionFacts.protein} g</td>
                                  </tr>
                                  <tr>
                                    <td className="py-1">Sól</td>
                                    <td className="py-1 text-right">{nutritionFacts.salt} g</td>
                                  </tr>
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                        
                        {/* Wyświetlanie numeru komory tuż nad przyciskiem KUP TERAZ */}
                        <div className="mb-3 flex items-center">
                          <div className="text-emerald-500 flex items-center font-semibold">
                            <div className="inline-flex items-center">
                              <div className="w-3 h-3 bg-emerald-500 rounded-full mr-2"></div>
                              Komora: #{currentProduct.chambers.length > 0 ? String(currentProduct.chambers[0].id).padStart(2, '0') : '00'}
                            </div>
                          </div>
                        </div>
                        
                        {/* Przycisk KUP */}
                        <div className="mt-auto">
                          <div className="w-full">
                            <button
                              onClick={handlePurchase}
                              disabled={isPurchasing || currentProduct.chambers.length === 0}
                              className="w-full h-[90px] text-3xl rounded-xl bg-gradient-to-br from-emerald-500 to-green-600 text-white shadow-lg flex items-center justify-center transform active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed animate-glow"
                            >
                              {isPurchasing ? (
                                <div className="flex items-center">
                                  <svg className="animate-spin -ml-1 mr-3 h-6 w-6 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                  </svg>
                                  Przetwarzanie...
                                </div>
                              ) : currentProduct.chambers.length === 0 ? (
                                "Produkt niedostępny"
                              ) : (
                                <>
                                  <svg className="w-8 h-8 mr-3" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M4 4H2V6H3.2L5.05 15.46C5.17 16.15 5.76 16.66 6.46 16.66H17.54C18.25 16.66 18.84 16.14 18.95 15.44L20 8H6L6.5 11H18.1L17.37 15.66H6.46L4 4Z" fill="white"/>
                                    <circle cx="7" cy="19.5" r="1.5" fill="white"/>
                                    <circle cx="17" cy="19.5" r="1.5" fill="white"/>
                                  </svg>
                                  <span className="tracking-wide font-medium">KUP TERAZ</span>
                                </>
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Licznik stron produktów */}
                <div className="flex justify-center py-4">
                  <div className="flex space-x-3">
                    {filteredProducts.map((_, i) => (
                      <button
                        key={i}
                        className={`w-3 h-3 rounded-full transition-colors ${
                          i === activeIndex ? "bg-emerald-500" : "bg-gray-300"
                        }`}
                        onClick={() => setActiveIndex(i)}
                      />
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center p-8">
                <h2 className="text-2xl font-semibold text-gray-700">Brak produktów w tej kategorii</h2>
                <p className="text-gray-500 mt-2">Wybierz inną kategorię lub sprawdź później.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal do wprowadzania PIN-u administratora - ukryty, ale zachowujemy funkcjonalność */}
      <AdminModal
        isOpen={false}
        onClose={() => setAdminModalOpen(false)}
        pin={adminPin}
        onPinChange={setAdminPin}
        onSubmit={verifyPin}
      />
      
      {/* Modal do wyświetlania składu */}
      <IngredientsModal
        isOpen={ingredientsModalOpen}
        onClose={() => setIngredientsModalOpen(false)}
        product={currentProduct?.product || null}
      />
      
      {/* Modal do wyświetlania alergenów */}
      <AllergensModal
        isOpen={allergensModalOpen}
        onClose={() => setAllergensModalOpen(false)}
        product={currentProduct?.product || null}
      />
      
      {/* Modal do wyświetlania preferencji dietetycznych */}
      <DietaryPreferencesModal
        isOpen={dietaryPreferencesModalOpen}
        onClose={() => setDietaryPreferencesModalOpen(false)}
        product={currentProduct?.product || null}
        dietaryPreferences={dietaryPreferences}
      />
      
      {/* Wygaszacz ekranu - renderowany jako ostatni element */}
      <ScreenSaver />
    </>
  );
};