import React from "react";
import { Package } from "lucide-react";

interface ProductCellProps {
  item: {
    product?: {
      name?: string;
      imageUrl?: string;
    };
    productId: number;
  };
}

/**
 * Komponent wyświetlający zdjęcie produktu obok jego nazwy
 */
export const ProductCell: React.FC<ProductCellProps> = ({ item }) => (
  <div className="flex items-center space-x-3">
    {item.product?.imageUrl ? (
      <div className="h-10 w-10 rounded-md overflow-hidden bg-muted">
        <img 
          src={item.product.imageUrl} 
          alt={item.product?.name || "Produkt"} 
          className="h-full w-full object-cover" 
        />
      </div>
    ) : (
      <div className="h-10 w-10 rounded-md bg-muted flex items-center justify-center">
        <Package className="h-5 w-5 text-muted-foreground" />
      </div>
    )}
    <span>{item.product?.name || `Produkt ID: ${item.productId}`}</span>
  </div>
);

export default ProductCell;