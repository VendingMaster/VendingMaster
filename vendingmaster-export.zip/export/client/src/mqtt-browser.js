// Implementacja MQTT przez bibliotekę mqtt dla przeglądarki
import * as mqtt from 'mqtt';

// Temat MQTT
const MQTT_TOPIC = '/szuflada/otworz';

// Połączenie przez WebSocket, dokładnie jak w instrukcji
const MQTT_URL = window.location.protocol === 'https:' 
  ? 'wss://test.mosquitto.org:8081/mqtt'  // dla HTTPS
  : 'ws://test.mosquitto.org:8080/mqtt';  // dla HTTP

console.log(`MQTT Browser: Konfiguracja połączenia: ${MQTT_URL}`);

// Zmienna przechowująca klienta MQTT
let mqttClient = null;
let isConnected = false;

// Funkcja do inicjalizacji połączenia
function connectMqtt() {
  if (mqttClient && mqttClient.connected) {
    console.log('MQTT Browser: Klient już połączony');
    return true;
  }
  
  try {
    console.log('MQTT Browser: Próba połączenia z brokerem...');
    
    // Tworzenie klienta MQTT przez WebSocket
    mqttClient = mqtt.connect(MQTT_URL, {
      clientId: 'vending_machine_' + Math.random().toString(16).substr(2, 8),
      clean: true,
      reconnectPeriod: 5000
    });
    
    // Obsługa zdarzeń
    mqttClient.on('connect', () => {
      console.log('MQTT Browser: Połączono z brokerem MQTT');
      isConnected = true;
    });
    
    mqttClient.on('error', (err) => {
      console.error('MQTT Browser: Błąd połączenia:', err);
      isConnected = false;
    });
    
    mqttClient.on('close', () => {
      console.log('MQTT Browser: Połączenie zamknięte');
      isConnected = false;
    });
    
    return true;
  } catch (error) {
    console.error('MQTT Browser: Błąd podczas tworzenia połączenia:', error);
    return false;
  }
}

// Funkcja globalna do wysyłania numeru szuflady
window.sendMqttDrawerCommand = function(drawerNumber) {
  // Upewniamy się, że drawerNumber jest liczbą bez formatowania
  const cleanDrawerNumber = parseInt(drawerNumber.toString(), 10).toString();
  console.log(`MQTT Browser: Przygotowano numer szuflady: "${cleanDrawerNumber}"`);
  
  // Próba połączenia jeśli nie jest połączony
  if (!mqttClient || !isConnected) {
    connectMqtt();
  }
  
  // Wysyłanie wiadomości
  try {
    if (mqttClient && mqttClient.connected) {
      mqttClient.publish(MQTT_TOPIC, cleanDrawerNumber, { qos: 0 }, (err) => {
        if (err) {
          console.error('MQTT Browser: Błąd wysyłania wiadomości:', err);
        } else {
          console.log(`✅ MQTT Browser: Wysłano komendę otwarcia szuflady ${cleanDrawerNumber}`);
        }
      });
      return true;
    } else {
      console.log('MQTT Browser: Brak połączenia, publikacja w fallback-mode');
      // Fallback - używamy HTTP API Mosquitto jako alternatywy
      const formData = new FormData();
      formData.append('topic', MQTT_TOPIC);
      formData.append('message', cleanDrawerNumber);
      formData.append('qos', '0');
      
      fetch('https://test.mosquitto.org/mqtt/publish', {
        method: 'POST',
        body: formData,
        mode: 'no-cors' 
      })
      .then(() => {
        console.log(`✅ MQTT Browser (fallback): Wysłano komendę otwarcia szuflady ${cleanDrawerNumber}`);
      })
      .catch(error => {
        console.error('❌ MQTT Browser (fallback): Błąd wysyłania komendy:', error);
      });
      
      return true;
    }
  } catch (error) {
    console.error('MQTT Browser: Błąd podczas wysyłania:', error);
    return false;
  }
};

// Automatyczne połączenie przy starcie
connectMqtt();