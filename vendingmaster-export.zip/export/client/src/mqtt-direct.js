/**
 * mqtt-direct.js - Bezpośrednia implementacja klienta MQTT
 * 
 * Ten skrypt używa biblioteki MQTT.js z działającego rozwiązania w mqtt-drawer.html
 */

// Zmienna globalna dla klienta MQTT
let mqttClient = null;
let isConnected = false;
const MQTT_TOPIC = '/szuflada/otworz';
const MQTT_BROKER = 'wss://test.mosquitto.org:8081';

// Funkcja inicjująca połączenie MQTT
function initializeMqtt() {
  try {
    console.log(`MQTT Bezpośredni: Łączenie z ${MQTT_BROKER}...`);
    
    // Sprawdź, czy biblioteka mqtt jest dostępna
    if (typeof mqtt === 'undefined') {
      console.error('MQTT Bezpośredni: Biblioteka MQTT nie jest dostępna. Proszę dodać <script src="https://unpkg.com/mqtt/dist/mqtt.min.js"></script> do head dokumentu.');
      return false;
    }
    
    // Rozłącz poprzednie połączenie, jeśli istnieje
    if (mqttClient) {
      mqttClient.end();
    }
    
    // Połącz z brokerem MQTT
    mqttClient = mqtt.connect(MQTT_BROKER, {
      clientId: 'automat_vendingowy_' + Math.random().toString(16).slice(2, 10)
    });
    
    mqttClient.on('connect', function() {
      console.log('✅ MQTT Bezpośredni: Połączono z brokerem MQTT');
      isConnected = true;
    });
    
    mqttClient.on('error', function(err) {
      console.error(`❌ MQTT Bezpośredni: Błąd MQTT: ${err.message}`);
      isConnected = false;
    });
    
    mqttClient.on('close', function() {
      console.log('❌ MQTT Bezpośredni: Rozłączono z brokerem MQTT');
      isConnected = false;
    });
    
    return true;
  } catch (error) {
    console.error(`❌ MQTT Bezpośredni: Błąd podczas inicjalizacji: ${error.message}`);
    return false;
  }
}

// Funkcja otwierająca szufladę przez MQTT
function openDrawerMqtt(drawerNumber) {
  // Sprawdź czy mamy połączenie
  if (!mqttClient || !isConnected) {
    console.log('MQTT Bezpośredni: Brak połączenia. Próba ponownego połączenia...');
    initializeMqtt();
    
    // Jeśli nadal nie ma połączenia, użyj alternatywnej metody
    if (!mqttClient || !isConnected) {
      console.error('MQTT Bezpośredni: Nie można połączyć z brokerem MQTT');
      if (typeof window.sendMqttDrawerCommand === 'function') {
        console.log('MQTT Bezpośredni: Używam alternatywnej metody HTTP');
        return window.sendMqttDrawerCommand(drawerNumber);
      }
      return false;
    }
  }
  
  // Sprawdź, czy numer szuflady jest prawidłowy
  if (drawerNumber < 1 || drawerNumber > 48) {
    console.error(`MQTT Bezpośredni: Nieprawidłowy numer szuflady: ${drawerNumber} (1-48)`);
    return false;
  }
  
  try {
    // Konwersja na surowy numer bez formatowania
    const rawDrawerNumber = parseInt(drawerNumber, 10).toString();
    
    // Wysłanie komunikatu MQTT
    mqttClient.publish(MQTT_TOPIC, rawDrawerNumber);
    console.log(`✅ MQTT Bezpośredni: Wysłano komendę otwarcia szuflady ${rawDrawerNumber}`);
    return true;
  } catch (error) {
    console.error(`❌ MQTT Bezpośredni: Błąd podczas wysyłania: ${error.message}`);
    
    // Spróbuj użyć alternatywnej metody
    if (typeof window.sendMqttDrawerCommand === 'function') {
      console.log('MQTT Bezpośredni: Używam alternatywnej metody HTTP');
      return window.sendMqttDrawerCommand(drawerNumber);
    }
    
    return false;
  }
}

// Inicjalizuj połączenie MQTT przy ładowaniu skryptu
initializeMqtt();

// Eksport funkcji do globalnego obiektu window
window.sendMqttDrawerCommand = openDrawerMqtt;
window.mqttInitialize = initializeMqtt;
window.mqttOpenDrawer = openDrawerMqtt;