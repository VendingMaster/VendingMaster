// Super uproszczona wersja wysyłania komend MQTT
// Używamy fetch API zamiast skomplikowanych bibliotek

// Temat MQTT
const MQTT_TOPIC = '/szuflada/otworz';

// Funkcja do wysyłania wiadomości MQTT przez HTTP (API mosquitto)
window.sendMqttDrawerCommand = function(drawerNumber) {
  // Upewniamy się, że mamy surowy, prosty numer szuflady (usuwa zera wiodące)
  const cleanDrawerNumber = parseInt(drawerNumber.toString(), 10).toString();
  
  console.log(`MQTT Simple: Przygotowano numer szuflady do wysłania: "${cleanDrawerNumber}"`);
  
  // Przygotowanie danych do wysłania przez HTTP POST
  const formData = new FormData();
  formData.append('topic', MQTT_TOPIC);
  formData.append('message', cleanDrawerNumber);
  formData.append('qos', '0');
  
  // Wysłanie żądania do serwera MQTT przez interfejs HTTP
  fetch('https://test.mosquitto.org/mqtt/publish', {
    method: 'POST',
    body: formData,
    mode: 'no-cors' // Używamy no-cors aby uniknąć problemów CORS
  })
  .then(() => {
    console.log(`✅ MQTT Simple: Wysłano komendę otwarcia szuflady ${cleanDrawerNumber}`);
  })
  .catch(error => {
    console.error('❌ MQTT Simple: Błąd wysyłania komendy:', error);
  });
  
  // Zwracamy true aby nie blokować aplikacji na oczekiwaniu
  // Faktyczny status będzie widoczny w logach
  return true;
};