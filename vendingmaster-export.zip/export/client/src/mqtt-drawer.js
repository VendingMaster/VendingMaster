// Implementacja WebSocket w przeglądarce do komunikacji z naszym lokalnym serwerem
(function() {
  let webSocket = null;
  let isConnected = false;
  let connectionAttempts = 0;
  const MAX_RECONNECT_ATTEMPTS = 5;
  const RECONNECT_DELAY_MS = 2000;
  
  // Funkcja do inicjalizacji połączenia WebSocket
  function connectWebSocket() {
    if (webSocket && (webSocket.readyState === WebSocket.OPEN || webSocket.readyState === WebSocket.CONNECTING)) {
      console.log('[WebSocket] Połączenie już istnieje');
      return;
    }

    try {
      // Określamy adres URL WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      console.log(`[WebSocket] Łączenie z ${wsUrl}...`);
      
      // Tworzymy nowe połączenie WebSocket
      webSocket = new WebSocket(wsUrl);
      
      // Obsługa zdarzenia otwarcia połączenia
      webSocket.onopen = function() {
        console.log('[WebSocket] Połączono z serwerem');
        isConnected = true;
        connectionAttempts = 0;
        
        // Wysyłamy ping od razu po połączeniu, aby sprawdzić czy serwer działa
        sendPing();
      };
      
      // Obsługa zdarzenia zamknięcia połączenia
      webSocket.onclose = function() {
        console.log('[WebSocket] Rozłączono z serwerem');
        isConnected = false;
        
        // Spróbuj ponownie połączyć, jeśli nie przekroczono limitu prób
        if (connectionAttempts < MAX_RECONNECT_ATTEMPTS) {
          connectionAttempts++;
          setTimeout(connectWebSocket, RECONNECT_DELAY_MS);
          console.log(`[WebSocket] Próba ponownego połączenia ${connectionAttempts}/${MAX_RECONNECT_ATTEMPTS}`);
        } else {
          console.error('[WebSocket] Przekroczono maksymalną liczbę prób połączenia');
        }
      };
      
      // Obsługa zdarzenia błędu
      webSocket.onerror = function(error) {
        console.error('[WebSocket] Błąd połączenia:', error);
      };
      
      // Obsługa odebranych wiadomości
      webSocket.onmessage = function(event) {
        try {
          const message = JSON.parse(event.data);
          console.log('[WebSocket] Odebrano wiadomość:', message);
          
          // Obsługa różnych typów wiadomości
          if (message.type === 'welcome') {
            console.log('[WebSocket] Wiadomość powitalna:', message.message);
          } 
          else if (message.type === 'drawer_response') {
            console.log(`[WebSocket] Status otwarcia szuflady ${message.drawerNumber}: ${message.message}`);
          }
          else if (message.type === 'drawer_status') {
            console.log(`[WebSocket] Aktualizacja statusu szuflady ${message.drawerNumber}: ${message.status}`);
          }
          else if (message.type === 'pong') {
            console.log('[WebSocket] Otrzymano odpowiedź pong, serwer działa prawidłowo');
          }
          else if (message.type === 'error') {
            console.error('[WebSocket] Błąd z serwera:', message.message);
          }
        } catch (error) {
          console.error('[WebSocket] Błąd parsowania wiadomości:', error);
        }
      };
    } catch (error) {
      console.error('[WebSocket] Błąd podczas tworzenia połączenia:', error);
    }
  }

  // Funkcja wysyłająca ping
  function sendPing() {
    if (!webSocket || webSocket.readyState !== WebSocket.OPEN) {
      console.warn('[WebSocket] Nie można wysłać ping - brak połączenia');
      return;
    }

    try {
      webSocket.send(JSON.stringify({
        type: 'ping',
        timestamp: new Date().toISOString()
      }));
      console.log('[WebSocket] Wysłano ping do serwera');
    } catch (error) {
      console.error('[WebSocket] Błąd podczas wysyłania ping:', error);
    }
  }

  // Inicjalizacja połączenia WebSocket
  connectWebSocket();

  // Ping serwera co 30 sekund, aby utrzymać połączenie
  setInterval(sendPing, 30000);

  // Funkcja globalna do wysyłania numeru szuflady
  window.sendMqttDrawerCommand = function(drawerNumber) {
    if (!webSocket || webSocket.readyState !== WebSocket.OPEN) {
      console.error('[WebSocket] Brak połączenia WebSocket');
      
      // Spróbuj ponownie połączyć jeśli nie jest połączony
      if (!isConnected) {
        connectWebSocket();
        // Zwracamy false, ponieważ próba wysłania komendy nie powiodła się
        return false;
      }
      
      return false;
    }

    try {
      // Zapewniamy, że numer szuflady jest liczbą
      const numericDrawerNumber = parseInt(drawerNumber.toString(), 10);
      
      if (isNaN(numericDrawerNumber) || numericDrawerNumber < 1 || numericDrawerNumber > 48) {
        console.error('[WebSocket] Nieprawidłowy numer szuflady:', drawerNumber);
        return false;
      }
      
      console.log(`[WebSocket] Przygotowano numer szuflady: ${numericDrawerNumber}`);
      
      // Przygotowujemy i wysyłamy wiadomość
      const message = {
        type: 'drawer_command',
        drawerNumber: numericDrawerNumber,
        timestamp: new Date().toISOString()
      };
      
      webSocket.send(JSON.stringify(message));
      console.log(`✅ [WebSocket] Wysłano komendę otwarcia szuflady ${numericDrawerNumber}`);
      return true;
    } catch (error) {
      console.error('❌ [WebSocket] Błąd podczas wysyłania komendy:', error);
      return false;
    }
  };
})();