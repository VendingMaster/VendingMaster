import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    try {
      // Próbuj sparsować jako JSON (dla błędów API)
      const data = await res.json();
      
      // Jeśli mamy specyficzne błędy związane z magazynem
      if (data.error === 'INSUFFICIENT_INVENTORY') {
        console.log("Dane z odpowiedzi:", data);
        // Używamy message z odpowiedzi lub dodatkowych pól jeśli są dostępne
        const message = data.message || "Niewystarczająca ilość produktu w magazynie";
        const available = data.availableQuantity !== undefined ? data.availableQuantity : 0;
        const required = data.requiredQuantity !== undefined ? data.requiredQuantity : 0;
        
        // Bardziej szczegółowy komunikat dla błędu braku wystarczającej ilości produktu, bez żadnych sugestii o ponownej próbie
        throw new Error(`${message}\n\nW magazynie dostępne jest ${available} sztuk, a wymagane jest ${required} sztuk.`);
      } else if (data.error === 'PRODUCT_NOT_FOUND') {
        throw new Error('Produkt nie został znaleziony w bazie danych');
      } else if (data.message) {
        throw new Error(data.message);
      } else {
        throw new Error(`Wystąpił błąd podczas przetwarzania żądania`);
      }
    } catch (parseError) {
      // Jeśli odpowiedź nie jest prawidłowym JSON lub wystąpił inny błąd przy parsowaniu
      try {
        const text = await res.text() || res.statusText;
        
        // Sprawdź, czy to problem z "body stream already read"
        if (text.includes('body stream already read')) {
          throw new Error(`Wystąpił błąd komunikacji z serwerem`);
        }
        
        // Ogólny bardziej przyjazny komunikat, bez sugestii o ponownych próbach
        throw new Error(`Wystąpił błąd podczas przetwarzania żądania`);
      } catch (e) {
        // Ostateczny fallback jeśli nie można pobrać tekstu błędu
        throw new Error(`Wystąpił błąd podczas przetwarzania żądania`);
      }
    }
  }
}

export async function apiRequest<T = any>(
  url: string,
  options?: {
    method?: string;
    data?: unknown;
    body?: BodyInit;
    headers?: HeadersInit;
  }
): Promise<T> {
  const method = options?.method || 'GET';
  const data = options?.data;
  const customBody = options?.body;
  const customHeaders = options?.headers;
  
  // Zawsze dodajemy nagłówek Accept: application/json
  const defaultHeaders = {
    "Accept": "application/json",
    ...(data ? { "Content-Type": "application/json" } : {})
  };
  
  const res = await fetch(url, {
    method,
    headers: customHeaders || defaultHeaders,
    body: customBody || (data ? JSON.stringify(data) : undefined),
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res.json();
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
      headers: {
        "Accept": "application/json"
      }
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
