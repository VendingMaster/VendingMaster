import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Oblicza cenę brutto na podstawie ceny netto i stawki VAT
 * @param netPrice - cena netto
 * @param vatRate - stawka VAT (np. "23%", "8%", "5%", "0%")
 * @returns - cena brutto
 */
export function calculateGrossPrice(netPrice: number, vatRate: string = "8%"): number {
  const validVatRate = vatRate || "8%"; // Domyślna wartość 8%
  const vatPercentage = parseFloat(validVatRate.replace('%', '')) / 100;
  return netPrice * (1 + vatPercentage);
}

/**
 * Formatuje cenę jako string z dwoma miejscami po przecinku
 * @param price - cena do sformatowania
 * @returns - sformatowany string ceny (np. "12.99")
 */
export function formatPrice(price: number): string {
  return price.toFixed(2);
}
