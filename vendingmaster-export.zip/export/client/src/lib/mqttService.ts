/**
 * Serwis komunikacji z szufladami poprzez WebSocket lub REST API
 * 
 * Klasa zapewnia interfejs do komunikacji z systemem sterowania szufladami
 * używając WebSocket (preferowane) lub REST API jako fallback.
 */

class MqttService {
  private _isReady: boolean = false;
  private webSocketEnabled: boolean = true;
  private webSocket: WebSocket | null = null;
  private connectionAttempts: number = 0;
  private readonly MAX_RECONNECT_ATTEMPTS = 5;
  private readonly RECONNECT_DELAY_MS = 2000;
  private pingInterval: NodeJS.Timeout | null = null;

  constructor() {
    console.log('Inicjalizacja MqttService...');
  }

  /**
   * Inicjalizacja serwisu
   */
  connect(): void {
    console.log('MqttService: Łączenie...');
    // Sprawdzamy dostępność WebSocket w przeglądarce
    this.webSocketEnabled = typeof WebSocket !== 'undefined';
    
    if (this.webSocketEnabled) {
      console.log('MqttService: Używam komunikacji przez WebSocket');
      this.connectWebSocket();
      
      // Ustawienie ping co 30 sekund
      if (this.pingInterval === null) {
        this.pingInterval = setInterval(() => {
          this.sendPing();
        }, 30000);
      }
    } else {
      console.log('MqttService: WebSocket niedostępny, używam REST API');
      this._isReady = true;
    }
  }

  /**
   * Inicjalizacja połączenia WebSocket
   */
  private connectWebSocket(): void {
    if (this.webSocket && (this.webSocket.readyState === WebSocket.OPEN || this.webSocket.readyState === WebSocket.CONNECTING)) {
      console.log('[WebSocket] Połączenie już istnieje');
      return;
    }

    try {
      // Określamy adres URL WebSocket
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      console.log(`[WebSocket] Łączenie z ${wsUrl}...`);
      
      // Tworzymy nowe połączenie WebSocket
      this.webSocket = new WebSocket(wsUrl);
      
      // Obsługa zdarzenia otwarcia połączenia
      this.webSocket.onopen = () => {
        console.log('[WebSocket] Połączono z serwerem');
        this._isReady = true;
        this.connectionAttempts = 0;
        
        // Wysyłamy ping od razu po połączeniu, aby sprawdzić czy serwer działa
        this.sendPing();
      };
      
      // Obsługa zdarzenia zamknięcia połączenia
      this.webSocket.onclose = () => {
        console.log('[WebSocket] Rozłączono z serwerem');
        
        // Spróbuj ponownie połączyć, jeśli nie przekroczono limitu prób
        if (this.connectionAttempts < this.MAX_RECONNECT_ATTEMPTS) {
          this.connectionAttempts++;
          setTimeout(() => this.connectWebSocket(), this.RECONNECT_DELAY_MS);
          console.log(`[WebSocket] Próba ponownego połączenia ${this.connectionAttempts}/${this.MAX_RECONNECT_ATTEMPTS}`);
        } else {
          console.error('[WebSocket] Przekroczono maksymalną liczbę prób połączenia');
          // Fallback do HTTP
          this._isReady = true; // Nawet jeśli WebSocket nie działa, możemy użyć REST API
        }
      };
      
      // Obsługa zdarzenia błędu
      this.webSocket.onerror = (error) => {
        console.error('[WebSocket] Błąd połączenia:', error);
      };
      
      // Obsługa odebranych wiadomości
      this.webSocket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log('[WebSocket] Odebrano wiadomość:', message);
          
          // Obsługa różnych typów wiadomości
          if (message.type === 'welcome') {
            console.log('[WebSocket] Wiadomość powitalna:', message.message);
          } 
          else if (message.type === 'drawer_response') {
            console.log(`[WebSocket] Status otwarcia szuflady ${message.drawerNumber}: ${message.message}`);
          }
          else if (message.type === 'drawer_status') {
            console.log(`[WebSocket] Aktualizacja statusu szuflady ${message.drawerNumber}: ${message.status}`);
          }
          else if (message.type === 'pong') {
            console.log('[WebSocket] Otrzymano odpowiedź pong, serwer działa prawidłowo');
          }
          else if (message.type === 'error') {
            console.error('[WebSocket] Błąd z serwera:', message.message);
          }
        } catch (error) {
          console.error('[WebSocket] Błąd parsowania wiadomości:', error);
        }
      };
    } catch (error) {
      console.error('[WebSocket] Błąd podczas tworzenia połączenia:', error);
      this._isReady = true; // Nawet jeśli WebSocket nie działa, możemy użyć REST API
    }
  }

  /**
   * Wysyłanie ping do serwera
   */
  private sendPing(): void {
    if (!this.webSocket || this.webSocket.readyState !== WebSocket.OPEN) {
      console.warn('[WebSocket] Nie można wysłać ping - brak połączenia');
      return;
    }

    try {
      this.webSocket.send(JSON.stringify({
        type: 'ping',
        timestamp: new Date().toISOString()
      }));
      console.log('[WebSocket] Wysłano ping do serwera');
    } catch (error) {
      console.error('[WebSocket] Błąd podczas wysyłania ping:', error);
    }
  }

  /**
   * Otwiera szufladę o podanym numerze
   * @param drawerNumber Numer szuflady do otwarcia (1-48)
   * @returns Wynik operacji
   */
  openDrawer(drawerNumber: number): boolean {
    if (!this._isReady) {
      console.error('MqttService: Serwis nie jest gotowy');
      return false;
    }
    
    // Sprawdzamy poprawność numeru szuflady
    if (isNaN(drawerNumber) || drawerNumber < 1 || drawerNumber > 48) {
      console.error('MqttService: Nieprawidłowy numer szuflady:', drawerNumber);
      return false;
    }
    
    try {
      // Sprawdzamy czy WebSocket jest aktywny
      if (this.webSocketEnabled && this.webSocket && this.webSocket.readyState === WebSocket.OPEN) {
        console.log(`MqttService: Otwieranie szuflady ${drawerNumber} przez WebSocket`);
        this.sendDrawerCommandByWebSocket(drawerNumber);
        return true;
      } 
      // W przeciwnym razie używamy REST API
      else {
        console.log(`MqttService: Otwieranie szuflady ${drawerNumber} przez REST API`);
        this.sendDrawerCommandByHttp(drawerNumber);
        return true;
      }
    } catch (error) {
      console.error('MqttService: Błąd podczas otwierania szuflady:', error);
      return false;
    }
  }

  /**
   * Wysyła komendę otwarcia szuflady przez WebSocket
   * @param drawerNumber Numer szuflady
   */
  private sendDrawerCommandByWebSocket(drawerNumber: number): void {
    if (!this.webSocket || this.webSocket.readyState !== WebSocket.OPEN) {
      throw new Error('Brak aktywnego połączenia WebSocket');
    }

    try {
      // Zapewniamy, że numer szuflady jest liczbą
      const numericDrawerNumber = parseInt(drawerNumber.toString(), 10);
      
      if (isNaN(numericDrawerNumber) || numericDrawerNumber < 1 || numericDrawerNumber > 48) {
        console.error('[WebSocket] Nieprawidłowy numer szuflady:', drawerNumber);
        throw new Error('Nieprawidłowy numer szuflady');
      }
      
      // Przygotowujemy i wysyłamy wiadomość
      const message = {
        type: 'drawer_command',
        drawerNumber: numericDrawerNumber,
        timestamp: new Date().toISOString()
      };
      
      this.webSocket.send(JSON.stringify(message));
      console.log(`✅ [WebSocket] Wysłano komendę otwarcia szuflady ${numericDrawerNumber}`);
    } catch (error) {
      console.error('❌ [WebSocket] Błąd podczas wysyłania komendy:', error);
      throw error;
    }
  }

  /**
   * Wysyła komendę otwarcia szuflady przez REST API
   * @param drawerNumber Numer szuflady
   */
  private async sendDrawerCommandByHttp(drawerNumber: number): Promise<void> {
    try {
      // Próbujemy najpierw nowszy endpoint
      const url = `/api/mqtt/drawer/open/${drawerNumber}`;
      console.log(`MqttService: Wysyłanie komendy do ${url}`);
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'Cache-Control': 'no-cache'
        }
      });

      // Sprawdzenie czy odpowiedź to JSON
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        console.error(`MqttService: Odpowiedź nie jest w formacie JSON (${contentType})`);
        throw new Error('Nieoczekiwany format odpowiedzi');
      }
      
      const data = await response.json();
      
      if (data.success) {
        console.log(`MqttService: Pomyślnie wysłano komendę REST. ${data.message}`);
      } else {
        console.error('MqttService: Błąd podczas wysyłania komendy REST:', data.message);
        throw new Error(data.message || 'Nieznany błąd podczas otwierania szuflady');
      }
    } catch (error) {
      console.error('MqttService: Błąd podczas wysyłania komendy REST:', error);
      
      // Próba alternatywnego endpointu jako plan B
      try {
        console.log('MqttService: Próba użycia alternatywnego endpointu...');
        const response = await fetch('/api/mqtt/drawer/open', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Cache-Control': 'no-cache'
          },
          body: JSON.stringify({ drawerNumber }),
        });
        
        const data = await response.json();
        
        if (data.success) {
          console.log(`MqttService: Pomyślnie wysłano komendę alternatywną. ${data.message}`);
        } else {
          console.error('MqttService: Błąd podczas alternatywnej komendy:', data.message);
        }
      } catch (err) {
        console.error('MqttService: Krytyczny błąd komunikacji z serwerem:', err);
      }
    }
  }

  /**
   * Zamknięcie połączenia
   */
  disconnect(): void {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
    
    if (this.webSocket) {
      this.webSocket.close();
      this.webSocket = null;
    }
    
    this._isReady = false;
    console.log('MqttService: Zakończono pracę serwisu');
  }

  /**
   * Sprawdzenie gotowości serwisu
   * @returns Stan gotowości
   */
  isActive(): boolean {
    return this._isReady;
  }
}

// Eksport pojedynczej instancji serwisu
export const mqttService = new MqttService();