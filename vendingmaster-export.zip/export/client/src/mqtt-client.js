// Plik implementujący klienta MQTT przez formalną bibliotekę
import * as mqtt from 'mqtt';

// Konfiguracja połączenia MQTT
const MQTT_BROKER_URL = 'mqtt://test.mosquitto.org:1883';
// Używamy bezpiecznego protokołu WebSocket (wss) lub zwykłego (ws) w zależności od protokołu strony
const isSecure = window.location.protocol === 'https:';
const MQTT_WS_URL = isSecure 
  ? 'wss://test.mosquitto.org:8081' // port 8081 dla wss
  : 'ws://test.mosquitto.org:8080';  // port 8080 dla ws
const MQTT_TOPIC = '/szuflada/otworz';

// Zmienne do przechowywania stanu
let mqttClient = null;
let isConnected = false;
let connectPromise = null;

/**
 * Funkcja inicjująca połączenie MQTT
 * @returns {Promise<boolean>} Promise rozwiązywany po nawiązaniu połączenia
 */
function initializeMqttClient() {
  if (connectPromise) return connectPromise;
  
  connectPromise = new Promise((resolve, reject) => {
    try {
      console.log('MQTT Client: Próba połączenia z brokerem MQTT...');
      
      // Próba połączenia przez WebSocket
      mqttClient = mqtt.connect(MQTT_WS_URL, {
        clientId: 'vending_machine_' + Math.random().toString(16).slice(2, 10),
        clean: true,
        reconnectPeriod: 3000
      });
      
      // Obsługa zdarzeń
      mqttClient.on('connect', () => {
        console.log('MQTT Client: Połączono z brokerem MQTT');
        isConnected = true;
        resolve(true);
      });
      
      mqttClient.on('error', (err) => {
        console.error('MQTT Client: Błąd połączenia MQTT:', err);
        isConnected = false;
        if (!mqttClient.connected) {
          reject(err);
        }
      });
      
      mqttClient.on('close', () => {
        console.log('MQTT Client: Rozłączono z brokerem MQTT');
        isConnected = false;
      });
      
      mqttClient.on('message', (topic, message) => {
        console.log(`MQTT Client: Otrzymano wiadomość w temacie ${topic}: ${message.toString()}`);
      });
      
      // Ustaw timeout dla połączenia
      setTimeout(() => {
        if (!isConnected) {
          console.error('MQTT Client: Timeout przy łączeniu do brokera MQTT');
          reject(new Error('Timeout przy łączeniu do brokera MQTT'));
        }
      }, 5000);
      
    } catch (err) {
      console.error('MQTT Client: Błąd inicjalizacji klienta MQTT:', err);
      reject(err);
    }
  });
  
  return connectPromise;
}

/**
 * Funkcja wysyłająca komendę otwarcia szuflady
 * @param {number} drawerNumber - Numer szuflady do otwarcia
 * @returns {Promise<boolean>} Promise rozwiązywany po wysłaniu wiadomości
 */
export async function sendMqttDrawerCommand(drawerNumber) {
  // Upewniamy się, że drawerNumber jest liczbą bez formatowania
  const cleanDrawerNumber = parseInt(drawerNumber.toString(), 10).toString();
  console.log(`MQTT Client: Przygotowano surowy numer szuflady: "${cleanDrawerNumber}"`);
  
  try {
    // Inicjalizacja klienta jeśli jeszcze nie istnieje
    if (!mqttClient) {
      await initializeMqttClient();
    }
    
    // Jeśli klient nie jest połączony, próbujemy ponownie nawiązać połączenie
    if (!isConnected) {
      console.log('MQTT Client: Ponowne łączenie z brokerem...');
      connectPromise = null;
      await initializeMqttClient();
    }
    
    // Wysyłanie wiadomości
    return new Promise((resolve) => {
      mqttClient.publish(MQTT_TOPIC, cleanDrawerNumber, { qos: 0 }, (err) => {
        if (err) {
          console.error('MQTT Client: Błąd wysyłania wiadomości:', err);
          resolve(false);
        } else {
          console.log(`MQTT Client: Wysłano komendę otwarcia szuflady ${cleanDrawerNumber}`);
          resolve(true);
        }
      });
    });
    
  } catch (err) {
    console.error('MQTT Client: Błąd podczas wysyłania komendy:', err);
    return false;
  }
}

/**
 * Funkcja rozłączająca klienta MQTT
 */
export function disconnectMqtt() {
  if (mqttClient && mqttClient.connected) {
    console.log('MQTT Client: Rozłączanie...');
    mqttClient.end();
  }
  isConnected = false;
}

// Aktualizacja globalnego obiektu window z nową funkcją
window.sendMqttDrawerCommand = async function(drawerNumber) {
  return await sendMqttDrawerCommand(drawerNumber);
};

// Automatyczna inicjalizacja połączenia przy ładowaniu
initializeMqttClient().catch((err) => {
  console.error('MQTT Client: Nie udało się zainicjować klienta MQTT:', err);
});

// Eksport funkcji
export { initializeMqttClient };