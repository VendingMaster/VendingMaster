import * as crypto from 'crypto';

/**
 * Generuje losową sól do haszowania hasła
 * @returns {string} - losowa sól w formacie hex
 */
export function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

/**
 * Haszuje hasło z podaną solą
 * @param {string} password - oryginalne hasło
 * @param {string} salt - sól do haszowania
 * @returns {string} - zahaszowane hasło w formacie hex
 */
export function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
}

/**
 * Sprawdza czy podane hasło pasuje do zahaszowanego hasła
 * @param {string} password - oryginalne hasło do sprawdzenia
 * @param {string} salt - sól używana do haszowania
 * @param {string} storedHash - zapisany hash hasła
 * @returns {boolean} - true jeśli hasło jest poprawne
 */
export function verifyPassword(password: string, salt: string, storedHash: string): boolean {
  const hash = hashPassword(password, salt);
  return hash === storedHash;
}

/**
 * Generuje losowe hasło o określonej długości
 * @param {number} length - długość generowanego hasła (domyślnie 8)
 * @returns {string} - wygenerowane hasło
 */
export function generateRandomPassword(length: number = 8): string {
  // Zestaw znaków do wygenerowania hasła
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  let password = '';
  
  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * chars.length);
    password += chars[randomIndex];
  }
  
  return password;
}