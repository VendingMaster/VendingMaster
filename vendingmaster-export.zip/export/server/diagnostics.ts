/**
 * Moduł diagnostyczny dla systemu IQSTORE
 * 
 * Zawiera endpointy i funkcje pomocnicze do monitorowania i diagnozowania
 * stanu systemu, szczególnie mechanizmów magazynowych.
 */
import { Express, Request, Response } from 'express';
import { db } from './db';
import { storage } from './storage';
import { eq, and, ne, isNull, sql } from 'drizzle-orm';
import { chambers, inventory, products, settings } from '@shared/schema';

// Zdefiniuj interfejsy dla obiektów odpowiedzi
interface ProductAssignment {
  productId: number;
  productName: string;
  chambersCount: number;
  totalAvailable: number;
  sufficient: boolean;
}

interface InventoryItem {
  id: number;
  productId: number;
  batchNumber: string | null;
  expiryDate: string;
  quantity: number;
  usedQuantity: number | null;
  disposedQuantity: number | null;
  available?: number;
}

interface ProductGroup {
  productId: number;
  productName: string;
  items: InventoryItem[];
  totalQuantity: number;
  availableQuantity: number;
}

interface InventoryDiagnostics {
  inventoryBasedAssignment: boolean;
  productAssignments: ProductAssignment[];
}

interface InventoryStatus {
  summary: {
    totalItems: number;
    totalQuantity: number;
    availableQuantity: number;
    usedQuantity: number;
  };
  products: ProductGroup[];
}

/**
 * Rejestruje endpointy diagnostyczne w aplikacji Express
 */
export function registerDiagnosticRoutes(app: Express) {
  /**
   * Endpoint diagnostyczny dla magazynu i szuflad
   * Pozwala na analizę zgodności między przypisaniami szuflad a stanem magazynowym
   */
  app.get('/api/diagnostics/inventory', async (req: Request, res: Response) => {
    try {
      // Pobierz ustawienia, aby sprawdzić czy jest włączony magazyn
      const [settingsData] = await db.select().from(settings);
      const inventoryBasedAssignment = settingsData?.inventoryBasedAssignment || false;
      
      // Pobierz szuflady z przypisanymi produktami
      const chambersWithProducts = await db.select().from(chambers)
        .where(
          sql`${chambers.productId} is not null`
        );
      
      // Pogrupuj szuflady według produktów i policz ich liczbę
      const productGroups = new Map<number, number>();
      for (const chamber of chambersWithProducts) {
        if (chamber.productId) {
          const count = productGroups.get(chamber.productId) || 0;
          productGroups.set(chamber.productId, count + 1);
        }
      }
      
      // Przygotuj analizę magazynu
      const productAssignments: ProductAssignment[] = [];
      
      // Konwertuj Map.entries() na zwykłą tablicę aby uniknąć problemów z iteracją
      const productEntries = Array.from(productGroups.entries());
      
      for (const entry of productEntries) {
        const productId = entry[0];
        const chambersCount = entry[1];
        // Pobierz informacje o produkcie
        const product = await storage.getProduct(productId);
        if (!product) continue;
        
        // Sprawdź dostępną ilość w magazynie
        const inventoryItems = await storage.getInventoryItemsByProduct(productId);
        const totalAvailable = inventoryItems.reduce((total, item) => {
          // Licz tylko dostępne (nie zużyte i nie zutylizowane)
          const usedQty = item.usedQuantity || 0;
          const disposedQty = item.disposedQuantity || 0;
          
          // Obliczamy dostępną ilość, nigdy nie pozwalając na wartości ujemne
          const availableQty = Math.max(0, item.quantity - usedQty - disposedQty);
          
          return total + availableQty;
        }, 0);
        
        // Czy mamy wystarczającą ilość produktów w magazynie dla przypisanych szuflad
        const sufficient = totalAvailable >= chambersCount;
        
        productAssignments.push({
          productId,
          productName: product.name,
          chambersCount,
          totalAvailable,
          sufficient
        });
      }
      
      res.json({
        inventoryBasedAssignment,
        productAssignments
      });
    } catch (error) {
      console.error('Błąd podczas pobierania diagnostyki magazynu:', error);
      res.status(500).json({ error: 'Wystąpił błąd podczas pobierania diagnostyki magazynu' });
    }
  });
  
  /**
   * Endpoint diagnostyczny dla sprawdzania zawartości magazynu
   * Pokazuje szczegółowe informacje o produktach w magazynie
   */
  app.get('/api/diagnostics/inventory-status', async (req: Request, res: Response) => {
    try {
      // Pobierz wszystkie produkty w magazynie, które nie są całkowicie użyte lub zutylizowane
      const inventoryItems = await db.select({
        id: inventory.id,
        productId: inventory.productId,
        batchNumber: inventory.batchNumber,
        expiryDate: inventory.expiryDate,
        quantity: inventory.quantity,
        usedQuantity: inventory.usedQuantity,
        disposedQuantity: inventory.disposedQuantity
      }).from(inventory)
        .where(
          and(
            ne(inventory.quantity, sql`${inventory.usedQuantity} + ${inventory.disposedQuantity}`),
            ne(inventory.quantity, 0)
          )
        );
      
      // Pobierz wszystkie produkty
      const allProducts = await db.select().from(products);
      
      // Oblicz sumy statystyczne
      const totalItems = inventoryItems.length;
      const totalQuantity = inventoryItems.reduce((total, item) => total + item.quantity, 0);
      
      // Zapewniamy, że dostępna ilość nigdy nie jest ujemna
      const availableQuantity = inventoryItems.reduce((total, item) => {
        const usedQty = Math.max(0, item.usedQuantity || 0);
        const disposedQty = Math.max(0, item.disposedQuantity || 0);
        
        // Dodatkowa walidacja - zużyta ilość nigdy nie może przekroczyć całkowitej ilości
        const validatedUsedQty = Math.min(usedQty, item.quantity);
        const validatedDisposedQty = Math.min(disposedQty, item.quantity - validatedUsedQty);
        
        // Zapewniamy, że dostępna ilość nigdy nie jest ujemna
        const available = Math.max(0, item.quantity - validatedUsedQty - validatedDisposedQty);
        return total + available;
      }, 0);
      
      // Zapewniamy, że zużyta ilość nigdy nie przekracza całkowitej ilości
      const usedQuantity = inventoryItems.reduce((total, item) => {
        const usedQty = Math.max(0, item.usedQuantity || 0);
        // Zużyta ilość nie może przekroczyć całkowitej ilości
        const validatedUsedQty = Math.min(usedQty, item.quantity);
        return total + validatedUsedQty;
      }, 0);
      
      // Pogrupuj elementy według produktów
      const productGroups = new Map<number, {
        productId: number;
        productName: string;
        items: typeof inventoryItems;
        totalQuantity: number;
        availableQuantity: number;
      }>();
      
      for (const item of inventoryItems) {
        if (!productGroups.has(item.productId)) {
          const product = allProducts.find(p => p.id === item.productId);
          productGroups.set(item.productId, {
            productId: item.productId,
            productName: product?.name || 'Nieznany produkt',
            items: [],
            totalQuantity: 0,
            availableQuantity: 0
          });
        }
        
        const group = productGroups.get(item.productId)!;
        const usedQty = Math.max(0, item.usedQuantity || 0);
        const disposedQty = Math.max(0, item.disposedQuantity || 0);
        
        // Dodatkowa walidacja - zużyta ilość nigdy nie może przekroczyć całkowitej ilości
        const validatedUsedQty = Math.min(usedQty, item.quantity);
        const validatedDisposedQty = Math.min(disposedQty, item.quantity - validatedUsedQty);
        
        // Zapewniamy, że dostępna ilość nigdy nie jest ujemna
        const available = Math.max(0, item.quantity - validatedUsedQty - validatedDisposedQty);
        
        // Dodajemy przedmiot do listy z obliczoną dostępną ilością i zwalidowanymi wartościami
        const itemWithAvailable: InventoryItem = {
          ...item,
          usedQuantity: validatedUsedQty,
          disposedQuantity: validatedDisposedQty,
          available: available
        };
        
        group.items.push(itemWithAvailable);
        group.totalQuantity += item.quantity;
        group.availableQuantity += available;
      }
      
      // Przygotuj wynik
      const result: InventoryStatus = {
        summary: {
          totalItems,
          totalQuantity,
          availableQuantity,
          usedQuantity
        },
        products: Array.from(productGroups.values()) as ProductGroup[]
      };
      
      res.json(result);
    } catch (error) {
      console.error('Błąd podczas pobierania statusu magazynu:', error);
      res.status(500).json({ error: 'Wystąpił błąd podczas pobierania statusu magazynu' });
    }
  });
}