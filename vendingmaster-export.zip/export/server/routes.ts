import { type Express, type Request, type Response, type NextFunction } from "express";
import { eq, and, gt, gte, lt, lte, like, desc, asc, or, not, isNull, sql } from "drizzle-orm";
import { Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import z from "zod";
import multer from "multer";
import * as fs from "fs";
import * as path from "path";
import { parse as parseCsv } from "csv-parse/sync";
import { db } from "./db";
import { storage } from "./storage";
import { registerDiagnosticRoutes } from "./diagnostics";
import { hashPassword, verifyPassword, generateSalt, generateRandomPassword } from "./password-utils";

import {
  users,
  products,
  employees,
  chambers,
  settings,
  categories,
  temperatureReadings,
  inventory,
  deliveries,
  usages,
  mealReservations,
  employeeWorkDays,
  type User,
  type Product,
  type Employee,
  type Chamber,
  type Settings,
  type Category,
  type Inventory,
  type Delivery,
  type Usage,
  type MealReservation,
  type EmployeeWorkDay,
  type InsertUser,
  type InsertProduct,
  type InsertEmployee,
  type InsertChamber,
  type InsertSettings,
  type InsertCategory,
  type InsertInventory,
  type InsertMealReservation,
  type InsertDelivery,
  type InsertUsage,
  type InsertEmployeeWorkDay,
  type TemperatureReading,
  type InsertTemperatureReading,
  temperatureReadingSchema,
  insertInventorySchema,
  insertEmployeeWorkDaySchema,
  insertCategorySchema,
  passwordSchema,
  changePasswordSchema,
  type Password,
  type ChangePassword
} from "@shared/schema";

// Użyteczne funkcje pomocnicze

/**
 * Zwraca dostępną ilość dla danego elementu magazynowego
 * Uwzględnia zarówno usedQuantity jak i disposedQuantity
 */
function getAvailableQuantity(item: any): number {
  if (item.disposed) return 0;
  
  const usedQty = item.usedQuantity || 0;
  const disposedQty = item.disposedQuantity || 0;
  
  // Upewniamy się, że dostępna ilość nigdy nie jest ujemna
  return Math.max(0, item.quantity - usedQty - disposedQty);
}

/**
 * Zwraca sumę dostępnych ilości dla wszystkich elementów
 */
function getTotalAvailableQuantity(items: any[]): number {
  return items.reduce((sum, item) => sum + getAvailableQuantity(item), 0);
}

/**
 * Filtruje elementy magazynowe zwracając tylko te dostępne
 * (nie usunięte i z dostępną ilością > 0)
 */
function getAvailableInventoryItems(items: any[]) {
  return items.filter(item => !item.disposed && getAvailableQuantity(item) > 0);
}

// Zmienna do śledzenia ostatniego żądania otwarcia szuflady
let lastDrawerRequest: {
  drawerNumber: number;
  timestamp: Date;
  processed: boolean;
} | null = null;

export async function registerRoutes(app: Express): Promise<Server> {
  // Dodajemy endpointy diagnostyczne
  registerDiagnosticRoutes(app);
  
  // Endpoint testowy do ręcznego wyzwalania generowania posiłków
  app.post("/api/test/auto-generate-meal-reservations", async (req: Request, res: Response) => {
    try {
      const { date } = req.body;
      
      if (!date || typeof date !== 'string') {
        return res.status(400).json({ success: false, message: "Brak lub nieprawidłowa data" });
      }
      
      // Pobieramy ustawienia, aby zobaczyć ile dni przed mamy automatycznie przypisywać
      const settings = await storage.getSettings();
      const mealOrderAdvanceDays = settings.mealOrderAdvanceDays || 2; // Domyślnie 2 dni
      
      console.log(`[Test] Ręczne uruchomienie generowania posiłków dla daty ${date}`);
      console.log(`[Test] Ustawienie mealOrderAdvanceDays: ${mealOrderAdvanceDays} dni`);
      
      // Obliczamy, dla jakiej daty powinniśmy wygenerować posiłki, bazując na dzisiejszej dacie
      // i ustawieniu mealOrderAdvanceDays
      const today = new Date();
      const targetDate = new Date(today);
      targetDate.setDate(today.getDate() + mealOrderAdvanceDays);
      const formattedTargetDate = targetDate.toISOString().split('T')[0];
      
      console.log(`[Test] Dzisiejsza data: ${today.toISOString().split('T')[0]}`);
      console.log(`[Test] Zgodnie z ustawieniami, powinniśmy generować posiłki na: ${formattedTargetDate}`);
      console.log(`[Test] Żądana data generowania: ${date}`);
      
      // Generujemy dla żądanej daty (dla celów testowych)
      const result = await storage.autoGenerateMealReservations(date);
      
      return res.json({
        success: true,
        message: `Wygenerowano ${result.generatedCount} rezerwacji posiłków dla daty ${date}`,
        currentDate: today.toISOString().split('T')[0],
        targetDateBasedOnSettings: formattedTargetDate,
        mealOrderAdvanceDays,
        userRequestedDate: date,
        ...result
      });
    } catch (error) {
      console.error("[Test] Błąd podczas generowania posiłków:", error);
      return res.status(500).json({ 
        success: false, 
        message: error instanceof Error ? error.message : "Nieznany błąd" 
      });
    }
  });
  
  // Witaj świecie - strona główna
  app.get("/api", (_req: Request, res: Response) => {
    res.json({ 
      message: "IQSTORE API - System zarządzania magazynem i szufladami",
      version: "1.0.0",
      serverTime: new Date().toISOString()
    });
  });

  // ========== ENDPOINTY PRACOWNIKÓW ==========
  app.get("/api/employees", async (_req: Request, res: Response) => {
    try {
      const employees = await storage.getEmployees();
      res.json(employees);
    } catch (error) {
      console.error("Błąd podczas pobierania pracowników:", error);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania pracowników" });
    }
  });

  app.get("/api/employees/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID pracownika" });
      }
      
      const employee = await storage.getEmployee(id);
      if (!employee) {
        return res.status(404).json({ success: false, message: "Nie znaleziono pracownika o podanym ID" });
      }
      
      res.json(employee);
    } catch (error) {
      console.error("Błąd podczas pobierania pracownika:", error);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania pracownika" });
    }
  });
  
  app.post("/api/employees", async (req: Request, res: Response) => {
    try {
      // Tworzymy pracownika - password zostanie obsłużone wewnątrz createEmployee
      const employee = req.body as InsertEmployee;
      const result = await storage.createEmployee(employee);
      
      res.status(201).json(result);
    } catch (error) {
      console.error("Błąd podczas tworzenia pracownika:", error);
      res.status(500).json({ success: false, message: "Błąd podczas tworzenia pracownika" });
    }
  });
  
  app.put("/api/employees/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID pracownika" });
      }
      
      const employee = req.body as InsertEmployee;
      const result = await storage.updateEmployee(id, employee);
      
      if (!result) {
        return res.status(404).json({ success: false, message: "Nie znaleziono pracownika o podanym ID" });
      }
      
      res.json(result);
    } catch (error) {
      console.error("Błąd podczas aktualizacji pracownika:", error);
      res.status(500).json({ success: false, message: "Błąd podczas aktualizacji pracownika" });
    }
  });
  
  app.delete("/api/employees/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID pracownika" });
      }
      
      const success = await storage.deleteEmployee(id);
      
      if (!success) {
        return res.status(404).json({ success: false, message: "Nie znaleziono pracownika o podanym ID" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Błąd podczas usuwania pracownika:", error);
      res.status(500).json({ success: false, message: "Błąd podczas usuwania pracownika" });
    }
  });

  // Konfiguracja multera dla plików CSV
  const storage_csv = multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(process.cwd(), 'uploads');
      // Upewnij się, że katalog istnieje
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const timestamp = new Date().toISOString().replace(/:/g, '-');
      cb(null, `import-pracowników-${timestamp}-${file.originalname}`);
    }
  });

  const uploadCsv = multer({
    storage: storage_csv,
    fileFilter: (req, file, cb) => {
      // Akceptuj tylko pliki CSV
      if (file.mimetype === 'text/csv' || file.originalname.endsWith('.csv')) {
        cb(null, true);
      } else {
        cb(new Error('Dozwolone są tylko pliki CSV'));
      }
    },
    limits: {
      fileSize: 5 * 1024 * 1024 // Limit 5MB
    }
  });

  // Endpoint do importu pracowników z CSV
  app.post('/api/employees/import/csv', uploadCsv.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, message: 'Nie przesłano pliku' });
      }

      const filePath = req.file.path;
      const fileContent = fs.readFileSync(filePath, 'utf8');
      
      // Parsowanie CSV
      const records = parseCsv(fileContent, {
        columns: true,
        skip_empty_lines: true,
        trim: true
      });

      // Liczniki dla raportu
      let imported = 0;
      let skipped = 0;
      let errors: string[] = [];

      // Przetwarzanie każdego rekordu
      for (const record of records) {
        try {
          // Przygotowanie danych pracownika
          const employee: InsertEmployee = {
            firstName: record.firstName,
            lastName: record.lastName,
            email: record.email || null,
            rfidCardNumber: record.rfidCardNumber || null,
            rfidCardFormat: (record.rfidCardFormat === 'hex' ? 'hex' : 'decimal'),
            dietaryPreference: record.dietaryPreference || null
          };

          // Walidacja podstawowych pól
          if (!employee.firstName || !employee.lastName) {
            throw new Error(`Pracownik musi mieć imię i nazwisko`);
          }

          // Sprawdź czy pracownik z tym samym RFID już istnieje
          if (employee.rfidCardNumber) {
            const existingEmployee = await storage.getEmployeeByRfid(employee.rfidCardNumber);
            if (existingEmployee) {
              skipped++;
              continue; // Pomijamy, bo pracownik już istnieje
            }
          }

          // Dodaj pracownika
          await storage.createEmployee(employee);
          imported++;
        } catch (error) {
          console.error('Błąd podczas importu pracownika:', error);
          const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
          errors.push(`Wiersz ${imported + skipped + 1}: ${errorMessage}`);
          skipped++;
        }
      }

      // Usuń plik po przetworzeniu
      fs.unlinkSync(filePath);

      // Zwróć raport
      res.json({
        success: true,
        imported,
        skipped,
        errors: errors.length > 0 ? errors : null
      });
    } catch (error) {
      console.error('Błąd podczas importu CSV:', error);
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      res.status(500).json({ 
        success: false, 
        message: 'Błąd podczas przetwarzania pliku CSV',
        error: errorMessage
      });
    }
  });

  // Endpoint do pobierania szablonu CSV dla pracowników
  app.get('/api/employees/template/csv', (req: Request, res: Response) => {
    const templatePath = path.join(process.cwd(), 'public', 'templates', 'template-pracownicy.csv');
    
    try {
      if (fs.existsSync(templatePath)) {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=szablon-pracownicy.csv');
        fs.createReadStream(templatePath).pipe(res);
      } else {
        res.status(404).json({ success: false, message: 'Szablon nie istnieje' });
      }
    } catch (error) {
      console.error('Błąd podczas pobierania szablonu:', error);
      res.status(500).json({ success: false, message: 'Błąd podczas pobierania szablonu' });
    }
  });
  
  // ========== ENDPOINTY DNI PRACY PRACOWNIKÓW ==========
  
  // Pobieranie dni pracy pracownika
  app.get('/api/employee-work-days/:employeeId', async (req: Request, res: Response) => {
    // Ustawienie nagłówka Content-Type na application/json
    res.setHeader('Content-Type', 'application/json');
    
    try {
      const employeeId = parseInt(req.params.employeeId);
      if (isNaN(employeeId)) {
        return res.status(400).json({ success: false, message: 'Nieprawidłowe ID pracownika' });
      }
      
      const fromDate = req.query.fromDate as string | undefined;
      const toDate = req.query.toDate as string | undefined;
      
      const workDays = await storage.getEmployeeWorkDays(employeeId, fromDate, toDate);
      return res.json(workDays);
    } catch (error) {
      console.error('Błąd podczas pobierania dni pracy:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Błąd podczas pobierania dni pracy',
        error: error instanceof Error ? error.message : 'Nieznany błąd'
      });
    }
  });
  
  // Dodawanie dnia pracy
  app.post('/api/employee-work-days', async (req: Request, res: Response) => {
    // Ustawienie nagłówka Content-Type na application/json
    res.setHeader('Content-Type', 'application/json');
    
    try {
      const workDay = insertEmployeeWorkDaySchema.parse(req.body);
      const result = await storage.addEmployeeWorkDay(workDay);
      
      // Dodajemy informację, czy dzień pracy był dodany czy już istniał
      return res.status(201).json({
        ...result.workDay,
        isNew: result.isNew,
        success: true,
        message: result.isNew 
          ? 'Dzień pracy został dodany' 
          : 'Dzień pracy już istnieje'
      });
    } catch (error) {
      console.error('Błąd podczas dodawania dnia pracy:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Błąd podczas dodawania dnia pracy',
        error: error instanceof Error ? error.message : 'Nieznany błąd'
      });
    }
  });
  
  // Usuwanie dnia pracy
  app.delete('/api/employee-work-days/:employeeId/:workDate', async (req: Request, res: Response) => {
    // Ustawienie nagłówka Content-Type na application/json
    res.setHeader('Content-Type', 'application/json');
    
    try {
      const employeeId = parseInt(req.params.employeeId);
      if (isNaN(employeeId)) {
        return res.status(400).json({ success: false, message: 'Nieprawidłowe ID pracownika' });
      }
      
      const workDate = req.params.workDate;
      if (!workDate || !/^\d{4}-\d{2}-\d{2}$/.test(workDate)) {
        return res.status(400).json({ success: false, message: 'Nieprawidłowy format daty pracy (YYYY-MM-DD)' });
      }
      
      const success = await storage.deleteEmployeeWorkDay(employeeId, workDate);
      
      if (success) {
        return res.json({ success: true });
      } else {
        return res.status(404).json({ success: false, message: 'Nie znaleziono dnia pracy o podanych parametrach' });
      }
    } catch (error) {
      console.error('Błąd podczas usuwania dnia pracy:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Błąd podczas usuwania dnia pracy',
        error: error instanceof Error ? error.message : 'Nieznany błąd'
      });
    }
  });
  
  // Sprawdzanie, czy pracownik pracuje w danym dniu
  app.get('/api/employee-work-days/:employeeId/check/:date', async (req: Request, res: Response) => {
    // Ustawienie nagłówka Content-Type na application/json
    res.setHeader('Content-Type', 'application/json');
    
    try {
      const employeeId = parseInt(req.params.employeeId);
      if (isNaN(employeeId)) {
        return res.status(400).json({ success: false, message: 'Nieprawidłowe ID pracownika' });
      }
      
      const date = req.params.date;
      if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return res.status(400).json({ success: false, message: 'Nieprawidłowy format daty (YYYY-MM-DD)' });
      }
      
      const isWorking = await storage.isEmployeeWorkingOnDate(employeeId, date);
      return res.json({ isWorking });
    } catch (error) {
      console.error('Błąd podczas sprawdzania dni pracy:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Błąd podczas sprawdzania dni pracy',
        error: error instanceof Error ? error.message : 'Nieznany błąd'
      });
    }
  });
  
  // Endpoint do zwracania dni pracy pracowników w formacie używanym przez MealReservationsView
  app.get('/api/employee-work-days', async (req: Request, res: Response) => {
    // Ustawienie odpowiednich nagłówków aby upewnić się, że odpowiedź będzie traktowana jako JSON
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    
    try {
      const date = req.query.date as string | undefined;
      
      // Sprawdzamy, czy przekazano datę
      if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        console.log(`[Employee Work Days] Brak daty lub niepoprawny format: ${date}`);
        return res.status(400).json({ success: false, message: 'Nieprawidłowy format daty (YYYY-MM-DD) lub brak daty' });
      }
      
      console.log(`[Employee Work Days] Pobieranie dni pracy dla daty: ${date}`);
      
      // Pobierz wszystkich pracowników
      const employees = await storage.getEmployees();
      console.log(`[Employee Work Days] Liczba pracowników: ${employees.length}`);
      
      // Dla każdego pracownika, sprawdź czy pracuje danego dnia
      const result: Record<string, string[]> = {};
      
      // Dodatkowa zmienna do śledzenia pracowników, którzy NIE pracują w danym dniu
      const nonWorkingEmployees: number[] = [];
      
      // Ustaw granice czasowe - zakładamy, że przeszłe dni mają jawnie określone dni pracy,
      // ale przyszłe dni są domyślnie dniami pracy, chyba że jawnie oznaczono inaczej
      const today = new Date();
      today.setHours(0, 0, 0, 0); // Reset do początku dnia
      
      const requestDate = new Date(date);
      requestDate.setHours(0, 0, 0, 0); // Reset do początku dnia
      
      const isPastOrToday = requestDate <= today;
      console.log(`[Employee Work Days] Data ${date} jest ${isPastOrToday ? 'przeszła lub dzisiejsza' : 'przyszła'}`);
      
      // Pobierz wszystkie dni wolne dla wybranej daty (lista id pracowników, którzy mają dzień wolny)
      const nonWorkDays = await storage.getEmployeeNonWorkDays(undefined, date, date);
      const employeesWithDayOff = new Set(nonWorkDays.map(nwd => nwd.employeeId));
      
      if (employeesWithDayOff.size > 0) {
        console.log(`[Employee Work Days] Znaleziono ${employeesWithDayOff.size} pracowników z dniami wolnymi na datę ${date}`);
      }
      
      // Dla każdego pracownika
      for (const employee of employees) {
        // Sprawdź czy pracownik ma jawnie oznaczony dzień wolny
        if (employeesWithDayOff.has(employee.id)) {
          console.log(`[Employee Work Days] Pracownik ${employee.firstName} ${employee.lastName} (ID: ${employee.id}) ma jawnie oznaczony dzień wolny w dniu ${date}`);
          
          // Dodajemy do listy niepracujących
          nonWorkingEmployees.push(employee.id);
          continue; // Pomijamy pracownika z dniem wolnym
        }
        
        // Używamy nowej logiki z storage.ts, która sprawdza, czy pracownik pracuje w danym dniu
        const isWorking = await storage.isEmployeeWorkingOnDate(employee.id, date);
        
        console.log(`[Employee Work Days] Pracownik ${employee.firstName} ${employee.lastName} (ID: ${employee.id}) ${isWorking ? 'pracuje' : 'nie pracuje'} w dniu ${date}`);
        
        // Tylko dodaj do wynikowego obiektu jeśli pracownik pracuje
        if (isWorking) {
          if (!result[employee.id]) {
            result[employee.id] = [];
          }
          result[employee.id].push(date);
        } else {
          // Jeśli nie pracuje, dodajemy do listy niepracujących
          nonWorkingEmployees.push(employee.id);
        }
      }
      
      console.log(`[Employee Work Days] Zwracam dni pracy dla ${Object.keys(result).length} pracowników`);
      console.log(`[Employee Work Days] Liczba niepracujących pracowników: ${nonWorkingEmployees.length}`);
      
      // Wysyłamy odpowiedź JSON z określeniem statusu HTTP
      const responseObject = {
        working: result,
        nonWorking: nonWorkingEmployees
      };
      
      return res.status(200).json(responseObject);
    } catch (error) {
      console.error('Błąd podczas pobierania dni pracy:', error);
      return res.status(500).json({ 
        success: false, 
        message: 'Błąd podczas pobierania dni pracy',
        error: error instanceof Error ? error.message : 'Nieznany błąd'
      });
    }
  });
  
  // Endpoint do pobierania szablonu CSV dla szuflad
  app.get('/api/chambers/template/csv', (req: Request, res: Response) => {
    const templatePath = path.join(process.cwd(), 'public', 'templates', 'template-szuflady.csv');
    
    try {
      if (fs.existsSync(templatePath)) {
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', 'attachment; filename=szablon-szuflady.csv');
        fs.createReadStream(templatePath).pipe(res);
      } else {
        res.status(404).json({ success: false, message: 'Szablon nie istnieje' });
      }
    } catch (error) {
      console.error('Błąd podczas pobierania szablonu:', error);
      res.status(500).json({ success: false, message: 'Błąd podczas pobierania szablonu' });
    }
  });
  
  // Endpoint do generowania raportu załadunku
  app.get('/api/chambers/loading-report', async (req: Request, res: Response) => {
    try {
      // Pobierz wszystkie szuflady
      const chambers = await storage.getChambers();
      
      // Pobierz wszystkie produkty
      const products = await storage.getProducts();
      
      // Pobierz wszystkich pracowników
      const employees = await storage.getEmployees();
      
      // Pobierz rezerwacje posiłków na bieżący dzień
      const today = new Date().toISOString().split('T')[0]; // Format YYYY-MM-DD
      const mealReservations = await storage.getMealReservationsByDate(today);
      
      // Przygotuj dane do raportu
      const reportData = chambers.map(chamber => {
        // Sprawdź, czy szuflada jest przypisana do pracownika
        if (chamber.employeeId) {
          const employee = employees.find(e => e.id === chamber.employeeId);
          
          if (employee) {
            // Sprawdź, czy pracownik ma rezerwację na dzisiaj
            const reservation = mealReservations.find(r => r.employeeId === employee.id);
            
            if (reservation) {
              const reservedProduct = products.find(p => p.id === reservation.productId);
              
              return {
                chamberId: chamber.id,
                type: 'employee',
                orderNumber: `Zamówienie #${reservation.id}`,
                employeeId: employee.id,
                productName: reservedProduct ? reservedProduct.name : 'Nieznany produkt',
                productId: reservation.productId,
                imageUrl: reservedProduct ? reservedProduct.imageUrl : null
              };
            }
            
            // Pracownik nie ma dzisiejszej rezerwacji
            return {
              chamberId: chamber.id,
              type: 'employee',
              orderNumber: `Brak zamówienia`,
              employeeId: employee.id,
              productName: 'Brak rezerwacji na dzisiaj',
              productId: null,
              imageUrl: null
            };
          }
        }
        
        // Szuflada z przypisanym produktem (zwykła)
        if (chamber.productId) {
          const product = products.find(p => p.id === chamber.productId);
          
          return {
            chamberId: chamber.id,
            type: 'product',
            productName: product ? product.name : 'Nieznany produkt',
            productId: chamber.productId,
            isAvailable: chamber.isAvailable,
            imageUrl: product ? product.imageUrl : null
          };
        }
        
        // Pusta szuflada
        return {
          chamberId: chamber.id,
          type: 'empty'
        };
      });
      
      // Zwróć dane raportu
      res.json({
        success: true,
        date: today,
        chambers: reportData
      });
    } catch (error) {
      console.error('Błąd podczas generowania raportu załadunku:', error);
      res.status(500).json({ 
        success: false, 
        message: `Błąd podczas generowania raportu załadunku: ${error instanceof Error ? error.message : 'Nieznany błąd'}`
      });
    }
  });
  
  // Endpoint do importu szuflad z CSV
  app.post('/api/chambers/import/csv', uploadCsv.single('file'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, message: 'Nie przesłano pliku' });
      }

      const filePath = req.file.path;
      const fileContent = fs.readFileSync(filePath, 'utf8');
      
      // Parsowanie CSV
      const records = parseCsv(fileContent, {
        columns: true,
        skip_empty_lines: true,
        comment: '#'
      });
      
      let imported = 0;
      let skipped = 0;
      const errors: string[] = [];
      
      // Pobieramy wszystkie szuflady z przypisanymi pracownikami, które pominiemy podczas importu
      const allChambers = await storage.getChambers();
      const chambersWithEmployees = allChambers.filter(chamber => chamber.employeeId !== null);
      
      // Pobierz wszystkie produkty aby móc wyszukiwać po SKU
      const allProducts = await storage.getProducts();
      
      // Iterujemy po rekordach CSV
      for (const record of records) {
        try {
          // Pobierz identyfikator szuflady
          const chamberId = parseInt(record.id);
          if (isNaN(chamberId) || chamberId < 1 || chamberId > 48) {
            throw new Error(`Nieprawidłowy identyfikator szuflady: ${record.id} (dozwolony zakres: 1-48)`);
          }
          
          // Sprawdź, czy szuflada ma przypisanego pracownika
          const hasEmployee = chambersWithEmployees.some(chamber => chamber.id === chamberId);
          if (hasEmployee) {
            console.log(`Pomijam szufladę ${chamberId}, ponieważ ma przypisanego pracownika`);
            skipped++;
            continue;
          }
          
          // Pobierz SKU produktu (jeśli podany) i znajdź odpowiadający mu produkt
          let productId: number | null = null;
          
          if (record.productSKU && record.productSKU.trim() !== '') {
            const sku = record.productSKU.trim();
            
            // Znajdź produkt o podanym SKU
            const product = allProducts.find(p => p.sku === sku);
            
            if (!product) {
              throw new Error(`Nie znaleziono produktu o kodzie SKU: ${sku}`);
            }
            
            productId = product.id;
            console.log(`Znaleziono produkt "${product.name}" (ID: ${productId}) dla kodu SKU: ${sku}`);
          }
          
          // Pobierz istniejącą szufladę lub utwórz nową
          let chamber = await storage.getChamber(chamberId);
          if (chamber) {
            // Aktualizuj istniejącą szufladę
            chamber = await storage.updateChamber(chamberId, { 
              productId: productId,
              isAvailable: productId !== null // Jeśli produkt przypisany, to szuflada jest dostępna
            });
          } else {
            // Utwórz nową szufladę
            chamber = await storage.createChamber({
              id: chamberId,
              productId: productId,
              employeeId: null,
              isAvailable: productId !== null
            });
          }
          
          imported++;
        } catch (error) {
          console.error('Błąd podczas importu szuflady:', error);
          const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
          errors.push(`Wiersz ${imported + skipped + 1}: ${errorMessage}`);
          skipped++;
        }
      }
      
      // Usuń plik po przetworzeniu
      fs.unlinkSync(filePath);
      
      // Zwróć raport
      res.json({
        success: true,
        imported,
        skipped,
        errors: errors.length > 0 ? errors : null
      });
    } catch (error) {
      console.error('Błąd podczas importu CSV:', error);
      const errorMessage = error instanceof Error ? error.message : 'Nieznany błąd';
      res.status(500).json({ 
        success: false, 
        message: 'Błąd podczas przetwarzania pliku CSV',
        error: errorMessage
      });
    }
  });

  // ================================
  // Utwórz serwer HTTP
  // ================================
  const httpServer = new Server(app);

  // ================================
  // Dodajemy WebSocket Server
  // ================================
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Funkcja do powiadamiania wszystkich klientów WebSocket
  const notifyAllClients = (message: any) => {
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  };

  wss.on('connection', (ws: WebSocket) => {
    console.log('[WebSocket] Nowe połączenie');

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message.toString());
        console.log(`[WebSocket] Otrzymano wiadomość:`, data);

        // Obsługa ping/pong dla utrzymania połączenia
        if (data.type === 'ping') {
          ws.send(JSON.stringify({ 
            type: 'pong', 
            timestamp: new Date().toISOString() 
          }));
          console.log('[WebSocket] Wysłano odpowiedź pong');
        }
      } catch (error) {
        console.error('[WebSocket] Błąd przetwarzania wiadomości:', error);
      }
    });

    ws.on('close', () => {
      console.log('[WebSocket] Połączenie zamknięte');
    });
  });

  // Funkcja do powiadamiania wszystkich klientów WebSocket
  function broadcastToClients(message: any) {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }

  // ================================
  // Endpointy MQTT i szuflad
  // ================================
  
  // Obsługa długiego odpytywania (long polling) dla MQTT
  app.get("/api/mqtt/drawer/listen", (req: Request, res: Response) => {
    try {
      // Zwróć ostatnie żądanie otwarcia szuflady, jeśli jest i nie zostało jeszcze przetworzone
      if (lastDrawerRequest && !lastDrawerRequest.processed) {
        // Oznacz jako przetworzone
        lastDrawerRequest.processed = true;
        
        // Zarejestruj w logach
        console.log(`[MQTT] Wysłano żądanie otwarcia szuflady ${lastDrawerRequest.drawerNumber} do Arduino (long polling)`);
        
        // Zwróć informacje o szufladzie do otwarcia
        return res.json({ 
          hasRequest: true, 
          drawerNumber: lastDrawerRequest.drawerNumber, 
          timestamp: lastDrawerRequest.timestamp.toISOString() 
        });
      }
      
      // Nie ma nowych żądań
      return res.json({ 
        hasRequest: false, 
        drawerNumber: 0, 
        timestamp: new Date().toISOString() 
      });
    } catch (error) {
      console.error(`[MQTT Listen Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return res.status(500).json({ hasRequest: false, drawerNumber: 0, error: "Błąd serwera" });
    }
  });

  // Endpoint do otwierania szuflady przez HTTP
  app.post("/api/mqtt/drawer/open", async (req: Request, res: Response) => {
    try {
      // Walidacja danych wejściowych
      const openSchema = z.object({
        drawerNumber: z.number().int().min(1).max(48),
        reduceInventory: z.boolean().optional().default(false), // Domyślnie FALSE - nie zmniejszaj stanu przy samym otwarciu
        purchaseMode: z.boolean().optional().default(false) // Nowy parametr określający, czy to jest faktyczny zakup
      });
      
      const { drawerNumber, reduceInventory, purchaseMode } = openSchema.parse(req.body);
      
      // Zapisujemy żądanie otwarcia szuflady
      lastDrawerRequest = {
        drawerNumber,
        timestamp: new Date(),
        processed: false
      };
      
      // Powiadamiamy klientów WebSocket o nowym żądaniu
      broadcastToClients({
        type: "drawer_open",
        drawerNumber,
        timestamp: lastDrawerRequest.timestamp.toISOString()
      });
      
      console.log(`[MQTT] Wysłano żądanie otwarcia szuflady ${drawerNumber} do Arduino (HTTP POST)`);
      
      // Zmniejszamy stan magazynowy dla produktu w szufladzie TYLKO gdy:
      // - Jawnie zażądano zmniejszenia stanu (reduceInventory=true) LUB
      // - Jest to tryb zakupu (purchaseMode=true)
      if (reduceInventory || purchaseMode) {
        try {
          // Pobierz informacje o szufladzie
          const chamber = await storage.getChamber(drawerNumber);
          if (!chamber) {
            console.log(`[Magazyn] Nie znaleziono szuflady o ID ${drawerNumber}`);
          } else if (!chamber.productId) {
            console.log(`[Magazyn] Szuflada ${drawerNumber} nie ma przypisanego produktu`);
          } else {
            console.log(`[Magazyn] Szuflada ${drawerNumber} ma przypisany produkt ID ${chamber.productId}`);
            
            // Pobranie ustawień
            const settings = await storage.getSettings();
            if (!settings.inventoryBasedAssignment) {
              console.log(`[Magazyn] Tryb bazowania na magazynie jest wyłączony, pomijam zmniejszanie stanu`);
            } else {
              // Pobranie produktu i danych tego produktu z bazy
              const product = await storage.getProduct(chamber.productId);
              if (!product) {
                console.log(`[Magazyn] Nie znaleziono informacji o produkcie ID ${chamber.productId}`);
              } else {
                console.log(`[Magazyn] Produkt: "${product.name}" (ID: ${chamber.productId})`);
                
                // Pobranie stanu magazynowego produktu
                const inventoryItems = await storage.getInventoryItemsByProduct(chamber.productId);
                // Używamy funkcji pomocniczej do filtrowania dostępnych pozycji
                const availableItems = getAvailableInventoryItems(inventoryItems);
                
                console.log(`[Magazyn] Znaleziono ${availableItems.length} dostępnych pozycji magazynowych dla produktu "${product.name}"`);
                
                // Jeśli jest to faktyczny zakup, zmniejszamy stan magazynowy
                if (purchaseMode) {
                  console.log(`[Magazyn] Tryb zakupu - zmniejszam stan magazynowy`);
                  
                  // Zmniejszanie stanu - wywołanie funkcji
                  const result = await storage.useProductFromChamber(drawerNumber);
                  if (result) {
                    console.log(`[Magazyn] Pomyślnie zmniejszono stan magazynowy dla produktu "${product.name}" z szuflady ${drawerNumber}`);
                    
                    // Powiadom wszystkich klientów o zmianie stanu magazynowego
                    broadcastToClients({
                      type: "inventory_changed",
                      message: "Stan magazynowy został zaktualizowany",
                      timestamp: new Date().toISOString()
                    });
                    console.log(`[WebSocket] Wysłano powiadomienie o zmianie stanu magazynowego`);
                  } else {
                    console.log(`[Magazyn] Nie udało się zmniejszyć stanu magazynowego dla produktu "${product.name}" z szuflady ${drawerNumber}`);
                  }
                } else {
                  console.log(`[Magazyn] Zwykłe otwarcie szuflady bez zmniejszania stanu magazynowego`);
                }
              }
            }
          }
        } catch (error) {
          console.error(`[Błąd] Podczas zmniejszania stanu magazynowego: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      } else {
        console.log(`[Magazyn] Pomijam zmniejszanie stanu magazynowego - zwykłe otwarcie szuflady`);
      }
      
      // Zwracamy odpowiedź o sukcesie
      res.json({ 
        success: true, 
        message: `Wysłano żądanie otwarcia szuflady ${drawerNumber}`,
        drawerNumber
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane wejściowe", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "Błąd serwera przy próbie otwarcia szuflady" 
      });
    }
  });

  // Endpoint do symulacji otwarcia szuflady (tylko do testów)
  app.get("/api/mqtt/drawer/open/:drawerNumber", async (req: Request, res: Response) => {
    try {
      const drawerNumber = parseInt(req.params.drawerNumber);
      
      if (isNaN(drawerNumber) || drawerNumber < 1 || drawerNumber > 48) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowy numer szuflady (wymagany zakres: 1-48)" 
        });
      }
      
      // Zapisujemy żądanie otwarcia szuflady
      lastDrawerRequest = {
        drawerNumber,
        timestamp: new Date(),
        processed: false
      };
      
      console.log(`[MQTT] Symulacja otwarcia szuflady ${drawerNumber} (GET request)`);
      
      // W metodzie GET otwieramy tylko szufladę bez zmniejszania stanu magazynowego
      // Zmniejszanie stanu magazynowego będzie odbywać się tylko w przypadku jawnego zakupu
      try {
        // Pobierz informacje o szufladzie
        const chamber = await storage.getChamber(drawerNumber);
        if (!chamber) {
          console.log(`[Magazyn GET] Nie znaleziono szuflady o ID ${drawerNumber}`);
        } else if (!chamber.productId) {
          console.log(`[Magazyn GET] Szuflada ${drawerNumber} nie ma przypisanego produktu`);
        } else {
          console.log(`[Magazyn GET] Szuflada ${drawerNumber} ma przypisany produkt ID ${chamber.productId}`);
          
          // Pobranie produktu i danych tego produktu z bazy (tylko do celów informacyjnych)
          const product = await storage.getProduct(chamber.productId);
          if (product) {
            console.log(`[Magazyn GET] Produkt: "${product.name}" (ID: ${chamber.productId})`);
          }
        }
      } catch (error) {
        console.error(`[Błąd] Podczas sprawdzania szuflady: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
      
      // Zwracamy odpowiedź o sukcesie
      res.json({ 
        success: true, 
        message: `Symulacja otwarcia szuflady ${drawerNumber}`,
        drawerNumber: drawerNumber,
        info: "Metoda GET tylko do testów. W produkcji użyj POST z odpowiednim JSON body." 
      });
    } catch (error) {
      res.status(500).json({ 
        success: false,
        message: "Błąd serwera przy próbie symulacji otwarcia szuflady" 
      });
    }
  });
  
  // Endpointy do obsługi RFID i automatycznego otwierania szuflad dla pracowników
  
  // Nowy uproszczony endpoint dla ESP32 do obsługi kart RFID
  app.post("/api/rfid", async (req: Request, res: Response) => {
    try {
      // Schemat dla żądania od ESP32
      const espRfidSchema = z.object({
        cardId: z.string().min(1, { message: "Numer karty RFID jest wymagany" }),
      });
      
      // Parsowanie danych wejściowych
      const { cardId } = espRfidSchema.parse(req.body);
      
      console.log(`[ESP32 RFID] Otrzymano odczyt karty RFID: ${cardId}`);
      
      // Pobierz ustawienia systemu
      const settings = await storage.getSettings();
      
      // Sprawdzenie, czy jest to karta dla trybu załadunkowego
      // Porównujemy z numerem karty zapisanym w ustawieniach
      if (settings.loadingModeRfidCardNumber && cardId === settings.loadingModeRfidCardNumber) {
        console.log(`[ESP32 RFID] Wykryto kartę skonfigurowaną dla trybu załadunkowego: ${cardId}`);
        
        // Powiadomienie klientów WebSocket o rozpoczęciu trybu załadunkowego
        broadcastToClients({
          type: "loading_mode_authorized",
          timestamp: new Date().toISOString(),
          message: "Tryb załadunkowy uruchomiony przez kartę RFID"
        });
        
        // Implementacja sekwencyjnego otwierania szuflad
        console.log("[RFID Loading Mode] Rozpoczynanie sekwencji otwierania szuflad z serwera...");
          
        // Stałe dla procesu otwierania szuflad
        const totalDrawers = 48;
        const delayBetweenDrawers = 3000; // 3 sekundy
        
        // Uruchamiamy sekwencję w tle z setTimeout, aby uniknąć problemów z strict mode
        setTimeout(() => {
          console.log("[RFID Loading Mode] Rozpoczynanie procesu otwierania szuflad po 1 sekundzie...");
          
          // Rozpoczynamy proces po 1 sekundzie
          let currentDrawer = 1;
          
          // Funkcja pomocnicza do otwierania szuflady
          const openNextDrawer = () => {
            if (currentDrawer > totalDrawers) {
              // Zakończono wszystkie szuflady
              console.log("[RFID Loading Mode] Zakończono sekwencję otwierania szuflad");
              broadcastToClients({
                type: "loading_mode_completed",
                timestamp: new Date().toISOString(),
                message: "Tryb załadunkowy zakończony"
              });
              return;
            }
            
            // Informujemy klientów o aktualnie otwieranej szufladzie
            broadcastToClients({
              type: "loading_mode_progress",
              currentDrawer: currentDrawer,
              totalDrawers: totalDrawers,
              timestamp: new Date().toISOString()
            });
            
            // Otwieranie szuflady
            console.log(`[RFID Loading Mode] Otwieranie szuflady ${currentDrawer}...`);
            
            // Wywołaj API do otwarcia szuflady
            const port = process.env.PORT || 5000;
            console.log(`[RFID Loading Mode] Wywołuję endpoint otwarcia szuflady ${currentDrawer} na porcie ${port}...`);
            
            fetch(`http://localhost:${port}/api/mqtt/drawer/open/${currentDrawer}`, {
              method: 'GET',
              headers: { 'Accept': 'application/json' }
            })
            .then(response => response.json())
            .then(drawerOpenResponse => {
              if (drawerOpenResponse.success) {
                console.log(`[RFID Loading Mode] Szuflada ${currentDrawer} została pomyślnie otwarta`);
              } else {
                console.error(`[RFID Loading Mode] Błąd podczas otwierania szuflady ${currentDrawer}: ${drawerOpenResponse.message || 'Nieznany błąd'}`);
              }
              
              // Wysyłamy powiadomienie o otwarciu szuflady (niezależnie od rezultatu otwarcia)
              broadcastToClients({
                type: "drawer_opened",
                drawerNumber: currentDrawer,
                timestamp: new Date().toISOString()
              });
              
              // Zwiększ licznik i zaplanuj otwarcie następnej szuflady
              currentDrawer++;
              setTimeout(openNextDrawer, delayBetweenDrawers);
            })
            .catch(error => {
              console.error(`[RFID Loading Mode] Błąd podczas otwierania szuflady ${currentDrawer}:`, error);
              // Kontynuuj mimo błędu
              currentDrawer++;
              setTimeout(openNextDrawer, delayBetweenDrawers);
            });
          };
          
          // Rozpocznij sekwencję
          openNextDrawer();
        }, 1000);
        

        
        return res.json({
          success: true,
          message: "Rozpoczęto tryb załadunkowy",
          action: "loading_mode_started"
        });
      }
      
      // Wyszukaj pracownika na podstawie numeru karty
      const employee = await storage.getEmployeeByRfid(cardId);
      
      if (!employee) {
        console.log(`[ESP32 RFID] Nie znaleziono pracownika z kartą o numerze: ${cardId}`);
        return res.status(404).json({ 
          success: false, 
          message: "Nieznana karta RFID" 
        });
      }
      
      console.log(`[ESP32 RFID] Znaleziono pracownika: ${employee.firstName} ${employee.lastName}`);
      
      // Pobierz wszystkie szuflady
      const allChambers = await storage.getChambers();
      
      // Znajdź szufladę przypisaną do tego pracownika (jeśli istnieje)
      const employeeChamber = allChambers.find(chamber => chamber.employeeId === employee.id);
      
      if (!employeeChamber) {
        console.log(`[ESP32 RFID] Pracownik ${employee.firstName} ${employee.lastName} nie ma przypisanej szuflady`);
        return res.status(404).json({ 
          success: false,
          message: "Brak przypisanej szuflady" 
        });
      }
      
      // Zapisujemy żądanie otwarcia szuflady
      lastDrawerRequest = {
        drawerNumber: employeeChamber.id,
        timestamp: new Date(),
        processed: false
      };
      
      console.log(`[ESP32 RFID] Otwieranie szuflady ${employeeChamber.id} dla pracownika: ${employee.firstName} ${employee.lastName}`);
      
      // Zmniejszamy stan magazynowy dla produktu w szufladzie (jeśli włączone w ustawieniach)
      try {
        console.log(`[ESP32 RFID] Rozpoczęcie procesu zmniejszania stanu magazynowego dla szuflady ${employeeChamber.id}`);
        
        // Pobierz informacje o szufladzie
        const chamber = await storage.getChamber(employeeChamber.id);
        if (!chamber) {
          console.log(`[ESP32 RFID] Nie znaleziono szuflady o ID ${employeeChamber.id}`);
        } else if (!chamber.productId) {
          console.log(`[ESP32 RFID] Szuflada ${employeeChamber.id} nie ma przypisanego produktu`);
        } else {
          console.log(`[ESP32 RFID] Szuflada ${employeeChamber.id} ma przypisany produkt ID ${chamber.productId}`);
          
          // Pobranie ustawień
          const settings = await storage.getSettings();
          if (!settings.inventoryBasedAssignment) {
            console.log(`[ESP32 RFID] Tryb bazowania na magazynie jest wyłączony, pomijam zmniejszanie stanu`);
          } else {
            // Pobranie produktu i danych tego produktu z bazy
            const product = await storage.getProduct(chamber.productId);
            if (!product) {
              console.log(`[ESP32 RFID] Nie znaleziono informacji o produkcie ID ${chamber.productId}`);
            } else {
              console.log(`[ESP32 RFID] Produkt: "${product.name}" (ID: ${chamber.productId})`);
              
              // Pobranie stanu magazynowego produktu
              const inventoryItems = await storage.getInventoryItemsByProduct(chamber.productId);
              // Używamy funkcji pomocniczej do filtrowania dostępnych pozycji
              const availableItems = getAvailableInventoryItems(inventoryItems);
              
              // Zmniejszanie stanu - wywołanie funkcji
              const result = await storage.useProductFromChamber(employeeChamber.id);
              if (result) {
                console.log(`[ESP32 RFID] Pomyślnie zmniejszono stan magazynowy dla produktu "${product.name}" z szuflady ${employeeChamber.id}`);
                
                // Powiadom wszystkich klientów o zmianie stanu magazynowego
                broadcastToClients({
                  type: "inventory_changed",
                  message: "Stan magazynowy został zaktualizowany",
                  timestamp: new Date().toISOString()
                });
                console.log(`[WebSocket] Wysłano powiadomienie o zmianie stanu magazynowego`);
              } else {
                console.log(`[ESP32 RFID] Nie udało się zmniejszyć stanu magazynowego dla produktu "${product.name}" z szuflady ${employeeChamber.id}`);
              }
            }
          }
        }
      } catch (error) {
        console.error(`[ESP32 RFID] Błąd podczas zmniejszania stanu magazynowego: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
      
      // Zwróć odpowiedź sukcesu
      res.status(200).json({ 
        success: true, 
        drawerNumber: employeeChamber.id,
        employeeName: `${employee.firstName} ${employee.lastName}`
      });
      
    } catch (error) {
      console.error(`[ESP32 RFID Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane wejściowe", 
          error: "Niepoprawny format JSON"
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "Błąd serwera" 
      });
    }
  });
  
  // Endpoint do uwierzytelniania pracownika przez RFID i otwierania przypisanej szuflady
  app.post("/api/rfid/authenticate", async (req: Request, res: Response) => {
    try {
      const rfidSchema = z.object({
        rfidCardNumber: z.string().min(1),
        rfidCardFormat: z.enum(["decimal", "hex"]).optional().default("decimal")
      });
      
      const { rfidCardNumber, rfidCardFormat } = rfidSchema.parse(req.body);
      
      console.log(`[RFID] Otrzymano żądanie uwierzytelnienia, numer karty: ${rfidCardNumber}, format: ${rfidCardFormat}`);
      
      // Pobierz ustawienia systemu, aby sprawdzić czy to karta dla trybu załadunkowego
      const settings = await storage.getSettings();
      
      // Sprawdzenie, czy jest to karta dla trybu załadunkowego
      if (settings.loadingModeRfidCardNumber && rfidCardNumber === settings.loadingModeRfidCardNumber) {
        console.log(`[RFID] Wykryto kartę skonfigurowaną dla trybu załadunkowego: ${rfidCardNumber}`);
        
        // Powiadomienie klientów WebSocket o rozpoczęciu trybu załadunkowego
        broadcastToClients({
          type: "loading_mode_authorized",
          timestamp: new Date().toISOString(),
          message: "Tryb załadunkowy uruchomiony przez kartę RFID"
        });
        
        return res.json({
          success: true,
          message: "Rozpoczęto tryb załadunkowy",
          action: "loading_mode_started"
        });
      }
      
      // Wyszukaj pracownika na podstawie numeru karty RFID
      const employee = await storage.getEmployeeByRfid(rfidCardNumber);
      
      if (!employee) {
        console.log(`[RFID] Nie znaleziono pracownika z kartą o numerze: ${rfidCardNumber}`);
        return res.status(404).json({ 
          success: false, 
          message: "Karta RFID nie jest przypisana do żadnego pracownika" 
        });
      }
      
      console.log(`[RFID] Znaleziono pracownika: ${employee.firstName} ${employee.lastName}`);
      
      // Pobierz wszystkie szuflady
      const allChambers = await storage.getChambers();
      
      // Znajdź szufladę przypisaną do tego pracownika (jeśli istnieje)
      const employeeChamber = allChambers.find(chamber => chamber.employeeId === employee.id);
      
      if (!employeeChamber) {
        console.log(`[RFID] Pracownik ${employee.firstName} ${employee.lastName} nie ma przypisanej szuflady`);
        return res.status(404).json({ 
          success: false, 
          employeeFound: true,
          employee: { firstName: employee.firstName, lastName: employee.lastName, id: employee.id },
          message: "Pracownik nie ma przypisanej szuflady" 
        });
      }
      
      // Zapisujemy żądanie otwarcia szuflady
      lastDrawerRequest = {
        drawerNumber: employeeChamber.id,
        timestamp: new Date(),
        processed: false
      };
      
      console.log(`[RFID] Wysłano żądanie otwarcia szuflady ${employeeChamber.id} dla pracownika: ${employee.firstName} ${employee.lastName}`);
      
      // Zmniejszamy stan magazynowy dla produktu w szufladzie (jeśli włączone w ustawieniach)
      try {
        // Pobierz informacje o szufladzie
        const chamber = await storage.getChamber(employeeChamber.id);
        if (!chamber) {
          console.log(`[RFID] Nie znaleziono szuflady o ID ${employeeChamber.id}`);
        } else if (!chamber.productId) {
          console.log(`[RFID] Szuflada ${employeeChamber.id} nie ma przypisanego produktu`);
        } else {
          console.log(`[RFID] Szuflada ${employeeChamber.id} ma przypisany produkt ID ${chamber.productId}`);
          
          // Pobranie ustawień
          const settings = await storage.getSettings();
          if (!settings.inventoryBasedAssignment) {
            console.log(`[RFID] Tryb bazowania na magazynie jest wyłączony, pomijam zmniejszanie stanu`);
          } else {
            // Pobranie produktu i danych tego produktu z bazy
            const product = await storage.getProduct(chamber.productId);
            if (!product) {
              console.log(`[RFID] Nie znaleziono informacji o produkcie ID ${chamber.productId}`);
            } else {
              console.log(`[RFID] Produkt: "${product.name}" (ID: ${chamber.productId})`);
              
              // Pobranie stanu magazynowego produktu
              const inventoryItems = await storage.getInventoryItemsByProduct(chamber.productId);
              // Używamy funkcji pomocniczej do filtrowania dostępnych pozycji
              const availableItems = getAvailableInventoryItems(inventoryItems);

              console.log(`[RFID] Znaleziono ${availableItems.length} dostępnych pozycji magazynowych dla produktu "${product.name}"`);
              
              // Zmniejszanie stanu - wywołanie funkcji
              const result = await storage.useProductFromChamber(employeeChamber.id);
              if (result) {
                console.log(`[RFID] Pomyślnie zmniejszono stan magazynowy dla produktu "${product.name}" z szuflady ${employeeChamber.id}`);
                
                // Powiadom wszystkich klientów o zmianie stanu magazynowego
                broadcastToClients({
                  type: "inventory_changed",
                  message: "Stan magazynowy został zaktualizowany",
                  timestamp: new Date().toISOString()
                });
                console.log(`[WebSocket] Wysłano powiadomienie o zmianie stanu magazynowego`);
              } else {
                console.log(`[RFID] Nie udało się zmniejszyć stanu magazynowego dla produktu "${product.name}" z szuflady ${employeeChamber.id}`);
              }
            }
          }
        }
      } catch (error) {
        console.error(`[RFID] Błąd podczas zmniejszania stanu magazynowego: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
      
      // Zwróć odpowiedź z informacją o pracowniku i szufladzie
      res.json({ 
        success: true, 
        employee: {
          id: employee.id,
          firstName: employee.firstName,
          lastName: employee.lastName,
          rfidCardNumber: employee.rfidCardNumber
        },
        chamber: {
          id: employeeChamber.id
        },
        message: `Szuflada ${employeeChamber.id} zostanie otwarta dla pracownika ${employee.firstName} ${employee.lastName}`
      });
      
    } catch (error) {
      console.error(`[RFID Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane karty RFID", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "Wystąpił błąd podczas przetwarzania żądania RFID" 
      });
    }
  });
  
  // Endpoint do sprawdzania poprawności numeru RFID i uzyskiwania informacji o pracowniku
  app.get("/api/rfid/validate/:rfidCardNumber", async (req: Request, res: Response) => {
    try {
      const rfidCardNumber = req.params.rfidCardNumber;
      
      if (!rfidCardNumber) {
        return res.status(400).json({ 
          success: false, 
          message: "Brak numeru karty RFID" 
        });
      }
      
      console.log(`[RFID] Walidacja karty RFID o numerze: ${rfidCardNumber}`);
      
      // Pobierz ustawienia systemu, aby sprawdzić czy to karta dla trybu załadunkowego
      const settings = await storage.getSettings();
      
      // Sprawdzenie, czy jest to karta dla trybu załadunkowego
      if (settings.loadingModeRfidCardNumber && rfidCardNumber === settings.loadingModeRfidCardNumber) {
        console.log(`[RFID] Wykryto kartę skonfigurowaną dla trybu załadunkowego: ${rfidCardNumber}`);
        
        return res.json({
          success: true,
          valid: true,
          isLoadingModeCard: true,
          message: "Karta skonfigurowana dla trybu załadunkowego"
        });
      }
      
      // Wyszukaj pracownika na podstawie numeru karty RFID
      const employee = await storage.getEmployeeByRfid(rfidCardNumber);
      
      if (!employee) {
        console.log(`[RFID] Nie znaleziono pracownika z kartą o numerze: ${rfidCardNumber}`);
        return res.status(404).json({ 
          success: false, 
          valid: false,
          message: "Karta RFID nie jest przypisana do żadnego pracownika" 
        });
      }
      
      // Pobierz wszystkie szuflady
      const allChambers = await storage.getChambers();
      
      // Znajdź szufladę przypisaną do tego pracownika (jeśli istnieje)
      const employeeChamber = allChambers.find(chamber => chamber.employeeId === employee.id);
      
      // Zwróć informacje o karcie RFID i pracowniku
      res.json({ 
        success: true,
        valid: true,
        employee: {
          id: employee.id,
          firstName: employee.firstName,
          lastName: employee.lastName
        },
        hasChamber: !!employeeChamber,
        chamber: employeeChamber ? { id: employeeChamber.id } : null
      });
      
    } catch (error) {
      console.error(`[RFID Validate Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false,
        valid: false,
        message: "Wystąpił błąd podczas walidacji karty RFID" 
      });
    }
  });
  
  // Endpoint do przypisywania pracownika do szuflady (dla testów RFID)
  app.post("/api/chambers/assign-employee", async (req: Request, res: Response) => {
    try {
      // Walidacja danych wejściowych
      const assignSchema = z.object({
        chamberId: z.number(),
        employeeId: z.number()
      });
      
      const { chamberId, employeeId } = assignSchema.parse(req.body);
      
      // Sprawdź, czy szuflada istnieje
      const chamber = await storage.getChamber(chamberId);
      if (!chamber) {
        return res.status(404).json({
          success: false,
          message: `Szuflada o ID ${chamberId} nie istnieje`
        });
      }
      
      // Sprawdź, czy pracownik istnieje
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({
          success: false,
          message: `Pracownik o ID ${employeeId} nie istnieje`
        });
      }
      
      // Sprawdź, czy pracownik już ma przypisaną szufladę
      const assignedChambers = await storage.getChambersByEmployeeId(employee.id);
      console.log(`[Employee] Znaleziono pracownika: ${employee.firstName} ${employee.lastName} z ${assignedChambers.length} przypisanymi szufladami`);
      
      // Jeżeli pracownik ma już przypisaną inną szufladę, usuń to przypisanie
      if (assignedChambers.length > 0) {
        for (const assignedChamber of assignedChambers) {
          // Pomijamy szufladę, którą właśnie przypisujemy (jeśli pracownik już ją ma)
          if (assignedChamber.id !== chamberId) {
            await storage.updateChamber(assignedChamber.id, {
              employeeId: null,
              isAvailable: true
            });
            console.log(`[API] Usunięto poprzednie przypisanie pracownika do szuflady ${assignedChamber.id}`);
          }
        }
      }
      
      // Aktualizuj szufladę - przypisz pracownika
      const updatedChamber = await storage.updateChamber(chamberId, { 
        employeeId, 
        isAvailable: true 
      });
      
      console.log(`[API] Przypisano pracownika ${employee.firstName} ${employee.lastName} (ID: ${employeeId}) do szuflady ${chamberId}`);
      
      res.json({
        success: true,
        message: `Przypisano pracownika ${employee.firstName} ${employee.lastName} do szuflady ${chamberId}`,
        chamber: updatedChamber,
        previousAssignmentsRemoved: assignedChambers.length > 0
      });
      
    } catch (error) {
      console.error(`[Chamber-Employee Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowe dane wejściowe",
          errors: error.errors
        });
      }
      
      res.status(500).json({
        success: false,
        message: "Wystąpił błąd podczas przypisywania pracownika do szuflady"
      });
    }
  });
  
  // ====================================
  // Endpointy zarządzania produktami
  // ====================================
  
  // Pobieranie wszystkich produktów
  app.get("/api/products", async (_req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania produktów" });
    }
  });
  
  // Pobieranie szczegółów produktu
  app.get("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator produktu" });
      }
      
      const product = await storage.getProduct(id);
      if (!product) {
        return res.status(404).json({ success: false, message: "Nie znaleziono produktu" });
      }
      
      res.json(product);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania szczegółów produktu" });
    }
  });
  
  // Dodawanie nowego produktu
  app.post("/api/products", async (req: Request, res: Response) => {
    try {
      const product = req.body;
      const newProduct = await storage.createProduct(product);
      res.status(201).json(newProduct);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas dodawania produktu" });
    }
  });
  
  // Aktualizacja produktu
  app.put("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator produktu" });
      }
      
      const product = req.body;
      const updatedProduct = await storage.updateProduct(id, product);
      
      if (!updatedProduct) {
        return res.status(404).json({ success: false, message: "Nie znaleziono produktu" });
      }
      
      res.json(updatedProduct);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas aktualizacji produktu" });
    }
  });
  
  // Endpoint do częściowej aktualizacji produktu (np. tylko status widoczności)
  app.patch("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator produktu" });
      }
      
      // Pobierz aktualny produkt
      const currentProduct = await storage.getProduct(id);
      if (!currentProduct) {
        return res.status(404).json({ success: false, message: "Nie znaleziono produktu" });
      }
      
      // Zaktualizuj tylko te pola, które zostały przesłane
      const updates = req.body;
      const productToUpdate = { ...currentProduct, ...updates };
      
      const updatedProduct = await storage.updateProduct(id, productToUpdate);
      
      res.json(updatedProduct);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas aktualizacji produktu" });
    }
  });
  
  // Usuwanie produktu
  app.delete("/api/products/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator produktu" });
      }
      
      const success = await storage.deleteProduct(id);
      if (!success) {
        return res.status(404).json({ success: false, message: "Nie znaleziono produktu" });
      }
      
      res.json({ success: true, message: "Produkt został usunięty" });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas usuwania produktu" });
    }
  });
  
  // ====================================
  // Endpointy zarządzania kategoriami
  // ====================================
  
  // Pobieranie wszystkich kategorii
  app.get("/api/categories", async (_req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania kategorii" });
    }
  });

  // Dodawanie nowej kategorii
  app.post("/api/categories", async (req: Request, res: Response) => {
    try {
      // Validacja danych wejściowych za pomocą schematu z Zod
      const categoryData = insertCategorySchema.parse(req.body);
      
      const category = await storage.createCategory(categoryData);
      res.status(201).json(category);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane kategorii", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ success: false, message: "Błąd podczas tworzenia kategorii" });
    }
  });

  // Aktualizacja istniejącej kategorii
  app.put("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID kategorii" });
      }
      
      // Validacja danych wejściowych za pomocą schematu z Zod
      const categoryData = insertCategorySchema.parse(req.body);
      
      const category = await storage.updateCategory(id, categoryData);
      if (!category) {
        return res.status(404).json({ success: false, message: "Nie znaleziono kategorii" });
      }
      
      res.json(category);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane kategorii", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ success: false, message: "Błąd podczas aktualizacji kategorii" });
    }
  });

  // Usuwanie kategorii
  app.delete("/api/categories/:id", async (req: Request, res: Response) => {
    try {
      const id = Number(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID kategorii" });
      }
      
      const success = await storage.deleteCategory(id);
      if (!success) {
        return res.status(404).json({ success: false, message: "Nie znaleziono kategorii" });
      }
      
      res.json({ success: true, message: "Kategoria została usunięta" });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas usuwania kategorii" });
    }
  });
  
  // ====================================
  // Endpointy zarządzania szufladami
  // ====================================
  
  // Pobieranie wszystkich szuflad
  app.get("/api/chambers", async (req: Request, res: Response) => {
    try {
      // Wymuszanie odświeżania danych, zapobieganie cache'owaniu
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      const chambers = await storage.getChambers();
      
      // Sprawdź, czy żądanie pochodzi z ESP32 (dodaj nagłówek 'X-ESP32-Client: true' w żądaniach z ESP32)
      const isEsp32Client = req.headers['x-esp32-client'] === 'true' || req.query.format === 'esp32';
      
      if (isEsp32Client) {
        // Format kompatybilny z ESP32 - zwróć po prostu tablicę szuflad
        console.log('[API] Odpowiedź w formacie kompatybilnym z ESP32');
        return res.json(chambers);
      }
      
      // Standardowy format dla aplikacji webowej - z timestamp do wymuszenia odświeżania
      res.json({
        chambers: chambers,
        timestamp: new Date().getTime()
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania szuflad" });
    }
  });
  
  // Pobieranie dostępnych szuflad
  app.get("/api/chambers/available", async (_req: Request, res: Response) => {
    try {
      const chambers = await storage.getAvailableChambers();
      res.json(chambers);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania dostępnych szuflad" });
    }
  });
  
  // Pobieranie szczegółów szuflady
  app.get("/api/chambers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator szuflady" });
      }
      
      const chamber = await storage.getChamber(id);
      if (!chamber) {
        return res.status(404).json({ success: false, message: "Nie znaleziono szuflady" });
      }
      
      res.json(chamber);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania szczegółów szuflady" });
    }
  });
  
  // Aktualizacja szuflady
  app.put("/api/chambers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator szuflady" });
      }
      
      const chamber = req.body;
      const settings = await storage.getSettings();
      
      // Sprawdzenie ograniczenia jednej szuflady na pracownika
      if (chamber.employeeId) {
        // Pobierz pracownika
        const employee = await storage.getEmployee(chamber.employeeId);
        if (!employee) {
          return res.status(404).json({
            success: false,
            message: `Pracownik o ID ${chamber.employeeId} nie istnieje`
          });
        }
        
        // Sprawdź, czy pracownik już ma przypisaną szufladę
        const assignedChambers = await storage.getChambersByEmployeeId(chamber.employeeId);
        console.log(`[Chamber] Pracownik ${employee.firstName} ${employee.lastName} ma ${assignedChambers.length} przypisanych szuflad`);
        
        // Jeżeli pracownik ma już przypisaną inną szufladę, usuń to przypisanie
        if (assignedChambers.length > 0) {
          for (const assignedChamber of assignedChambers) {
            // Pomijamy szufladę, którą właśnie edytujemy
            if (assignedChamber.id !== id) {
              await storage.updateChamber(assignedChamber.id, {
                employeeId: null,
                isAvailable: true
              });
              console.log(`[Chamber] Usunięto poprzednie przypisanie pracownika do szuflady ${assignedChamber.id}`);
            }
          }
        }
      }
      
      // Sprawdź, czy używamy magazynu do przypisywania produktów
      if (settings.inventoryBasedAssignment && chamber.productId) {
        // Najpierw pobierz istniejącą szufladę
        const existingChamber = await storage.getChamber(id);
        
        // Sprawdź, czy produkt się zmienia na nowy lub czy przypisujemy nowy produkt do pustej szuflady
        const isNewProductAssignment = !existingChamber || !existingChamber.productId || 
                                     (existingChamber.productId !== chamber.productId);
        
        if (isNewProductAssignment) {
          console.log(`[Walidacja magazynu] Sprawdzanie dostępności produktu ID ${chamber.productId} przed przypisaniem do szuflady ${id}`);
          
          try {
            // Sprawdź dostępność produktu
            const availability = await storage.checkProductAvailability(chamber.productId);
            
            // Jeśli nie ma dostępnych produktów dla nowych przypisań, zwróć błąd
            if (availability.availableForNewAssignments <= 0) {
              console.log(`[Walidacja magazynu] Niewystarczająca ilość produktu ${availability.productName} (ID: ${chamber.productId}) w magazynie.`);
              console.log(`[Walidacja magazynu] Dostępne: ${availability.totalAvailable}, Przypisane: ${availability.chambersAssigned}`);
              
              return res.status(400).json({
                success: false,
                error: 'INSUFFICIENT_INVENTORY',
                message: `Niewystarczająca ilość produktu ${availability.productName} w magazynie.`,
                productId: chamber.productId,
                productName: availability.productName,
                availableQuantity: availability.totalAvailable,
                requiredQuantity: availability.chambersAssigned + 1,
                chambersAssigned: availability.chambersAssigned
              });
            }
            
            console.log(`[Walidacja magazynu] Produkt ${availability.productName} (ID: ${chamber.productId}) jest dostępny w magazynie.`);
            console.log(`[Walidacja magazynu] Dostępne: ${availability.totalAvailable}, Przypisane: ${availability.chambersAssigned}, Dostępne dla nowych przypisań: ${availability.availableForNewAssignments}`);
          } catch (error) {
            console.error(`[Walidacja magazynu] Błąd podczas sprawdzania dostępności produktu:`, error);
            return res.status(400).json({
              success: false,
              error: 'PRODUCT_NOT_FOUND',
              message: `Nie można zweryfikować dostępności produktu (ID: ${chamber.productId})`,
            });
          }
        } else {
          console.log(`[Walidacja magazynu] Pomijam sprawdzanie dostępności, bo produkt ID ${chamber.productId} jest już przypisany do szuflady ${id}`);
        }
      }
      
      // Aktualizacja szuflady
      const updatedChamber = await storage.updateChamber(id, chamber);
      
      if (!updatedChamber) {
        return res.status(404).json({ success: false, message: "Nie znaleziono szuflady" });
      }
      
      res.json({
        ...updatedChamber,
        previousAssignmentsRemoved: chamber.employeeId ? true : false
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas aktualizacji szuflady" });
    }
  });
  
  // Usuwanie produktu z szuflady
  app.delete("/api/chambers/:id/product", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator szuflady" });
      }
      
      const updatedChamber = await storage.resetChamber(id);
      
      if (!updatedChamber) {
        return res.status(404).json({ success: false, message: "Nie znaleziono szuflady" });
      }
      
      res.json({ success: true, message: "Produkt został usunięty z szuflady", chamber: updatedChamber });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas usuwania produktu z szuflady" });
    }
  });
  
  // Inicjalizacja szuflad (tworzy lub aktualizuje określoną liczbę szuflad)
  app.post("/api/chambers/initialize", async (req: Request, res: Response) => {
    try {
      const initSchema = z.object({
        count: z.number().int().min(1).max(48).default(48),
        isAvailable: z.boolean().default(true)
      });
      
      const { count, isAvailable } = initSchema.parse(req.body);
      const results = [];
      
      for (let i = 1; i <= count; i++) {
        // Sprawdź, czy szuflada już istnieje
        let chamber = await storage.getChamber(i);
        
        if (chamber) {
          // Aktualizuj istniejącą szufladę
          chamber = await storage.updateChamber(i, { isAvailable });
        } else {
          // Utwórz nową szufladę
          chamber = await storage.createChamber({
            id: i,
            productId: null,
            employeeId: null,
            isAvailable: isAvailable
          });
        }
        
        results.push(chamber);
      }
      
      res.json({ success: true, count: results.length, chambers: results });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane wejściowe", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ success: false, message: "Błąd podczas inicjalizacji szuflad" });
    }
  });
  
  // ====================================
  // Endpointy zarządzania ustawieniami
  // ====================================
  
  // Pobieranie ustawień
  app.get("/api/settings", async (_req: Request, res: Response) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania ustawień" });
    }
  });
  
  // Aktualizacja ustawień
  app.patch("/api/settings", async (req: Request, res: Response) => {
    try {
      const settingsData = req.body;
      
      console.log("[API Settings] Otrzymano dane do aktualizacji:", JSON.stringify(settingsData, null, 2));
      
      // Walidacja danych wejściowych
      if (!settingsData) {
        return res.status(400).json({ success: false, message: "Brak danych do aktualizacji" });
      }
      
      // Konwersja otherSettings na string jeśli przyszło jako obiekt
      if (settingsData.otherSettings && typeof settingsData.otherSettings === 'object') {
        settingsData.otherSettings = JSON.stringify(settingsData.otherSettings);
      }
      
      // Upewniamy się, że wartość screensaverEnabled jest przesyłana jako Boolean
      if (settingsData.screensaverEnabled !== undefined) {
        // Konwersja do boolean jeśli przyszło jako string
        if (typeof settingsData.screensaverEnabled === 'string') {
          settingsData.screensaverEnabled = settingsData.screensaverEnabled === 'true';
        }
        console.log("[API Settings] Wartość screensaverEnabled:", settingsData.screensaverEnabled, 
                    "typu", typeof settingsData.screensaverEnabled);
      }
      
      // Upewniamy się, że wartość screensaverTimeoutSeconds jest liczbą
      if (settingsData.screensaverTimeoutSeconds !== undefined) {
        settingsData.screensaverTimeoutSeconds = Number(settingsData.screensaverTimeoutSeconds);
        console.log("[API Settings] Wartość screensaverTimeoutSeconds:", 
                    settingsData.screensaverTimeoutSeconds, "typu", 
                    typeof settingsData.screensaverTimeoutSeconds);
      }
      
      // Aktualizacja ustawień
      const updatedSettings = await storage.updateSettings(settingsData);
      
      console.log("[API Settings] Zaktualizowane ustawienia:", JSON.stringify({
        screensaverEnabled: updatedSettings.screensaverEnabled,
        screensaverTimeoutSeconds: updatedSettings.screensaverTimeoutSeconds,
        screensaverImageUrl: updatedSettings.screensaverImageUrl
      }, null, 2));
      
      // Zwracamy zaktualizowane ustawienia
      res.json({ success: true, settings: updatedSettings });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas aktualizacji ustawień" });
    }
  });
  
  // Konfiguracja Multer dla przesyłania obrazów wygaszacza ekranu
  const screensaverStorage = multer.diskStorage({
    destination: function (req, file, cb) {
      const uploadDir = path.join(process.cwd(), 'uploads');
      // Upewnij się, że katalog uploads istnieje
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const ext = path.extname(file.originalname);
      cb(null, 'screensaver-' + uniqueSuffix + ext);
    }
  });

  const uploadScreensaver = multer({ 
    storage: screensaverStorage,
    limits: { fileSize: 10 * 1024 * 1024 }, // Limit 10MB
    fileFilter: function (req, file, cb) {
      // Akceptuj tylko pliki obrazów
      if (file.mimetype.startsWith('image/')) {
        cb(null, true);
      } else {
        cb(new Error('Tylko pliki obrazów są dozwolone!'));
      }
    }
  });

  // Endpoint do przesłania obrazu wygaszacza ekranu
  app.post('/api/settings/screensaver-image', uploadScreensaver.single('screensaverImage'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ success: false, message: "Nie przesłano pliku" });
      }

      // Pobierz aktualne ustawienia
      const currentSettings = await storage.getSettings();
      
      // Przygotuj ścieżkę URL dla przesłanego obrazu
      const imageUrl = `/uploads/${req.file.filename}`;
      
      // Zaktualizuj ustawienia w bazie danych - zapisz URL bezpośrednio do pola screensaverImageUrl
      const updatedSettings = await storage.updateSettings({
        ...currentSettings,
        screensaverImageUrl: imageUrl
      });
      
      res.json({ 
        success: true, 
        message: "Obraz wygaszacza ekranu został zaktualizowany", 
        imageUrl: imageUrl,
        settings: updatedSettings
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas przetwarzania obrazu wygaszacza ekranu" });
    }
  });
  
  // ====================================
  // Endpointy do obsługi temperatury
  // ====================================
  
  // Odbieranie odczytu temperatury (usunięty duplikat)
  
  // ====================================
  // Endpointy obsługi dostaw
  // ====================================
  
  // Tworzenie nowej dostawy
  app.post("/api/deliveries", async (req: Request, res: Response) => {
    try {
      console.log("[API] Otrzymano dane dostawy:", JSON.stringify(req.body));
      
      const { deliveryNumber, deliveryDate, notes, items } = req.body;
      
      console.log("[API] Parsowane dane:", { deliveryNumber, deliveryDate, notes, items: Array.isArray(items) ? items.length : "nie jest tablicą" });
      
      if (!items || !Array.isArray(items) || items.length === 0) {
        console.log("[API] Błąd: Brak produktów w dostawie");
        return res.status(400).json({ 
          success: false, 
          message: "Brak produktów w dostawie" 
        });
      }
      
      // Walidacja wymaganych pól
      if (!deliveryNumber || !deliveryDate) {
        console.log("[API] Błąd: Brak wymaganych pól");
        return res.status(400).json({ 
          success: false, 
          message: "Brak wymaganych pól (numer dostawy, data dostawy)" 
        });
      }
      
      console.log("[API] Przygotowanie danych do zapisania w bazie");
      const deliveryData = {
        deliveryNumber,
        deliveryDate,
        notes: notes || null,
        items: items.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          expiryDate: item.expiryDate,
          batchNumber: item.batchNumber || null
        }))
      };
      
      console.log("[API] Dane do zapisania:", JSON.stringify(deliveryData));
      
      const delivery = await storage.createDelivery(deliveryData);
      
      console.log("[API] Dostawa utworzona pomyślnie:", delivery?.id);
      
      res.status(201).json({
        success: true,
        message: "Dostawa została utworzona",
        delivery
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas tworzenia dostawy" });
    }
  });
  
  // Pobieranie listy dostaw
  app.get("/api/deliveries", async (_req: Request, res: Response) => {
    try {
      // Wymuszaj odświeżenie pamięci podręcznej przeglądarki
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      
      const deliveries = await storage.getDeliveries();
      console.log(`Endpoint /api/deliveries zwraca ${deliveries.length} dostaw z łączną ilością ${deliveries.reduce((sum, delivery) => sum + (delivery.items?.length || 0), 0)} produktów`);
      
      // Sprawdź szczegóły pierwszej dostawy
      if (deliveries.length > 0) {
        const firstDelivery = deliveries[0];
        console.log(`Pierwsza dostawa: ${firstDelivery.deliveryNumber}, ilość produktów: ${firstDelivery.items?.length || 0}`);
      }
      
      res.json(deliveries);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania listy dostaw" });
    }
  });
  
  // Pobieranie szczegółów dostawy
  app.get("/api/deliveries/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator dostawy" });
      }
      
      const delivery = await storage.getDelivery(id);
      if (!delivery) {
        return res.status(404).json({ success: false, message: "Dostawa nie istnieje" });
      }
      
      res.json(delivery);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania szczegółów dostawy" });
    }
  });
  
  app.get("/api/temperature", async (req: Request, res: Response) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const readings = await storage.getTemperatureReadings(limit);
      res.json(readings);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania historii temperatury" });
    }
  });
  
  // Pobieranie odczytów temperatury w zakresie dat
  app.get("/api/temperature/range", async (req: Request, res: Response) => {
    try {
      let startTime = req.query.start ? new Date(req.query.start as string) : new Date(Date.now() - 24 * 60 * 60 * 1000);
      let endTime = req.query.end ? new Date(req.query.end as string) : new Date();
      
      // Walidacja dat
      if (isNaN(startTime.getTime()) || isNaN(endTime.getTime())) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowy format daty - wymagany format ISO 8601" 
        });
      }
      
      const readings = await storage.getTemperatureReadingsInRange(startTime, endTime);
      res.json(readings);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania historii temperatury" });
    }
  });

  // ====================================
  // Endpointy zarządzania magazynem
  // ====================================
  
  // Pobieranie elementów magazynowych
  app.get("/api/inventory", async (req: Request, res: Response) => {
    try {
      const items = await storage.getInventoryItems();
      
      // Pobierz informacje o produktach dla elementów
      const productIds = [...new Set(items.map(item => item.productId))];
      let products: Product[] = [];
      
      if (productIds.length > 0) {
        products = await storage.getProducts();
      }
      
      // Wzbogać elementy o informacje o produktach
      const enrichedItems = items.map(item => {
        const product = products.find(p => p.id === item.productId);
        return {
          ...item,
          productName: product ? product.name : `Produkt ID: ${item.productId}`,
          productImage: product ? product.imageUrl : undefined
        };
      });
      
      res.json(enrichedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania elementów magazynowych" });
    }
  });
  
  // Pobieranie elementów magazynowych pogrupowanych według produktów
  app.get("/api/inventory/grouped", async (req: Request, res: Response) => {
    try {
      const groupedItems = await storage.getGroupedInventoryItems();
      res.json(groupedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania pogrupowanych elementów magazynowych" });
    }
  });
  
  // Pobieranie elementów magazynowych dla określonego produktu
  app.get("/api/inventory/product/:productId", async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      if (isNaN(productId)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator produktu" });
      }
      
      const items = await storage.getInventoryItemsByProduct(productId);
      
      // Pobierz informacje o produkcie
      const product = await storage.getProduct(productId);
      
      // Wzbogać elementy o informacje o produkcie
      const enrichedItems = items.map(item => ({
        ...item,
        productName: product ? product.name : `Produkt ID: ${productId}`,
        productImage: product ? product.imageUrl : undefined
      }));
      
      res.json(enrichedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania elementów magazynowych produktu" });
    }
  });
  
  // Pobieranie przeterminowanych elementów magazynowych
  app.get("/api/inventory/expired", async (req: Request, res: Response) => {
    try {
      // Użyj nowej metody z storage, która jest już zgodna z logiką w innych częściach aplikacji
      const items = await storage.getExpiredInventoryItems();
      
      // Pobierz informacje o produktach dla elementów
      const productIds = [...new Set(items.map(item => item.productId))];
      let products: Product[] = [];
      
      if (productIds.length > 0) {
        products = await storage.getProducts();
      }
      
      // Wzbogać elementy o informacje o produktach
      const enrichedItems = items.map(item => {
        const product = products.find(p => p.id === item.productId);
        return {
          ...item,
          productName: product ? product.name : `Produkt ID: ${item.productId}`,
          productImage: product ? product.imageUrl : undefined
        };
      });
      
      res.json(enrichedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania przeterminowanych elementów magazynowych" });
    }
  });
  
  // Pobieranie elementów magazynowych z kończącym się terminem
  app.get("/api/inventory/expiring", async (req: Request, res: Response) => {
    try {
      // Pobierz ustawienia
      const settings = await storage.getSettings();
      console.log("[API] Ustawienia expiring threshold:", settings.expiringDaysThreshold);
      
      // Przekazanie jawnie parametru dni z ustawień
      const expiringItems = await storage.getExpiringInventoryItems(settings.expiringDaysThreshold);
      
      // Pobierz informacje o produktach dla elementów
      const productIds = [...new Set(expiringItems.map(item => item.productId))];
      let products: Product[] = [];
      
      if (productIds.length > 0) {
        products = await storage.getProducts();
      }
      
      // Wzbogać elementy o informacje o produktach
      const enrichedItems = expiringItems.map(item => {
        const product = products.find(p => p.id === item.productId);
        return {
          ...item,
          productName: product ? product.name : `Produkt ID: ${item.productId}`,
          productImage: product ? product.imageUrl : undefined
        };
      });
      
      console.log("[API] Znaleziono kończące się produkty:", enrichedItems.length);
      res.json(enrichedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania elementów magazynowych z kończącym się terminem" });
    }
  });
  
  // Pobieranie elementów magazynowych w terminie
  app.get("/api/inventory/indate", async (req: Request, res: Response) => {
    try {
      // Pobierz ustawienia
      const settings = await storage.getSettings();
      console.log("[API] Ustawienia 'W terminie', próg: ", settings.expiringDaysThreshold);
      
      const inDateItems = await storage.getInDateItems();
      
      // Pobierz informacje o produktach dla elementów
      const productIds = [...new Set(inDateItems.map(item => item.productId))];
      let products: Product[] = [];
      
      if (productIds.length > 0) {
        products = await storage.getProducts();
      }
      
      // Wzbogać elementy o informacje o produktach
      const enrichedItems = inDateItems.map(item => {
        const product = products.find(p => p.id === item.productId);
        return {
          ...item,
          productName: product ? product.name : `Produkt ID: ${item.productId}`,
          productImage: product ? product.imageUrl : undefined
        };
      });
      
      console.log("[API] Znaleziono produktów 'W terminie':", enrichedItems.length);
      res.json(enrichedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania elementów magazynowych w terminie" });
    }
  });
  
  // Pobieranie historii rozchodów
  app.get("/api/inventory/usage", async (req: Request, res: Response) => {
    try {
      // Pobieranie parametrów paginacji z query
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 10;
      const offset = req.query.offset ? parseInt(req.query.offset as string, 10) : 0;
      
      console.log(`[API] Pobieranie historii rozchodów - limit: ${limit}, offset: ${offset}`);
      
      // Pobieranie listy rozchodów z paginacją
      const usageList = await storage.getUsageList(limit, offset);
      res.json(usageList);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania historii rozchodów" });
    }
  });
  
  // Pobieranie historii utylizacji
  app.get("/api/inventory/disposed", async (req: Request, res: Response) => {
    try {
      // Pobieranie parametrów paginacji z query
      const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 10;
      const offset = req.query.offset ? parseInt(req.query.offset as string, 10) : 0;
      
      console.log(`[API] Pobieranie historii utylizacji - limit: ${limit}, offset: ${offset}`);
      
      // Pobieranie listy utylizacji z paginacją
      const disposedItems = await storage.getDisposedItems(limit, offset);
      
      // Pobierz informacje o produktach dla elementów
      const productIds = [...new Set(disposedItems.map(item => item.productId))];
      let products: Product[] = [];
      
      if (productIds.length > 0) {
        products = await storage.getProducts();
      }
      
      // Wzbogać elementy o informacje o produktach
      const enrichedItems = disposedItems.map(item => {
        const product = products.find(p => p.id === item.productId);
        return {
          ...item,
          productName: product ? product.name : `Produkt ID: ${item.productId}`,
          productImage: product ? product.imageUrl : undefined
        };
      });
      
      res.json(enrichedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania elementów zutylizowanych" });
    }
  });
  
  // Rozchód elementu magazynowego
  app.post("/api/inventory/:id/use", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator elementu magazynowego" });
      }
      
      const { quantity, reason, notes } = req.body;
      
      // Sprawdź czy element istnieje
      const item = await storage.getInventoryItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: "Element magazynowy nie istnieje" });
      }
      
      // Sprawdź czy ilość jest dostępna
      if (quantity > item.quantity) {
        return res.status(400).json({ success: false, message: "Ilość do rozchodu przekracza dostępną ilość" });
      }
      
      // Wykonaj rozchód
      const updatedItem = await storage.useInventoryItem(id, quantity, reason || "manual_usage");
      
      res.json({ 
        success: true, 
        message: "Element magazynowy został rozchodowany", 
        item: updatedItem 
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas rozchodu elementu magazynowego" });
    }
  });
  
  // Utylizacja elementu magazynowego
  app.post("/api/inventory/:id/dispose", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator elementu magazynowego" });
      }
      
      const { quantity } = req.body;
      
      // Sprawdź czy element istnieje
      const item = await storage.getInventoryItemById(id);
      if (!item) {
        return res.status(404).json({ success: false, message: "Element magazynowy nie istnieje" });
      }
      
      // Sprawdź czy ilość jest dostępna
      if (quantity > item.quantity) {
        return res.status(400).json({ success: false, message: "Ilość do utylizacji przekracza dostępną ilość" });
      }
      
      // Wykonaj utylizację
      const updatedItem = await storage.disposeInventoryItem(id, quantity);
      
      if (!updatedItem) {
        return res.status(400).json({ 
          success: false, 
          message: "Nie można zutylizować elementu. Brak dostępnej ilości lub produkt już zutylizowany." 
        });
      }
      
      res.json({ 
        success: true, 
        message: "Element magazynowy został zutylizowany", 
        item: updatedItem 
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas utylizacji elementu magazynowego" });
    }
  });
  
  // Pobieranie elementów dostawy
  app.get("/api/deliveries/:id/items", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowy identyfikator dostawy" });
      }
      
      const inventoryItems = await storage.getInventoryItemsByDelivery(id);
      
      // Pobierz informacje o produktach dla elementów
      const productIds = [...new Set(inventoryItems.map(item => item.productId))];
      let products: Product[] = [];
      
      if (productIds.length > 0) {
        products = await storage.getProducts();
      }
      
      // Wzbogać elementy o informacje o produktach
      const enrichedItems = inventoryItems.map(item => {
        const product = products.find(p => p.id === item.productId);
        return {
          ...item,
          productName: product ? product.name : `Produkt ID: ${item.productId}`,
          productImage: product ? product.imageUrl : undefined
        };
      });
      
      res.json(enrichedItems);
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania elementów dostawy" });
    }
  });

  // ====================================
  // Endpointy komunikacji z ESP32
  // ====================================

  // Endpoint do sprawdzania czy jest żądanie otwarcia szuflady (długi polling)
  app.get("/api/mqtt/drawer/listen", async (req: Request, res: Response) => {
    try {
      console.log("[ESP32] Otrzymano zapytanie o żądania otwarcia szuflad");
      
      // Sprawdzenie, czy istnieje nieprzetworzony request
      if (lastDrawerRequest && !lastDrawerRequest.processed) {
        // Oznacz żądanie jako przetworzone
        lastDrawerRequest.processed = true;
        
        return res.json({
          hasRequest: true,
          drawerNumber: lastDrawerRequest.drawerNumber,
          timestamp: lastDrawerRequest.timestamp.toISOString()
        });
      }
      
      // Jeśli nie ma żądania
      return res.json({
        hasRequest: false
      });
    } catch (error) {
      console.error(`[ESP32] Błąd obsługi żądania sprawdzenia szuflad: ${error}`);
      return res.status(500).json({
        success: false,
        message: "Błąd serwera"
      });
    }
  });
  
  // Endpoint do potwierdzenia otwarcia szuflady
  app.post("/api/mqtt/drawer/confirm", async (req: Request, res: Response) => {
    try {
      console.log(`[ESP32] Otrzymano potwierdzenie otwarcia szuflady: ${JSON.stringify(req.body)}`);
      
      // Parsowanie danych wejściowych
      let drawerNumber: number;
      let status: string = "opened";
      
      // Obsługa różnych formatów danych
      if (typeof req.body === 'string') {
        try {
          const parsedBody = JSON.parse(req.body);
          drawerNumber = parseInt(parsedBody.drawerNumber);
          status = parsedBody.status || "opened";
        } catch (e) {
          console.error(`[ESP32] Błąd parsowania JSON: ${e}`);
          return res.status(400).json({
            success: false,
            message: "Nieprawidłowy format danych"
          });
        }
      } else {
        drawerNumber = parseInt(req.body.drawerNumber);
        status = req.body.status || "opened";
      }
      
      // Walidacja numeru szuflady
      if (isNaN(drawerNumber) || drawerNumber < 1 || drawerNumber > 48) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowy numer szuflady (wymagany zakres: 1-48)"
        });
      }
      
      // Aktualizacja stanu magazynowego, jeśli jest to wymagane
      if (status === "opened") {
        console.log(`[ESP32] Potwierdzono otwarcie szuflady ${drawerNumber}`);
        
        try {
          // Pobierz informacje o szufladzie
          const chamber = await storage.getChamber(drawerNumber);
          if (chamber && chamber.productId) {
            // Pobierz ustawienia
            const settings = await storage.getSettings();
            if (settings.inventoryBasedAssignment) {
              const productUpdated = await storage.useProductFromChamber(drawerNumber);
              console.log(`[ESP32] Stan magazynowy zaktualizowany: ${productUpdated ? 'tak' : 'nie'}`);
              
              // Jeśli stan magazynowy został zaktualizowany, powiadom wszystkich klientów
              if (productUpdated) {
                broadcastToClients({
                  type: "inventory_changed",
                  message: "Stan magazynowy został zaktualizowany",
                  timestamp: new Date().toISOString()
                });
                console.log(`[WebSocket] Wysłano powiadomienie o zmianie stanu magazynowego`);
              }
            }
          }
        } catch (error) {
          console.error(`[ESP32] Błąd aktualizacji stanu magazynowego: ${error}`);
        }
        
        // Powiadomienie klientów WebSocket o otwarciu szuflady
        broadcastToClients({
          type: "drawer_opened",
          drawerNumber,
          timestamp: new Date().toISOString()
        });
      }
      
      return res.json({
        success: true,
        message: `Potwierdzenie otwarcia szuflady ${drawerNumber} zostało zarejestrowane`
      });
    } catch (error) {
      console.error(`[ESP32] Błąd przetwarzania potwierdzenia: ${error}`);
      return res.status(500).json({
        success: false,
        message: "Błąd serwera podczas przetwarzania potwierdzenia"
      });
    }
  });
  
  // Endpoint do odbierania danych RFID
  app.post("/api/rfid", async (req: Request, res: Response) => {
    try {
      console.log(`[ESP32] Otrzymano dane RFID: ${JSON.stringify(req.body)}`);
      
      // Parsowanie danych wejściowych
      let cardId: string;
      
      // Obsługa różnych formatów danych
      if (typeof req.body === 'string') {
        try {
          const parsedBody = JSON.parse(req.body);
          cardId = parsedBody.cardId;
        } catch (e) {
          console.error(`[ESP32] Błąd parsowania JSON RFID: ${e}`);
          return res.status(400).json({
            success: false,
            message: "Nieprawidłowy format danych RFID"
          });
        }
      } else {
        cardId = req.body.cardId;
      }
      
      // Walidacja ID karty
      if (!cardId) {
        return res.status(400).json({
          success: false,
          message: "Brak ID karty RFID"
        });
      }
      
      // Wyszukanie pracownika po karcie RFID
      const employee = await storage.getEmployeeByRfid(cardId);
      
      if (!employee) {
        console.log(`[RFID] Nieznana karta RFID: ${cardId}`);
        return res.json({
          success: false,
          message: "Nieznana karta RFID",
          action: "auth_failed"
        });
      }
      
      // Znajdź szufladę przypisaną do pracownika
      const chambers = await storage.getChambers();
      const employeeChamber = chambers.find(chamber => chamber.employeeId === employee.id);
      
      if (!employeeChamber) {
        console.log(`[RFID] Brak przypisanej szuflady dla pracownika: ${employee.firstName} ${employee.lastName}`);
        return res.json({
          success: true,
          authenticated: true,
          employee: {
            firstName: employee.firstName,
            lastName: employee.lastName
          },
          message: "Brak przypisanej szuflady",
          action: "auth_success_no_drawer"
        });
      }
      
      console.log(`[RFID] Uwierzytelniono pracownika: ${employee.firstName} ${employee.lastName}, szuflada: ${employeeChamber.id}`);
      
      // Zapisz żądanie otwarcia szuflady
      lastDrawerRequest = {
        drawerNumber: employeeChamber.id,
        timestamp: new Date(),
        processed: false
      };
      
      // Aktualizacja stanu magazynowego, jeśli włączone
      const settings = await storage.getSettings();
      if (settings.inventoryBasedAssignment && employeeChamber.productId) {
        const productUpdated = await storage.useProductFromChamber(employeeChamber.id);
        
        // Jeśli stan magazynowy został zaktualizowany, powiadom wszystkich klientów
        if (productUpdated) {
          broadcastToClients({
            type: "inventory_changed",
            message: "Stan magazynowy został zaktualizowany",
            timestamp: new Date().toISOString()
          });
          console.log(`[WebSocket] Wysłano powiadomienie o zmianie stanu magazynowego`);
        }
      }
      
      // Powiadomienie klientów WebSocket
      broadcastToClients({
        type: "rfid_authenticated",
        employee: {
          firstName: employee.firstName,
          lastName: employee.lastName
        },
        drawerNumber: employeeChamber.id,
        timestamp: lastDrawerRequest.timestamp.toISOString()
      });
      
      return res.json({
        success: true,
        action: "open_drawer",
        drawerNumber: employeeChamber.id,
        employee: {
          firstName: employee.firstName,
          lastName: employee.lastName
        },
        message: `Otwieranie szuflady ${employeeChamber.id}`
      });
    } catch (error) {
      console.error(`[ESP32] Błąd przetwarzania danych RFID: ${error}`);
      return res.status(500).json({
        success: false,
        message: "Błąd serwera podczas przetwarzania danych RFID"
      });
    }
  });
  
  // Endpoint do odbierania danych temperatury
  app.post("/api/temperature", async (req: Request, res: Response) => {
    try {
      console.log(`[ESP32] Otrzymano dane temperatury: ${JSON.stringify(req.body)}`);
      
      // Parsowanie danych wejściowych
      let temperature: number;
      let humidity: number | undefined;
      
      // Obsługa różnych formatów danych
      if (typeof req.body === 'string') {
        try {
          const parsedBody = JSON.parse(req.body);
          temperature = parseFloat(parsedBody.temperature);
          humidity = parsedBody.humidity !== undefined ? parseFloat(parsedBody.humidity) : undefined;
        } catch (e) {
          console.error(`[ESP32] Błąd parsowania JSON temperatury: ${e}`);
          return res.status(400).json({
            success: false,
            message: "Nieprawidłowy format danych temperatury"
          });
        }
      } else {
        temperature = parseFloat(req.body.temperature);
        humidity = req.body.humidity !== undefined ? parseFloat(req.body.humidity) : undefined;
      }
      
      // Walidacja temperatury
      if (isNaN(temperature)) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowa wartość temperatury"
        });
      }
      
      // Tworzenie obiektu odczytu temperatury
      const now = new Date();
      const reading: TemperatureReading = {
        temperature,
        humidity,
        timestamp: now.toISOString()
      };
      
      // Zapis odczytu temperatury
      await storage.addTemperatureReading(reading);
      console.log(`[ESP32] Zapisano temperaturę: ${temperature}°C${humidity !== undefined ? `, wilgotność: ${humidity}%` : ''}`);
      
      // Sprawdzenie czy temperatura jest w granicach
      const settings = await storage.getSettings();
      const minTemp = settings.minTemperature;
      const maxTemp = settings.maxTemperature;
      
      // Powiadomienie, jeśli temperatura jest poza zakresem
      if (temperature < minTemp || temperature > maxTemp) {
        broadcastToClients({
          type: "temperature_alert",
          temperature,
          minTemp,
          maxTemp,
          timestamp: reading.timestamp,
          message: temperature < minTemp 
            ? `Temperatura poniżej normy: ${temperature}°C (min: ${minTemp}°C)` 
            : `Temperatura powyżej normy: ${temperature}°C (max: ${maxTemp}°C)`
        });
      }
      
      return res.json({
        success: true,
        message: "Odczyt temperatury zapisany pomyślnie"
      });
    } catch (error) {
      console.error(`[ESP32] Błąd przetwarzania danych temperatury: ${error}`);
      return res.status(500).json({
        success: false,
        message: "Błąd serwera podczas przetwarzania danych temperatury"
      });
    }
  });

  // Legacy endpoint dla kompatybilności wstecznej - przesyła do odpowiednich dedykowanych endpointów
  app.post("/api/esp32/data", async (req: Request, res: Response) => {
    try {
      console.log(`[ESP32] Otrzymano dane przez stary endpoint: ${JSON.stringify(req.body)}`);
      
      let data: any;
      
      // Parsowanie danych wejściowych jeśli są w formie stringa
      if (typeof req.body === 'string') {
        try {
          data = JSON.parse(req.body);
        } catch (e) {
          console.error(`[ESP32] Błąd parsowania JSON: ${e}`);
          data = req.body;
        }
      } else {
        data = req.body;
      }
      
      // Przekierowanie do odpowiednich endpointów w zależności od zawartości
      if (data.temperature !== undefined) {
        // Dane temperatury
        return res.json({
          success: true,
          message: "Użyj dedykowanego endpointu /api/temperature",
          redirectTo: "/api/temperature"
        });
      } else if (data.rfid || data.cardId) {
        // Dane RFID
        return res.json({
          success: true,
          message: "Użyj dedykowanego endpointu /api/rfid",
          redirectTo: "/api/rfid"
        });
      } else if (data.drawer || data.drawerNumber) {
        // Otwarcie szuflady
        return res.json({
          success: true,
          message: "Użyj dedykowanego endpointu /api/mqtt/drawer/confirm",
          redirectTo: "/api/mqtt/drawer/confirm"
        });
      }
      
      // Domyślna odpowiedź
      return res.json({ 
        success: false, 
        message: "Nierozpoznane dane, użyj dedykowanych endpointów API"
      });
    } catch (error) {
      console.error(`[ESP32 Legacy Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return res.status(500).json({ 
        success: false, 
        message: "Błąd przetwarzania" 
      });
    }
  });
  
  // Endpoint do sprawdzania statusu ESP32
  app.get("/api/esp32/status", (_req: Request, res: Response) => {
    try {
      res.json({ 
        success: true, 
        status: "online",
        serverTime: new Date().toISOString()
      });
    } catch (error) {
      console.error(`[ESP32 Status Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd serwera" });
    }
  });
  
  // Endpoint do ręcznego otwierania szuflady dla ESP32
  app.get("/api/esp32/drawer/:drawerNumber", async (req: Request, res: Response) => {
    try {
      const drawerNumber = parseInt(req.params.drawerNumber);
      
      if (isNaN(drawerNumber) || drawerNumber < 1 || drawerNumber > 48) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowy numer szuflady (wymagany zakres: 1-48)" 
        });
      }
      
      // Zapisujemy żądanie otwarcia szuflady
      lastDrawerRequest = {
        drawerNumber,
        timestamp: new Date(),
        processed: false
      };
      
      console.log(`[ESP32] Ręczne żądanie otwarcia szuflady ${drawerNumber}`);
      
      // Zmniejszamy stan magazynowy dla produktu w szufladzie (jeśli włączone w ustawieniach)
      const chamber = await storage.getChamber(drawerNumber);
      if (chamber && chamber.productId) {
        const settings = await storage.getSettings();
        if (settings.inventoryBasedAssignment) {
          const productUpdated = await storage.useProductFromChamber(drawerNumber);
          
          // Jeśli stan magazynowy został zaktualizowany, powiadom wszystkich klientów
          if (productUpdated) {
            broadcastToClients({
              type: "inventory_changed",
              message: "Stan magazynowy został zaktualizowany",
              timestamp: new Date().toISOString()
            });
            console.log(`[WebSocket] Wysłano powiadomienie o zmianie stanu magazynowego`);
          }
        }
      }
      
      res.json({ 
        success: true, 
        action: "open_drawer",
        drawerNumber,
        message: `Otwieranie szuflady ${drawerNumber}`
      });
    } catch (error) {
      console.error(`[ESP32 Drawer Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd serwera" });
    }
  });
  
  // Endpoint do obsługi trybu załadunkowego przez kartę RFID
  app.post("/api/rfid/loading-mode", async (req: Request, res: Response) => {
    try {
      // Schemat dla żądania weryfikacji karty RFID dla trybu załadunkowego
      const loadingModeRfidSchema = z.object({
        cardId: z.string().min(1, { message: "Numer karty RFID jest wymagany" }),
      });
      
      // Parsowanie danych wejściowych
      const { cardId } = loadingModeRfidSchema.parse(req.body);
      
      console.log(`[RFID Loading Mode] Otrzymano zapytanie dla karty RFID: ${cardId}`);
      
      // Pobierz ustawienia systemu
      const settings = await storage.getSettings();
      
      // Sprawdź, czy karta jest autoryzowana do trybu załadunkowego
      if (!settings.loadingModeRfidCardNumber || settings.loadingModeRfidCardNumber !== cardId) {
        console.log(`[RFID Loading Mode] Karta o numerze ${cardId} nie jest autoryzowana do trybu załadunkowego`);
        return res.json({ 
          success: false, 
          authorized: false,
          message: "Ta karta nie jest autoryzowana do uruchamiania trybu załadunkowego" 
        });
      }
      
      // Karta jest autoryzowana - możemy uruchomić tryb załadunkowy
      console.log(`[RFID Loading Mode] Autoryzowano kartę ${cardId} do trybu załadunkowego`);
      
      // Powiadomienie klientów WebSocket o rozpoczęciu trybu załadunkowego
      broadcastToClients({
        type: "loading_mode_authorized",
        timestamp: new Date().toISOString(),
        message: "Tryb załadunkowy uruchomiony przez kartę RFID"
      });

      // Uruchamiamy tryb załadunkowy bezpośrednio z serwera
      console.log("[RFID Loading Mode] Rozpoczynanie sekwencji otwierania szuflad z serwera...");
      
      // Przypisz funkcję do zmiennej, aby można było do niej odwołać się wewnątrz
      const openDrawerWithDelay = async (drawerNumber: number) => {
        try {
          // Faktyczne otwarcie szuflady
          console.log(`[RFID Loading Mode] Otwieranie szuflady ${drawerNumber}...`);
          
          // Sprawdzamy, czy dana szuflada ma przypisany produkt
          const chamber = await storage.getChamber(drawerNumber);
          
          if (chamber && chamber.productId) {
            console.log(`[RFID Loading Mode] Szuflada ${drawerNumber} ma przypisany produkt ID ${chamber.productId}`);
            // Jeśli tryb bazowania na magazynie jest włączony, zmniejszamy stan magazynu
            if (settings.inventoryBasedAssignment) {
              // Tutaj byłaby logika zmniejszania stanu magazynu, ale pomijamy ją w tym przypadku
              console.log(`[RFID Loading Mode] Tryb bazowania na magazynie jest włączony, ale pomijam zmniejszanie stanu w trybie załadunkowym`);
            }
          }
          
          // Bezpośrednio wywołujemy endpoint otwierania szuflady przez fetch
          const port = process.env.PORT || 5000;
          console.log(`[RFID Loading Mode] Wywołuję endpoint otwarcia szuflady ${drawerNumber} na porcie ${port}...`);
          
          const response = await fetch(`http://localhost:${port}/api/mqtt/drawer/open/${drawerNumber}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' }
          });
          
          const drawerOpenResponse = await response.json();
                    
          if (drawerOpenResponse.success) {
            console.log(`[RFID Loading Mode] Szuflada ${drawerNumber} została pomyślnie otwarta`);
          } else {
            console.error(`[RFID Loading Mode] Błąd podczas otwierania szuflady ${drawerNumber}: ${drawerOpenResponse.message || 'Nieznany błąd'}`);
          }
          
          // Wysyłamy powiadomienie o otwarciu szuflady (niezależnie od rezultatu otwarcia)
          broadcastToClients({
            type: "drawer_opened",
            drawerNumber: drawerNumber,
            timestamp: new Date().toISOString()
          });
          
          return true;
        } catch (error) {
          console.error(`[RFID Loading Mode] Błąd podczas otwierania szuflady ${drawerNumber}:`, error);
          return false;
        }
      };
      
      // Uruchamiamy oddzielny proces dla sekwencji otwierania szuflad
      const totalDrawers = 48;
      const delayBetweenDrawers = 3000; // 3 sekundy
      
      let currentDrawer = 1;
      
      // Funkcja pomocnicza do otwierania szuflady
      const openNextDrawer = () => {
        if (currentDrawer > totalDrawers) {
          // Zakończono wszystkie szuflady
          console.log("[RFID Loading Mode] Zakończono sekwencję otwierania szuflad");
          broadcastToClients({
            type: "loading_mode_completed",
            timestamp: new Date().toISOString(),
            message: "Tryb załadunkowy zakończony"
          });
          return;
        }
        
        // Informujemy klientów o aktualnie otwieranej szufladzie
        broadcastToClients({
          type: "loading_mode_progress",
          currentDrawer: currentDrawer,
          totalDrawers: totalDrawers,
          timestamp: new Date().toISOString()
        });
        
        // Otwieranie szuflady
        console.log(`[RFID Loading Mode] Otwieranie szuflady ${currentDrawer}...`);
        
        // Wywołaj API do otwarcia szuflady
        const port = process.env.PORT || 5000;
        console.log(`[RFID Loading Mode] Wywołuję endpoint otwarcia szuflady ${currentDrawer} na porcie ${port}...`);
        
        fetch(`http://localhost:${port}/api/mqtt/drawer/open/${currentDrawer}`, {
          method: 'GET',
          headers: { 'Accept': 'application/json' }
        })
        .then(response => response.json())
        .then(drawerOpenResponse => {
          if (drawerOpenResponse.success) {
            console.log(`[RFID Loading Mode] Szuflada ${currentDrawer} została pomyślnie otwarta`);
          } else {
            console.error(`[RFID Loading Mode] Błąd podczas otwierania szuflady ${currentDrawer}: ${drawerOpenResponse.message || 'Nieznany błąd'}`);
          }
          
          // Wysyłamy powiadomienie o otwarciu szuflady (niezależnie od rezultatu otwarcia)
          broadcastToClients({
            type: "drawer_opened",
            drawerNumber: currentDrawer,
            timestamp: new Date().toISOString()
          });
          
          // Zwiększ licznik i zaplanuj otwarcie następnej szuflady
          currentDrawer++;
          setTimeout(openNextDrawer, delayBetweenDrawers);
        })
        .catch(error => {
          console.error(`[RFID Loading Mode] Błąd podczas otwierania szuflady ${currentDrawer}:`, error);
          // Kontynuuj mimo błędu
          currentDrawer++;
          setTimeout(openNextDrawer, delayBetweenDrawers);
        });
      };
      
      // Rozpocznij sekwencję po 1 sekundzie
      setTimeout(openNextDrawer, 1000);
      
      return res.json({ 
        success: true, 
        authorized: true,
        action: "start_loading_mode",
        message: "Tryb załadunkowy został uruchomiony"
      });
      
    } catch (error) {
      console.error(`[RFID Loading Mode Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane karty RFID", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ 
        success: false,
        message: "Wystąpił błąd podczas przetwarzania żądania RFID dla trybu załadunkowego" 
      });
    }
  });
  
  // Endpoint do uwierzytelniania pracownika przez email i hasło
  app.post("/api/employees/authenticate", async (req: Request, res: Response) => {
    try {
      const authSchema = z.object({
        email: z.string().email(),
        password: z.string().min(1)
      });
      
      const { email, password } = authSchema.parse(req.body);
      
      console.log(`[Auth] Próba logowania przez email: ${email}`);
      
      // Znajdź pracownika po emailu
      const employee = await storage.getEmployeeByEmail(email);
      
      if (!employee) {
        console.log(`[Auth] Nie znaleziono pracownika z emailem: ${email}`);
        return res.status(401).json({ 
          success: false, 
          message: "Nieprawidłowy email lub hasło" 
        });
      }
      
      // Sprawdź czy pracownik ma ustawione hasło
      if (!employee.passwordHash) {
        // Jeśli pracownik nie ma ustawionego hasła, używamy domyślnego hasła "1308"
        if (password !== "1308") {
          console.log(`[Auth] Błędne hasło dla pracownika: ${employee.firstName} ${employee.lastName}`);
          return res.status(401).json({ 
            success: false, 
            message: "Nieprawidłowy email lub hasło" 
          });
        }
      } else {
        // Sprawdź hasło z użyciem funkcji verifyEmployeePassword
        const isValid = await storage.verifyEmployeePassword(employee.id, password);
        if (!isValid) {
          console.log(`[Auth] Błędne hasło dla pracownika: ${employee.firstName} ${employee.lastName}`);
          return res.status(401).json({ 
            success: false, 
            message: "Nieprawidłowy email lub hasło" 
          });
        }
      }
      
      console.log(`[Auth] Pomyślne logowanie pracownika: ${employee.firstName} ${employee.lastName}`);
      
      // Ustaw ID pracownika w sesji lub użyj innego mechanizmu uwierzytelniania
      // Na razie zwracamy ID pracownika, które będzie używane w zapytaniach
      // Zapisz identyfikator jako liczbę, aby zapewnić spójność typów
      const employeeId = Number(employee.id);
      
      console.log(`[Auth] Zwracany identyfikator pracownika: ${employeeId}, typ: ${typeof employeeId}`);
      
      // Sprawdź, czy pracownik musi zmienić hasło
      const passwordResetRequired = employee.passwordResetRequired || false;
      
      res.json({
        success: true,
        message: "Zalogowano pomyślnie",
        employeeId: employeeId,
        passwordResetRequired: passwordResetRequired
      });
      
    } catch (error) {
      console.error(`[Auth Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane logowania", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ 
        success: false, 
        message: "Wystąpił błąd podczas logowania" 
      });
    }
  });
  
  // Endpoint do resetowania hasła pracownika (dla administratora)
  app.post("/api/employees/:id/reset-password", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowe ID pracownika"
        });
      }
      
      // Resetuj hasło pracownika
      const newPassword = await storage.resetEmployeePassword(id);
      
      res.json({
        success: true,
        message: "Hasło zostało zresetowane",
        password: newPassword
      });
    } catch (error) {
      console.error(`[Password Reset Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({
        success: false,
        message: "Wystąpił błąd podczas resetowania hasła"
      });
    }
  });
  
  // Endpoint do ustawiania hasła pracownika (dla administratora)
  app.post("/api/employees/:id/set-password", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowe ID pracownika"
        });
      }
      
      // Walidacja danych
      const validationResult = passwordSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowe dane",
          errors: validationResult.error.errors
        });
      }
      
      // Ustaw nowe hasło
      await storage.setEmployeePassword(id, req.body.password);
      
      res.json({
        success: true,
        message: "Hasło zostało ustawione"
      });
    } catch (error) {
      console.error(`[Set Password Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({
        success: false,
        message: "Wystąpił błąd podczas ustawiania hasła"
      });
    }
  });
  
  // Endpoint do zmiany hasła pracownika (dla pracownika)
  app.post("/api/employees/:id/change-password", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowe ID pracownika"
        });
      }
      
      // Walidacja danych
      const validationResult = changePasswordSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowe dane",
          errors: validationResult.error.errors
        });
      }
      
      // Zmień hasło
      const success = await storage.changeEmployeePassword(
        id, 
        req.body.currentPassword, 
        req.body.password
      );
      
      if (!success) {
        return res.status(400).json({
          success: false,
          message: "Aktualne hasło jest nieprawidłowe"
        });
      }
      
      res.json({
        success: true,
        message: "Hasło zostało zmienione"
      });
    } catch (error) {
      console.error(`[Change Password Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({
        success: false,
        message: "Wystąpił błąd podczas zmiany hasła"
      });
    }
  });

  // Endpoint do pobierania danych pracownika na podstawie jego ID (dla portalu pracownika)
  app.get("/api/employees/current", async (req: Request, res: Response) => {
    try {
      // TYMCZASOWE ROZWIĄZANIE: Zawsze zwracaj pracownika o ID 1
      // W rzeczywistym wdrożeniu należy używać ID z sesji użytkownika
      console.log(`[Employee] Używamy tymczasowego hard-coded ID = 1`);
      
      const employee = await storage.getEmployee(1);
      
      if (!employee) {
        console.log(`[Employee] Nie znaleziono pracownika o ID: 1`);
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono pracownika o ID 1" 
        });
      }
      
      // Pobierz szuflady przypisane do pracownika
      const assignedChambers = await storage.getChambersByEmployeeId(employee.id);
      
      console.log(`[Employee] Znaleziono pracownika: ${employee.firstName} ${employee.lastName} z ${assignedChambers.length} przypisanymi szufladami`);
      
      res.json({
        success: true,
        employee,
        assignedChambers
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania danych pracownika" });
    }
  });
  
  // Endpoint do pobierania dostępnych produktów dla pracownika
  app.get("/api/employee-portal/products", async (req: Request, res: Response) => {
    try {
      const products = await storage.getProducts();
      // Pobierz oceny produktów
      const productRatings = await storage.getProductRatings();
      
      // Połącz produkty z ich ocenami i filtruj tylko te, które są widoczne w portalu pracownika
      const productsWithRatings = products
        .filter(product => product.visibleInEmployeePortal) // Filtrujemy produkty widoczne w portalu
        .map(product => {
          // Znajdź ocenę dla produktu
          const rating = productRatings.find(r => r.productId === product.id);
          
          // Jeśli jest ocena, dodaj ją do produktu
          if (rating) {
            return {
              ...product,
              rating: {
                rating: rating.averageRating,
                count: rating.count
              }
            };
          }
          
          return product;
        });
      
      res.json({
        success: true,
        products: productsWithRatings
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania produktów" });
    }
  });
  
  // Endpoint do wyboru posiłku przez pracownika
  app.post("/api/employee-portal/select-meal", async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        employeeId: z.number().int().positive(),
        productId: z.number().int().positive()
      });
      
      const parseResult = schema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowe dane wejściowe",
          errors: parseResult.error.errors
        });
      }
      
      const { employeeId, productId } = parseResult.data;
      
      // Sprawdź, czy pracownik istnieje
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({
          success: false,
          message: "Nie znaleziono pracownika o podanym ID"
        });
      }
      
      // Sprawdź, czy produkt istnieje
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({
          success: false,
          message: "Nie znaleziono produktu o podanym ID"
        });
      }
      
      // Pobierz dostępne szuflady (niezajęte przez innych pracowników)
      const chambers = await storage.getChambers();
      const freeChambers = chambers.filter(chamber => !chamber.employeeId);
      
      if (freeChambers.length === 0) {
        return res.status(400).json({
          success: false,
          message: "Brak dostępnych szuflad do przypisania"
        });
      }
      
      // Przypisz produkt do pierwszej dostępnej szuflady
      const chamberToAssign = freeChambers[0];
      
      const updatedChamber = await storage.updateChamber(chamberToAssign.id, {
        productId: productId,
        employeeId: employeeId,
        isAvailable: true
      });
      
      if (!updatedChamber) {
        return res.status(500).json({
          success: false,
          message: "Nie udało się przypisać produktu do szuflady"
        });
      }
      
      res.json({
        success: true,
        message: "Produkt został przypisany do szuflady",
        chamberNumber: updatedChamber.id,
        productName: product.name
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas przypisywania produktu do szuflady" });
    }
  });
  
  // Endpoint do pobierania historii posiłków pracownika
  app.get("/api/employee-portal/meal-history", async (req: Request, res: Response) => {
    try {
      const employeeId = req.query.employeeId ? Number(req.query.employeeId) : null;
      
      if (!employeeId) {
        return res.status(400).json({ 
          success: false, 
          message: "Brak identyfikatora pracownika" 
        });
      }
      
      // Pobieramy wszystkie rezerwacje posiłków pracownika
      let reservations = await storage.getMealReservations(employeeId);
      
      // Najpierw aktualizujemy statusy przeterminowanych rezerwacji
      reservations = await updateExpiredReservations(reservations);
      
      // Filtrujemy tylko zrealizowane rezerwacje i aktywne rezerwacje z minionym terminem
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const historyReservations = reservations.filter(r => {
        // Jeśli status jest 'fulfilled', dodaj do historii
        if (r.status === 'fulfilled') return true;
        
        // Jeśli status jest 'active' ale data minęła, dodaj do historii
        if (r.status === 'active') {
          const reservationDate = new Date(r.reservedForDate);
          reservationDate.setHours(0, 0, 0, 0);
          return reservationDate < today;
        }
        
        return false;
      });
      
      // Pobieramy informacje o produktach
      const productIds = [...new Set(historyReservations.map(r => r.productId))];
      const productsData = productIds.length > 0 
        ? await db.select().from(products).where(sql`${products.id} IN (${productIds.join(',')})`)
        : [];
      
      // Tworzymy mapę dla szybkiego dostępu
      const productsMap = new Map();
      productsData.forEach(product => {
        productsMap.set(product.id, product);
      });
      
      // Przygotowujemy historię posiłków
      const mealHistory = historyReservations.map(r => {
        const product = productsMap.get(r.productId);
        return {
          id: r.id,
          chamberId: r.chamberId || 0,
          productId: r.productId,
          productName: product ? product.name : `Produkt #${r.productId}`,
          productImage: product ? product.imageUrl : null,
          date: r.reservedForDate,
          status: r.status,
          time: r.fulfillmentDate ? new Date(r.fulfillmentDate).toLocaleTimeString('pl-PL', { hour: '2-digit', minute: '2-digit' }) : '--:--'
        };
      });
      
      res.json({
        success: true,
        mealHistory
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ success: false, message: "Błąd podczas pobierania historii posiłków" });
    }
  });

  // ====================================
  // Endpointy do rezerwacji posiłków
  // ====================================
  
  // WAŻNE: Endpointy ze stałymi ścieżkami (np. /check) muszą być zdefiniowane
  // przed endpointami z parametrami (np. /:id), aby uniknąć konfliktów
  
  // Endpoint do sprawdzania czy pracownik ma już rezerwację na dany dzień
  app.get("/api/meal-reservations/check", async (req: Request, res: Response) => {
    try {
      const employeeId = req.query.employeeId ? Number(req.query.employeeId) : null;
      const date = req.query.date as string | undefined;
      
      if (!employeeId || !date) {
        return res.status(400).json({ 
          success: false, 
          message: "Brakujące parametry: employeeId i date są wymagane" 
        });
      }
      
      let reservation = await storage.getMealReservationByEmployeeAndDate(employeeId, date);
      
      // Sprawdź, czy rezerwacja nie powinna mieć statusu "fulfilled"
      if (reservation && reservation.status === 'active') {
        const reservationDate = new Date(reservation.reservedForDate);
        reservationDate.setHours(0, 0, 0, 0);
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Jeśli data rezerwacji jest wcześniejsza niż dzisiejsza, zmień status na fulfilled
        if (reservationDate < today) {
          console.log(`Aktualizacja statusu rezerwacji ${reservation.id} z 'active' na 'fulfilled' - data minęła`);
          const updatedReservation = await storage.updateMealReservation(reservation.id, { status: 'fulfilled' });
          if (updatedReservation) {
            reservation = updatedReservation;
          }
        }
      }
      
      // Dodajemy informację o produkcie dla lepszego wyświetlania
      let reservationWithProductInfo = null;
      if (reservation) {
        const product = await storage.getProduct(reservation.productId);
        reservationWithProductInfo = {
          ...reservation,
          productName: product?.name || 'Nieznany produkt',
          imageUrl: product?.imageUrl || null
        };
      }
      
      res.json({
        success: true,
        hasReservation: !!reservation,
        reservation: reservationWithProductInfo
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false, 
        message: "Błąd podczas sprawdzania rezerwacji" 
      });
    }
  });
  
  // Funkcja do aktualizacji statusów przeterminowanych rezerwacji
  async function updateExpiredReservations(reservations: any[]) {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Ustawienie godziny na 00:00:00 dzisiejszego dnia
    
    const updatedReservations = [...reservations];
    const reservationsToUpdate = [];
    
    for (let i = 0; i < updatedReservations.length; i++) {
      const reservation = updatedReservations[i];
      
      if (reservation.status === 'active') {
        const reservationDate = new Date(reservation.reservedForDate);
        reservationDate.setHours(0, 0, 0, 0);
        
        // Jeśli data rezerwacji jest wcześniejsza niż dzisiejsza data, zmień status na 'fulfilled'
        if (reservationDate < today) {
          updatedReservations[i] = { ...reservation, status: 'fulfilled' };
          reservationsToUpdate.push({
            id: reservation.id,
            status: 'fulfilled'
          });
        }
      }
    }
    
    // Aktualizuj wszystkie przeterminowane rezerwacje w bazie danych
    for (const update of reservationsToUpdate) {
      await storage.updateMealReservation(update.id, { status: update.status });
    }
    
    return updatedReservations;
  }

  // Endpoint do pobierania rezerwacji posiłków
  app.get("/api/meal-reservations", async (req: Request, res: Response) => {
    try {
      const employeeId = req.query.employeeId ? Number(req.query.employeeId) : undefined;
      const fromDate = req.query.fromDate as string | undefined;
      const toDate = req.query.toDate as string | undefined;
      
      // Pobierz rezerwacje
      let reservations = await storage.getMealReservations(employeeId, fromDate, toDate);
      
      // Aktualizuj statusy przeterminowanych rezerwacji
      reservations = await updateExpiredReservations(reservations);
      
      res.json({
        success: true,
        reservations
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false, 
        message: "Błąd podczas pobierania rezerwacji posiłków" 
      });
    }
  });
  
  // Endpoint do pobierania pojedynczej rezerwacji posiłku
  app.get("/api/meal-reservations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowy identyfikator rezerwacji" 
        });
      }
      
      let reservation = await storage.getMealReservation(id);
      if (!reservation) {
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono rezerwacji o podanym identyfikatorze" 
        });
      }
      
      // Sprawdź, czy rezerwacja nie powinna mieć statusu "fulfilled"
      if (reservation.status === 'active') {
        const reservationDate = new Date(reservation.reservedForDate);
        reservationDate.setHours(0, 0, 0, 0);
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Jeśli data rezerwacji jest wcześniejsza niż dzisiejsza, zmień status na fulfilled
        if (reservationDate < today) {
          console.log(`Aktualizacja statusu rezerwacji ${reservation.id} z 'active' na 'fulfilled' - data minęła`);
          const updatedReservation = await storage.updateMealReservation(reservation.id, { status: 'fulfilled' });
          if (updatedReservation) {
            reservation = updatedReservation;
          }
        }
      }
      
      res.json({
        success: true,
        reservation
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false, 
        message: "Błąd podczas pobierania rezerwacji posiłku" 
      });
    }
  });

  
  // Endpoint do tworzenia nowej rezerwacji posiłku
  app.post("/api/meal-reservations", async (req: Request, res: Response) => {
    try {
      // Schemat walidacji danych rezerwacji
      const schema = z.object({
        employeeId: z.number().int().positive(),
        productId: z.number().int().positive(),
        reservedForDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Oczekiwany format daty: YYYY-MM-DD")
      });
      
      // Walidacja danych wejściowych
      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane rezerwacji", 
          errors: result.error.errors 
        });
      }
      
      const { employeeId, productId, reservedForDate } = result.data;
      
      // Sprawdź, czy pracownik istnieje
      const employee = await storage.getEmployee(employeeId);
      if (!employee) {
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono pracownika o podanym identyfikatorze" 
        });
      }
      
      // Sprawdź, czy produkt istnieje
      const product = await storage.getProduct(productId);
      if (!product) {
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono produktu o podanym identyfikatorze" 
        });
      }
      
      // Sprawdź, czy pracownik nie ma już rezerwacji na ten dzień
      const existingReservation = await storage.getMealReservationByEmployeeAndDate(employeeId, reservedForDate);
      if (existingReservation) {
        return res.status(409).json({ 
          success: false, 
          message: "Pracownik ma już rezerwację na ten dzień", 
          reservation: existingReservation 
        });
      }
      
      // Pobierz ustawienia
      const settings = await storage.getSettings();
      
      // Sprawdź ograniczenia dotyczące dat rezerwacji
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const reservationDate = new Date(reservedForDate);
      reservationDate.setHours(0, 0, 0, 0);
      
      // Sprawdź czy data nie jest z przeszłości
      if (reservationDate < today) {
        return res.status(400).json({ 
          success: false, 
          message: "Nie można dokonać rezerwacji na datę z przeszłości" 
        });
      }
      
      // Sprawdź maksymalny limit dni do przodu
      const maxDaysAhead = settings.maxReservationDays || 7;
      const maxDate = new Date(today);
      maxDate.setDate(maxDate.getDate() + maxDaysAhead);
      
      if (reservationDate > maxDate) {
        return res.status(400).json({ 
          success: false, 
          message: `Nie można dokonać rezerwacji dalej niż ${maxDaysAhead} dni do przodu` 
        });
      }
      
      // Sprawdź minimalny wyprzedzenie dla pierwszej rezerwacji
      const firstReservationDays = settings.firstReservationDays || 2;
      
      // Sprawdź czy istnieją już jakieś rezerwacje dla tego pracownika
      const existingReservations = await storage.getMealReservations(employeeId);
      const isFirstReservation = existingReservations.length === 0;
      
      // Specjalna obsługa dla wartości 0 - pozwala na zamówienie na dzień bieżący
      if (firstReservationDays === 0) {
        console.log("[API] Wartość firstReservationDays = 0 - dozwolone zamawianie na dzień bieżący");
        // Nie wykonujemy dodatkowego sprawdzenia dla dzisiejszej daty, gdy firstReservationDays = 0
      } else {
        // Dla wartości > 0, standardowa logika sprawdzająca wyprzedzenie
        const minFirstReservationDate = new Date(today);
        minFirstReservationDate.setDate(minFirstReservationDate.getDate() + firstReservationDays);
        
        if (isFirstReservation && reservationDate < minFirstReservationDate) {
          return res.status(400).json({ 
            success: false, 
            message: `Pierwsza rezerwacja musi być dokonana z wyprzedzeniem co najmniej ${firstReservationDays} dni` 
          });
        }
      }
      
      // Utwórz rezerwację
      const reservation: InsertMealReservation = {
        employeeId,
        productId,
        reservedForDate,
        status: 'active',
        chamberId: null,
        assignmentType: 'manual' // Dodajemy oznaczenie, że to samodzielny wybór pracownika
      };
      
      const newReservation = await storage.createMealReservation(reservation);
      
      res.status(201).json({
        success: true,
        reservation: newReservation
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false, 
        message: "Wystąpił błąd podczas tworzenia rezerwacji posiłku" 
      });
    }
  });
  
  // Endpoint do aktualizacji rezerwacji posiłku
  app.put("/api/meal-reservations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowy identyfikator rezerwacji" 
        });
      }
      
      // Schemat walidacji danych rezerwacji
      const schema = z.object({
        productId: z.number().int().positive().optional(),
        employeeId: z.number().int().positive().optional(),
        reservedForDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Oczekiwany format daty: YYYY-MM-DD").optional(),
        status: z.enum(['active', 'cancelled', 'fulfilled']).optional(),
        chamberId: z.number().int().positive().nullable().optional()
      });
      
      // Walidacja danych wejściowych
      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane rezerwacji", 
          errors: result.error.errors 
        });
      }
      
      // Sprawdź, czy rezerwacja istnieje
      const existingReservation = await storage.getMealReservation(id);
      if (!existingReservation) {
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono rezerwacji o podanym identyfikatorze" 
        });
      }
      
      // Sprawdź, czy próbujemy zmienić produkt i czy nowy produkt istnieje
      if (result.data.productId) {
        const product = await storage.getProduct(result.data.productId);
        if (!product) {
          return res.status(404).json({ 
            success: false, 
            message: "Nie znaleziono produktu o podanym identyfikatorze" 
          });
        }
      }
      
      // Sprawdź, czy próbujemy przypisać szufladę i czy szuflada istnieje
      if (result.data.chamberId) {
        const chamber = await storage.getChamber(result.data.chamberId);
        if (!chamber) {
          return res.status(404).json({ 
            success: false, 
            message: "Nie znaleziono szuflady o podanym identyfikatorze" 
          });
        }
      }
      
      // Jeśli zmieniana jest data rezerwacji, sprawdź czy pracownik nie ma już rezerwacji na ten dzień
      // (z wyłączeniem bieżącej rezerwacji)
      if (result.data.reservedForDate) {
        const employeeId = result.data.employeeId || existingReservation.employeeId;
        
        const conflictingReservation = await storage.getMealReservationByEmployeeAndDate(
          employeeId, 
          result.data.reservedForDate
        );
        
        if (conflictingReservation && conflictingReservation.id !== id) {
          return res.status(409).json({ 
            success: false, 
            message: "Pracownik ma już inną rezerwację na ten dzień", 
            reservation: conflictingReservation 
          });
        }
      }
      
      // Zaktualizuj rezerwację
      // Dodajemy oznaczenie 'manual' jeśli użytkownik zmienia produkt
      const updateData = {
        ...result.data,
        // Jeśli zmieniamy produkt, to jest to samodzielny wybór pracownika
        ...(result.data.productId ? { assignmentType: 'manual' } : {})
      };
      
      const updatedReservation = await storage.updateMealReservation(id, updateData);
      
      res.json({
        success: true,
        reservation: updatedReservation
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false, 
        message: "Wystąpił błąd podczas aktualizacji rezerwacji posiłku" 
      });
    }
  });
  
  // Endpoint do usuwania rezerwacji posiłku
  app.delete("/api/meal-reservations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowy identyfikator rezerwacji" 
        });
      }
      
      // Sprawdź, czy rezerwacja istnieje
      const existingReservation = await storage.getMealReservation(id);
      if (!existingReservation) {
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono rezerwacji o podanym identyfikatorze" 
        });
      }
      
      // Sprawdź, czy rezerwacja może być usunięta (tylko aktywne rezerwacje)
      if (existingReservation.status !== 'active') {
        return res.status(400).json({ 
          success: false, 
          message: "Tylko aktywne rezerwacje mogą być usunięte" 
        });
      }
      
      // Usuń rezerwację
      const success = await storage.deleteMealReservation(id);
      
      res.json({
        success
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false, 
        message: "Wystąpił błąd podczas usuwania rezerwacji posiłku" 
      });
    }
  });
  
  /**
   * Endpoint do automatycznego generowania rezerwacji posiłków
   * dla pracowników, którzy pracują w dany dzień, ale nie złożyli zamówienia.
   */
  app.post("/api/meal-reservations/auto-generate", async (req: Request, res: Response) => {
    try {
      const { date } = req.body;
      
      if (!date) {
        return res.status(400).json({
          success: false,
          message: "Brak daty dla której mają zostać wygenerowane rezerwacje"
        });
      }
      
      // Walidacja formatu daty (YYYY-MM-DD)
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
      if (!dateRegex.test(date)) {
        return res.status(400).json({
          success: false,
          message: "Nieprawidłowy format daty. Wymagany format: YYYY-MM-DD"
        });
      }
      
      // Wywołanie funkcji generującej automatycznie rezerwacje
      const result = await storage.autoGenerateMealReservations(date);
      
      return res.json({
        success: result.success,
        message: result.success 
          ? `Automatycznie wygenerowano ${result.generatedCount} rezerwacji na dzień ${date}` 
          : "Wystąpił błąd podczas generowania rezerwacji",
        generatedCount: result.generatedCount,
        errors: result.errors,
        reservations: result.reservations
      });
    } catch (error) {
      console.error("Błąd podczas automatycznego generowania rezerwacji:", error);
      return res.status(500).json({
        success: false,
        message: "Wystąpił błąd podczas automatycznego generowania rezerwacji",
        error: error instanceof Error ? error.message : "Nieznany błąd"
      });
    }
  });
  
  // Endpoint do realizacji rezerwacji posiłku (przypisanie szuflady)
  app.post("/api/meal-reservations/:id/fulfill", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowy identyfikator rezerwacji" 
        });
      }
      
      // Schemat walidacji danych
      const schema = z.object({
        chamberId: z.number().int().positive()
      });
      
      // Walidacja danych wejściowych
      const result = schema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane", 
          errors: result.error.errors 
        });
      }
      
      const { chamberId } = result.data;
      
      // Sprawdź, czy rezerwacja istnieje
      const existingReservation = await storage.getMealReservation(id);
      if (!existingReservation) {
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono rezerwacji o podanym identyfikatorze" 
        });
      }
      
      // Sprawdź, czy rezerwacja może być zrealizowana (tylko aktywne rezerwacje)
      if (existingReservation.status !== 'active') {
        return res.status(400).json({ 
          success: false, 
          message: "Tylko aktywne rezerwacje mogą być zrealizowane" 
        });
      }
      
      // Sprawdź, czy szuflada istnieje
      const chamber = await storage.getChamber(chamberId);
      if (!chamber) {
        return res.status(404).json({ 
          success: false, 
          message: "Nie znaleziono szuflady o podanym identyfikatorze" 
        });
      }
      
      // Sprawdź, czy szuflada jest dostępna
      if (!chamber.isAvailable) {
        return res.status(400).json({ 
          success: false, 
          message: "Szuflada nie jest dostępna" 
        });
      }
      
      // Zrealizuj rezerwację
      const fulfilledReservation = await storage.fulfillMealReservation(id, chamberId);
      
      res.json({
        success: true,
        reservation: fulfilledReservation
      });
    } catch (error) {
      console.error(`[API Error] ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      res.status(500).json({ 
        success: false, 
        message: "Wystąpił błąd podczas realizacji rezerwacji posiłku" 
      });
    }
  });

  // === Endpointy dla ocen posiłków ===
  
  // Pobieranie wszystkich ocen posiłków
  app.get("/api/meal-ratings", async (req: Request, res: Response) => {
    try {
      const employeeId = req.query.employeeId ? Number(req.query.employeeId) : undefined;
      const ratings = await storage.getMealRatings(employeeId);
      res.json(ratings);
    } catch (error) {
      console.error("Błąd podczas pobierania ocen posiłków:", error);
      res.status(500).json({ success: false, message: "Wystąpił błąd podczas pobierania ocen posiłków" });
    }
  });
  
  // Pobieranie ocen pogrupowanych według produktów
  app.get("/api/product-ratings", async (_req: Request, res: Response) => {
    try {
      const ratings = await storage.getProductRatings();
      res.json(ratings);
    } catch (error) {
      console.error("Błąd podczas pobierania ocen produktów:", error);
      res.status(500).json({ success: false, message: "Wystąpił błąd podczas pobierania ocen produktów" });
    }
  });
  
  // Pobieranie szczegółowych ocen dla konkretnego produktu
  app.get("/api/product-ratings/:productId/details", async (req: Request, res: Response) => {
    try {
      const productId = parseInt(req.params.productId);
      
      if (isNaN(productId)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID produktu" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 20;
      
      // Pobieramy szczegółowe oceny dla produktu
      const ratings = await storage.getDetailedProductRatings(productId, limit);
      
      // Wzbogacamy dane o informacje o pracowniku (imię i nazwisko)
      const employeeIds = ratings.map(rating => rating.employeeId);
      const uniqueEmployeeIds = [...new Set(employeeIds)];
      
      // Pobieramy dane pracowników
      const employees = await Promise.all(
        uniqueEmployeeIds.map(id => storage.getEmployee(id))
      );
      
      // Tworzymy mapę ID pracownika na jego dane
      const employeeMap = new Map();
      employees.forEach(employee => {
        if (employee) {
          employeeMap.set(employee.id, employee);
        }
      });
      
      // Wzbogacamy oceny o dane pracowników
      const ratingsWithEmployees = ratings.map(rating => {
        const employee = employeeMap.get(rating.employeeId);
        return {
          ...rating,
          employee: employee ? {
            firstName: employee.firstName,
            lastName: employee.lastName
          } : null
        };
      });
      
      res.json({
        success: true,
        productId,
        ratings: ratingsWithEmployees
      });
    } catch (error) {
      console.error("Błąd podczas pobierania szczegółowych ocen produktu:", error);
      res.status(500).json({ success: false, message: "Wystąpił błąd podczas pobierania szczegółowych ocen produktu" });
    }
  });
  
  // Administracyjny endpoint do czyszczenia magazynu - usuwa wszystkie elementy magazynowe
  // UWAGA: Ten endpoint jest przeznaczony tylko do użytku administracyjnego!
  app.post("/api/admin/inventory/clear", async (_req: Request, res: Response) => {
    try {
      console.log("[ADMIN API] Żądanie czyszczenia całego magazynu");
      const result = await storage.clearInventory();
      console.log(`[ADMIN API] Usunięto ${result.deletedItems} elementów magazynowych`);
      res.json({ success: true, ...result });
    } catch (error) {
      console.error("[ADMIN API] Błąd podczas czyszczenia magazynu:", error);
      res.status(500).json({ 
        success: false, 
        message: "Wystąpił błąd podczas czyszczenia magazynu",
        error: error instanceof Error ? error.message : "Nieznany błąd" 
      });
    }
  });
  

  
  // Pobieranie oceny dla konkretnej rezerwacji
  app.get("/api/meal-ratings/reservation/:reservationId", async (req: Request, res: Response) => {
    try {
      const reservationId = parseInt(req.params.reservationId);
      if (isNaN(reservationId)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID rezerwacji" });
      }
      
      const rating = await storage.getMealRatingByReservation(reservationId);
      if (!rating) {
        return res.status(404).json({ success: false, message: "Nie znaleziono oceny dla tej rezerwacji" });
      }
      
      res.json(rating);
    } catch (error) {
      console.error("Błąd podczas pobierania oceny posiłku:", error);
      res.status(500).json({ success: false, message: "Wystąpił błąd podczas pobierania oceny posiłku" });
    }
  });
  
  // Dodawanie oceny posiłku
  app.post("/api/meal-ratings", async (req: Request, res: Response) => {
    try {
      // Schemat walidacji danych oceny
      const schema = z.object({
        reservationId: z.number(),
        employeeId: z.number(),
        productId: z.number(),
        rating: z.number().min(1).max(5),
        comment: z.string().optional()
      });
      
      const parsedBody = schema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane oceny",
          errors: parsedBody.error.issues
        });
      }
      
      // Sprawdź, czy rezerwacja istnieje
      const reservation = await storage.getMealReservation(parsedBody.data.reservationId);
      if (!reservation) {
        return res.status(404).json({ success: false, message: "Nie znaleziono rezerwacji" });
      }
      
      // Sprawdź, czy rezerwacja została zrealizowana lub czy jej data już minęła
      const reservationDate = new Date(reservation.reservedForDate);
      const today = new Date();
      
      if (reservation.status !== "fulfilled" && !(reservation.status === "active" && reservationDate < today)) {
        return res.status(400).json({ success: false, message: "Nie można ocenić posiłku, który nie został zrealizowany" });
      }
      
      // Sprawdź, czy istnieje już ocena dla tej rezerwacji
      const existingRating = await storage.getMealRatingByReservation(parsedBody.data.reservationId);
      if (existingRating) {
        return res.status(409).json({ success: false, message: "Ocena dla tej rezerwacji już istnieje" });
      }
      
      // Dodaj ocenę
      const newRating = await storage.createMealRating(parsedBody.data);
      res.status(201).json({ success: true, rating: newRating });
    } catch (error) {
      console.error("Błąd podczas dodawania oceny posiłku:", error);
      res.status(500).json({ success: false, message: "Wystąpił błąd podczas dodawania oceny posiłku" });
    }
  });
  
  // Aktualizacja oceny posiłku
  app.put("/api/meal-ratings/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID oceny" });
      }
      
      // Schemat walidacji danych aktualizacji oceny
      const schema = z.object({
        rating: z.number().min(1).max(5).optional(),
        comment: z.string().optional()
      });
      
      const parsedBody = schema.safeParse(req.body);
      if (!parsedBody.success) {
        return res.status(400).json({ 
          success: false, 
          message: "Nieprawidłowe dane aktualizacji",
          errors: parsedBody.error.issues
        });
      }
      
      // Aktualizacja oceny
      const updatedRating = await storage.updateMealRating(id, parsedBody.data);
      if (!updatedRating) {
        return res.status(404).json({ success: false, message: "Nie znaleziono oceny o podanym ID" });
      }
      
      res.json({ success: true, rating: updatedRating });
    } catch (error) {
      console.error("Błąd podczas aktualizacji oceny posiłku:", error);
      res.status(500).json({ success: false, message: "Wystąpił błąd podczas aktualizacji oceny posiłku" });
    }
  });
  
  // Usuwanie oceny posiłku
  app.delete("/api/meal-ratings/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ success: false, message: "Nieprawidłowe ID oceny" });
      }
      
      const result = await storage.deleteMealRating(id);
      if (!result) {
        return res.status(404).json({ success: false, message: "Nie znaleziono oceny o podanym ID" });
      }
      
      res.json({ success: true, message: "Ocena została usunięta" });
    } catch (error) {
      console.error("Błąd podczas usuwania oceny posiłku:", error);
      res.status(500).json({ success: false, message: "Wystąpił błąd podczas usuwania oceny posiłku" });
    }
  });

  // === API RAPORTÓW SPRZEDAŻY ===

  // Pobranie danych sprzedaży według miesięcy
  app.get("/api/sales/monthly", async (req, res) => {
    try {
      const year = req.query.year ? parseInt(req.query.year as string) : undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 6;
      
      const data = await storage.getMonthlySalesData(year, limit);
      res.json(data);
    } catch (error) {
      console.error("Błąd podczas pobierania danych miesięcznych sprzedaży:", error);
      res.status(500).json({ error: "Błąd podczas pobierania danych" });
    }
  });

  // Pobranie danych sprzedaży według godzin
  app.get("/api/sales/hourly", async (req, res) => {
    try {
      const date = req.query.date as string;
      const data = await storage.getHourlySalesData(date);
      res.json(data);
    } catch (error) {
      console.error("Błąd podczas pobierania danych godzinowych sprzedaży:", error);
      res.status(500).json({ error: "Błąd podczas pobierania danych" });
    }
  });

  // Pobranie danych sprzedaży według kategorii
  app.get("/api/sales/categories", async (req, res) => {
    try {
      const period = (req.query.period as "week" | "month" | "year") || "month";
      const data = await storage.getCategorySalesData(period);
      res.json(data);
    } catch (error) {
      console.error("Błąd podczas pobierania danych kategorii sprzedaży:", error);
      res.status(500).json({ error: "Błąd podczas pobierania danych" });
    }
  });

  // Pobranie danych dziennej sprzedaży
  app.get("/api/sales/daily", async (req, res) => {
    try {
      const period = (req.query.period as "week" | "month") || "week";
      const data = await storage.getDailySalesData(period);
      res.json(data);
    } catch (error) {
      console.error("Błąd podczas pobierania danych dziennej sprzedaży:", error);
      res.status(500).json({ error: "Błąd podczas pobierania danych" });
    }
  });

  // Pobranie statystyk sprzedaży
  app.get("/api/sales/statistics", async (req, res) => {
    try {
      const data = await storage.getSalesStatistics();
      res.json(data);
    } catch (error) {
      console.error("Błąd podczas pobierania statystyk sprzedaży:", error);
      res.status(500).json({ error: "Błąd podczas pobierania danych" });
    }
  });

  return httpServer;
}