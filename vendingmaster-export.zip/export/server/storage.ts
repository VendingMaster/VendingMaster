import { 
  users, type User, type InsertUser,
  products, type Product, type InsertProduct,
  chambers, type Chamber, type InsertChamber,
  employees, type Employee, type InsertEmployee,
  settings, type Settings, type InsertSettings,
  categories, type Category, type InsertCategory,
  temperatureReadings, type InsertTemperatureReading, type TemperatureReadingDB,
  inventory, type Inventory, type InsertInventory,
  deliveries, type Delivery, type InsertDelivery,
  usages, type Usage, type InsertUsage,
  mealReservations, type MealReservation, type InsertMealReservation,
  mealRatings, type MealRating, type InsertMealRating,
  employeeWorkDays, type EmployeeWorkDay, type InsertEmployeeWorkDay,
  employeeNonWorkDays, type EmployeeNonWorkDay, type InsertEmployeeNonWorkDay,
  PRODUCT_CATEGORIES,
  type TemperatureReading,
  type Password,
  type ChangePassword,
  type InventoryStatus,
  type UsageReason,
  deliveryItems, type DeliveryItem
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, gte, lte, lt, gt, sql, isNull, isNotNull, asc, inArray, not } from "drizzle-orm";
import { generateSalt, hashPassword, verifyPassword, generateRandomPassword } from './password-utils';

// Używamy aliasu dla uniknięcia konfliktu nazw
const settingsTable = settings;

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Product operations
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: InsertProduct): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, category: InsertCategory): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<boolean>;
  
  // Employee operations
  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  getEmployeeByRfid(rfidCardNumber: string): Promise<Employee | undefined>;
  getEmployeeByEmail(email: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: InsertEmployee): Promise<Employee | undefined>;
  deleteEmployee(id: number): Promise<boolean>;
  
  // Password operations
  setEmployeePassword(employeeId: number, password: string): Promise<boolean>;
  resetEmployeePassword(employeeId: number): Promise<string>; // zwraca wygenerowane hasło
  verifyEmployeePassword(employeeId: number, password: string): Promise<boolean>;
  changeEmployeePassword(employeeId: number, currentPassword: string, newPassword: string): Promise<boolean>;
  
  // Chamber operations
  getChambers(): Promise<Chamber[]>;
  getChamber(id: number): Promise<Chamber | undefined>;
  createChamber(chamber: InsertChamber): Promise<Chamber>;
  updateChamber(id: number, chamber: Partial<InsertChamber>): Promise<Chamber | undefined>;
  resetChamber(id: number): Promise<Chamber | undefined>;
  getAvailableChambers(): Promise<Chamber[]>;
  getChambersByEmployeeId(employeeId: number): Promise<Chamber[]>;
  
  // Settings operations
  getSettings(): Promise<Settings>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings>;
  
  // Temperature sensor operations
  addTemperatureReading(reading: TemperatureReading): Promise<TemperatureReading>;
  getTemperatureReadings(limit?: number): Promise<TemperatureReading[]>;
  getTemperatureReadingsInRange(startTime: Date, endTime: Date): Promise<TemperatureReading[]>;
  
  // Inventory operations
  getInventoryItems(): Promise<Inventory[]>;
  getInventoryItemById(id: number): Promise<Inventory | undefined>;
  getInventoryItemsByProduct(productId: number): Promise<Inventory[]>;
  addToInventory(item: InsertInventory): Promise<Inventory>;
  updateInventoryItem(id: number, item: Partial<InsertInventory>): Promise<Inventory | undefined>;
  removeFromInventory(id: number): Promise<boolean>;
  getExpiringInventoryItems(days?: number): Promise<Inventory[]>;
  getExpiredInventoryItems(): Promise<Inventory[]>;
  getDisposedItems(): Promise<Inventory[]>;
  disposeInventoryItem(id: number, quantity?: number): Promise<Inventory | undefined>;
  getInDateItems(): Promise<Inventory[]>;
  getUsedItems(): Promise<Inventory[]>;
  useInventoryItem(id: number, quantity: number, reason: string): Promise<Inventory | undefined>;
  clearInventory(): Promise<{ deletedItems: number }>;
  
  // Delivery operations
  getDeliveries(): Promise<Delivery[]>;
  getDelivery(id: number): Promise<Delivery | undefined>;
  createDelivery(delivery: InsertDelivery): Promise<Delivery>;
  updateDelivery(id: number, delivery: Partial<InsertDelivery>): Promise<Delivery | undefined>;
  getInventoryItemsByDelivery(deliveryId: number): Promise<Inventory[]>;
  getGroupedInventoryItems(): Promise<any[]>;
  getUsageList(): Promise<any[]>;
  
  // Meal Reservation operations
  getMealReservations(employeeId?: number, fromDate?: string, toDate?: string): Promise<MealReservation[]>;
  getMealReservation(id: number): Promise<MealReservation | undefined>;
  autoGenerateMealReservations(date: string): Promise<{ 
    success: boolean; 
    generatedCount: number; 
    errors: any[];
    reservations: MealReservation[];
  }>;
  getMealReservationByEmployeeAndDate(employeeId: number, date: string): Promise<MealReservation | undefined>;
  getMealReservationsByDate(date: string): Promise<MealReservation[]>;
  createMealReservation(reservation: InsertMealReservation): Promise<MealReservation>;
  updateMealReservation(id: number, reservation: Partial<InsertMealReservation>): Promise<MealReservation | undefined>;
  deleteMealReservation(id: number): Promise<boolean>;
  fulfillMealReservation(id: number, chamberId: number): Promise<MealReservation | undefined>;
  
  // Meal Rating operations
  getMealRatings(employeeId?: number): Promise<MealRating[]>;
  getMealRatingByReservation(reservationId: number): Promise<MealRating | undefined>;
  getProductRatings(): Promise<{ productId: number, averageRating: number, count: number }[]>;
  getDetailedProductRatings(productId: number, limit?: number): Promise<MealRating[]>;
  createMealRating(rating: InsertMealRating): Promise<MealRating>;
  updateMealRating(id: number, rating: Partial<InsertMealRating>): Promise<MealRating | undefined>;
  deleteMealRating(id: number): Promise<boolean>;
  
  // Employee Work Day operations
  getEmployeeWorkDays(employeeId: number, fromDate?: string, toDate?: string): Promise<EmployeeWorkDay[]>;
  addEmployeeWorkDay(workDay: InsertEmployeeWorkDay): Promise<{ workDay: EmployeeWorkDay; isNew: boolean }>;
  deleteEmployeeWorkDay(employeeId: number, workDateString: string): Promise<boolean>;
  isEmployeeWorkingOnDate(employeeId: number, dateString: string): Promise<boolean>;
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db
      .insert(products)
      .values(product)
      .returning();
    return newProduct;
  }

  async updateProduct(id: number, product: InsertProduct): Promise<Product | undefined> {
    const [updatedProduct] = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct || undefined;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db
      .delete(products)
      .where(eq(products.id, id));
    return !!result;
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(categories.displayOrder, categories.name);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category || undefined;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db
      .insert(categories)
      .values(category)
      .returning();
    return newCategory;
  }

  async updateCategory(id: number, category: InsertCategory): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set(category)
      .where(eq(categories.id, id))
      .returning();
    return updatedCategory || undefined;
  }

  async deleteCategory(id: number): Promise<boolean> {
    const result = await db
      .delete(categories)
      .where(eq(categories.id, id));
    return !!result;
  }

  async getEmployees(): Promise<Employee[]> {
    return await db.select().from(employees);
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.id, id));
    return employee || undefined;
  }

  async getEmployeeByRfid(rfidCardNumber: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(employees).where(eq(employees.rfidCardNumber, rfidCardNumber));
    return employee || undefined;
  }
  
  async getEmployeeByEmail(email: string): Promise<Employee | undefined> {
    // Najpierw szukamy pracownika z ustawionym hasłem
    const [employeeWithPassword] = await db
      .select()
      .from(employees)
      .where(and(
        eq(employees.email, email),
        isNotNull(employees.passwordHash)
      ));
    
    if (employeeWithPassword) {
      return employeeWithPassword;
    }
    
    // Jeśli nie znaleziono pracownika z hasłem, szukamy bez uwzględniania hasła
    const [employee] = await db
      .select()
      .from(employees)
      .where(eq(employees.email, email));
      
    return employee || undefined;
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    // Sprawdzamy czy przekazano hasło
    const { password, ...employeeData } = employee;
    
    let insertData: any = { ...employeeData };
    
    // Jeśli przekazano hasło, generujemy sól i hash
    if (password) {
      const salt = generateSalt();
      const hash = hashPassword(password, salt);
      
      insertData.passwordHash = hash;
      insertData.passwordSalt = salt;
      insertData.lastPasswordChange = new Date();
      insertData.passwordResetRequired = false;
    }
    
    const [newEmployee] = await db
      .insert(employees)
      .values(insertData)
      .returning();
    return newEmployee;
  }

  async updateEmployee(id: number, employee: InsertEmployee): Promise<Employee | undefined> {
    // Sprawdzamy czy przekazano hasło
    const { password, ...employeeData } = employee;
    
    let updateData: any = { ...employeeData };
    
    // Jeśli przekazano hasło, generujemy sól i hash
    if (password) {
      const salt = generateSalt();
      const hash = hashPassword(password, salt);
      
      updateData.passwordHash = hash;
      updateData.passwordSalt = salt;
      updateData.lastPasswordChange = new Date();
      updateData.passwordResetRequired = false;
    }
    
    const [updatedEmployee] = await db
      .update(employees)
      .set(updateData)
      .where(eq(employees.id, id))
      .returning();
    return updatedEmployee || undefined;
  }
  
  // Implementacja funkcji zarządzania hasłami
  
  async setEmployeePassword(employeeId: number, password: string): Promise<boolean> {
    try {
      // Sprawdzamy czy pracownik istnieje
      const employee = await this.getEmployee(employeeId);
      if (!employee) {
        return false;
      }
      
      // Generujemy nową sól i hash
      const salt = generateSalt();
      const hash = hashPassword(password, salt);
      
      // Aktualizujemy dane pracownika
      await db
        .update(employees)
        .set({
          passwordHash: hash,
          passwordSalt: salt,
          lastPasswordChange: new Date(),
          passwordResetRequired: false
        })
        .where(eq(employees.id, employeeId));
      
      return true;
    } catch (error) {
      console.error(`Błąd podczas ustawiania hasła: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return false;
    }
  }
  
  async resetEmployeePassword(employeeId: number): Promise<string> {
    try {
      // Sprawdzamy czy pracownik istnieje
      const employee = await this.getEmployee(employeeId);
      if (!employee) {
        throw new Error(`Pracownik o ID ${employeeId} nie istnieje`);
      }
      
      // Generujemy nowe losowe hasło
      const newPassword = generateRandomPassword(8);
      
      // Generujemy nową sól i hash
      const salt = generateSalt();
      const hash = hashPassword(newPassword, salt);
      
      // Aktualizujemy dane pracownika
      await db
        .update(employees)
        .set({
          passwordHash: hash,
          passwordSalt: salt,
          lastPasswordChange: new Date(),
          passwordResetRequired: true // Wymagamy zmiany hasła przy kolejnym logowaniu
        })
        .where(eq(employees.id, employeeId));
      
      return newPassword;
    } catch (error) {
      console.error(`Błąd podczas resetowania hasła: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      throw error;
    }
  }
  
  async verifyEmployeePassword(employeeId: number, password: string): Promise<boolean> {
    try {
      // Pobieramy dane pracownika
      const employee = await this.getEmployee(employeeId);
      if (!employee || !employee.passwordHash || !employee.passwordSalt) {
        return false;
      }
      
      // Weryfikujemy hasło
      return verifyPassword(password, employee.passwordSalt, employee.passwordHash);
    } catch (error) {
      console.error(`Błąd podczas weryfikacji hasła: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return false;
    }
  }
  
  async changeEmployeePassword(employeeId: number, currentPassword: string, newPassword: string): Promise<boolean> {
    try {
      // Weryfikujemy obecne hasło
      const isCurrentPasswordValid = await this.verifyEmployeePassword(employeeId, currentPassword);
      if (!isCurrentPasswordValid) {
        return false;
      }
      
      // Ustawiamy nowe hasło
      return await this.setEmployeePassword(employeeId, newPassword);
    } catch (error) {
      console.error(`Błąd podczas zmiany hasła: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return false;
    }
  }

  async deleteEmployee(id: number): Promise<boolean> {
    const result = await db
      .delete(employees)
      .where(eq(employees.id, id));
    return !!result;
  }

  async getChambers(): Promise<Chamber[]> {
    // Sortowanie szuflad według ID, aby zawsze zachować tę samą kolejność
    return await db.select().from(chambers).orderBy(chambers.id);
  }

  async getChamber(id: number): Promise<Chamber | undefined> {
    const [chamber] = await db.select().from(chambers).where(eq(chambers.id, id));
    return chamber || undefined;
  }

  async createChamber(chamber: InsertChamber): Promise<Chamber> {
    const [newChamber] = await db
      .insert(chambers)
      .values(chamber)
      .returning();
    return newChamber;
  }

  async updateChamber(id: number, chamberData: Partial<InsertChamber>): Promise<Chamber | undefined> {
    try {
      // Sprawdź, czy aktualizacja dotyczy przypisania pracownika
      if (chamberData.employeeId !== undefined && chamberData.employeeId !== null) {
        console.log(`[Storage] Przypisywanie pracownika ID ${chamberData.employeeId} do szuflady ${id}`);
        
        // Pobierz aktualne przypisania tego pracownika
        const employeeAssignments = await db
          .select()
          .from(chambers)
          .where(eq(chambers.employeeId, chamberData.employeeId));
          
        console.log(`[Storage] Znaleziono ${employeeAssignments.length} istniejących przypisań dla pracownika ID ${chamberData.employeeId}`);
        
        // Jeśli znaleziono przypisania, usuń je (poza aktualnie modyfikowaną szufladą)
        if (employeeAssignments.length > 0) {
          for (const chamber of employeeAssignments) {
            if (chamber.id !== id) {
              console.log(`[Storage] Usuwanie przypisania pracownika ID ${chamberData.employeeId} z szuflady ${chamber.id}`);
              
              await db
                .update(chambers)
                .set({ 
                  employeeId: null,
                  isAvailable: true 
                })
                .where(eq(chambers.id, chamber.id));
            }
          }
        }
      }
      
      // Wykonaj właściwą aktualizację
      const [updatedChamber] = await db
        .update(chambers)
        .set(chamberData)
        .where(eq(chambers.id, id))
        .returning();
        
      return updatedChamber || undefined;
    } catch (error) {
      console.error(`[Storage Error] Błąd podczas aktualizacji szuflady ${id}:`, error);
      throw error;
    }
  }

  async resetChamber(id: number): Promise<Chamber | undefined> {
    // Pobieramy informacje o szufladzie przed resetem
    const [chamber] = await db
      .select()
      .from(chambers)
      .where(eq(chambers.id, id));
    
    if (!chamber) {
      console.log(`Nie znaleziono szuflady o ID ${id}`);
      return undefined;
    }
    
    // Sprawdzamy, czy szuflada miała przypisany produkt
    if (chamber.productId) {
      // Pobieramy ustawienia aby sprawdzić tryb przypisywania szuflad
      const settings = await this.getSettings();
      
      // UWAGA: Usuwamy odliczanie stanu magazynowego w tej funkcji, bo zostało już wykonane
      // przez funkcję useProductFromChamber przy otwarciu szuflady
      if (settings.inventoryBasedAssignment) {
        console.log(`Szuflada ${id} została zresetowana - stan magazynowy został już zmniejszony przy otwarciu szuflady`);
        
        try {
          // Pobieramy informacje o produkcie tylko w celach informacyjnych (dla logów)
          const [product] = await db
            .select()
            .from(products)
            .where(eq(products.id, chamber.productId));
          
          if (product) {
            console.log(`Szuflada ${id} zawierała produkt "${product.name}" (ID: ${chamber.productId})`);
          } else {
            console.log(`Nie znaleziono informacji o produkcie ID ${chamber.productId} z szuflady ${id}`);
          }
          
          // Nie wykonujemy już żadnych operacji na stanie magazynowym
          console.log(`Pominięto zmniejszanie stanu magazynowego dla produktu ${chamber.productId} - zostało już wykonane przy otwarciu szuflady`);
        } catch (error) {
          console.error(`Błąd podczas pobierania informacji o produkcie: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
        }
      } else {
        console.log(`Szuflada ${id} została zresetowana - tryb bez integracji z magazynem`);
      }
    } else {
      console.log(`Szuflada ${id} nie miała przypisanego produktu`);
    }
    
    // Wykonujemy reset szuflady
    const [resetChamber] = await db
      .update(chambers)
      .set({ productId: null, employeeId: null, isAvailable: false })
      .where(eq(chambers.id, id))
      .returning();
    
    return resetChamber || undefined;
  }
  
  /**
   * Zmniejsza stan magazynowy produktu przypisanego do szuflady - używane TYLKO przy faktycznym pobraniu produktu
   * @param chamberId ID szuflady
   * @returns true jeśli operacja się powiodła, false w przeciwnym razie
   */
  async useProductFromChamber(chamberId: number): Promise<boolean> {
    try {
      // Pobieramy informacje o szufladzie
      const [chamber] = await db
        .select()
        .from(chambers)
        .where(eq(chambers.id, chamberId));
      
      if (!chamber) {
        console.log(`Nie znaleziono szuflady o ID ${chamberId}`);
        return false;
      }
      
      // Sprawdzamy, czy szuflada ma przypisany produkt
      if (!chamber.productId) {
        console.log(`Szuflada ${chamberId} nie ma przypisanego produktu`);
        return false;
      }
      
      // Pobieramy ustawienia aby sprawdzić tryb przypisywania szuflad
      const settings = await this.getSettings();
      
      // Jeśli tryb nie bazuje na magazynie, kończymy
      if (!settings.inventoryBasedAssignment) {
        console.log(`Otwarcie szuflady ${chamberId} bez integracji z magazynem`);
        return true;
      }
      
      console.log(`Integracja z magazynem: zmniejszanie stanu magazynowego dla produktu ${chamber.productId} z szuflady ${chamberId}`);
      
      // Pobieramy dostępne pozycje magazynowe dla tego produktu, sortujemy je według daty ważności
      const inventoryItems = await db
        .select()
        .from(inventory)
        .where(eq(inventory.productId, chamber.productId))
        .orderBy(asc(inventory.expiryDate));
      
      // Filtrujemy tylko dostępne pozycje (nie zutylizowane, z dostępną ilością)
      const availableItems = inventoryItems.filter(item => {
        // Sprawdzamy, czy pozycja nie została zutylizowana
        if (item.disposed) return false;
        
        // Obliczamy dostępną ilość uwzględniając zarówno zużyte jak i zutylizowane jednostki
        const usedQty = Math.max(0, item.usedQuantity || 0);
        const disposedQty = Math.max(0, item.disposedQuantity || 0);
        const totalUnavailable = usedQty + disposedQty;
        const available = item.quantity - totalUnavailable;
        
        // Sprawdzamy, czy jest dostępna jakakolwiek ilość
        return available > 0;
      });
      
      if (availableItems.length === 0) {
        console.log(`Brak dostępnych pozycji magazynowych dla produktu ${chamber.productId}`);
        return false;
      }
      
      // Używamy pierwszej dostępnej pozycji (najstarsza data ważności - FIFO)
      const oldestItem = availableItems[0];
      
      // Pobieramy aktualny stan z bazy danych, aby zawsze mieć aktualne informacje
      const [currentItem] = await db
        .select()
        .from(inventory)
        .where(eq(inventory.id, oldestItem.id));
      
      if (!currentItem) {
        console.log(`Nie znaleziono pozycji magazynowej ID ${oldestItem.id} - została prawdopodobnie usunięta`);
        return false;
      }

      // Obliczamy dostępną ilość uwzględniając zarówno zużyte jak i zutylizowane jednostki
      const currentUsedQty = Math.max(0, currentItem.usedQuantity || 0);
      const currentDisposedQty = Math.max(0, currentItem.disposedQuantity || 0);
      const totalUnavailable = currentUsedQty + currentDisposedQty;
      const availableQuantity = currentItem.quantity - totalUnavailable;
      
      if (availableQuantity <= 0) {
        console.log(`Brak dostępnej ilości produktu ${chamber.productId} w magazynie (pozycja ${currentItem.id})`);
        return false;
      }
      
      // Definiujemy ilość do użycia - zawsze 1 sztuka przy wydawaniu z szuflady
      const quantityToUse = 1;
      
      // Sprawdzamy, czy mamy wystarczającą ilość do wykorzystania
      if (quantityToUse > availableQuantity) {
        console.log(`Niewystarczająca ilość produktu ${chamber.productId} w magazynie (dostępne: ${availableQuantity}, wymagane: ${quantityToUse})`);
        return false;
      }
      
      // Aktualizujemy pozycję magazynową - zwiększamy ilość wykorzystaną
      const newUsedQuantity = currentUsedQty + quantityToUse;
      
      // Ustawiamy isUsed=true tylko jeśli wykorzystano cały produkt
      const isFullyUsed = newUsedQuantity >= currentItem.quantity;
      
      await db
        .update(inventory)
        .set({ 
          usedQuantity: newUsedQuantity,
          usedAt: new Date(),
          usageReason: "Wydanie z automatu",
          isUsed: isFullyUsed  // Tylko jeśli w pełni wykorzystane
        })
        .where(eq(inventory.id, currentItem.id));
      
      console.log(`Zmniejszono stan magazynowy dla produktu ${chamber.productId}, pozycja ${currentItem.id}, ilość przed: ${currentUsedQty}, po: ${newUsedQuantity}, pozostało: ${currentItem.quantity - newUsedQuantity}`);
      
      // Wysyłamy powiadomienie WebSocket o zmianie stanu magazynowego
      const wss = global.wss;
      if (wss) {
        const notification = {
          type: 'inventory_changed',
          message: 'Stan magazynowy został zaktualizowany',
          timestamp: new Date().toISOString()
        };
        
        wss.clients.forEach(client => {
          if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(notification));
          }
        });
        
        console.log('[WebSocket] Wysłano powiadomienie o zmianie stanu magazynowego');
      }
      
      return true;
    } catch (error) {
      console.error(`Błąd podczas zmniejszania stanu magazynowego: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return false;
    }
  }

  async getAvailableChambers(): Promise<Chamber[]> {
    return await db
      .select()
      .from(chambers)
      .where(eq(chambers.isAvailable, true))
      .orderBy(chambers.id);
  }
  
  async getChambersByEmployeeId(employeeId: number): Promise<Chamber[]> {
    return await db
      .select()
      .from(chambers)
      .where(eq(chambers.employeeId, employeeId))
      .orderBy(chambers.id);
  }

  async getSettings(): Promise<Settings> {
    const existingSettings = await db.select().from(settingsTable);
    
    if (!existingSettings || existingSettings.length === 0) {
      // Tworzymy ustawienia domyślne, jeśli nie istnieją
      const defaultSettings = {
        adminPin: "1308",
        machineName: "IQSTORE Gastro",
        minTemperature: 2,
        maxTemperature: 8,
        expiringDaysThreshold: 0,
        expiredDaysThreshold: -1,
        inventoryBasedAssignment: true,
        loadingModeRfidCardNumber: null,
        adminLogo: null,
        maxReservationDays: 7,
        firstReservationDays: 2,
        otherSettings: {}
      };
      
      const [settings] = await db
        .insert(settingsTable)
        .values(defaultSettings)
        .returning();
      
      return settings;
    }
    
    return existingSettings[0];
  }

  async updateSettings(settingsUpdate: Partial<InsertSettings>): Promise<Settings> {
    const existingSettings = await this.getSettings();
    
    const [settings] = await db
      .update(settingsTable)
      .set(settingsUpdate)
      .where(eq(settingsTable.id, existingSettings.id))
      .returning();
    
    return settings;
  }

  async addTemperatureReading(reading: TemperatureReading): Promise<TemperatureReading> {
    const insertReading: InsertTemperatureReading = {
      temperature: reading.temperature,
      humidity: reading.humidity ?? undefined
    };
    
    const [newReading] = await db
      .insert(temperatureReadings)
      .values(insertReading)
      .returning();
    
    return {
      temperature: newReading.temperature,
      humidity: newReading.humidity ?? undefined,
      timestamp: newReading.timestamp.toISOString()
    };
  }

  async getTemperatureReadings(limit: number = 100): Promise<TemperatureReading[]> {
    const readings = await db
      .select()
      .from(temperatureReadings)
      .orderBy(desc(temperatureReadings.timestamp))
      .limit(limit);
    
    return readings.map(reading => ({
      temperature: reading.temperature,
      humidity: reading.humidity ?? undefined,
      timestamp: reading.timestamp.toISOString()
    }));
  }

  async getTemperatureReadingsInRange(startTime: Date, endTime: Date): Promise<TemperatureReading[]> {
    const readings = await db
      .select()
      .from(temperatureReadings)
      .where(
        and(
          gte(temperatureReadings.timestamp, startTime),
          lte(temperatureReadings.timestamp, endTime)
        )
      )
      .orderBy(desc(temperatureReadings.timestamp));
    
    return readings.map(reading => ({
      temperature: reading.temperature,
      humidity: reading.humidity ?? undefined,
      timestamp: reading.timestamp.toISOString()
    }));
  }

  async getInventoryItems(): Promise<Inventory[]> {
    return await db
      .select()
      .from(inventory)
      .orderBy(inventory.expiryDate);
  }

  async getInventoryItemById(id: number): Promise<Inventory | undefined> {
    const [item] = await db
      .select()
      .from(inventory)
      .where(eq(inventory.id, id));
    
    return item || undefined;
  }

  async getInventoryItemsByProduct(productId: number): Promise<Inventory[]> {
    return await db
      .select()
      .from(inventory)
      .where(eq(inventory.productId, productId))
      .orderBy(inventory.expiryDate);
  }

  async addToInventory(item: InsertInventory): Promise<Inventory> {
    const [newItem] = await db
      .insert(inventory)
      .values(item)
      .returning();
    
    return newItem;
  }

  async updateInventoryItem(id: number, item: Partial<InsertInventory>): Promise<Inventory | undefined> {
    const [updatedItem] = await db
      .update(inventory)
      .set(item)
      .where(eq(inventory.id, id))
      .returning();
    
    return updatedItem || undefined;
  }

  async removeFromInventory(id: number): Promise<boolean> {
    const result = await db
      .delete(inventory)
      .where(eq(inventory.id, id));
    
    return !!result;
  }

  async getExpiringInventoryItems(days?: number): Promise<Inventory[]> {
    // Pobierz ustawienia aby określić próg dla produktów kończących się
    const settings = await this.getSettings();
    const expiringThresholdDays = days !== undefined ? days : settings.expiringDaysThreshold ?? 0;
    
    // Oblicz datę graniczną
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    console.log(`[DEBUG] getExpiringInventoryItems: Próg ${expiringThresholdDays} dni`);
    console.log(`[DEBUG] getExpiringInventoryItems: Dzisiaj: ${today.toISOString().split('T')[0]}`);
    
    // Jeśli wartość progu jest nadpisana w API na 0, użyjmy logiki dla progu 0
    if (expiringThresholdDays === 0) {
      console.log(`[DEBUG] getExpiringInventoryItems: Używam logiki dla progu 0`);
      
      // Gdy próg = 0, kończące się to tylko produkty z dzisiejszą datą
      return await db
        .select()
        .from(inventory)
        .where(
          and(
            eq(inventory.disposed, false),
            eq(inventory.isUsed, false),
            // Tylko produkty z dzisiejszą datą ważności
            eq(sql`DATE(${inventory.expiryDate})`, today.toISOString().split('T')[0])
          )
        )
        .orderBy(inventory.expiryDate);
    }
    
    // Dla progu > 0, standardowa logika:
    // Oblicz datę końcową dla przedziału "kończących się produktów"
    const endDate = new Date(today);
    endDate.setDate(endDate.getDate() + expiringThresholdDays);
    
    console.log(`[DEBUG] getExpiringInventoryItems: Używam logiki dla progu > 0`);
    console.log(`[DEBUG] getExpiringInventoryItems: Produkty kończące się to te z datą od ${today.toISOString().split('T')[0]} do ${endDate.toISOString().split('T')[0]}`);
    
    // Jeśli expiringThresholdDays = 1, to produkty z dzisiejszą datą i jutrzejszą datą
    // Jeśli expiringThresholdDays = 2, to produkty z dzisiejszą datą i dwie kolejne daty itd.
    
    return await db
      .select()
      .from(inventory)
      .where(
        and(
          eq(inventory.disposed, false),
          eq(inventory.isUsed, false),
          // Produkty kończące się to te, które mieszczą się w przedziale od dzisiaj włącznie do progu kończących się (włącznie)
          gte(sql`DATE(${inventory.expiryDate})`, today.toISOString().split('T')[0]),
          lte(sql`DATE(${inventory.expiryDate})`, endDate.toISOString().split('T')[0]),
        )
      )
      .orderBy(inventory.expiryDate);
  }
  
  async getExpiredInventoryItems(): Promise<Inventory[]> {
    // Pobierz ustawienia, aby określić próg dla produktów przeterminowanych
    const settings = await this.getSettings();
    
    // Oblicz datę graniczną dla przedawnionych produktów
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return await db
      .select()
      .from(inventory)
      .where(
        and(
          eq(inventory.disposed, false),
          eq(inventory.isUsed, false),
          lt(sql`DATE(${inventory.expiryDate})`, today.toISOString().split('T')[0])
        )
      )
      .orderBy(inventory.expiryDate);
  }
  
  // Funkcja usunięta - zastąpiona przez poprawioną definicję poniżej
  
  // Ta funkcja została już zaimplementowana poprawnie poniżej.
  
  async getInDateItems(): Promise<Inventory[]> {
    try {
      // Pobierz ustawienia aby określić próg dla produktów przeterminowanych i kończących się
      const settings = await this.getSettings();
      const expiringThreshold = settings.expiringDaysThreshold ?? 0; // Domyślnie 0 dni, zgodnie z ustawieniami
      
      // Oblicz datę graniczną dla kończących się produktów
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      console.log(`[DEBUG] getInDateItems: Próg ${expiringThreshold} dni`);
      console.log(`[DEBUG] getInDateItems: Dzisiaj: ${today.toISOString().split('T')[0]}`);
      
      let thresholdDate;
      
      // Specjalny przypadek gdy próg wynosi 0
      // W takim przypadku "w terminie" są produkty z datą po dzisiejszej
      if (expiringThreshold === 0) {
        // Jutrzejsza data
        thresholdDate = new Date(today);
        thresholdDate.setDate(thresholdDate.getDate() + 1); // Jutrzejsza data
        
        console.log(`[DEBUG] getInDateItems: Dla progu 0, produkty w terminie od: ${thresholdDate.toISOString().split('T')[0]}`);
      } 
      // Dla progu = 1, produkty "w terminie" to te, które mają datę ważności > jutrzejszą (czyli od 2 dni)
      else if (expiringThreshold === 1) {
        thresholdDate = new Date(today);
        thresholdDate.setDate(thresholdDate.getDate() + 2); // Data za 2 dni
        
        console.log(`[DEBUG] getInDateItems: Dla progu 1, produkty w terminie od: ${thresholdDate.toISOString().split('T')[0]}`);
      }
      // Standardowy przypadek - próg > 1
      else {
        thresholdDate = new Date(today);
        thresholdDate.setDate(thresholdDate.getDate() + expiringThreshold + 1); // Data po progu
        
        console.log(`[DEBUG] getInDateItems: Data progowa: ${thresholdDate.toISOString().split('T')[0]}`);
      }
      
      // Jednolite zapytanie dla wszystkich przypadków
      const items = await db
        .select()
        .from(inventory)
        .where(
          and(
            eq(inventory.disposed, false),
            eq(inventory.isUsed, false),
            // Produkty z datą ważności od daty progowej (włącznie) w górę
            gte(sql`DATE(${inventory.expiryDate})`, thresholdDate.toISOString().split('T')[0])
          )
        )
        .orderBy(inventory.expiryDate);
        
      // Pobierz informacje o produktach
      for (const item of items) {
        if (item.productId) {
          const product = await this.getProduct(item.productId);
          if (product) {
            item.productName = product.name;
            item.productImage = product.imageUrl;
          }
        }
      }
      
      return items;
    } catch (error) {
      console.error("Błąd w getInDateItems:", error);
      return [];
    }
  }
  
  async getUsedItems(): Promise<Inventory[]> {
    return await db
      .select()
      .from(inventory)
      .where(eq(inventory.isUsed, true))
      .orderBy(desc(inventory.usedAt));
  }

  async getDeliveries(): Promise<Delivery[]> {
    try {
      // Pobierz unikalne numery dostaw i daty
      const uniqueDeliveryNumbers = await db
        .select({
          deliveryNumber: deliveries.deliveryNumber,
          deliveryDate: deliveries.deliveryDate,
        })
        .from(deliveries)
        .groupBy(deliveries.deliveryNumber, deliveries.deliveryDate)
        .orderBy(desc(deliveries.deliveryDate));

      // Pobierz wszystkie dostawy
      const allDeliveries = await db
        .select()
        .from(deliveries)
        .orderBy(desc(deliveries.deliveryDate));
      
      // Znajdź wszystkie ID dostaw (nawet dla produktów, które zostały zużyte lub zutylizowane)
      const allInventoryItems = await db
        .select({
          id: inventory.id,
          productId: inventory.productId,
          quantity: inventory.quantity,
          expiryDate: inventory.expiryDate,
          batchNumber: inventory.batchNumber,
          deliveryId: inventory.deliveryId,
          isUsed: inventory.isUsed,
          disposed: inventory.disposed,
          usedQuantity: inventory.usedQuantity,
          disposedQuantity: inventory.disposedQuantity,
        })
        .from(inventory)
        .where(isNotNull(inventory.deliveryId));
      
      // Pobierz wszystkie produkty
      const productsData = await db
        .select()
        .from(products);
      
      // Stwórz mapę dla szybkiego dostępu do produktów
      const productsMap = new Map();
      productsData.forEach(product => {
        productsMap.set(product.id, product);
      });

      // Stwórz mapę dostaw według numeru dostawy
      const deliveriesByNumber = allDeliveries.reduce((acc, delivery) => {
        if (!acc[delivery.deliveryNumber]) {
          acc[delivery.deliveryNumber] = [];
        }
        acc[delivery.deliveryNumber].push(delivery);
        return acc;
      }, {} as Record<string, typeof allDeliveries>);
      
      // Grupuj elementy magazynowe według ID dostawy
      const inventoryByDeliveryId = allInventoryItems.reduce((acc, item) => {
        if (!item.deliveryId) return acc;
        
        if (!acc[item.deliveryId]) {
          acc[item.deliveryId] = [];
        }
        acc[item.deliveryId].push(item);
        return acc;
      }, {} as Record<number, typeof allInventoryItems>);
      
      // Dla każdego unikalnego numeru dostawy, agregujemy wszystkie powiązane elementy
      const result = uniqueDeliveryNumbers.map(uniqueDelivery => {
        const relatedDeliveries = deliveriesByNumber[uniqueDelivery.deliveryNumber] || [];
        
        // Weź pierwsze ID dostawy z danego numeru dostawy (potrzebne do identyfikacji)
        const firstDelivery = relatedDeliveries[0];
        if (!firstDelivery) {
          return {
            id: 0,
            deliveryNumber: uniqueDelivery.deliveryNumber,
            deliveryDate: uniqueDelivery.deliveryDate,
            notes: '',
            createdAt: new Date(),
            items: []
          };
        }
        
        // Zbieramy wszystkie elementy z każdej dostawy o tym samym numerze
        let allItems: any[] = [];
        relatedDeliveries.forEach(delivery => {
          const deliveryItems = inventoryByDeliveryId[delivery.id] || [];
          
          const mappedItems = deliveryItems.map(item => {
            const product = productsMap.get(item.productId);
            
            return {
              productId: item.productId,
              quantity: item.quantity,
              expiryDate: item.expiryDate,
              batchNumber: item.batchNumber,
              productName: product ? product.name : `Produkt ID: ${item.productId}`,
              status: item.disposed ? 'Zutylizowany' : 
                      item.isUsed ? 'Użyty' : 
                      (item.usedQuantity && item.usedQuantity > 0) ? 'Częściowo użyty' : 
                      (item.disposedQuantity && item.disposedQuantity > 0) ? 'Częściowo zutylizowany' : 
                      'Dostępny'
            };
          });
          
          allItems = [...allItems, ...mappedItems];
        });
        
        // Tworzymy zagregowaną dostawę
        // Sprawdzanie, czy mamy jakiekolwiek elementy dla tej dostawy
        let finalItems = allItems;
        
        // Dla starszych dostaw, które nie mają powiązanych elementów, dodajemy przykładowy element
        if (finalItems.length === 0) {
          // Dodajemy informację, że te dane są generowane
          finalItems = [{
            productId: 1, // Domyślny produkt
            quantity: 1,
            expiryDate: uniqueDelivery.deliveryDate, // Używamy daty dostawy jako daty ważności
            batchNumber: null,
            productName: 'Historyczna dostawa (brak danych szczegółowych)',
            status: 'Archiwalny'
          }];
          console.log(`Dodano zastępcze dane dla historycznej dostawy: ${uniqueDelivery.deliveryNumber}`);
        }
        
        return {
          id: firstDelivery.id,
          deliveryNumber: uniqueDelivery.deliveryNumber,
          deliveryDate: uniqueDelivery.deliveryDate,
          notes: firstDelivery.notes || '',
          createdAt: firstDelivery.createdAt,
          items: finalItems
        };
      });
      
      // Dodanie szczegółowych logów dla debugowania
      const totalItems = result.reduce((sum, delivery) => sum + (delivery.items?.length || 0), 0);
      console.log(`Znaleziono ${result.length} dostaw z łączną ilością ${totalItems} produktów`);
      
      // Wyloguj szczegóły pierwszej dostawy (jeśli istnieje)
      if (result.length > 0) {
        const firstDelivery = result[0];
        console.log(`Szczegóły pierwszej dostawy (${firstDelivery.deliveryNumber}):`);
        console.log(`- Liczba produktów: ${firstDelivery.items?.length || 0}`);
        console.log(`- Szczegóły produktów: ${JSON.stringify(firstDelivery.items?.slice(0, 2))}`);
      }
      
      // Wymuś nową odpowiedź HTTP poprzez dodanie nagłówka
      return result;
    } catch (error) {
      console.error('Błąd podczas pobierania dostaw:', error);
      return [];
    }
  }

  async getDelivery(id: number): Promise<Delivery | undefined> {
    const [delivery] = await db
      .select()
      .from(deliveries)
      .where(eq(deliveries.id, id));
    
    return delivery || undefined;
  }

  async createDelivery(delivery: InsertDelivery): Promise<Delivery> {
    console.log("createDelivery otrzymał dane:", JSON.stringify(delivery, null, 2));
    
    try {
      // Tworzenie transakcji, aby zapewnić spójność danych
      return await db.transaction(async (tx) => {
        // 1. Najpierw zapisz główny rekord dostawy
        const deliveryData = {
          deliveryNumber: delivery.deliveryNumber,
          deliveryDate: delivery.deliveryDate,
          notes: delivery.notes
        };
        
        console.log("Tworzenie głównego rekordu dostawy:", JSON.stringify(deliveryData, null, 2));
        
        const [newDelivery] = await tx
          .insert(deliveries)
          .values(deliveryData)
          .returning();
        
        console.log("Utworzony główny rekord dostawy:", JSON.stringify(newDelivery, null, 2));
        
        // 2. Następnie zapisz wszystkie elementy dostawy
        if (delivery.items && delivery.items.length > 0) {
          const deliveryItems = delivery.items.map(item => ({
            deliveryId: newDelivery.id,
            productId: item.productId,
            quantity: item.quantity,
            expiryDate: item.expiryDate,
            batchNumber: item.batchNumber
          }));
          
          console.log("Zapisywanie elementów dostawy:", JSON.stringify(deliveryItems, null, 2));
          
          // W schemacie nie ma tabeli delivery_items, więc pomijamy ten krok
          // Wydrukujmy listę delivery_items, które byłyby dodane, gdyby tabela istniała
          for (const item of deliveryItems) {
            console.log("Would insert delivery item (skipped as table doesn't exist):", JSON.stringify(item, null, 2));
          }
          
          // 3. Dla każdego elementu dostawy, dodaj wpis do inwentarza
          for (const item of delivery.items) {
            const inventoryItem = {
              productId: item.productId,
              quantity: item.quantity,
              expiryDate: item.expiryDate,
              batchNumber: item.batchNumber,
              deliveryId: newDelivery.id
            };
            
            console.log("Dodawanie elementu do inwentarza:", JSON.stringify(inventoryItem, null, 2));
            await tx.insert(inventory).values(inventoryItem);
          }
        }
        
        // Zwróć utworzoną dostawę z elementami
        const result = {
          ...newDelivery,
          items: delivery.items || []
        };
        
        console.log("Zwracanie wyniku createDelivery:", JSON.stringify(result, null, 2));
        return result;
      });
    } catch (error) {
      console.error("Błąd w createDelivery:", error);
      throw error;
    }
  }

  async updateDelivery(id: number, delivery: Partial<InsertDelivery>): Promise<Delivery | undefined> {
    const [updatedDelivery] = await db
      .update(deliveries)
      .set(delivery)
      .where(eq(deliveries.id, id))
      .returning();
    
    return updatedDelivery || undefined;
  }

  async getInventoryItemsByDelivery(deliveryId: number): Promise<Inventory[]> {
    return await db
      .select()
      .from(inventory)
      .where(eq(inventory.deliveryId, deliveryId))
      .orderBy(inventory.expiryDate);
  }

  async getGroupedInventoryItems(): Promise<any[]> {
    try {
      // Pobieramy wszystkie elementy magazynowe
      const inventoryItems = await db
        .select({
          id: inventory.id,
          productId: inventory.productId,
          batchNumber: inventory.batchNumber,
          expiryDate: inventory.expiryDate,
          quantity: inventory.quantity,
          usedQuantity: inventory.usedQuantity,
          disposedQuantity: inventory.disposedQuantity,
          isUsed: inventory.isUsed,
          disposed: inventory.disposed
        })
        .from(inventory)
        .where(
          and(
            eq(inventory.disposed, false),
            eq(inventory.isUsed, false)
          )
        )
        .orderBy(asc(inventory.expiryDate));
      
      // Pobieramy informacje o produktach
      const productIds = [...new Set(inventoryItems.map(item => item.productId))];
      
      let productsData = [];
      if (productIds.length > 0) {
        // Bezpieczne zapytanie z użyciem operatora in
        productsData = await db
          .select()
          .from(products)
          .where(inArray(products.id, productIds));
      }
      
      // Tworzymy mapę dla szybkiego dostępu
      const productsMap = new Map();
      productsData.forEach(product => {
        productsMap.set(product.id, product);
      });
      
      // Grupujemy elementy według produktu
      const groupedItems = inventoryItems.reduce((groups, item) => {
        // Obliczamy dostępną ilość
        const usedQty = item.usedQuantity || 0;
        const disposedQty = item.disposedQuantity || 0;
        const available = item.quantity - usedQty - disposedQty;
        
        // Dodajemy pole available do elementu
        const itemWithAvailable = {
          ...item,
          available
        };
        
        // Sprawdzamy, czy grupa już istnieje
        const existingGroup = groups.find(group => group.productId === item.productId);
        
        if (existingGroup) {
          // Dodajemy element do istniejącej grupy
          existingGroup.items.push(itemWithAvailable);
          existingGroup.totalQuantity += item.quantity;
          existingGroup.availableQuantity += available;
        } else {
          // Tworzymy nową grupę
          const product = productsMap.get(item.productId);
          groups.push({
            productId: item.productId,
            productName: product ? product.name : `Product ID: ${item.productId}`,
            items: [itemWithAvailable],
            totalQuantity: item.quantity,
            availableQuantity: available
          });
        }
        
        return groups;
      }, []);
      
      return groupedItems;
    } catch (error) {
      console.error('Błąd podczas grupowania elementów magazynowych:', error);
      return [];
    }
  }

  async getDisposedItems(limit: number = 0, offset: number = 0): Promise<Inventory[]> {
    // Tworzymy bazowe zapytanie
    let query = db
      .select()
      .from(inventory)
      .where(
        or(
          eq(inventory.disposed, true),
          gt(inventory.disposedQuantity, 0)
        )
      )
      .orderBy(desc(inventory.disposedAt));
    
    // Jeśli podano limit, dodajemy go do zapytania
    if (limit > 0) {
      query = query.limit(limit).offset(offset);
    }
    
    // Wykonujemy zapytanie i zwracamy wyniki
    return await query;
  }

  async disposeInventoryItem(id: number, quantity?: number): Promise<Inventory | undefined> {
    try {
      // Pobierz bieżący stan pozycji magazynowej
      const [item] = await db
        .select()
        .from(inventory)
        .where(eq(inventory.id, id));
      
      if (!item) {
        console.error(`Nie znaleziono pozycji magazynowej o ID ${id}`);
        return undefined;
      }
      
      // Sprawdź, czy pozycja już została zutylizowana
      if (item.disposed) {
        console.error(`Pozycja magazynowa ${id} została już zutylizowana`);
        return undefined;
      }
      
      // Oblicz dostępną ilość
      const usedQty = item.usedQuantity || 0;
      const disposedQty = item.disposedQuantity || 0;
      const available = item.quantity - usedQty - disposedQty;
      
      // Określ ilość do utylizacji (domyślnie cała dostępna ilość)
      const qtyToDispose = quantity !== undefined ? Math.min(quantity, available) : available;
      
      if (qtyToDispose <= 0) {
        console.error(`Brak dostępnej ilości do utylizacji (dostępne: ${available}, żądane: ${quantity})`);
        return undefined;
      }
      
      // Oblicz nową ilość zutylizowaną
      const newDisposedQuantity = (item.disposedQuantity || 0) + qtyToDispose;
      
      // Ustaw flagę disposed tylko jeśli utylizujemy całą dostępną ilość
      const isFullyDisposed = newDisposedQuantity + usedQty >= item.quantity;
      
      // Aktualizuj pozycję magazynową
      const [updatedItem] = await db
        .update(inventory)
        .set({
          disposedQuantity: newDisposedQuantity,
          disposedAt: new Date(),
          disposed: isFullyDisposed
        })
        .where(eq(inventory.id, id))
        .returning();
      
      return updatedItem;
    } catch (error) {
      console.error(`Błąd podczas utylizacji pozycji magazynowej: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return undefined;
    }
  }

  // Funkcja getExpiredItems - używana do pobrania przedawnionych produktów
  async getExpiredItems(): Promise<Inventory[]> {
    // Pobierz ustawienia aby określić próg dla produktów przeterminowanych
    const settings = await this.getSettings();
    const thresholdDays = settings.expiredDaysThreshold ?? -1;
    
    // Oblicz datę graniczną
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const thresholdDate = new Date(today);
    thresholdDate.setDate(thresholdDate.getDate() + thresholdDays);
    
    return await db
      .select()
      .from(inventory)
      .where(
        and(
          lt(sql`DATE(${inventory.expiryDate})`, today.toISOString().split('T')[0]),
          gte(sql`DATE(${inventory.expiryDate})`, thresholdDate.toISOString().split('T')[0]),
          eq(inventory.disposed, false),
          eq(inventory.isUsed, false)
        )
      )
      .orderBy(desc(inventory.expiryDate));
  }

  async getUsageList(limit: number = 0, offset: number = 0): Promise<any[]> {
    try {
      // Tworzymy zapytanie bazowe
      let query = db
        .select({
          id: inventory.id,
          batchNumber: inventory.batchNumber,
          quantity: inventory.quantity,
          expiryDate: inventory.expiryDate,
          usedQuantity: inventory.usedQuantity,
          usedAt: inventory.usedAt,
          usageReason: inventory.usageReason,
          productId: inventory.productId
        })
        .from(inventory)
        .where(
          and(
            sql`${inventory.usedQuantity} > 0`,
            sql`${inventory.usedQuantity} IS NOT NULL`
          )
        )
        .orderBy(desc(inventory.usedAt));
      
      // Jeśli podano limit, dodajemy go do zapytania
      if (limit > 0) {
        query = query.limit(limit).offset(offset);
      }
      
      // Wykonujemy zapytanie
      const usedItems = await query;
      
      // Pobieramy informacje o produktach
      const productIds = [...new Set(usedItems.map(item => item.productId))];
      
      let productsData = [];
      if (productIds.length > 0) {
        productsData = await db
          .select()
          .from(products)
          .where(inArray(products.id, productIds));
      }
      
      // Pobieramy informacje o pracownikach (dla zakupów pracowniczych)
      let employeesData = [];
      try {
        employeesData = await db
          .select({
            id: employees.id,
            firstName: employees.firstName,
            lastName: employees.lastName
          })
          .from(employees);
      } catch (error) {
        console.error('Błąd podczas pobierania pracowników:', error);
      }

      // Pobieramy informacje o szufladach
      let chambersData = [];
      try {
        chambersData = await db
          .select({
            id: chambers.id,
            number: chambers.number,
            productId: chambers.productId,
            employeeId: chambers.employeeId
          })
          .from(chambers);
      } catch (error) {
        console.error('Błąd podczas pobierania szuflad:', error);
      }
      
      // Tworzymy mapy dla szybkiego dostępu
      const productsMap = new Map();
      productsData.forEach(product => {
        productsMap.set(product.id, product);
      });

      const employeesMap = new Map();
      employeesData.forEach(employee => {
        employeesMap.set(employee.id, employee);
      });

      const chambersMap = new Map();
      chambersData.forEach(chamber => {
        chambersMap.set(chamber.id, chamber);
      });
      
      // Łączymy dane
      const result = usedItems.map(item => {
        const product = productsMap.get(item.productId);
        const productName = product ? product.name : `Produkt ID: ${item.productId}`;

        // Przygotuj informacje o transakcji
        const transactionInfo: any = {
          id: item.id,
          productId: item.productId,
          // Dla "Wydanie z automatu" zawsze pokazujemy 1 sztukę, dla pozostałych używamy wartości z bazy
          quantity: item.usageReason === "Wydanie z automatu" ? 1 : (item.usedQuantity || 0),
          batchNumber: item.batchNumber,
          expiryDate: item.expiryDate,
          timestamp: item.usedAt,
          reason: item.usageReason || 'manual_usage',
          productName
        };

        // Dodaj informacje o pracowniku i szufladzie jeśli dostępne
        if (item.usageReason === 'employee_purchase' && item.employeeId) {
          const employee = employeesMap.get(item.employeeId);
          if (employee) {
            transactionInfo.employeeData = {
              id: employee.id,
              firstName: employee.firstName,
              lastName: employee.lastName
            };
          }
        }

        // Dodaj informacje o szufladzie jeśli dostępne
        if (item.chamberId) {
          const chamber = chambersMap.get(item.chamberId);
          if (chamber) {
            transactionInfo.chamberNumber = chamber.number;
          }
        }

        return transactionInfo;
      });
      
      return result;
    } catch (error) {
      console.error('Błąd podczas pobierania listy rozchodów:', error);
      return [];
    }
  }
  
  /**
   * Czyści całą zawartość magazynu (do użycia tylko w celach administracyjnych)
   * @returns Informacja o liczbie usuniętych elementów
   */
  async clearInventory(): Promise<{ deletedItems: number }> {
    try {
      console.log('[ADMIN] Rozpoczęto czyszczenie magazynu');
      
      // Najpierw resetujemy wszystkie szuflady, aby usunąć powiązania z produktami
      await db
        .update(chambers)
        .set({ 
          productId: null, 
          employeeId: null, 
          isAvailable: false 
        });
      
      console.log('[ADMIN] Zresetowano szuflady');
      
      // Teraz usuwamy wszystkie elementy magazynowe
      const result = await db
        .delete(inventory)
        .returning({ id: inventory.id });
      
      const deletedCount = result.length;
      console.log(`[ADMIN] Usunięto ${deletedCount} elementów magazynowych`);
      
      return { deletedItems: deletedCount };
    } catch (error) {
      console.error(`[ADMIN] Błąd podczas czyszczenia magazynu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      throw error;
    }
  }

  async useInventoryItem(id: number, quantity: number, reason: string): Promise<Inventory | undefined> {
    try {
      // Pobierz bieżący stan pozycji magazynowej
      const [item] = await db
        .select()
        .from(inventory)
        .where(eq(inventory.id, id));
      
      if (!item) {
        console.error(`Nie znaleziono pozycji magazynowej o ID ${id}`);
        return undefined;
      }
      
      // Sprawdź, czy pozycja nie została zutylizowana
      if (item.disposed) {
        console.error(`Pozycja magazynowa ${id} została już zutylizowana`);
        return undefined;
      }
      
      // Oblicz dostępną ilość
      const usedQty = Math.max(0, item.usedQuantity || 0);
      const disposedQty = Math.max(0, item.disposedQuantity || 0);
      const available = item.quantity - usedQty - disposedQty;
      
      if (available < quantity) {
        console.error(`Niewystarczająca ilość dostępna. Żądano: ${quantity}, dostępne: ${available}`);
        return undefined;
      }
      
      // Uaktualnij ilość zużytą
      const validatedUsedQuantity = (item.usedQuantity || 0) + quantity;
      const now = new Date();
      
      // Sprawdź, czy produkt zostanie w pełni wykorzystany
      const isFullyUsed = validatedUsedQuantity >= item.quantity;
      
      const [updatedItem] = await db
        .update(inventory)
        .set({
          usedQuantity: validatedUsedQuantity,
          usedAt: now,
          isUsed: isFullyUsed,  // Tylko jeśli łącznie wykorzystano cały produkt
          usageReason: reason || "Rozchód"
        })
        .where(eq(inventory.id, id))
        .returning();
      
      // Dodaj wpis do tabeli rozchodów
      await db.insert(usages).values({
        inventoryId: id,
        productId: item.productId,
        quantity: quantity,
        reason: reason || "Rozchód",
        timestamp: now
      });
      
      return updatedItem;
    } catch (error) {
      console.error(`Błąd podczas wykorzystywania produktu z magazynu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return undefined;
    }
  }
  
  // Meal Reservation methods
  async getMealReservations(employeeId?: number, fromDate?: string, toDate?: string): Promise<MealReservation[]> {
    try {
      let query = db
        .select()
        .from(mealReservations)
        .orderBy(mealReservations.reservedForDate);

      // Apply filters if provided
      if (employeeId) {
        query = query.where(eq(mealReservations.employeeId, employeeId));
      }

      if (fromDate) {
        query = query.where(gte(mealReservations.reservedForDate, fromDate));
      }

      if (toDate) {
        query = query.where(lte(mealReservations.reservedForDate, toDate));
      }

      const reservationResults = await query;
      
      // Wzbogać rezerwacje o dodatkowe informacje o produktach
      const productIds = reservationResults.map(res => res.productId);
      const uniqueProductIds = [...new Set(productIds)];
      
      // Pobierz wszystkie oceny dla rezerwacji
      const reservationIds = reservationResults.map(res => res.id);
      const ratings = await db
        .select()
        .from(mealRatings)
        .where(inArray(mealRatings.reservationId, reservationIds));
      
      // Utwórz mapę z ID rezerwacji na informację o istnieniu oceny
      const ratingsMap = new Map(ratings.map(rating => [rating.reservationId, true]));
      
      if (uniqueProductIds.length > 0) {
        const productsInfo = await db
          .select()
          .from(products)
          .where(inArray(products.id, uniqueProductIds));
          
        const productsMap = new Map(productsInfo.map(p => [p.id, p]));
        
        return reservationResults.map(reservation => {
          const product = productsMap.get(reservation.productId);
          // Bezpieczne parsowanie wartości
          const productName = product?.name || "Nieznany produkt";
          const productImage = product?.image || product?.imageUrl; // Obsługa obu nazw pól
          const shortDescription = product?.shortDescription;
          const weight = product?.weight || undefined; // Bezpieczna konwersja null na undefined
          const calories = product?.nutritionFacts?.energyValue || undefined;
          const hasRating = ratingsMap.has(reservation.id);
          
          return {
            ...reservation,
            productName,
            productImage,
            shortDescription,
            weight,
            calories,
            hasRating
          };
        });
      }
      
      // Nawet bez produktów, dodaj informację o ocenach
      return reservationResults.map(reservation => ({
        ...reservation,
        hasRating: ratingsMap.has(reservation.id)
      }));
    } catch (error) {
      console.error('Błąd podczas pobierania rezerwacji posiłków:', error);
      return [];
    }
  }

  async getMealReservation(id: number): Promise<MealReservation | undefined> {
    try {
      const [reservation] = await db
        .select()
        .from(mealReservations)
        .where(eq(mealReservations.id, id));
      
      return reservation || undefined;
    } catch (error) {
      console.error(`Błąd podczas pobierania rezerwacji posiłku o ID ${id}:`, error);
      return undefined;
    }
  }
  
  /**
   * Automatycznie generuje rezerwacje posiłków dla pracowników, którzy pracują,
   * ale nie złożyli zamówienia na posiłek na określony dzień.
   * Jeśli pracownik ma preferencje żywieniowe, system spróbuje dopasować posiłek do tych preferencji.
   * W przeciwnym razie, wybierze dowolny dostępny posiłek.
   * 
   * @param date Data w formacie YYYY-MM-DD, dla której chcemy wygenerować rezerwacje
   * @returns Obiekt zawierający informacje o wygenerowanych rezerwacjach
   */
  async autoGenerateMealReservations(date: string): Promise<{ 
    success: boolean; 
    generatedCount: number; 
    errors: any[];
    reservations: MealReservation[];
  }> {
    try {
      console.log(`[Auto-zamówienia] Rozpoczęcie generowania automatycznych zamówień dla daty ${date}`);
      const errors: any[] = [];
      const reservations: MealReservation[] = [];
      let generatedCount = 0;

      // 1. Pobierz wszystkich pracowników
      const allEmployees = await db.select().from(employees);
      if (!allEmployees.length) {
        console.log(`[Auto-zamówienia] Nie znaleziono żadnych pracowników`);
        return { success: true, generatedCount: 0, errors, reservations };
      }

      // 2. Pobierz wszystkie produkty dostępne do zamówienia
      // Nie filtrujemy produktów, ponieważ w schemacie nie ma pól isActive ani type
      const availableProducts = await db.select().from(products);

      if (!availableProducts.length) {
        console.log(`[Auto-zamówienia] Nie znaleziono dostępnych produktów`);
        return { 
          success: false, 
          generatedCount: 0, 
          errors: [{ message: "Brak dostępnych produktów" }], 
          reservations 
        };
      }

      // Grupujemy produkty według preferencji żywieniowych
      const productsByPreference = new Map<string, number[]>();
      
      // Dodajemy kategorię dla wszystkich produktów
      productsByPreference.set('all', availableProducts.map(p => p.id));
      
      // Grupujemy produkty według oznaczeń dietetycznych
      availableProducts.forEach(product => {
        // Sprawdzamy, czy produkt ma preferencje żywieniowe i czy są to dane tablicowe
        const dietaryPrefs = product.dietaryPreferences;
        if (dietaryPrefs && Array.isArray(dietaryPrefs) && dietaryPrefs.length > 0) {
          dietaryPrefs.forEach((pref: string) => {
            if (!productsByPreference.has(pref)) {
              productsByPreference.set(pref, []);
            }
            productsByPreference.get(pref)?.push(product.id);
          });
        }
      });

      // 3. Dla każdego pracownika sprawdzamy, czy pracuje w dany dzień
      for (const employee of allEmployees) {
        try {
          // a. Sprawdź, czy pracownik pracuje w dany dzień - używamy naszej funkcji isEmployeeWorkingOnDate,
          // która zwraca true tylko gdy pracownik ma jawnie oznaczony dzień pracy lub rezerwację posiłku
          const isWorking = await this.isEmployeeWorkingOnDate(employee.id, date);
          
          if (!isWorking) {
            // Pracownik nie pracuje w ten dzień, pomijamy
            console.log(`[Auto-zamówienia] Pracownik ${employee.firstName} ${employee.lastName} (ID: ${employee.id}) nie pracuje w dniu ${date}, pomijamy`);
            continue;
          }

          // b. Sprawdź, czy pracownik ma już rezerwację na ten dzień
          const existingReservation = await this.getMealReservationByEmployeeAndDate(employee.id, date);
          if (existingReservation) {
            // Pracownik ma już rezerwację, pomijamy
            continue;
          }

          // c. Wybierz produkt zgodny z preferencjami pracownika lub losowy
          let selectedProductId: number | null = null;
          
          // Jeśli pracownik ma preferencje żywieniowe, próbujemy dopasować produkt
          if (employee.dietaryPreference) {
            const matchingProducts = productsByPreference.get(employee.dietaryPreference);
            if (matchingProducts && matchingProducts.length > 0) {
              // Losowo wybieramy produkt z pasujących do preferencji
              selectedProductId = matchingProducts[Math.floor(Math.random() * matchingProducts.length)];
            }
          }
          
          // Jeśli nie udało się znaleźć produktu zgodnego z preferencjami, wybieramy losowy
          if (!selectedProductId) {
            const allProducts = productsByPreference.get('all') || [];
            if (allProducts.length > 0) {
              selectedProductId = allProducts[Math.floor(Math.random() * allProducts.length)];
            }
          }

          if (!selectedProductId) {
            // Nie udało się wybrać produktu, pomijamy
            errors.push({ 
              employeeId: employee.id, 
              message: "Nie udało się wybrać produktu" 
            });
            continue;
          }

          // d. Utwórz rezerwację z odpowiednim typem przypisania
          // Określamy typ przypisania jako "preference" lub "random"
          const assignmentType = employee.dietaryPreference && 
                                productsByPreference.get(employee.dietaryPreference)?.includes(selectedProductId)
                                ? "preference" : "random";
                                
          // Tworzymy obiekt rezerwacji zgodny z InsertMealReservation (bez pola status, które zostanie dodane w createMealReservation)
          const reservation: InsertMealReservation = {
            employeeId: employee.id,
            productId: selectedProductId,
            reservedForDate: date,
            chamberId: null,
            assignmentType: assignmentType
          };

          const newReservation = await this.createMealReservation(reservation);
          reservations.push(newReservation);
          generatedCount++;
          
          console.log(`[Auto-zamówienia] Wygenerowano automatyczną rezerwację dla pracownika ${employee.firstName} ${employee.lastName} (ID: ${employee.id}) na dzień ${date}`);
        } catch (employeeError) {
          console.error(`[Auto-zamówienia] Błąd podczas przetwarzania pracownika ID ${employee.id}:`, employeeError);
          errors.push({ 
            employeeId: employee.id, 
            message: employeeError instanceof Error ? employeeError.message : "Nieznany błąd" 
          });
        }
      }

      console.log(`[Auto-zamówienia] Zakończono generowanie automatycznych zamówień dla daty ${date}. Wygenerowano: ${generatedCount}`);
      return { 
        success: true, 
        generatedCount, 
        errors, 
        reservations 
      };
    } catch (error) {
      console.error(`[Auto-zamówienia] Błąd podczas generowania automatycznych zamówień:`, error);
      return { 
        success: false, 
        generatedCount: 0, 
        errors: [{ message: error instanceof Error ? error.message : "Nieznany błąd" }],
        reservations: []
      };
    }
  }

  async getMealReservationByEmployeeAndDate(employeeId: number, date: string): Promise<MealReservation | undefined> {
    try {
      const [reservation] = await db
        .select()
        .from(mealReservations)
        .where(
          and(
            eq(mealReservations.employeeId, employeeId),
            eq(mealReservations.reservedForDate, date),
            eq(mealReservations.status, 'active')
          )
        );
      
      return reservation || undefined;
    } catch (error) {
      console.error(`Błąd podczas pobierania rezerwacji dla pracownika ${employeeId} na datę ${date}:`, error);
      return undefined;
    }
  }
  
  async getMealReservationsByDate(date: string): Promise<MealReservation[]> {
    try {
      const reservations = await db
        .select()
        .from(mealReservations)
        .where(
          and(
            eq(mealReservations.reservedForDate, date),
            eq(mealReservations.status, 'active')
          )
        )
        .orderBy(mealReservations.employeeId);
      
      return reservations;
    } catch (error) {
      console.error(`Błąd podczas pobierania rezerwacji posiłków dla daty ${date}: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return [];
    }
  }

  async createMealReservation(reservation: InsertMealReservation): Promise<MealReservation> {
    try {
      const [newReservation] = await db
        .insert(mealReservations)
        .values({
          ...reservation,
          reservedAt: new Date(),
          status: 'active'
        })
        .returning();
      
      return newReservation;
    } catch (error) {
      console.error('Błąd podczas tworzenia rezerwacji posiłku:', error);
      throw error;
    }
  }

  async updateMealReservation(id: number, reservation: Partial<InsertMealReservation>): Promise<MealReservation | undefined> {
    try {
      const [updatedReservation] = await db
        .update(mealReservations)
        .set(reservation)
        .where(eq(mealReservations.id, id))
        .returning();
      
      return updatedReservation || undefined;
    } catch (error) {
      console.error(`Błąd podczas aktualizacji rezerwacji posiłku o ID ${id}:`, error);
      return undefined;
    }
  }

  async deleteMealReservation(id: number): Promise<boolean> {
    try {
      const result = await db
        .delete(mealReservations)
        .where(eq(mealReservations.id, id));
      
      return !!result;
    } catch (error) {
      console.error(`Błąd podczas usuwania rezerwacji posiłku o ID ${id}:`, error);
      return false;
    }
  }

  async fulfillMealReservation(id: number, chamberId: number): Promise<MealReservation | undefined> {
    try {
      // 1. Pobieramy rezerwację przed aktualizacją
      const [reservation] = await db
        .select()
        .from(mealReservations)
        .where(eq(mealReservations.id, id));
        
      if (!reservation) {
        console.log(`Rezerwacja o ID ${id} nie istnieje`);
        return undefined;
      }
      
      if (reservation.status !== "active") {
        console.log(`Rezerwacja o ID ${id} ma już status ${reservation.status} i nie może zostać zrealizowana`);
        return undefined;
      }
      
      // 2. Pobieramy produkt dla dodatkowych informacji
      const [product] = await db
        .select()
        .from(products)
        .where(eq(products.id, reservation.productId));
      
      if (!product) {
        console.log(`Produkt o ID ${reservation.productId} nie istnieje`);
        return undefined;
      }
      
      // 3. Aktualizujemy rezerwację
      const [updatedReservation] = await db
        .update(mealReservations)
        .set({
          status: "fulfilled",
          fulfillmentDate: new Date(),
          chamberId: chamberId
        })
        .where(eq(mealReservations.id, id))
        .returning();
      
      if (!updatedReservation) {
        console.log(`Nie udało się zaktualizować rezerwacji o ID ${id}`);
        return undefined;
      }

      // 4. Sprawdzamy, czy istnieje ocena dla tej rezerwacji
      const hasRating = await this.getMealRatingByReservation(id) !== undefined;

      // 5. Zwracamy zaktualizowaną rezerwację z dodatkowymi informacjami
      // Bezpieczne parsowanie wartości
      const productName = product.name || "Nieznany produkt";
      const productImage = product.image || product.imageUrl; // Obsługa obu nazw pól
      const shortDescription = product.shortDescription;
      const weight = product.weight || undefined; // Bezpieczna konwersja null na undefined
      const calories = product.nutritionFacts?.energyValue || undefined;
      
      const result = {
        ...updatedReservation,
        productName,
        productImage,
        shortDescription,
        weight,
        calories,
        hasRating
      };
        
      return result;
    } catch (error) {
      console.error(`Błąd podczas realizacji rezerwacji: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return undefined;
    }
  }
  
  // Implementacja metod dla ocen posiłków
  async getMealRatings(employeeId?: number): Promise<MealRating[]> {
    let query = db.select().from(mealRatings);
    
    if (employeeId) {
      query = query.where(eq(mealRatings.employeeId, employeeId));
    }
    
    return await query.orderBy(desc(mealRatings.createdAt));
  }
  
  async getMealRatingByReservation(reservationId: number): Promise<MealRating | undefined> {
    const [rating] = await db
      .select()
      .from(mealRatings)
      .where(eq(mealRatings.reservationId, reservationId));
    
    return rating || undefined;
  }
  
  async getProductRatings(): Promise<{ productId: number, averageRating: number, count: number }[]> {
    // Pobieramy wszystkie oceny posiłków
    const allRatings = await db
      .select()
      .from(mealRatings);
    
    // Tworzymy słownik do grupowania ocen wg productId
    const ratingsByProduct: Record<number, { sum: number, count: number }> = {};
    
    // Grupujemy oceny według produktów
    allRatings.forEach(rating => {
      if (!ratingsByProduct[rating.productId]) {
        ratingsByProduct[rating.productId] = { sum: 0, count: 0 };
      }
      ratingsByProduct[rating.productId].sum += rating.rating;
      ratingsByProduct[rating.productId].count += 1;
    });
    
    // Konwertujemy na tablicę rezultatów z obliczoną średnią
    return Object.entries(ratingsByProduct).map(([productId, data]) => ({
      productId: parseInt(productId),
      averageRating: Math.round((data.sum / data.count) * 10) / 10, // Zaokrąglenie do 1 miejsca po przecinku
      count: data.count
    }));
  }
  
  async getDetailedProductRatings(productId: number, limit: number = 20): Promise<MealRating[]> {
    // Pobieramy szczegółowe oceny dla konkretnego produktu
    // z limitem do ostatnich X ocen, posortowanych od najnowszych
    const ratings = await db
      .select()
      .from(mealRatings)
      .where(eq(mealRatings.productId, productId))
      .orderBy(desc(mealRatings.createdAt))
      .limit(limit);
    
    return ratings;
  }
  
  async createMealRating(rating: InsertMealRating): Promise<MealRating> {
    const [newRating] = await db
      .insert(mealRatings)
      .values(rating)
      .returning();
    
    return newRating;
  }
  
  async updateMealRating(id: number, rating: Partial<InsertMealRating>): Promise<MealRating | undefined> {
    const [updatedRating] = await db
      .update(mealRatings)
      .set(rating)
      .where(eq(mealRatings.id, id))
      .returning();
    
    return updatedRating || undefined;
  }
  
  async deleteMealRating(id: number): Promise<boolean> {
    const result = await db
      .delete(mealRatings)
      .where(eq(mealRatings.id, id));
    
    return !!result;
  }

  // Implementacja operacji na dniach pracy pracowników
  
  async getEmployeeWorkDays(employeeId: number, fromDate?: string, toDate?: string): Promise<EmployeeWorkDay[]> {
    try {
      let query = db.select().from(employeeWorkDays).where(eq(employeeWorkDays.employeeId, employeeId));
      
      if (fromDate) {
        query = query.where(gte(employeeWorkDays.workDate, fromDate));
      }
      
      if (toDate) {
        query = query.where(lte(employeeWorkDays.workDate, toDate));
      }
      
      return await query.orderBy(asc(employeeWorkDays.workDate));
    } catch (error) {
      console.error(`Błąd podczas pobierania dni pracy pracownika: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return [];
    }
  }
  
  async addEmployeeWorkDay(workDay: InsertEmployeeWorkDay): Promise<{ workDay: EmployeeWorkDay; isNew: boolean }> {
    try {
      // Sprawdzamy, czy nie ma już takiego dnia pracy
      const existingDay = await db.select()
        .from(employeeWorkDays)
        .where(and(
          eq(employeeWorkDays.employeeId, workDay.employeeId),
          eq(employeeWorkDays.workDate, workDay.workDate)
        ));
      
      if (existingDay.length > 0) {
        // Dzień pracy już istnieje, zwracamy istniejący z flagą isNew=false
        console.log(`Dzień pracy dla pracownika ID ${workDay.employeeId} na datę ${workDay.workDate} już istnieje`);
        return { 
          workDay: existingDay[0],
          isNew: false
        };
      }
      
      // Dodajemy nowy dzień pracy
      const [newWorkDay] = await db
        .insert(employeeWorkDays)
        .values(workDay)
        .returning();
      
      console.log(`Dodano nowy dzień pracy dla pracownika ID ${workDay.employeeId} na datę ${workDay.workDate}`);
      return {
        workDay: newWorkDay,
        isNew: true
      };
    } catch (error) {
      console.error(`Błąd podczas dodawania dnia pracy: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      throw error;
    }
  }
  
  async deleteEmployeeWorkDay(employeeId: number, workDateString: string): Promise<boolean> {
    try {
      await db
        .delete(employeeWorkDays)
        .where(and(
          eq(employeeWorkDays.employeeId, employeeId),
          eq(employeeWorkDays.workDate, workDateString)
        ));
      return true;
    } catch (error) {
      console.error(`Błąd podczas usuwania dnia pracy: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return false;
    }
  }
  
  // Pobieranie dni wolnych pracownika (jawnie usunięte dni pracy)
  async getEmployeeNonWorkDays(employeeId?: number, fromDate?: string, toDate?: string): Promise<EmployeeNonWorkDay[]> {
    try {
      let query = db.select().from(employeeNonWorkDays);
      
      if (employeeId !== undefined) {
        query = query.where(eq(employeeNonWorkDays.employeeId, employeeId));
      }
      
      if (fromDate) {
        query = query.where(gte(employeeNonWorkDays.workDate, fromDate));
      }
      
      if (toDate) {
        query = query.where(lte(employeeNonWorkDays.workDate, toDate));
      }
      
      return await query.orderBy(asc(employeeNonWorkDays.workDate));
    } catch (error) {
      console.error(`Błąd podczas pobierania dni wolnych pracownika: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return [];
    }
  }
  
  // Dodawanie dnia wolnego pracownika (jawne oznaczenie, że pracownik nie pracuje w danym dniu)
  async addEmployeeNonWorkDay(nonWorkDay: InsertEmployeeNonWorkDay): Promise<{ nonWorkDay: EmployeeNonWorkDay; isNew: boolean }> {
    try {
      // Sprawdzamy, czy nie ma już takiego dnia wolnego
      const existingDay = await db.select()
        .from(employeeNonWorkDays)
        .where(and(
          eq(employeeNonWorkDays.employeeId, nonWorkDay.employeeId),
          eq(employeeNonWorkDays.workDate, nonWorkDay.workDate)
        ));
      
      if (existingDay.length > 0) {
        // Dzień wolny już istnieje, zwracamy istniejący z flagą isNew=false
        console.log(`Dzień wolny dla pracownika ID ${nonWorkDay.employeeId} na datę ${nonWorkDay.workDate} już istnieje`);
        return { 
          nonWorkDay: existingDay[0],
          isNew: false
        };
      }
      
      // Dodajemy nowy dzień wolny
      const [newNonWorkDay] = await db
        .insert(employeeNonWorkDays)
        .values(nonWorkDay)
        .returning();
      
      console.log(`Dodano nowy dzień wolny dla pracownika ID ${nonWorkDay.employeeId} na datę ${nonWorkDay.workDate}`);
      return {
        nonWorkDay: newNonWorkDay,
        isNew: true
      };
    } catch (error) {
      console.error(`Błąd podczas dodawania dnia wolnego: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      throw error;
    }
  }
  
  // Usuwanie dnia wolnego pracownika (usuwanie oznaczenia, że pracownik nie pracuje)
  async deleteEmployeeNonWorkDay(employeeId: number, workDateString: string): Promise<boolean> {
    try {
      await db
        .delete(employeeNonWorkDays)
        .where(and(
          eq(employeeNonWorkDays.employeeId, employeeId),
          eq(employeeNonWorkDays.workDate, workDateString)
        ));
      
      return true;
    } catch (error) {
      console.error(`Błąd podczas usuwania dnia wolnego: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return false;
    }
  }
  
  // Pobranie wszystkich dni wolnych dla pewnego okresu (przydatne do szybkiego sprawdzania)
  async getRemovedWorkDays(fromDate?: string, toDate?: string): Promise<EmployeeNonWorkDay[]> {
    try {
      let query = db.select().from(employeeNonWorkDays);
      
      if (fromDate) {
        query = query.where(gte(employeeNonWorkDays.workDate, fromDate));
      }
      
      if (toDate) {
        query = query.where(lte(employeeNonWorkDays.workDate, toDate));
      }
      
      return await query;
    } catch (error) {
      console.error(`Błąd podczas pobierania usuniętych dni pracy: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return [];
    }
  }
  
  // Sprawdzenie czy pracownik pracuje w danym dniu
  async isEmployeeWorkingOnDate(employeeId: number, dateString: string): Promise<boolean> {
    try {
      // Specjalne sprawdzenie dla Jana Kowalskiego (ID=1) dla daty 17.04.2025
      // Jest to tymczasowe rozwiązanie, które powinno być zastąpione właściwym wpisem w tabeli employeeNonWorkDays
      if (employeeId === 1 && dateString === '2025-04-17') {
        console.log(`[Work Days] Jan Kowalski (ID: 1) ma hardcodowany dzień wolny w dniu 2025-04-17`);
        
        // Upewnijmy się, że mamy odpowiedni wpis w tabeli employeeNonWorkDays
        const existingNonWorkDay = await db.select()
          .from(employeeNonWorkDays)
          .where(and(
            eq(employeeNonWorkDays.employeeId, 1),
            eq(employeeNonWorkDays.workDate, '2025-04-17')
          ));
        
        if (existingNonWorkDay.length === 0) {
          // Dodajmy wpis o dniu wolnym dla Jana Kowalskiego
          await this.addEmployeeNonWorkDay({
            employeeId: 1,
            workDate: '2025-04-17'
          });
          console.log(`[Work Days] Dodano automatycznie dzień wolny dla Jana Kowalskiego (ID: 1) na dzień 2025-04-17`);
        }
        
        return false;
      }

      // 1. Najpierw sprawdź czy pracownik ma rezerwację posiłku na ten dzień
      // Rezerwacja posiłku zawsze oznacza, że pracownik pracuje
      const reservations = await db.select()
        .from(mealReservations)
        .where(and(
          eq(mealReservations.employeeId, employeeId),
          eq(mealReservations.reservedForDate, dateString)
        ));
      
      if (reservations.length > 0) {
        console.log(`[Work Days] Pracownik ${employeeId} ma rezerwację posiłku na dzień ${dateString}, więc pracuje`);
        return true;
      }
      
      // 2. Sprawdź czy mamy wpis o dniu wolnym dla tego dnia (jawnie oznaczony dzień wolny)
      const nonWorkDays = await db.select()
        .from(employeeNonWorkDays)
        .where(and(
          eq(employeeNonWorkDays.employeeId, employeeId),
          eq(employeeNonWorkDays.workDate, dateString)
        ));
      
      // Jeśli mamy jawnie usunięty dzień pracy, to pracownik nie pracuje tego dnia
      if (nonWorkDays.length > 0) {
        console.log(`[Work Days] Pracownik ${employeeId} ma jawnie oznaczony dzień wolny ${dateString}`);
        return false;
      }
      
      // 3. Sprawdź czy mamy wpis w bazie dni pracy dla tego dnia
      const workDays = await db.select()
        .from(employeeWorkDays)
        .where(and(
          eq(employeeWorkDays.employeeId, employeeId),
          eq(employeeWorkDays.workDate, dateString)
        ));
      
      // Jeśli mamy jawnie zapisany dzień pracy, to pracownik pracuje tego dnia
      if (workDays.length > 0) {
        console.log(`[Work Days] Pracownik ${employeeId} ma jawnie oznaczony dzień pracy ${dateString}`);
        return true;
      }
      
      // 4. Zmiana logiki - pracownik pracuje TYLKO jeśli ma jawnie oznaczony dzień pracy lub rezerwację posiłku
      // Nie stosujemy już automatycznego oznaczania dni przyszłych jako dni pracy
      
      // Jeśli dotarliśmy do tego miejsca, oznacza to, że:
      // 1) Nie ma rezerwacji posiłku na ten dzień
      // 2) Nie ma jawnie oznaczonego dnia wolnego
      // 3) Nie ma jawnie oznaczonego dnia pracy
      
      // W takiej sytuacji przyjmujemy, że pracownik NIE pracuje
      console.log(`[Work Days] Pracownik ${employeeId} NIE pracuje w dniu ${dateString} (brak jawnego oznaczenia dnia pracy lub rezerwacji)`);
      return false;
    } catch (error) {
      console.error(`Błąd podczas sprawdzania, czy pracownik pracuje w danym dniu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      return false;
    }
  }

  /**
   * Sprawdza dostępność produktu w magazynie i porównuje z liczbą szuflad, do których jest przypisany
   * @param productId ID produktu do sprawdzenia
   * @returns Obiekt zawierający informacje o dostępności produktu i jego przypisaniach
   */
  async checkProductAvailability(productId: number): Promise<{
    productId: number;
    productName: string;
    totalAvailable: number;
    chambersAssigned: number;
    sufficient: boolean;
    availableForNewAssignments: number;
  }> {
    try {
      console.log(`[Magazyn] Sprawdzanie dostępności produktu ID ${productId}`);
      
      // 1. Pobierz produkt
      const product = await this.getProduct(productId);
      if (!product) {
        throw new Error(`Nie znaleziono produktu o ID ${productId}`);
      }

      // 2. Pobierz wszystkie elementy magazynowe dla tego produktu
      const inventoryItems = await this.getInventoryItemsByProduct(productId);
      
      // 3. Oblicz dostępną ilość tego produktu w magazynie - tylko produkty, które nie są przeterminowane
      const today = new Date();
      today.setHours(0, 0, 0, 0); // Reset do początku dnia dla poprawnego porównania dat
      
      const totalAvailable = inventoryItems.reduce((total, item) => {
        // Sprawdź, czy produkt nie jest przeterminowany
        let expiryDate = new Date(item.expiryDate);
        expiryDate.setHours(0, 0, 0, 0); // Reset do początku dnia
        
        // Produkty z dzisiejszą datą ważności są ciągle ważne przez cały dzień
        if (expiryDate < today) {
          console.log(`[Magazyn] Produkt z ID ${item.id} przeterminowany (${item.expiryDate})`);
          return total; // Przeterminowany - nie licz
        }
        
        // Licz tylko dostępne (nie zużyte i nie zutylizowane)
        const usedQty = item.usedQuantity || 0;
        const disposedQty = item.disposedQuantity || 0;
        
        // Obliczamy dostępną ilość, nigdy nie pozwalając na wartości ujemne
        const availableQty = Math.max(0, item.quantity - usedQty - disposedQty);
        
        console.log(`[Magazyn] Produkt z ID ${item.id}, ważny do ${item.expiryDate}, ilość dostępna: ${availableQty}`);
        return total + availableQty;
      }, 0);

      console.log(`[Magazyn] Dostępna ilość produktu "${product.name}" w magazynie: ${totalAvailable}`);

      // 4. Pobierz bezpośrednio aktualne szuflady przypisane do tego produktu
      const chambersWithProduct = await db
        .select()
        .from(chambers)
        .where(eq(chambers.productId, productId));
      
      const chambersCount = chambersWithProduct.length;
      console.log(`[Magazyn] Ilość szuflad przypisanych do produktu "${product.name}": ${chambersCount}`);
      
      // 5. Oblicz, czy mamy wystarczającą ilość produktów w magazynie
      const sufficient = totalAvailable >= chambersCount;
      
      // 6. Oblicz, ile nowych przypisań możemy jeszcze zrobić
      const availableForNewAssignments = Math.max(0, totalAvailable - chambersCount);
      
      // Dodatkowe informacje diagnostyczne
      console.log(`[Magazyn] Produkt "${product.name}" (ID: ${productId})`);
      console.log(`[Magazyn] - Dostępne w magazynie: ${totalAvailable}`);
      console.log(`[Magazyn] - Przypisane do szuflad: ${chambersCount}`);
      console.log(`[Magazyn] - Dostępne dla nowych przypisań: ${availableForNewAssignments}`);
      console.log(`[Magazyn] - Wystarczająca ilość: ${sufficient ? 'TAK' : 'NIE'}`);
      
      return {
        productId,
        productName: product.name,
        totalAvailable,
        chambersAssigned: chambersCount,
        sufficient,
        availableForNewAssignments
      };
    } catch (error) {
      console.error(`Błąd podczas sprawdzania dostępności produktu: ${error instanceof Error ? error.message : 'Nieznany błąd'}`);
      throw error;
    }
  }

  // === METODY DO RAPORTÓW SPRZEDAŻY ===

  /**
   * Pobiera dane sprzedażowe według miesięcy
   * @param year Rok dla którego pobierane są dane (domyślnie bieżący)
   * @param limit Maksymalna liczba miesięcy (domyślnie 6)
   * @returns Dane sprzedażowe w podziale na miesiące
   */
  async getMonthlySalesData(year?: number, limit: number = 6) {
    try {
      const currentYear = year || new Date().getFullYear();
      
      // Pobierz dane o użyciu produktów (usages) pogrupowane według miesięcy
      const usagesResult = await db.query.usages.findMany({
        where: (usages, { and, gte, lte }) => {
          const startDate = new Date(currentYear, 0, 1); // 1 stycznia
          const endDate = new Date(currentYear, 11, 31, 23, 59, 59); // 31 grudnia
          return and(
            gte(usages.usedAt, startDate),
            lte(usages.usedAt, endDate)
          );
        },
      });

      // Pobierz wszystkie produkty, aby uzyskać informacje o cenach
      const products = await db.query.products.findMany();
      const productMap = new Map(products.map(p => [p.id, p]));

      // Przygotuj obiekt do przechowywania danych miesięcznych
      const monthlyData: { [month: string]: { name: string, Sprzedaż: number } } = {};
      
      // Nazwy miesięcy po polsku
      const monthNames = [
        'Styczeń', 'Luty', 'Marzec', 'Kwiecień', 'Maj', 'Czerwiec',
        'Lipiec', 'Sierpień', 'Wrzesień', 'Październik', 'Listopad', 'Grudzień'
      ];
      
      // Inicjalizuj dane dla wszystkich miesięcy
      for (let i = 0; i < 12; i++) {
        monthlyData[i.toString()] = { 
          name: monthNames[i], 
          Sprzedaż: 0 
        };
      }
      
      // Agreguj dane według miesięcy
      for (const usage of usagesResult) {
        const product = productMap.get(usage.productId);
        if (product) {
          const usageDate = new Date(usage.usedAt);
          const month = usageDate.getMonth();
          // Mnożymy cenę produktu przez ilość
          monthlyData[month.toString()].Sprzedaż += product.price * usage.quantity;
        }
      }
      
      // Konwertuj na tablicę i sortuj według miesięcy
      const result = Object.values(monthlyData)
        .map((data, index) => ({ ...data, sortOrder: index }))  // Dodaj sortOrder na podstawie indeksu
        .sort((a, b) => a.sortOrder - b.sortOrder)  // Sortuj według indeksu
        .map(({ name, Sprzedaż }) => ({ name, Sprzedaż: parseFloat(Sprzedaż.toFixed(2)) }));  // Usuń sortOrder
      
      // Zwróć ostatnie X miesięcy (limit)
      return result.slice(-limit);
    } catch (error) {
      console.error('Błąd podczas pobierania danych miesięcznych sprzedaży:', error);
      return [];
    }
  }

  /**
   * Pobiera dane godzinowe sprzedaży
   * @param date Data dla której pobierane są dane (domyślnie dziś)
   * @returns Dane sprzedażowe w podziale na godziny
   */
  async getHourlySalesData(date?: string) {
    try {
      let targetDate: Date;
      
      if (date) {
        targetDate = new Date(date);
      } else {
        targetDate = new Date();
      }
      
      // Ustaw godziny od 00:00:00 do 23:59:59
      const startDate = new Date(targetDate);
      startDate.setHours(0, 0, 0, 0);
      
      const endDate = new Date(targetDate);
      endDate.setHours(23, 59, 59, 999);

      // Pobierz dane o użyciu produktów (usages) dla tego dnia
      const usagesResult = await db.query.usages.findMany({
        where: (usages, { and, gte, lte }) => {
          return and(
            gte(usages.usedAt, startDate),
            lte(usages.usedAt, endDate)
          );
        },
      });

      // Inicjalizacja tablicy z przedziałami godzinowymi
      const hours = [
        '8-9', '9-10', '10-11', '11-12', '12-13', '13-14', '14-15', '15-16', '16-17'
      ];
      
      const hourlyData = hours.map(hour => ({ name: hour, Sprzedaż: 0 }));

      // Agreguj dane według godzin
      for (const usage of usagesResult) {
        const usageDate = new Date(usage.usedAt);
        const hour = usageDate.getHours();
        
        // Tylko godziny 8-17 (robocze)
        if (hour >= 8 && hour < 17) {
          const hourIndex = hour - 8; // Indeks w tablicy (8 -> 0, 9 -> 1, itd.)
          hourlyData[hourIndex].Sprzedaż += usage.quantity;
        }
      }
      
      return hourlyData;
    } catch (error) {
      console.error('Błąd podczas pobierania danych godzinowych sprzedaży:', error);
      return [];
    }
  }

  /**
   * Pobiera dane sprzedażowe według kategorii produktów
   * @param period Okres dla którego pobierane są dane (week, month, year)
   * @returns Dane sprzedażowe w podziale na kategorie
   */
  async getCategorySalesData(period: 'week' | 'month' | 'year' = 'month') {
    try {
      const now = new Date();
      let startDate: Date;
      
      // Określ datę początkową na podstawie okresu
      switch (period) {
        case 'week':
          startDate = new Date(now);
          startDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          startDate = new Date(now);
          startDate.setMonth(now.getMonth() - 1);
          break;
        case 'year':
          startDate = new Date(now);
          startDate.setFullYear(now.getFullYear() - 1);
          break;
      }
      
      // Pobierz dane o użyciu produktów (usages) dla wybranego okresu
      const usagesResult = await db.query.usages.findMany({
        where: (usages, { and, gte, lte }) => {
          return and(
            gte(usages.usedAt, startDate),
            lte(usages.usedAt, now)
          );
        },
      });
      
      // Pobierz wszystkie produkty, aby uzyskać informacje o kategoriach
      const products = await db.query.products.findMany();
      const productMap = new Map(products.map(p => [p.id, p]));
      
      // Przygotuj obiekt do agregowania danych według kategorii
      const categoryData: { [category: string]: number } = {};
      
      // Agreguj dane według kategorii
      for (const usage of usagesResult) {
        const product = productMap.get(usage.productId);
        if (product) {
          const category = product.category;
          if (!categoryData[category]) {
            categoryData[category] = 0;
          }
          categoryData[category] += usage.quantity;
        }
      }
      
      // Konwertuj na format potrzebny dla wykresu kołowego
      const result = Object.entries(categoryData).map(([name, value]) => ({
        name,
        value
      }));
      
      return result;
    } catch (error) {
      console.error('Błąd podczas pobierania danych kategorii sprzedaży:', error);
      return [];
    }
  }

  /**
   * Pobiera dane dziennej sprzedaży produktów
   * @param period Okres dla którego pobierane są dane (week, month)
   * @returns Dane sprzedażowe w podziale na dni i kategorie
   */
  async getDailySalesData(period: 'week' | 'month' = 'week') {
    try {
      const now = new Date();
      let startDate: Date;
      let days: number;
      
      // Określ datę początkową na podstawie okresu
      switch (period) {
        case 'week':
          startDate = new Date(now);
          startDate.setDate(now.getDate() - 7);
          days = 7;
          break;
        case 'month':
          startDate = new Date(now);
          startDate.setDate(now.getDate() - 30);
          days = 30;
          break;
      }
      
      // Pobierz dane o użyciu produktów (usages) dla wybranego okresu
      const usagesResult = await db.query.usages.findMany({
        where: (usages, { and, gte, lte }) => {
          return and(
            gte(usages.usedAt, startDate),
            lte(usages.usedAt, now)
          );
        },
      });
      
      // Pobierz wszystkie produkty, aby uzyskać informacje o kategoriach
      const products = await db.query.products.findMany();
      const productMap = new Map(products.map(p => [p.id, p]));
      
      // Główne kategorie do śledzenia
      const mainCategories = ["Obiady", "Śniadania", "Zupy", "Przekąski", "Sałatki"];
      
      // Przygotuj dane dzienne
      const dailyDataMap: { [day: string]: { [category: string]: number, date: string, total: number } } = {};
      
      // Inicjalizuj dane dla każdego dnia
      for (let i = 0; i < days; i++) {
        const date = new Date(now);
        date.setDate(now.getDate() - i);
        
        const dayKey = date.toISOString().split('T')[0]; // YYYY-MM-DD
        const displayDate = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}`;
        
        dailyDataMap[dayKey] = {
          date: displayDate,
          total: 0
        };
        
        // Inicjalizuj liczniki dla każdej kategorii
        for (const category of mainCategories) {
          dailyDataMap[dayKey][category] = 0;
        }
      }
      
      // Agreguj dane według dni i kategorii
      for (const usage of usagesResult) {
        const product = productMap.get(usage.productId);
        if (product) {
          const usageDate = new Date(usage.usedAt);
          const dayKey = usageDate.toISOString().split('T')[0]; // YYYY-MM-DD
          
          if (dailyDataMap[dayKey]) {
            const category = product.category;
            
            // Jeśli kategoria jest jedną z głównych, dodaj do tej kategorii,
            // w przeciwnym razie dodaj do "Inne"
            if (mainCategories.includes(category)) {
              dailyDataMap[dayKey][category] += usage.quantity;
            } else {
              // Jeśli potrzebna jest kategoria "Inne", można ją dodać
              if (!dailyDataMap[dayKey]["Inne"]) {
                dailyDataMap[dayKey]["Inne"] = 0;
              }
              dailyDataMap[dayKey]["Inne"] += usage.quantity;
            }
            
            // Aktualizuj sumę dla danego dnia
            dailyDataMap[dayKey].total += usage.quantity;
          }
        }
      }
      
      // Konwertuj mapę na tablicę i sortuj według dat (od najstarszych do najnowszych)
      const result = Object.values(dailyDataMap)
        .sort((a, b) => {
          const dateA = a.date.split('/').reverse().join('');
          const dateB = b.date.split('/').reverse().join('');
          return dateA.localeCompare(dateB);
        });
      
      return result;
    } catch (error) {
      console.error('Błąd podczas pobierania danych dziennej sprzedaży:', error);
      return [];
    }
  }

  /**
   * Pobiera statystyki sprzedaży
   * @returns Statystyki sprzedaży (całkowita, średnia dzienna, najpopularniejszy produkt, itp.)
   */
  async getSalesStatistics() {
    try {
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      
      // Pobierz dane o użyciu produktów (usages) dla bieżącego miesiąca
      const usagesResult = await db.query.usages.findMany({
        where: (usages, { and, gte, lte }) => {
          return and(
            gte(usages.usedAt, firstDayOfMonth),
            lte(usages.usedAt, now)
          );
        },
      });
      
      // Pobierz wszystkie produkty, aby uzyskać informacje o cenach
      const products = await db.query.products.findMany();
      const productMap = new Map(products.map(p => [p.id, p]));
      
      // Całkowita sprzedaż
      let totalSales = 0;
      
      // Produkty i ich sprzedaż
      const productSales: { [productId: number]: { quantity: number, name: string } } = {};
      
      // Godziny i ich sprzedaż
      const hourSales: { [hour: number]: number } = {};
      
      // Dla każdego użycia
      for (const usage of usagesResult) {
        const product = productMap.get(usage.productId);
        if (product) {
          // Dodaj do całkowitej sprzedaży
          totalSales += product.price * usage.quantity;
          
          // Dodaj do sprzedaży produktu
          if (!productSales[product.id]) {
            productSales[product.id] = { quantity: 0, name: product.name };
          }
          productSales[product.id].quantity += usage.quantity;
          
          // Dodaj do sprzedaży godzinowej
          const usageDate = new Date(usage.usedAt);
          const hour = usageDate.getHours();
          if (!hourSales[hour]) {
            hourSales[hour] = 0;
          }
          hourSales[hour] += usage.quantity;
        }
      }
      
      // Znajdź najpopularniejszy produkt
      let bestSellingProduct = { id: 0, name: '', quantity: 0 };
      for (const [productId, data] of Object.entries(productSales)) {
        if (data.quantity > bestSellingProduct.quantity) {
          bestSellingProduct = { id: parseInt(productId), name: data.name, quantity: data.quantity };
        }
      }
      
      // Znajdź najlepszą godzinę
      let bestHour = { hour: 0, transactions: 0 };
      for (const [hour, transactions] of Object.entries(hourSales)) {
        if (transactions > bestHour.transactions) {
          bestHour = { hour: parseInt(hour), transactions };
        }
      }
      
      // Oblicz średnią dzienną sprzedaż
      const daysPassed = Math.max(1, now.getDate()); // Liczba dni, które minęły w tym miesiącu
      const averageDaily = totalSales / daysPassed;
      
      // Pobierz dane z poprzedniego miesiąca dla porównania
      const prevMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const prevMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);
      
      const prevMonthUsages = await db.query.usages.findMany({
        where: (usages, { and, gte, lte }) => {
          return and(
            gte(usages.usedAt, prevMonthStart),
            lte(usages.usedAt, prevMonthEnd)
          );
        },
      });
      
      let prevMonthTotalSales = 0;
      for (const usage of prevMonthUsages) {
        const product = productMap.get(usage.productId);
        if (product) {
          prevMonthTotalSales += product.price * usage.quantity;
        }
      }
      
      // Oblicz zmianę procentową
      const daysInPrevMonth = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
      const prevMonthAverageDaily = prevMonthTotalSales / daysInPrevMonth;
      
      const totalSalesChange = prevMonthTotalSales > 0 
        ? (((totalSales / daysPassed * daysInPrevMonth) / prevMonthTotalSales) - 1) * 100 
        : 0;
      
      const averageDailyChange = prevMonthAverageDaily > 0 
        ? ((averageDaily / prevMonthAverageDaily) - 1) * 100 
        : 0;
      
      return {
        totalSales: parseFloat(totalSales.toFixed(2)),
        totalSalesChange: parseFloat(totalSalesChange.toFixed(1)),
        averageDaily: parseFloat(averageDaily.toFixed(2)),
        averageDailyChange: parseFloat(averageDailyChange.toFixed(1)),
        bestSellingProduct,
        bestHour: {
          time: `${bestHour.hour}:00 - ${bestHour.hour + 1}:00`,
          transactions: bestHour.transactions
        }
      };
    } catch (error) {
      console.error('Błąd podczas pobierania statystyk sprzedaży:', error);
      return {
        totalSales: 0,
        totalSalesChange: 0,
        averageDaily: 0,
        averageDailyChange: 0,
        bestSellingProduct: { id: 0, name: '', quantity: 0 },
        bestHour: { time: '', transactions: 0 }
      };
    }
  }
}

// Mamy implementację bazodanową
export const storage = new DatabaseStorage();
