import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { registerDiagnosticRoutes } from "./diagnostics";
import { setupVite, serveStatic, log } from "./vite";
import path from "path";
import { storage } from "./storage";
import { format, addDays } from "date-fns";

const app = express();
// Zwiększamy limit wielkości przesyłanych danych dla wsparcia większych obrazków produktów
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

// Dodajemy nagłówki CORS aby umożliwić dostęp z przeglądarki
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  next();
});

// Udostępniamy folder z załączonymi plikami
app.use('/attached_assets', express.static(path.join(process.cwd(), 'attached_assets')));

// Udostępniamy folder uploads dla przesłanych obrazów wygaszacza ekranu
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Rejestrujemy endpointy diagnostyczne
  registerDiagnosticRoutes(app);
  
  // Rejestrujemy główne endpointy API
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
    
    // Uruchamiamy harmonogram automatycznego przypisywania posiłków
    setupAutoMealReservationsScheduler();
  });
})();

/**
 * Funkcja harmonogramu, która sprawdza czy jest północ i uruchamia
 * automatyczne przypisywanie posiłków dla następnego dnia.
 */
function setupAutoMealReservationsScheduler() {
  log("[Harmonogram] Uruchamianie harmonogramu automatycznego przypisywania posiłków");
  
  // Sprawdzamy co minutę, czy jest północ
  setInterval(async () => {
    const now = new Date();
    
    // Sprawdzamy, czy jest północ (0:00)
    if (now.getHours() === 0 && now.getMinutes() === 0) {
      // Pobieramy ustawienia, aby sprawdzić, czy funkcja automatycznego przypisywania posiłków jest włączona
      const settings = await storage.getSettings();
      
      if (settings.autoGenerateMealReservations) {
        // Pobieramy wartość wyprzedzenia zamówień z ustawień
        const advanceDays = settings.mealOrderAdvanceDays || 1; // Domyślnie 1 dzień, jeśli nie jest ustawione
        
        // Obliczamy datę, dla której chcemy wygenerować zamówienia - zgodnie z ustawionym okienkiem zamówień
        const targetDay = addDays(now, advanceDays);
        const formattedTargetDay = format(targetDay, 'yyyy-MM-dd');
        
        log(`[Harmonogram] Uruchamianie automatycznego przypisywania posiłków o północy dla daty: ${formattedTargetDay} (wyprzedzenie: ${advanceDays} dni)`);
        
        try {
          // Uruchamiamy funkcję automatycznego przypisywania posiłków
          const result = await storage.autoGenerateMealReservations(formattedTargetDay);
          
          log(`[Harmonogram] Automatyczne przypisywanie posiłków zakończone. Wygenerowano ${result.generatedCount} rezerwacji.`);
          
          if (result.errors.length > 0) {
            log(`[Harmonogram] Wystąpiły błędy podczas generowania rezerwacji: ${JSON.stringify(result.errors)}`);
          }
        } catch (error) {
          log(`[Harmonogram] Błąd podczas automatycznego przypisywania posiłków: ${error instanceof Error ? error.message : "Nieznany błąd"}`);
        }
      } else {
        log("[Harmonogram] Automatyczne przypisywanie posiłków jest wyłączone w ustawieniach.");
      }
    }
  }, 60000); // Sprawdzamy co minutę
};
